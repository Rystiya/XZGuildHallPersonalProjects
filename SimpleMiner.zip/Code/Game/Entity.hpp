#pragma once

#include "Engine\Core\Vertex_PCU.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Math\EulerAngles.hpp"
#include "Engine\Core\Rgba8.hpp"

struct Mat44;
class World;

//-----------------------------------------------------------------------------------------------
class Entity
{
public: // position, color, etc
	// Construction/Destruction
	Entity(World* parentWorld, Vec3 startingPosition = Vec3(0.f, 0.f, 0.f));
	virtual ~Entity() {}

	Rgba8 m_color = Rgba8(255, 255, 255, 255);
	Vec3 m_velocity = Vec3(0.f, 0.f, 0.f);
	Vec3 m_position = Vec3(0.f, 0.f, 0.f);
	EulerAngles m_orientationDegrees;
	EulerAngles m_angularVelocity;
	World* m_world = nullptr;

	virtual void Update(float deltaSeconds) = 0;
	virtual void Render() const = 0;

	bool m_isGarbage = false;

	//Get a matrix that represent my position and direction
	Mat44 GetModelMatrix() const;
};	