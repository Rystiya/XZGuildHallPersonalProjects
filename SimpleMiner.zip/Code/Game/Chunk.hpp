#pragma once
#include "Game\BlockDefinition.hpp"
#include "Engine\Math\IntVec3.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Core\JobSystem.hpp"
#include <mutex>


class Game;
class World;
class Chunk;
struct AABB3;
class VertexBuffer;


class ChunkGenerationJob : public Job {
public:
	ChunkGenerationJob(Chunk* chunkToGenerate, int ID = 0) : Job(ID) { m_chunkToGenerate = chunkToGenerate; }
	virtual void Execute();

	Chunk* m_chunkToGenerate = nullptr;
};


//-----------------------------------------------------------------------------------------------
class Chunk
{

public:
	friend class World;
	friend class ChunkGenerationJob;
	friend class ChunkVertsCreationJob;
	friend struct BlockPosition;
	
	// Construction/Destruction
	~Chunk();
	Chunk(World* theWorld, IntVec2 position = IntVec2(0, 0));
	World* m_world = nullptr;
	bool m_isGarbage = false;
	void Update(float deltaSeconds);
	void Render() const;

	static constexpr uint8_t CHUNK_SIZE_X_POW2 = 4;
	static constexpr uint8_t CHUNK_SIZE_Y_POW2 = 4;
	static constexpr uint8_t CHUNK_SIZE_Z_POW2 = 7;
	static constexpr int CHUNK_SIZE_X = 1 << CHUNK_SIZE_X_POW2;
	static constexpr int CHUNK_SIZE_Y = 1 << CHUNK_SIZE_Y_POW2;
	static constexpr int CHUNK_SIZE_Z = 1 << CHUNK_SIZE_Z_POW2;
	static constexpr int CHUNK_SIZE_HORIZONTAL = CHUNK_SIZE_X * CHUNK_SIZE_Y;
	static constexpr int CHUNK_SIZE_TOTAL = CHUNK_SIZE_X * CHUNK_SIZE_Y * CHUNK_SIZE_Z;

	IntVec3 LocalCordToGlobalCord(IntVec3 localCord) const;
	AABB3 GetBlockWorldBound(IntVec3 localCord) const;

	int ThreeDimCordToOneDim(IntVec3 threeDimCord) const;
	IntVec2 GetCoord() const { return m_chunkInWorldPosition; }
	IntVec3 OneDimCordToThreeDim(int oneDimCord) const;
	static bool IsValidThreeDimIndex(IntVec3 threeDimCord);
	void WorldActionChangeBlockType(IntVec3 threeDimCord, uint8_t blockType);

	int GetSeaLevelHeight() const { return CHUNK_SIZE_Z / 2; }
	int GetBaseSurfaceHeight() const { return GetSeaLevelHeight() - 4; }
	float GetForestnessZeroToOne(int worldX, int worldY) const;
	float GetTreePresenceZeroToOne(int worldX, int worldY) const;
	float GetCavePresenceFactor(int worldX, int worldY, int worldZ) const;
	float GetCavePresenceFactorB(int worldX, int worldY, int worldZ) const;
	float GetHillHeightRatioZeroToOne(int worldX, int worldY) const;
	float GetHillHeight(int worldX, int worldY, float hillHeightRatio) const;
	float GetOceanDepth(int worldX, int worldY) const;
	int GetSurfaceHeight(int worldX, int worldY) const;
	float GetTemperatureRatioMinusOneToOne(int worldX, int worldY) const;
	float GetHumidityRatioMinusOneToOne(int worldX, int worldY) const;
	float GetTemplenessZeroToOne(int worldX, int worldY) const;

protected:
	Block* GetBlockByCord(IntVec3 threeDimCord);
	bool m_needsRegenerateVertexes = true;
	bool m_needsInitializeLighting = true;
	bool m_needsSaving = false;
	Chunk* m_neighbourXPlus = nullptr;
	Chunk* m_neighbourXMinus = nullptr;
	Chunk* m_neighbourYPlus = nullptr;
	Chunk* m_neighbourYMinus = nullptr;

private:
	std::mutex m_chunkDeleteMutex;
	IntVec2 m_chunkInWorldPosition = IntVec2(0, 0);
	void AddVertsForBlock(std::vector<Vertex_PCU> & verts, IntVec3 localCord);
	void LoadOrGenerateBlocks();
	bool LoadBlocks();  //Return whether success or not
	void GenerateBlocks();
	void ApplyTemplateAt(BlockTemplate bTemplate, IntVec3 localPos);
	ChunkGenerationJob * const m_myBlockGenerationJob = new ChunkGenerationJob(this);

	void VisualGenerationCheck();
	void AddVertsForBlocks();
	void InitializeLightning();
	void SaveBlocks();
	std::string GetSaveFileFolder() const;
	std::string GetSaveFilePath() const;
	Block m_blocks[CHUNK_SIZE_TOTAL];
	std::vector<Vertex_PCU> m_vertexes;
	VertexBuffer* m_vertexesForGPU = nullptr;
};