#pragma once

#include "Game\GameCommon.hpp"
#include <vector>


class Entity;
class World;





class Game
{
	friend class App;

public: // position, color, etc
	// Construction/Destruction
	Game();
	~Game();											// destructor (do nothing)

	//Important stuff!!!!!!
	Camera* m_screen_camera = nullptr;

	//System functions----------------------------------------------------------------------------------------------
	void Startup();
	//Spawn stuff and others
	void UpdateStart(float deltaSeconds);
	void Update(float deltaSeconds);
	void UpdateEnd(float deltaSeconds);
	void Render() const;


	//Start up/exit
	void EnterPlayMode();
	void EnterAttractMode();

protected:
	World* m_world = nullptr;


};