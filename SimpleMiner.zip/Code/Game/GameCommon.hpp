#pragma once
#include "Game\App.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Input\InputSystem.hpp"
#include "Engine\Window\Window.hpp"


extern InputSystem* g_theInputSystem;
extern Renderer *g_theRenderer;
extern App* g_theApp;
extern Window* g_theWindow;


enum class BlockNeighbours { NONE = -1, XPlus, XMinus, YPlus, YMinus, ZPlus, ZMinus, COUNT };

constexpr float TARGET_FRAME_RATE = 90;  //No effect yet
//Will only slow down the game when frame rate is less than 1 / MAX_FRAME_TIME_STEP.
//If bullet speed reach 100 or higher, it will move 100 * MAX_FRAME_TIME_STEP distance each frame... 
//If MAX_FRAME_TIME_STEP is big, bullet might bypass targets, especially missiles!!! 
constexpr float MAX_FRAME_TIME_STEP = 0.033f;  
constexpr float SLOW_MODE_TIME_SCALE = 10.f;
constexpr float NIGHT_END_TIME = 6.f;
constexpr float DAY_START_TIME = 11.f;
constexpr float DAY_END_TIME = 14.f;
constexpr float NIGHT_START_TIME = 20.f;


constexpr uint8_t CurrentSaveFileVersion = 3;
constexpr uint8_t WorldExtraInfoConstantBufferID = 4;
constexpr uint8_t ByteMax = 255;
constexpr uint8_t IndoorLightningMask = 1 + 2 + 4 + 8;
constexpr uint8_t OutdoorLightningMask = ByteMax - IndoorLightningMask;
constexpr uint8_t LightValueMax = 2 * 2 * 2 * 2 - 1;
constexpr uint8_t MaxChunkToCreateEachFrame = 2;



extern NamedStrings g_gameConfigBlackboard; // declared in EngineCommon.hpp, defined in EngineCommon.cpp
