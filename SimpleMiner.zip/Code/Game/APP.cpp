
#include "Game\App.hpp"
#include "Game\GameCommon.hpp"
#include "Game\Game.hpp"
#include "Game\World.hpp"
#include "Game\Player.hpp"
#include "Game\Chunk.hpp"
#include "Engine\Core\Clock.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Renderer\SpriteSheet.hpp"
#include "Engine\Renderer\Shader.hpp"
#include "Engine\Renderer\ConstantBuffer.hpp"
#include "Engine\Core\DevConsole.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Core\JobSystem.hpp"


//Required by specification, but putting g_theApp here doesn't make sense... 
Renderer* g_theRenderer = nullptr;
InputSystem* g_theInputSystem = nullptr;
Window* g_theWindow = nullptr;

App::App() {
}

App::~App() {
	delete m_game;
	delete g_theRenderer;
	delete g_theInputSystem;
	delete g_theWindow;
	delete g_theEventSystem;
	delete g_theDevConsole;
	delete m_worldCBO;
	delete g_theJobSystem;
}


////////////////////////////////////////The App will doing this
// One "frame" of the game.  Generally: Input, Update, Render.  We call this 60+ times per second.
void App::Run() {
	// Program main loop; keep running frames until it's time to quit
	while (!m_isQuitting)
	{
		RunFrame();
	}
}


void App::RunFrame() {
	float deltaSeconds = GetUpdateAmount();
	BeginFrame();
	Update(deltaSeconds);
	Render();
	EndFrame();
}


//Primary functions-----------------------------------------------------------------------------------------------

void App::Startup() {

	m_game = new Game();
	InputSystemConfig inputConfig;
	g_theInputSystem = new InputSystem(inputConfig);
	LoadXmlFileIntoStringMap(g_gameConfigBlackboard, "Data/GameConfig.xml");
	m_chunkActivationRange = g_gameConfigBlackboard.GetValue("chunkActivationRange", m_chunkActivationRange);
	m_worldDayNightTimeScale = g_gameConfigBlackboard.GetValue("worldDayNightTimeScale", m_worldDayNightTimeScale);
	m_skyDarkColor = g_gameConfigBlackboard.GetValue("skyDarkColor", m_skyDarkColor);
	m_skyBrightColor = g_gameConfigBlackboard.GetValue("skyBrightColor", m_skyBrightColor);
	m_indoorLightColor = g_gameConfigBlackboard.GetValue("indoorLightColor", m_indoorLightColor);

	WindowConfig windowConfig;
	windowConfig.m_windowTitle = "SimpleMiner";
	windowConfig.m_clientAspect = g_gameConfigBlackboard.GetValue("windowAspect", 1.5f);
	windowConfig.m_inputSystem = g_theInputSystem;
	g_theWindow = new Window(windowConfig);

	RendererConfig renderConfig;
	renderConfig.m_window = g_theWindow;
	g_theRenderer = new Renderer(renderConfig);
	

	g_theEventSystem = new EventSystem(EventSystemConfig());
	m_gamePlayBaseClock = new Clock(Clock::GetSystemClock());
	m_gamePlayBaseClock->SetMaxTimeStep(MAX_FRAME_TIME_STEP);

	DevConsoleConfig consoleConfig = DevConsoleConfig();
	//consoleConfig.m_camera = m_game->m_player->GetCamera();
	consoleConfig.m_camera = m_game->m_screen_camera;
	consoleConfig.m_renderer = g_theRenderer;
	g_theDevConsole = new DevConsole(consoleConfig);

	JobSystemConfig jobSysConfig = JobSystemConfig();
	jobSysConfig.maxNumberOfWorkers = 100;
	g_theJobSystem = new JobSystem(jobSysConfig);

	//g_theRenderer start before g_theDevConsole, because the latter need the m_device for creating fonts
	g_theWindow->Startup();
	g_theRenderer->Startup();
	g_theDevConsole->Startup();
	g_theInputSystem->Startup();
	g_theEventSystem->Startup();
	g_theJobSystem->StartUp();

	DebugRenderSystemStartup(DebugRenderConfig{ g_theRenderer, false });

	SubscribeEventCallbackFunction("exit", App::HandleExitEvent);

	m_allTileTexture = g_theRenderer->CreateOrGetTextureFromFile("Data/Images/BasicSprites_64x64.png");
	m_mapTileSpriteSheet = new SpriteSheet(*m_allTileTexture, IntVec2(64, 64));
	m_worldShader = g_theRenderer->CreateShader("Data/Shaders/World");
 	m_worldCBO = g_theRenderer->CreateConstantBuffer(sizeof(WorldRenderExtraInfo));
	m_game->Startup();

}

void App::BeginFrame()
{
	if (m_pauseNextFrame) {
		m_pauseNextFrame = false;
		m_isPaused = true;
	}
	DebugRenderBeginFrame();
	g_theDevConsole->BeginFrame();
	g_theWindow->BeginFrame();
	g_theJobSystem->BeginFrame();
	CheckKeys();
	g_theRenderer->BeginFrame();
	g_theInputSystem->BeginFrame();
}

void App::Update(float deltaSeconds) {
	if ((g_CurrentGameState == GameState::inMenu || g_theDevConsole->GetIsOpen() || !g_theWindow->GetIsFocused())) {
		g_theInputSystem->SetCursorMode(false, false);
	} else {
		g_theInputSystem->SetCursorMode(true, true);
	}

	Clock::TickSystemClock();
	m_game->Update(deltaSeconds);
	g_theInputSystem->Update();
}

void App::EndFrame() {
	g_theDevConsole->EndFrame();
	g_theRenderer->EndFrame();
	g_theJobSystem->EndFrame();
	g_theInputSystem->EndFrame();
	g_theWindow->EndFrame();
	DebugRenderEndFrame();
}

// Some simple OpenGL example drawing code.
void App::Render() const {
	Rgba8 clearColor = Rgba8(0, 0, 0, 255);
	if (m_game != nullptr && m_game->m_world != nullptr) {
		clearColor = m_game->m_world->GetCurrentSkyColor();
	}
	g_theRenderer->ClearScreen(clearColor);
	m_game->Render();
	g_theDevConsole->Render();
}

//Maybe write a save file or something?
void App::Shutdown() {
	DebugRenderSystemShutdown();

	g_theDevConsole->Shutdown();
	g_theInputSystem->Shutdown();
	g_theWindow->Shutdown();
	g_theJobSystem->EndFrame();
	g_theRenderer->Shutdown();
	g_theEventSystem->Shutdown();

	UnSubscribeEventCallbackFunction("exit", App::HandleExitEvent);
}

float App::GetChunkDeactivationRange() const {
	return m_chunkActivationRange + Chunk::CHUNK_SIZE_X + Chunk::CHUNK_SIZE_Y + 2;
}

void App::BindWorldRenderExtraInfoToCPU(WorldRenderExtraInfo const& worldInfo) {
	g_theRenderer->CopyCPUToGPU(&worldInfo, sizeof(worldInfo), m_worldCBO);
	g_theRenderer->BindConstantBuffer(WorldExtraInfoConstantBufferID, m_worldCBO);
}

float App::GetUpdateAmount() {
	//static variable timePrevious is kept each time this is run.
	float deltaTime = m_gamePlayBaseClock->GetDeltaSeconds();
	m_averageSecondPerFrame = m_averageSecondPerFrame * 0.9f + deltaTime * 0.1f;
	if (m_isPaused) {
		m_gamePlayBaseClock->SetTimeScale(0.f);
	} else if (m_isSlowMode) {
		m_gamePlayBaseClock->SetTimeScale(1/ SLOW_MODE_TIME_SCALE);
	} else {
		m_gamePlayBaseClock->SetTimeScale(1.f);
	}
	return deltaTime;
}


//UI functions-----------------------------------------------------------------------------------------------
bool App::IsKeyDown(unsigned char charInInt) const {
	return g_theInputSystem->IsKeyDown(charInInt);
}
bool App::IsKeyUp(unsigned char charInInt) const {
	return !IsKeyDown(charInInt);
}
bool App::WasKeyJustPressed(unsigned char charInInt) const {
	return g_theInputSystem->WasKeyJustPressed(charInInt);
}
bool App::WasKeyJustUp(unsigned char charInInt) const {
	return g_theInputSystem->WasKeyJustReleased(charInInt);
}


void App::CheckKeys() {
	//Game control (keyboard)-------------------------------------------------------------------------------
	if (IsKeyDown('T')) {
		m_isSlowMode = true;
	}
	if (IsKeyDown('P')) {
		m_isPaused = true;
	}
	//if (WasKeyJustPressed('O')) {
		//m_isPaused = false;
	//}
	//if (WasKeyJustUp('O')) {
		//m_isPaused = true;
	//}
	if (WasKeyJustUp('O')) {
		m_isPaused = false;
		m_pauseNextFrame = true;
	}
	if (WasKeyJustPressed(KEYCODE_F8)) {
		ResetGame();
	}
	if (WasKeyJustPressed(KEYCODE_ESC)) {
		if (g_CurrentGameState == GameState::inMenu) {
			m_isQuitting = true;
		}
		g_CurrentGameState = GameState::inMenu;
	}
	if (IsKeyUp('T')) {
		m_isSlowMode = false;
	}
	if (WasKeyJustUp('P')) {
		m_isPaused = false;
	}
	if (WasKeyJustUp(' ') || WasKeyJustUp('N')) {
		g_CurrentGameState = GameState::inFight;
	}
	//Game control (xbox controller)-------------------------------------------------------------------------------
	XboxController myController = g_theInputSystem->GetController(0);
	if (myController.GetButton(XboxButtonID::ButtonStart).m_isPressed && !myController.GetButton(XboxButtonID::ButtonStart).m_wasPressedLastFrame) {
		g_CurrentGameState = GameState::inFight;
	}
	if (myController.GetButton(XboxButtonID::ButtonBack).m_isPressed && !myController.GetButton(XboxButtonID::ButtonBack).m_wasPressedLastFrame) {
		if (g_CurrentGameState == GameState::inMenu) {
			m_isQuitting = true;
		}
		g_CurrentGameState = GameState::inMenu;
	}
}

//Helper functions-----------------------------------------------------------------------------------------------
void App::ResetGame() {
	delete m_game;
	m_game = new Game();
	m_game->Startup();
	m_game->EnterPlayMode();
	//Many parameters might not be reverted to starting value if reset like below.
	//m_game->TryEraseAllGameObjects();
	//m_game->EnterGame();
}


bool App::HandleExitEvent(EventArgs& eventData) {
	(void)eventData;
	g_theApp->m_isQuitting = true;
	return true;
}