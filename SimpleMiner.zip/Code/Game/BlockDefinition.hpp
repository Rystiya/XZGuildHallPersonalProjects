#pragma once
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\IntVec3.hpp"
#include <string>
#include <vector>



class BlockDefinition;
class Block;
struct BlockTemplateEntry;
struct BlockTemplate;

struct BlockTemplateEntry {
	uint8_t m_type = 0;
	IntVec3 m_localPos = IntVec3();
	BlockTemplateEntry(uint8_t type, IntVec3 localPos);
};

struct BlockTemplate {
	std::string m_templateName = "";
	std::vector<BlockTemplateEntry> m_entries;
	BlockTemplate(std::string name, std::vector<BlockTemplateEntry> entries);
};

class Block {
public:
	uint8_t m_type = 0;

	void SetOutdoorLightIntensity(uint8_t intensity);
	void SetIndoorLightIntensity(uint8_t intensity);
	uint8_t GetOutdoorLightIntensity() const;
	uint8_t GetIndoorLightIntensity() const;
	//Normalized to 0-255 value
	uint8_t GetOutdoorLightIntensityNorm() const;
	uint8_t GetIndoorLightIntensityNorm() const;
	bool GetSolidness() const;
	bool GetOpaqueness() const;
	uint8_t GetLightEmission() const;

	void SetCanSeeSky(bool flag);
	void SetIsAtBottom(bool flag);
	void SetIsInLightDirtyQueue(bool flag);
	bool GetCanSeeSky() const;
	bool GetIsAtBottom() const;
	bool GetIsInLightDirtyQueue() const;

private:
	uint8_t m_lighting = 0;
	uint8_t m_flags = 0;
	void SetFlag(bool canSee, uint8_t pos);
	bool GetFlag(uint8_t pos) const;
};

class SpriteDefinition;

//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class BlockDefinition
{

public:
	// Construction/Destruction
	~BlockDefinition() {}
	BlockDefinition(std::string name, bool isVisible, bool isSolid, bool isOpaque, IntVec2 top, IntVec2 side, IntVec2 bottom, uint8_t lightEmission = 0);
	static void AddBlockDefs();
	static BlockDefinition const& GetBlockDef(int index);
	static bool IsSolid(int index);
	static bool IsOpaque(int index);
	static bool IsValid(int index);
	static uint8_t GetDefIndexOf(std::string name);
	static BlockTemplate const* GetBlockTemplate(std::string name);
	static uint8_t GetLightEmission(int index);

	std::string m_typeName = "default";
	const SpriteDefinition* m_topSprite = nullptr;
	const SpriteDefinition* m_bottomSprite = nullptr;
	const SpriteDefinition* m_sideSprite = nullptr;
	
	bool m_isVisible = true;
	bool m_isSolid = true;
	bool m_isOpaque = true;  //allow light to pass through?
	uint8_t m_lightEmitIntensity = 0;

	//void LoadFromXmlElement(const XmlElement& xmlElement);


};
