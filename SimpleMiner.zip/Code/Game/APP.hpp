#pragma once

#include "Engine\Core\EventSystem.hpp"
#include "Engine\Core\Rgba8.hpp"


class Game;
class Chunk;
class Camera;
class Clock;
class Texture;
class SpriteSheet;
class Shader;
class ConstantBuffer;
enum class GameState { inMenu, inFight, NONE, COUNT };

struct WorldRenderExtraInfo {
	float OutdoorLightColor[4] = { 1.f, 1.f, 1.f, 1.f };
	float IndoorLightColor[4] = { 1.0f, 0.9f, 0.8f, 1.f };
	float SkyColor[4] = { 0.f, 0.f, 0.f, 1.f };
	float PaddingA[2] = { 1.f, 1.f};
	float FogRange[2] = { 100.f, 200.f };
	float CameraPosition[3] = { 0.f, 0.f, 0.f };
	float PaddingB[1] = { 1.f};
};

class App
{
public:

	void Run();
	GameState g_CurrentGameState = GameState::inMenu;
	GameState g_PreviousGameState = GameState::inMenu;

	App();								// default constructor
	~App();
	bool m_isQuitting = false;
	bool m_isPaused = false;
	void Startup();
	void RunFrame();
	void Shutdown();
	bool IsKeyDown(unsigned char charInInt) const;
	bool IsKeyUp(unsigned char charInInt) const;
	bool WasKeyJustPressed(unsigned char charInInt) const;
	bool WasKeyJustUp(unsigned char charInInt) const;

	//System stuff
	float GetFrameRate() const { return 1.f / m_averageSecondPerFrame; }
	float GetChunkActivationRange() const { return m_chunkActivationRange; }
	float GetChunkDeactivationRange() const;
	float GetWorldDayNightTimeScale() const { return m_worldDayNightTimeScale; }
	Rgba8 GetSkyDarkColor() const { return m_skyDarkColor; }
	Rgba8 GetSkyBrightColor() const { return m_skyBrightColor; }
	Rgba8 GetIndoorLightColor() const { return m_indoorLightColor; }
	void BindWorldRenderExtraInfoToCPU(WorldRenderExtraInfo const& worldInfo);

	Texture* m_allTileTexture = nullptr;
	Clock* m_gamePlayBaseClock = nullptr;
	Shader* m_worldShader = nullptr;
	SpriteSheet const* GetSpriteSheet() const { return m_mapTileSpriteSheet; }

private:
	Game* m_game = nullptr;
	ConstantBuffer* m_worldCBO = nullptr;

	float GetUpdateAmount();
	void BeginFrame();
	void Update(float deltaSeconds);
	void Render() const;
	void EndFrame();
	void ResetGame();
	void CheckKeys();
	static bool HandleExitEvent(EventArgs& eventData);
	bool m_isSlowMode = false;
	bool m_pauseNextFrame = false;
	float m_averageSecondPerFrame = 1.f;

	float m_chunkActivationRange = 100.f;
	float m_worldDayNightTimeScale = 1.f;
	Rgba8 m_skyDarkColor = Rgba8(0, 0, 0, 255);
	Rgba8 m_skyBrightColor = Rgba8(255, 255, 255, 255);
	Rgba8 m_indoorLightColor = Rgba8(255, 255, 255, 255);

	//sprite sheet
	SpriteSheet* m_mapTileSpriteSheet = nullptr;

};


