
#include "Game\Game.hpp"
#include "Game\World.hpp"
#include "Game\Player.hpp"
#include "Game\BlockDefinition.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Core\Clock.hpp"
#include "Engine\Core\DevConsole.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"

bool DefaultFilter(Entity*) { return true; }

Game::Game() {
	m_screen_camera = new Camera(Vec2(0.f, 0.f), Vec2(10.f, 10.f));
}

Game::~Game() {
	delete m_world;
	delete m_screen_camera;
}

//Basic and critical stuff used by the system-------------------------------------------------------
void Game::Startup() {
	BlockDefinition::AddBlockDefs();
	EnterAttractMode();
}

void Game::EnterPlayMode() {
	m_world = new World(this);	
}

//
void Game::EnterAttractMode() {
	delete m_world;
	m_world = nullptr;
}

void Game::UpdateStart(float deltaSeconds) {
	(void)deltaSeconds;  //Do nothing, repress warning
	if (g_theApp->g_PreviousGameState != g_theApp->g_CurrentGameState) {
		if (g_theApp->g_CurrentGameState == GameState::inMenu) {
			EnterAttractMode();
		}
		if (g_theApp->g_CurrentGameState == GameState::inFight) {
			EnterPlayMode();
		}
		g_theApp->g_PreviousGameState = g_theApp->g_CurrentGameState;
		return;
	}
	if (g_theApp->g_CurrentGameState == GameState::inMenu) {
		return;
	}
}


void Game::Update(float deltaSeconds) {
	int frameRate = (int)g_theApp->GetFrameRate();
	DebugAddScreenText(Stringf("Frame rate: %d", frameRate), Vec2(0.1f, m_screen_camera->GetOrthoTopRight().y - 0.3f), 0.18f, Vec2(0.f, 0.5f), 0.f, Rgba8(0, 255, 255, 255));
	UpdateStart(deltaSeconds);
	if (g_theApp->g_CurrentGameState == GameState::inMenu) {
		return;
	}
	//Update entities here
	m_world->Update(deltaSeconds);
	UpdateEnd(deltaSeconds);
	
}

void Game::UpdateEnd(float deltaSeconds) {
	(void)deltaSeconds;
	if (g_theApp->g_CurrentGameState == GameState::inMenu) {
		return;
	}
	m_world->TryEraseAllGameObjects(true); //Only erase garbage
}


void Game::Render() const {
	//Draw actual stuff first
	if (g_theApp->g_CurrentGameState != GameState::inMenu) {
		//Render actual stuff here
		g_theRenderer->BeginCamera(*m_world->m_player->m_camera);
		m_world->Render();
		DebugRenderWorld(*m_world->m_player->m_camera);
		g_theRenderer->EndCamera(*m_world->m_player->m_camera);
	}
	//Render UI stuff here
	g_theRenderer->BeginCamera(*m_screen_camera);
	DebugRenderScreen(*m_screen_camera);
	g_theRenderer->EndCamera(*m_screen_camera);
}

