
#include "Game\World.hpp"
#include "Game\Entity.hpp"
#include "Game\GameCommon.hpp"
#include "Game\Player.hpp"
#include "Game\BlockDefinition.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "ThirdParty\Squirrel\SmoothNoise.hpp"
#include "ThirdParty\Squirrel\RawNoise.hpp"
#include <dxgidebug.h>
#include <assert.h>



World::World(Game* parentGame) {
	m_game = parentGame;
	m_player = new Player(this, Vec3(-30.f, 0.f, 100.f), EulerAngles(0.f, 30.f, 0.f));
	m_myEntityVector.emplace_back(m_player);
	Vec3 centerAxiesLocation = Vec3(0.f, 0.f, 0.f);
	Mat44 worldTextTranslationMat = Mat44::CreateTranslation3D(centerAxiesLocation + Vec3(0.2f, 0.2f, 0.2f));
	DebugAddWorldArrow(centerAxiesLocation, centerAxiesLocation + Vec3(15.f, 0.f, 0.f), 0.5f, -1.f, Rgba8(255, 0, 0));
}

World::~World() {
	TryDeleteEntityVector(m_myEntityVector, false);
	TryDeleteChunkMap();
	TryDeleteUnfinishedChunks();
}



void World::Render() const {
	g_theRenderer->UpdateShader(g_theApp->m_worldShader);
	TryRenderEntityVector(m_myEntityVector);
	TryRenderChunkMap();
	g_theRenderer->UseDefaultShader();
}

void World::Update(float deltaSeconds) {
	while (RetreiveAJob()) {
		continue;
	}
	for (int addChunkAttempt = 0; addChunkAttempt < MaxChunkToCreateEachFrame; addChunkAttempt++) {
		if ((g_theJobSystem->GetNumberOfJobsInQueue() >= 2 * g_theJobSystem->GetNumberOfWorkers())) {
			break;
		}
		StartBuildingNearestMissingChunk(m_player->m_position);
	}
	RemoveChunkTooFar(m_player->m_position);
	TryActivateFinishedChunks();
	TryUpdateEntityVector(m_myEntityVector, deltaSeconds);
	TryUpdateChunkMap(deltaSeconds);
	//ProcessAllDirtyLightBlocks();
	if (g_theInputSystem->IsKeyDown('Y')) {
		m_worldDayNightTime += deltaSeconds * 50.f;
	} else {
		m_worldDayNightTime += deltaSeconds;
	}
	//Let the renderer bind stuff to GPU, so the shader can use them
	m_rendererExtraInto.CameraPosition[0] = m_player->m_position.x;
	m_rendererExtraInto.CameraPosition[1] = m_player->m_position.y;
	m_rendererExtraInto.CameraPosition[2] = m_player->m_position.z;
	m_rendererExtraInto.FogRange[1] = g_theApp->GetChunkActivationRange() - 1.5f * (Chunk::CHUNK_SIZE_X + Chunk::CHUNK_SIZE_Y);
	m_rendererExtraInto.FogRange[0] = m_rendererExtraInto.FogRange[1] * 0.5f;
	Rgba8 currentSkyColor = GetCurrentSkyColor();
	m_rendererExtraInto.SkyColor[0] = float(currentSkyColor.r) / 255;
	m_rendererExtraInto.SkyColor[1] = float(currentSkyColor.g) / 255;
	m_rendererExtraInto.SkyColor[2] = float(currentSkyColor.b) / 255;
	m_rendererExtraInto.SkyColor[3] = 1.f;
	float lightningStrength = GetCurrentLightningStrength();
	m_rendererExtraInto.OutdoorLightColor[0] = 0.7f * lightningStrength + float(currentSkyColor.r) / 255;
	m_rendererExtraInto.OutdoorLightColor[1] = 0.8f * lightningStrength + float(currentSkyColor.g) / 255;
	m_rendererExtraInto.OutdoorLightColor[2] = 1.f * lightningStrength + float(currentSkyColor.b) / 255;
	m_rendererExtraInto.OutdoorLightColor[3] = 1.f;
	Rgba8 lightGlowColor = g_theApp->GetIndoorLightColor();
	float glowFlickerStrength = GetCurrentGlowFlickerStrength();
	m_rendererExtraInto.IndoorLightColor[0] = glowFlickerStrength * float(lightGlowColor.r) / 255;
	m_rendererExtraInto.IndoorLightColor[1] = glowFlickerStrength * float(lightGlowColor.g) / 255;
	m_rendererExtraInto.IndoorLightColor[2] = glowFlickerStrength * float(lightGlowColor.b) / 255;
	m_rendererExtraInto.IndoorLightColor[3] = 1.f;

	g_theApp->BindWorldRenderExtraInfoToCPU(m_rendererExtraInto);
}




void World::TryEraseAllGameObjects(bool onlyGarbage) {
	TryDeleteEntityVector(m_myEntityVector, onlyGarbage);
}

BlockPosition World::GetBlockPositionFromWorldBlockIndex(IntVec3 pos) const {

	int localX = pos.x % Chunk::CHUNK_SIZE_X;
	int localY = pos.y % Chunk::CHUNK_SIZE_Y;
	if (localX < 0) {
		localX += Chunk::CHUNK_SIZE_X;
	}
	if (localY < 0) {
		localY += Chunk::CHUNK_SIZE_Y;
	}
	int chunkIndexX = (pos.x - localX) / Chunk::CHUNK_SIZE_X;
	int chunkIndexY = (pos.y - localY) / Chunk::CHUNK_SIZE_Y;
	BlockPosition result;
	result.m_parentChunk = TryGetChunk(IntVec2(chunkIndexX, chunkIndexY));
	result.m_localCoordInChunk = IntVec3(localX, localY, pos.z);
	return result;
}

Block* World::GetBlockFromWorldBlockIndex(IntVec3 pos) const {
	BlockPosition blockCoord = GetBlockPositionFromWorldBlockIndex(pos);
	if (blockCoord.m_parentChunk == nullptr) {
		return nullptr;
	}
	return blockCoord.m_parentChunk->GetBlockByCord(blockCoord.m_localCoordInChunk);
}

Block* World::GetNeighbouringBlockOf(BlockPosition const& selfPos, BlockNeighbours neighbourDirection) {
	return GetNeighbouringPositionOf(selfPos, neighbourDirection).GetBlock();
}

BlockPosition World::GetNeighbouringPositionOf(BlockPosition const& selfPos, BlockNeighbours neighbourDirection) {
	BlockPosition result = selfPos;
	assert(Chunk::IsValidThreeDimIndex(selfPos.m_localCoordInChunk));
	switch (neighbourDirection) {
	case BlockNeighbours::XPlus:
		if (selfPos.m_localCoordInChunk.x >= Chunk::CHUNK_SIZE_X - 1) {
			result.m_localCoordInChunk.x = 0;
			result.m_parentChunk = selfPos.m_parentChunk->m_neighbourXPlus;
		}
		else {
			result.m_localCoordInChunk.x += 1;
		}
		return result;
	case BlockNeighbours::XMinus:
		if (selfPos.m_localCoordInChunk.x <= 0) {
			result.m_localCoordInChunk.x = Chunk::CHUNK_SIZE_X - 1;
			result.m_parentChunk = selfPos.m_parentChunk->m_neighbourXMinus;
		}
		else {
			result.m_localCoordInChunk.x -= 1;
		}
		return result;
	case BlockNeighbours::YPlus:
		if (selfPos.m_localCoordInChunk.y >= Chunk::CHUNK_SIZE_Y - 1) {
			result.m_localCoordInChunk.y = 0;
			result.m_parentChunk = selfPos.m_parentChunk->m_neighbourYPlus;
		}
		else {
			result.m_localCoordInChunk.y += 1;
		}
		return result;
	case BlockNeighbours::YMinus:
		if (selfPos.m_localCoordInChunk.y <= 0) {
			result.m_localCoordInChunk.y = Chunk::CHUNK_SIZE_Y - 1;
			result.m_parentChunk = selfPos.m_parentChunk->m_neighbourYMinus;
		}
		else {
			result.m_localCoordInChunk.y -= 1;
		}
		return result;
	case BlockNeighbours::ZPlus:
		result.m_localCoordInChunk.z += 1;
		return result;
	case BlockNeighbours::ZMinus:
		result.m_localCoordInChunk.z -= 1;
		return result;
	default:
		assert(false);
		return BlockPosition();
	}
}


bool  World::DigAt(IntVec3 pos, float force) {
	(void)force;
	BlockPosition currentBlockPosition = GetBlockPositionFromWorldBlockIndex(pos);
	if (currentBlockPosition.m_parentChunk != nullptr && currentBlockPosition.m_parentChunk->GetBlockByCord(currentBlockPosition.m_localCoordInChunk)->GetSolidness()) {
		currentBlockPosition.m_parentChunk->WorldActionChangeBlockType(currentBlockPosition.m_localCoordInChunk, 0);
		return true;
	}
	return false;
}
bool World::BuildAt(IntVec3 pos, uint8_t blockType) {
	BlockPosition currentBlockPosition = GetBlockPositionFromWorldBlockIndex(pos);
	if (currentBlockPosition.m_parentChunk != nullptr && Chunk::IsValidThreeDimIndex(currentBlockPosition.m_localCoordInChunk) && !currentBlockPosition.m_parentChunk->GetBlockByCord(currentBlockPosition.m_localCoordInChunk)->GetSolidness()) {
		currentBlockPosition.m_parentChunk->WorldActionChangeBlockType(currentBlockPosition.m_localCoordInChunk, blockType);
		return true;
	}
	return false;
}




void World::StartBuildingNearestMissingChunk(Vec2 center) {
	float radius = g_theApp->GetChunkActivationRange();
	//A virtual chunk's original point, its center is the input Vec2.
	Vec2 virtualChunkCenter = center - 0.5f * Vec2(Chunk::CHUNK_SIZE_X, Chunk::CHUNK_SIZE_Y);
	//The nearest chunk's original point
	IntVec2 nearestChunk = IntVec2(lround(virtualChunkCenter.x / Chunk::CHUNK_SIZE_X), lround(virtualChunkCenter.y / Chunk::CHUNK_SIZE_Y));
	int searchIndexRangeX = 1 + int(radius / Chunk::CHUNK_SIZE_X);
	int searchIndexRangeY = 1 + int(radius / Chunk::CHUNK_SIZE_Y);
	float bestDistanceSquardRecord = radius * radius * 2.f;
	IntVec2 bestChunkRecord;
	for (int chunkOffsetX = searchIndexRangeX * -1; chunkOffsetX < searchIndexRangeX; chunkOffsetX++) {
		for (int chunkOffsetY = searchIndexRangeY * -1; chunkOffsetY < searchIndexRangeY; chunkOffsetY++) {
			IntVec2 currentChunk = nearestChunk + IntVec2(chunkOffsetX, chunkOffsetY);
			Vec2 currentChunkCenter = Vec2(float(currentChunk.x * Chunk::CHUNK_SIZE_X), float(currentChunk.y * Chunk::CHUNK_SIZE_Y));
			float chunkDistanceSquared = GetDistanceSquardToChunk(center, currentChunk);
			if (chunkDistanceSquared >= radius * radius || chunkDistanceSquared >= bestDistanceSquardRecord) {
				continue;
			}
			if (m_chunksActive.count(currentChunk) <= 0 && m_chunksGenerating.count(currentChunk) <= 0) {
				bestDistanceSquardRecord = chunkDistanceSquared;
				bestChunkRecord = currentChunk;
			}
		}
	}
	if (bestDistanceSquardRecord < radius * radius) {
		StartBuildingChunk(bestChunkRecord);
	}
}

void World::RemoveChunkTooFar(Vec2 center) {
	float radius = g_theApp->GetChunkDeactivationRange();
	//A virtual chunk's original point, its center is the input Vec2.
	Vec2 virtualChunkCenter = center - 0.5f * Vec2(Chunk::CHUNK_SIZE_X, Chunk::CHUNK_SIZE_Y);
	for (auto currentElement = m_chunksActive.begin(); currentElement != m_chunksActive.end(); currentElement++) {
		IntVec2 currentChunkCord = currentElement->second->m_chunkInWorldPosition;
		float chunkDistanceSquared = GetDistanceSquardToChunk(center, currentChunkCord);
		if (chunkDistanceSquared > radius * radius) {
			TryRemoveChunk(currentChunkCord);
		}
	}
}

float World::GetDistanceSquardToChunk(Vec2 center, IntVec2 chunk) const {
	Vec2 chunkCenter = Vec2((chunk.x-0.5f) * Chunk::CHUNK_SIZE_X, (chunk.y-0.5f) * Chunk::CHUNK_SIZE_Y);
	return (chunkCenter - center).GetLengthSquared();
}

void World::TryRenderEntityVector(const std::vector<Entity*>& things) const {
	for (int index = 0; index < things.size(); index++) {
		if (things[index] != nullptr) {
			things[index]->Render();
		}
	}
}
void World::TryActivateFinishedChunks() {
	bool continueChecking = true;
	while (continueChecking) {
		continueChecking = false;
		for (auto currentElement = m_chunksGenerating.begin(); currentElement != m_chunksGenerating.end(); currentElement++) {
			if (currentElement->second->m_myBlockGenerationJob->m_state == JobState::RETRIEVED) {
				m_chunksActive.insert({ currentElement->first, currentElement->second });
				m_chunksGenerating.erase(currentElement->first);
				continueChecking = true;
				break;
				//the iterator is broken when one element is removed.
			}
		}
	}
}
void World::TryUpdateEntityVector(std::vector<Entity*>& things, float deltaSeconds) {
	for (int index = 0; index < things.size(); index++) {
		if (things[index] != nullptr && !things[index]->m_isGarbage) {
			things[index]->Update(deltaSeconds);
		}
	}
}
void World::TryDeleteEntityVector(std::vector<Entity*>& things, bool garbageOnly) {
	for (int index = 0; index < things.size(); index++) {
		if (things[index] == nullptr) {
			continue;
		}
		if (!garbageOnly || things[index]->m_isGarbage) {
			delete things[index];
			things[index] = nullptr;
		}
	}
}


//Functions to deal with lightning updates
void World::ProcessAllDirtyLightBlocks() {
	//return; //Disable lighting?
	while (m_lightUpdateQueue.size() > 0) {
		ProcessNextDirtyLightBlock();
	}
}
void World::ProcessNextDirtyLightBlock() {
	//Remove item from light update queue
	BlockPosition currentBlockPos = m_lightUpdateQueue.front();  //Get last element
	m_lightUpdateQueue.pop_front();
	Block* currentBlock = currentBlockPos.GetBlock();
	currentBlock->SetIsInLightDirtyQueue(false);
	//Calculate theoratical light value based on neighbours
	uint8_t calculatedIndoorLight = currentBlock->GetLightEmission();
	uint8_t calculatedOutdoorLight = 0;
	if (currentBlock->GetCanSeeSky()) {
		calculatedOutdoorLight = LightValueMax;
	}
	BlockPosition neighbours[6];
	neighbours[0] = GetNeighbouringPositionOf(currentBlockPos, BlockNeighbours::XPlus);
	neighbours[1] = GetNeighbouringPositionOf(currentBlockPos, BlockNeighbours::XMinus);
	neighbours[2] = GetNeighbouringPositionOf(currentBlockPos, BlockNeighbours::YPlus);
	neighbours[3] = GetNeighbouringPositionOf(currentBlockPos, BlockNeighbours::YMinus);
	neighbours[4] = GetNeighbouringPositionOf(currentBlockPos, BlockNeighbours::ZPlus);
	neighbours[5] = GetNeighbouringPositionOf(currentBlockPos, BlockNeighbours::ZMinus);
	//If I'm not opaque, also check neightbours: they might change my lighting as well.
	if (!currentBlock->GetOpaqueness()) {
		for (BlockPosition currentNeighbourPos : neighbours) {
			Block* neighbour = currentNeighbourPos.GetBlock();
			if (neighbour == nullptr) {
				continue;
			}
			//Note it might take multiple iterations to get lightings right, because the neighbours' lightning might also be wrong.
			calculatedIndoorLight = max(calculatedIndoorLight, neighbour->GetIndoorLightIntensity() - 1);
			calculatedOutdoorLight = max(calculatedOutdoorLight, neighbour->GetOutdoorLightIntensity() - 1);
		}
	}
	//If any light value is changed, also add neighbours to light update queue
	if (calculatedIndoorLight != currentBlock->GetIndoorLightIntensity() || calculatedOutdoorLight != currentBlock->GetOutdoorLightIntensity()) {
		currentBlockPos.m_parentChunk->m_needsRegenerateVertexes = true;
		for (BlockPosition currentNeighbourPos : neighbours) {
			//Neighbouring chunks might also be affected by my light. Regenerate their light as well.
			//Took me hours to fix this XD
			if (currentNeighbourPos.m_parentChunk != nullptr) {
				currentNeighbourPos.m_parentChunk->m_needsRegenerateVertexes = true;
			}
		}
		//Need to change vertexes in order to set lighting
		currentBlock->SetIndoorLightIntensity(calculatedIndoorLight);
		currentBlock->SetOutdoorLightIntensity(calculatedOutdoorLight);
		for (BlockPosition currentNeighbourPos : neighbours) {
			Block* neighbour = currentNeighbourPos.GetBlock();
			if (neighbour == nullptr) {
				continue;
			}
			MarkLightingDirty(currentNeighbourPos);
		}
	}
}

void World::MarkLightingDirty(BlockPosition& targetBlockPosition) {
	Block* currentBlock = targetBlockPosition.GetBlock();
	assert(currentBlock != nullptr);
	if (currentBlock->GetIsInLightDirtyQueue()) {
		//If this is true, then the block is already in queue
		return;
	}
	currentBlock->SetIsInLightDirtyQueue(true);
	m_lightUpdateQueue.emplace_back(targetBlockPosition);
}
void World::RemoveAllBlocksFromChunk(Chunk* theChunk) {
	for (auto currentItem = m_lightUpdateQueue.begin(); currentItem < m_lightUpdateQueue.end(); currentItem++) {
		//Element must be removed when its chunck is deleted, because their m_parentChunk will point to a deleted chunk!
		if (currentItem->m_parentChunk == theChunk) {
			m_lightUpdateQueue.erase(currentItem);
		}
	}
}

Rgba8 World::GetCurrentSkyColor() const {
	float lightFactor = GetCurrentSkyColorStrength();
	Rgba8 resultColor = g_theApp->GetSkyDarkColor() * (1.f - lightFactor) + g_theApp->GetSkyBrightColor() * lightFactor;
	return resultColor;
}

float World::GetCurrentSkyColorStrength() const {
	float oClock = fmodf(m_worldDayNightTime * g_theApp->GetWorldDayNightTimeScale(), 24.f);
	float lightFactor = 0.f;
	if (oClock > NIGHT_END_TIME && oClock < DAY_START_TIME) {
		lightFactor = GetFractionWithinRange(oClock, NIGHT_END_TIME, DAY_START_TIME);
	}
	if (oClock > DAY_START_TIME && oClock < DAY_END_TIME) {
		lightFactor = 1.f;
	}
	if (oClock > DAY_END_TIME && oClock < NIGHT_START_TIME) {
		lightFactor = 1.f - GetFractionWithinRange(oClock, DAY_END_TIME, NIGHT_START_TIME);
	}
	return lightFactor;
}
float World::GetCurrentLightningStrength() const {
	float randomFloatMinusOneToOne = Compute1dPerlinNoise(m_worldDayNightTime, 10.f, 1, 0.5f, 2.0f, 0);
	if (randomFloatMinusOneToOne < 0.f) {
		randomFloatMinusOneToOne *= -1.f;
	}
	float randomFloatMinusOneToOneUnstable = PowerInt(randomFloatMinusOneToOne, 5);
	randomFloatMinusOneToOneUnstable = PowerInt(randomFloatMinusOneToOneUnstable, 4);
	randomFloatMinusOneToOneUnstable = PowerInt(randomFloatMinusOneToOneUnstable, 4);
	randomFloatMinusOneToOneUnstable = PowerInt(randomFloatMinusOneToOneUnstable, 4);
	float dayNightModifier = fmaxf(0.f, (1.f - GetCurrentSkyColorStrength() * 2.f));
	return randomFloatMinusOneToOneUnstable * dayNightModifier;
}

float World::GetCurrentGlowFlickerStrength() const {
	float randomFloatMinusOneToOne = Compute1dPerlinNoise(m_worldDayNightTime, 1.f, 1, 0.5f, 2.0f, 0);
	return RangeMap(randomFloatMinusOneToOne, -1.f, 1.f, 0.8f, 1.f);
}


void World::TryRenderChunkMap() const {
	for (auto currentElement = m_chunksActive.begin(); currentElement != m_chunksActive.end(); currentElement++) {
		currentElement->second->Render();
	}
}
void World::TryUpdateChunkMap(float deltaSeconds) {
	for (auto currentElement = m_chunksActive.begin(); currentElement != m_chunksActive.end(); currentElement++) {
		currentElement->second->Update(deltaSeconds);
	}
}
void World::TryDeleteChunkMap() {
	for (auto currentElement = m_chunksActive.begin(); currentElement != m_chunksActive.end(); currentElement++) {
		delete currentElement->second;
		currentElement->second = nullptr;
	}
}
void World::TryDeleteUnfinishedChunks() {
	for (auto currentElement = m_chunksGenerating.begin(); currentElement != m_chunksGenerating.end(); currentElement++) {
		delete currentElement->second;
		currentElement->second = nullptr;
	}
}
void World::StartBuildingChunk(IntVec2 pos) {
	m_chunksGenerating.insert({ pos, new Chunk(this, pos) });
}
void  World::TryRemoveChunk(IntVec2 pos) {
	if (m_chunksActive.count(pos) > 0) {
		delete m_chunksActive.find(pos)->second;
		m_chunksActive.erase(pos);
	}
}
Chunk* World::TryGetChunk(IntVec2 pos) const {
	if (m_chunksActive.count(pos) <= 0) {
		return nullptr;
	}
	return m_chunksActive.find(pos)->second;
}


RaycastResult3D World::RaycastWorld(const Vec3& start, const Vec3& forwardNorm, float maxLength) const {
	float distanceExamined = 0.f;
	struct RaycastResult3D myResult;
	//Return if shooting downwards or upwards
	if (forwardNorm.GetLength() <= 0.f) {
		return myResult;
	}
	while (distanceExamined <= maxLength) {
		Vec3 currentPosition = start + distanceExamined * forwardNorm;
		IntVec3 currentCell = IntVec3((int)floorf(currentPosition.x), (int)floorf(currentPosition.y), (int)floorf(currentPosition.z));
		IntVec3 nextCell = currentCell;
		float minDistanceBeforeNextTile = maxLength * 2.f;
		//When is next x change
		float distanceTilNextXChange = Chunk::CHUNK_SIZE_X * 10.f;
		if (forwardNorm.x > 0.f) {
			distanceTilNextXChange = (ceilf(currentPosition.x) - currentPosition.x) / forwardNorm.x;
			if (distanceTilNextXChange < minDistanceBeforeNextTile) {
				nextCell = currentCell + IntVec3(1, 0, 0);
				minDistanceBeforeNextTile = distanceTilNextXChange;
			}
		}
		if (forwardNorm.x < 0.f) {
			distanceTilNextXChange = (currentPosition.x - floorf(currentPosition.x)) / (forwardNorm.x * -1.f);
			if (distanceTilNextXChange < minDistanceBeforeNextTile) {
				nextCell = currentCell + IntVec3(-1, 0, 0);
				minDistanceBeforeNextTile = distanceTilNextXChange;
			}
		}
		//When is next y change
		float distanceTilNextYChange = Chunk::CHUNK_SIZE_Y * 10.f;
		if (forwardNorm.y > 0.f) {
			distanceTilNextYChange = (ceilf(currentPosition.y) - currentPosition.y) / forwardNorm.y;
			if (distanceTilNextYChange < minDistanceBeforeNextTile) {
				nextCell = currentCell + IntVec3(0, 1, 0);
				minDistanceBeforeNextTile = distanceTilNextYChange;
			}
		}
		if (forwardNorm.y < 0.f) {
			distanceTilNextYChange = (currentPosition.y - floorf(currentPosition.y)) / (forwardNorm.y * -1.f);
			if (distanceTilNextYChange < minDistanceBeforeNextTile) {
				nextCell = currentCell + IntVec3(0, -1, 0);
				minDistanceBeforeNextTile = distanceTilNextYChange;
			}
		}
		//When is next z change
		float distanceTilNextZChange = Chunk::CHUNK_SIZE_Z * 10.f;
		if (forwardNorm.z > 0.f) {
			distanceTilNextZChange = (ceilf(currentPosition.z) - currentPosition.z) / forwardNorm.z;
			if (distanceTilNextZChange < minDistanceBeforeNextTile) {
				nextCell = currentCell + IntVec3(0, 0, 1);
				minDistanceBeforeNextTile = distanceTilNextZChange;
			}
		}
		if (forwardNorm.z < 0.f) {
			distanceTilNextZChange = (currentPosition.z - floorf(currentPosition.z)) / (forwardNorm.z * -1.f);
			if (distanceTilNextZChange < minDistanceBeforeNextTile) {
				nextCell = currentCell + IntVec3(0, 0, -1);
				minDistanceBeforeNextTile = distanceTilNextZChange;
			}
		}
		//Need to add an extra value to make sure we cross the boundary. 0.001 should be big enough.
		distanceExamined += minDistanceBeforeNextTile + 0.001f;
		if (distanceExamined > maxLength) {
			break;
		}
		Block* nextBlock = GetBlockFromWorldBlockIndex(nextCell);
		if (nextBlock != nullptr && nextBlock->GetSolidness()) {
			myResult.m_didImpact = true;
			myResult.m_impactNormal = Vec3(float(currentCell.x - nextCell.x), float(currentCell.y - nextCell.y), float(currentCell.z - nextCell.z));
			myResult.m_impactDist = distanceExamined;
			myResult.m_impactPos = start + distanceExamined * forwardNorm;
			break;
		}

	}
	return myResult;
}


bool World::RetreiveAJob() {
	ChunkGenerationJob* jobRetreived = static_cast<ChunkGenerationJob*>(g_theJobSystem->MainRetreiveOneJob());
	bool success = (jobRetreived != nullptr);
	return success;
}