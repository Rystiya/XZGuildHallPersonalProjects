
#include "Game\Entity.hpp"
#include "Game\World.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include "Engine\Math\Mat44.hpp"

#include <math.h> 
#include <vector>



Entity::Entity(World* parentWorld, Vec3 startingPosition) {
	m_world = parentWorld;
	m_position = startingPosition;
}


Mat44 Entity::GetModelMatrix() const {
	Mat44 transformMatrix = m_orientationDegrees.GetAsMatrix_XFwd_YLeft_ZUp();
	transformMatrix.SetTranslation3D(m_position);
	return transformMatrix;
}