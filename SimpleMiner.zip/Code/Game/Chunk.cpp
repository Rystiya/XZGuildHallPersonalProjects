
#include "Game\Chunk.hpp"
#include "Game\Game.hpp"
#include "Game\World.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include "Engine\Core\FileUtils.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Math\AABB3.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Renderer\VertexBuffer.hpp"
#include "ThirdParty\Squirrel\SmoothNoise.hpp"
#include "ThirdParty\Squirrel\RawNoise.hpp"
#include <assert.h>
#include <filesystem>

void ChunkGenerationJob::Execute() {
	m_chunkToGenerate->m_chunkDeleteMutex.lock();
	m_chunkToGenerate->LoadOrGenerateBlocks();
	m_chunkToGenerate->m_chunkDeleteMutex.unlock();
};


Chunk::Chunk(World* theWorld, IntVec2 position) {
	//Initionalization
	m_world = theWorld;
	m_chunkInWorldPosition = position;
	//About one vert per chunk?
	m_vertexesForGPU = g_theRenderer->CreateVertexBuffer(CHUNK_SIZE_TOTAL * 1);
	//Setting blocks to proper types
	g_theJobSystem->PostNewJob(m_myBlockGenerationJob);
	//LoadOrGenerateBlocks();
}

Chunk::~Chunk() {
	m_chunkDeleteMutex.lock();
	assert(m_myBlockGenerationJob->m_state != JobState::CLAIMED);  //Don't delete when one of the tread this generating!
	if (m_myBlockGenerationJob->m_state == JobState::RETRIEVED) {
		delete m_myBlockGenerationJob;
	}
	m_world->RemoveAllBlocksFromChunk(this);
	if (m_needsSaving) {
		SaveBlocks();
	}
	if (m_vertexesForGPU != nullptr) {
		delete m_vertexesForGPU;
	}
	m_chunkDeleteMutex.unlock();
}

void Chunk::Update(float deltaSeconds) {
	(void)deltaSeconds;
	m_neighbourXPlus = m_world->TryGetChunk(m_chunkInWorldPosition + IntVec2(1, 0));
	m_neighbourXMinus = m_world->TryGetChunk(m_chunkInWorldPosition + IntVec2(-1, 0));
	m_neighbourYPlus = m_world->TryGetChunk(m_chunkInWorldPosition + IntVec2(0, 1));
	m_neighbourYMinus = m_world->TryGetChunk(m_chunkInWorldPosition + IntVec2(0, -1));
	//Fill in the vertexes only when created or changed!
	VisualGenerationCheck();
}

void Chunk::Render() const {
	g_theRenderer->BindTexture(g_theApp->m_allTileTexture);
	g_theRenderer->SetModelConstants();
	g_theRenderer->DrawVertexBuffer(m_vertexesForGPU, (int)m_vertexes.size(), 0);
	//g_theRenderer->DrawVertexVector(m_vertexes);
	g_theRenderer->BindTexture(nullptr);
}


void Chunk::VisualGenerationCheck() {
	if (m_neighbourXPlus == nullptr || m_neighbourXMinus == nullptr || m_neighbourYPlus == nullptr || m_neighbourYMinus == nullptr) {
		return;
	}
	//Set Light dirtiness
	if (m_needsInitializeLighting) {
		InitializeLightning();
		m_needsRegenerateVertexes = true;
	}
	if (m_needsRegenerateVertexes) {
		//Do this after light rebuild, because it uses lighting
		AddVertsForBlocks();
	}
}


void Chunk::AddVertsForBlocks() {
	int sizeToReserve = std::min(int(m_vertexes.size()), 6 * 1 * CHUNK_SIZE_TOTAL);
	m_vertexes.clear();
	m_vertexes.reserve(sizeToReserve);
	for (int indexX = 0; indexX < CHUNK_SIZE_X; indexX++) {
		for (int indexY = 0; indexY < CHUNK_SIZE_Y; indexY++) {
			for (int indexZ = 0; indexZ < CHUNK_SIZE_Z; indexZ++) {
				AddVertsForBlock(m_vertexes, IntVec3(indexX, indexY, indexZ));
			}
		}
	}
	g_theRenderer->CopyCPUToGPU(m_vertexes.data(), (int)m_vertexes.size() * sizeof(Vertex_PCU), m_vertexesForGPU);
	m_vertexesForGPU->SetStride(sizeof(Vertex_PCU));
	m_needsRegenerateVertexes = false;
}

int Chunk::ThreeDimCordToOneDim(IntVec3 threeDimCord) const {
	assert(IsValidThreeDimIndex(threeDimCord));
	return threeDimCord.x + CHUNK_SIZE_X * threeDimCord.y + CHUNK_SIZE_HORIZONTAL * threeDimCord.z;
}

IntVec3 Chunk::OneDimCordToThreeDim(int oneDimCord)  const {
	int posHorizontal = oneDimCord % CHUNK_SIZE_HORIZONTAL;
	int posZ = (oneDimCord - posHorizontal) / CHUNK_SIZE_HORIZONTAL;
	int posX = posHorizontal % CHUNK_SIZE_X;
	int posY = (posHorizontal - posX) / CHUNK_SIZE_X;
	return IntVec3(posX, posY, posZ);
}


IntVec3 Chunk::LocalCordToGlobalCord(IntVec3 localCord) const {
	assert(IsValidThreeDimIndex(localCord));
	int posX = localCord.x + m_chunkInWorldPosition.x * CHUNK_SIZE_X;
	int posY = localCord.y + m_chunkInWorldPosition.y * CHUNK_SIZE_Y;
	return IntVec3(posX, posY, localCord.z);
}


bool Chunk::IsValidThreeDimIndex(IntVec3 threeDimCord) {
	if (threeDimCord.x < 0 || threeDimCord.x >= CHUNK_SIZE_X) {
		return false;
	}
	if (threeDimCord.y < 0 || threeDimCord.y >= CHUNK_SIZE_Y) {
		return false;
	}
	if (threeDimCord.z < 0 || threeDimCord.z >= CHUNK_SIZE_Z) {
		return false;
	}
	return true;
}

void Chunk::WorldActionChangeBlockType(IntVec3 threeDimCord, uint8_t blockType) {
	assert(IsValidThreeDimIndex(threeDimCord));
	assert(BlockDefinition::IsValid(blockType));
	Block* changedBlock = GetBlockByCord(threeDimCord);
	if (changedBlock->m_type == blockType) {
		return;
	}
	changedBlock->m_type = blockType;
	BlockPosition myPos = { this, threeDimCord };
	m_world->MarkLightingDirty(myPos);
	//Fix sky flag for the current vertical column 
	bool canSeeSky = true;
	for (int indexZ = CHUNK_SIZE_Z - 1; indexZ >= 0; indexZ--) {
		IntVec3 currentCoord = IntVec3(threeDimCord.x, threeDimCord.y, indexZ);
		Block* currentBlock = GetBlockByCord(currentCoord);
		if (currentBlock->GetOpaqueness()) {
			canSeeSky = false;
		}
		if (canSeeSky != currentBlock->GetCanSeeSky()) {
			currentBlock->SetCanSeeSky(canSeeSky);
			BlockPosition currentPos = { this, currentCoord };
			m_world->MarkLightingDirty(currentPos);
		}
	}
	//Necessary for regenerate lighting
	m_world->ProcessAllDirtyLightBlocks();
	//Need to neighbour as well, so that hidden surface removal won't be broken
	m_needsRegenerateVertexes = true;
	if (threeDimCord.x == 0 && m_neighbourXMinus) {
		m_neighbourXMinus->m_needsRegenerateVertexes = true;
	}
	if (threeDimCord.x == CHUNK_SIZE_X - 1 && m_neighbourXPlus) {
		m_neighbourXPlus->m_needsRegenerateVertexes = true;
	}
	if (threeDimCord.y == 0 && m_neighbourYMinus) {
		m_neighbourYMinus->m_needsRegenerateVertexes = true;
	}
	if (threeDimCord.y == CHUNK_SIZE_Y - 1 && m_neighbourYPlus) {
		m_neighbourYPlus->m_needsRegenerateVertexes = true;
	}
	m_needsSaving = true; 
}


Block* Chunk::GetBlockByCord(IntVec3 threeDimCord) {
	if (!IsValidThreeDimIndex(threeDimCord)) {
		return nullptr;
	}
	return &m_blocks[ThreeDimCordToOneDim(threeDimCord)];
}


AABB3 Chunk::GetBlockWorldBound(IntVec3 localCord) const {
	assert(IsValidThreeDimIndex(localCord));
	IntVec3 worldCord = LocalCordToGlobalCord(localCord);
	Vec3 worldBoundMin = Vec3(worldCord);
	Vec3 worldBoundMax = worldBoundMin + Vec3(1.f, 1.f, 1.f);
	return AABB3(worldBoundMin, worldBoundMax);
}

void Chunk::LoadOrGenerateBlocks() {
	if (!LoadBlocks()) {
		GenerateBlocks();
	}
}

bool Chunk::LoadBlocks() {
	std::vector<uint8_t> fileContents;
	uint64_t length = FileReadToBuffer(fileContents, GetSaveFilePath(), false);
	if (fileContents.size() <= 12 || length <= 12) {
		return false;
	}
	if (fileContents[0] != 'G' || fileContents[1] != 'C' || fileContents[2] != 'H' || fileContents[3] != 'K') {
		return false;
	}
	if (fileContents[4] != CurrentSaveFileVersion || fileContents[5] != CHUNK_SIZE_X_POW2 || fileContents[6] != CHUNK_SIZE_Y_POW2 || fileContents[7] != CHUNK_SIZE_Z_POW2) {
		return false;
	}
	unsigned int worldSeed = m_world->GetSeed();
	uint8_t* worldSeedAsUint8 = reinterpret_cast<uint8_t*>(&worldSeed);
	if (fileContents[8] != worldSeedAsUint8[0] || fileContents[9] != worldSeedAsUint8[1] || fileContents[10] != worldSeedAsUint8[2] || fileContents[11] != worldSeedAsUint8[3]) {
		return false;
	}
	//Being loading
	int blocksLoaded = 0;
	for (int index = 12; index <= fileContents.size() - 2; index+=2) {
		assert(BlockDefinition::IsValid(fileContents[index]));
		int sequenceSize = fileContents[index + 1];
		if (sequenceSize < -1) {
			sequenceSize *= -1;
		}
		if (sequenceSize == -1) {
			sequenceSize = 255;
		}
		for (int indexInSerial = 0; indexInSerial < sequenceSize; indexInSerial++) {
			m_blocks[blocksLoaded].m_type = fileContents[index];
			blocksLoaded++;
		}
	}
	if (blocksLoaded == CHUNK_SIZE_TOTAL) {
		return true;
	}
	return false;
}

std::string Chunk::GetSaveFileFolder() const {
	return Stringf("Saves/World_%u", m_world->GetSeed());

}
std::string Chunk::GetSaveFilePath() const {
	return Stringf("Saves/World_%u/Chunk(%i,%i).chunk",m_world->GetSeed(), m_chunkInWorldPosition.x, m_chunkInWorldPosition.y);
}


void Chunk::GenerateBlocks() {
	for (int indexX = 0; indexX < CHUNK_SIZE_X; indexX++) {
		for (int indexY = 0; indexY < CHUNK_SIZE_Y; indexY++) {
			int worldX = indexX + m_chunkInWorldPosition.x * CHUNK_SIZE_X;
			int worldY = indexY + m_chunkInWorldPosition.y * CHUNK_SIZE_Y;
			//Generating parameters-------------------------------------------------------------------------------------------
			int surfaceHeight = GetSurfaceHeight(worldX, worldY);
			//temperature lies in range [-6, 6] 
			float tempratureModifier = 6.f * GetTemperatureRatioMinusOneToOne(worldX, worldY);
			//humidityModifier lies in range [-7, 7] 
			float humidityModifier = 7.f * GetHumidityRatioMinusOneToOne(worldX, worldY);
			//Applying parameters-------------------------------------------------------------------------------------------
			for (int indexZ = 0; indexZ < CHUNK_SIZE_Z; indexZ++) {
				int blockIndex = ThreeDimCordToOneDim(IntVec3(indexX, indexY, indexZ));
				//If we are above the rocky surface
				if (indexZ > surfaceHeight || indexZ >= CHUNK_SIZE_Z - 1) {
					if (indexZ > GetSeaLevelHeight()) {
						//if we are above sea level, set to air
						m_blocks[blockIndex].m_type = 0;
					}
					else {
						//if we are below sea level
						int depth = GetSeaLevelHeight() - indexZ;
						float coldNess = -1.f * tempratureModifier;
						if (depth < coldNess) {
							//set to ice
							m_blocks[blockIndex].m_type = 11;
						}
						else {
							//set to water
							m_blocks[blockIndex].m_type = 8;
						}
					}
				}
				else if (indexZ != 0 && GetCavePresenceFactor(worldX, worldY, indexZ) > 0.97f && GetCavePresenceFactorB(worldX, worldY, indexZ) > 0.55f) {
					//If this is a cave
					m_blocks[blockIndex].m_type = 0;
				}
				else if (indexZ > surfaceHeight - 3) {
					int depth = surfaceHeight - indexZ;
					//Sand extend to a moderate height if it's really dry.
					//It also occur at sea level when it's slightly dry.
					if ((depth + humidityModifier < -3.5f) || (indexZ == GetSeaLevelHeight() && humidityModifier < 3.5f)) {
						//sand
						m_blocks[blockIndex].m_type = 12;
					}
					else {
						if (indexZ == surfaceHeight) {
							//grass
							m_blocks[blockIndex].m_type = 3;
						}
						else {
							//dirt
							m_blocks[blockIndex].m_type = 2;
						}
					}
				}
				else if (indexZ > surfaceHeight - 5) {
					//If we are 3-5 deep underground
					float tempRndVal = Get3dNoiseZeroToOne(indexX, indexY, indexZ, m_world->GetSeed());
					if (tempRndVal > 0) {
						m_blocks[blockIndex].m_type = 2;
					}
					else {
						m_blocks[blockIndex].m_type = 1;
					}
				}
				else {
					//If we are pretty deep underground
					float tempRndVal = Get3dNoiseZeroToOne(indexX, indexY, indexZ, m_world->GetSeed());
					tempRndVal = fabsf(tempRndVal);
					if (tempRndVal < 0.001f) {
						m_blocks[blockIndex].m_type = 7;
					}
					else if (tempRndVal < 0.005f) {
						m_blocks[blockIndex].m_type = 6;
					}
					else if (tempRndVal < 0.025f) {
						m_blocks[blockIndex].m_type = 5;
					}
					else if (tempRndVal < 0.075f) {
						m_blocks[blockIndex].m_type = 4;
					}
					else {
						//The default option is rock
						m_blocks[blockIndex].m_type = 1;
					}
				}
			}
		}
	}
	//Add trees------------------------------------------------------------------------------
	for (int indexX = -3; indexX < 3 + CHUNK_SIZE_X; indexX++) {
		for (int indexY = -3; indexY < 3 + CHUNK_SIZE_Y; indexY++) {
			int worldX = indexX + m_chunkInWorldPosition.x * CHUNK_SIZE_X;
			int worldY = indexY + m_chunkInWorldPosition.y * CHUNK_SIZE_Y;
			float forestnessModifier = GetForestnessZeroToOne(worldX, worldY);
			if (Compute2dFractalNoise(float(worldX), float(worldY)) > forestnessModifier) {
				continue;
			}
			if (forestnessModifier <= GetForestnessZeroToOne(worldX + 1, worldY) || forestnessModifier <= GetForestnessZeroToOne(worldX, worldY + 1) || forestnessModifier <= GetForestnessZeroToOne(worldX - 1, worldY) || forestnessModifier <= GetForestnessZeroToOne(worldX, worldY - 1)) {
				continue;
			}
			if (forestnessModifier <= GetForestnessZeroToOne(worldX + 1, worldY + 1) || forestnessModifier <= GetForestnessZeroToOne(worldX - 1, worldY - 1) || forestnessModifier <= GetForestnessZeroToOne(worldX - 1, worldY + 1) || forestnessModifier <= GetForestnessZeroToOne(worldX + 1, worldY - 1)) {
				continue;
			}
			float humidityModifier = 7.f * GetHumidityRatioMinusOneToOne(worldX, worldY);
			BlockTemplate const* treeTemplate = nullptr;
			if (humidityModifier < -3.5f) {
				treeTemplate = BlockDefinition::GetBlockTemplate("cactus");
			}
			else {
				treeTemplate = BlockDefinition::GetBlockTemplate("oak");
			}
			assert(treeTemplate != nullptr);
			int surfaceHeight = GetSurfaceHeight(worldX, worldY);
			if (surfaceHeight < GetSeaLevelHeight()) {
				continue;
			}
			ApplyTemplateAt(*treeTemplate, IntVec3(indexX, indexY, surfaceHeight));
		}
	}
	//Add temples------------------------------------------------------------------------------
	for (int chunkIndexX = -1; chunkIndexX <= 1; chunkIndexX++) {
		for (int chunkIndexY = -1; chunkIndexY <= 1; chunkIndexY++) {
			float currentTempleness = GetTemplenessZeroToOne(chunkIndexX + m_chunkInWorldPosition.x, chunkIndexY + m_chunkInWorldPosition.y);
			if (currentTempleness < 0.95f) {
				continue;
			}
			if (currentTempleness < GetTemplenessZeroToOne(chunkIndexX + m_chunkInWorldPosition.x + 1, chunkIndexY + m_chunkInWorldPosition.y)) {
				continue;
			}
			if (currentTempleness < GetTemplenessZeroToOne(chunkIndexX + m_chunkInWorldPosition.x, chunkIndexY + m_chunkInWorldPosition.y + 1)) {
				continue;
			}
			if (currentTempleness < GetTemplenessZeroToOne(chunkIndexX + m_chunkInWorldPosition.x - 1, chunkIndexY + m_chunkInWorldPosition.y)) {
				continue;
			}
			if (currentTempleness < GetTemplenessZeroToOne(chunkIndexX + m_chunkInWorldPosition.x, chunkIndexY + m_chunkInWorldPosition.y - 1)) {
				continue;
			}
			IntVec2 maxHeightPosition = IntVec2(-1, -1);
			int maxHeightInRecord = -10000;
			for (int indexX = 0; indexX < CHUNK_SIZE_X; indexX++) {
				for (int indexY = 0; indexY < CHUNK_SIZE_Y; indexY++) {
					int worldX = indexX + (chunkIndexX + m_chunkInWorldPosition.x) * CHUNK_SIZE_X;
					int worldY = indexY + (chunkIndexY + m_chunkInWorldPosition.y) * CHUNK_SIZE_Y;
					int surfaceHeight = GetSurfaceHeight(worldX, worldY);
					if (surfaceHeight > maxHeightInRecord) {
						maxHeightInRecord = surfaceHeight;
						maxHeightPosition = IntVec2(indexX + chunkIndexX * CHUNK_SIZE_X, indexY + chunkIndexY * CHUNK_SIZE_Y);
					}
				}
			}
			int worldX = maxHeightPosition.x + m_chunkInWorldPosition.x * CHUNK_SIZE_X;
			int worldY = maxHeightPosition.y + m_chunkInWorldPosition.y * CHUNK_SIZE_Y;
			if (GetHumidityRatioMinusOneToOne(worldX, worldY) > 0.25f && maxHeightInRecord < CHUNK_SIZE_Z - 10 && maxHeightInRecord > GetSeaLevelHeight() + 2) {
				BlockTemplate const* templeTemplate = BlockDefinition::GetBlockTemplate("temple");
				assert(templeTemplate != nullptr);
				ApplyTemplateAt(*templeTemplate, IntVec3(maxHeightPosition.x, maxHeightPosition.y, maxHeightInRecord));
				//ApplyTemplateAt(*templeTemplate, IntVec3(maxHeightPosition.x, maxHeightPosition.y, maxHeightInRecord));
			}
		}
	}
	//No need of saving if all blocks are generated.
	m_needsSaving = false;

}

void Chunk::InitializeLightning() {
	//Find those blocks that can see sky
	for (int indexX = 0; indexX < CHUNK_SIZE_X; indexX++) {
		for (int indexY = 0; indexY < CHUNK_SIZE_Y; indexY++) {
			for (int indexZ = CHUNK_SIZE_Z - 1; indexZ >= 0; indexZ--) {
				int blockIndex = ThreeDimCordToOneDim(IntVec3(indexX, indexY, indexZ));
				if (!m_blocks[blockIndex].GetOpaqueness()) {
					m_blocks[blockIndex].SetCanSeeSky(true);
					//Unnecessary. 
					//Also seem to let some chunk-boundry blocks slightly brighter than they should for some reason....
					//m_blocks[blockIndex].SetOutdoorLightIntensity(LightValueMax);
				}
				else {
					break;
				}
			}
		}
	}
	//Find those blocks that sky light should propagate to
	for (int indexX = 0; indexX < CHUNK_SIZE_X; indexX++) {
		for (int indexY = 0; indexY < CHUNK_SIZE_Y; indexY++) {
			for (int indexZ = CHUNK_SIZE_Z - 1; indexZ >= 0; indexZ--) {
				BlockPosition currentPosition = {this, IntVec3(indexX, indexY, indexZ) };
				Block* currentBlock = currentPosition.GetBlock();
				if (currentBlock->GetCanSeeSky()) {
					BlockPosition horizontalNeighbours[4];
					horizontalNeighbours[0] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::XPlus);
					horizontalNeighbours[1] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::XMinus);
					horizontalNeighbours[2] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::YPlus);
					horizontalNeighbours[3] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::YMinus);
					for (BlockPosition currentNeighbourPos : horizontalNeighbours) {
						Block* neighbour = currentNeighbourPos.GetBlock();
						if (neighbour != nullptr && !neighbour->GetOpaqueness() && !neighbour->GetCanSeeSky()) {
							m_world->MarkLightingDirty(currentNeighbourPos);
						}
					}
				}
				else {
					break;
				}
			}
		}
	}
	//Find those blocks at chunk boundries and emit light themselves
	for (int indexX = 0; indexX < CHUNK_SIZE_X; indexX++) {
		for (int indexY = 0; indexY < CHUNK_SIZE_Y; indexY++) {
			for (int indexZ = 0; indexZ < CHUNK_SIZE_Z; indexZ++) {
				BlockPosition currentPosition = { this, IntVec3(indexX, indexY, indexZ) };
				Block* currentBlock = currentPosition.GetBlock();
				BlockPosition horizontalNeighbours[4];
				horizontalNeighbours[0] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::XPlus);
				horizontalNeighbours[1] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::XMinus);
				horizontalNeighbours[2] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::YPlus);
				horizontalNeighbours[3] = m_world->GetNeighbouringPositionOf(currentPosition, BlockNeighbours::YMinus);
				for (BlockPosition currentNeighbourPos : horizontalNeighbours) {
					Block* neighbour = currentNeighbourPos.GetBlock();
					if (currentNeighbourPos.m_parentChunk != this) {
						//currentNeighbourPos.m_parentChunk->m_visualInitialized: nearby chunk might need light update when this chunk's light is initialized
						if (!currentNeighbourPos.m_parentChunk->m_needsInitializeLighting && !neighbour->GetOpaqueness()) {
							m_world->MarkLightingDirty(currentNeighbourPos);
						}
						if (!currentBlock->GetOpaqueness() && !currentBlock->GetCanSeeSky()) {
							m_world->MarkLightingDirty(currentPosition);
						}
					}
					if (currentBlock->GetLightEmission() > 0) {
						m_world->MarkLightingDirty(currentPosition);
					}
				}
			}
		}
	}
	m_world->ProcessAllDirtyLightBlocks();
	m_needsInitializeLighting = false;
}

void Chunk::SaveBlocks() {
	std::filesystem::create_directory(GetSaveFileFolder());
	std::vector<uint8_t> fileContents;
	fileContents.emplace_back('G');
	fileContents.emplace_back('C');
	fileContents.emplace_back('H');
	fileContents.emplace_back('K');
	fileContents.emplace_back(CurrentSaveFileVersion);
	fileContents.emplace_back(CHUNK_SIZE_X_POW2);
	fileContents.emplace_back(CHUNK_SIZE_Y_POW2);
	fileContents.emplace_back(CHUNK_SIZE_Z_POW2);
	unsigned int worldSeed = m_world->GetSeed();
	uint8_t* worldSeedAsUint8 = reinterpret_cast<uint8_t*>(&worldSeed);
	fileContents.emplace_back(worldSeedAsUint8[0]);
	fileContents.emplace_back(worldSeedAsUint8[1]);
	fileContents.emplace_back(worldSeedAsUint8[2]);
	fileContents.emplace_back(worldSeedAsUint8[3]);

	int previousBlockType = -1;
	int cummulativeBlocksOfSameType = 0;
	for (int index = 0; index < CHUNK_SIZE_TOTAL; index++) {
		int currentBlockType = m_blocks[index].m_type;
		if (currentBlockType != previousBlockType || cummulativeBlocksOfSameType >= 255) {
			if (index != 0) {
				fileContents.emplace_back(uint8_t(cummulativeBlocksOfSameType));
			}
			cummulativeBlocksOfSameType = 1;
			previousBlockType = currentBlockType;
			fileContents.emplace_back(uint8_t(currentBlockType));
		} else {
			cummulativeBlocksOfSameType += 1;
		}
	}
	fileContents.emplace_back(uint8_t(cummulativeBlocksOfSameType));
	FileWriteFromBuffer(fileContents, GetSaveFilePath());
}


void Chunk::AddVertsForBlock(std::vector<Vertex_PCU>& verts, IntVec3 localCord) {
	int currentDefIndex = m_blocks[ThreeDimCordToOneDim(localCord)].m_type;
	BlockDefinition currentDef = BlockDefinition::GetBlockDef(currentDefIndex);
	if (! currentDef.m_isVisible) {
		return;
	}
	AABB3 bounds = GetBlockWorldBound(localCord);
	Vec3 pointBottom1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointBottom2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointBottom3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointBottom4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointTop1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointTop2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointTop3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_maxs.z);
	Vec3 pointTop4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_maxs.z);
	BlockPosition currentBlockPos = { this, localCord };
	Block* zMinus = m_world->GetNeighbouringBlockOf(currentBlockPos, BlockNeighbours::ZMinus);
	Block* zPlus = m_world->GetNeighbouringBlockOf(currentBlockPos, BlockNeighbours::ZPlus);
	Block* yMinus = m_world->GetNeighbouringBlockOf(currentBlockPos, BlockNeighbours::YMinus);
	Block* xPlus = m_world->GetNeighbouringBlockOf(currentBlockPos, BlockNeighbours::XPlus);
	Block* yPlus = m_world->GetNeighbouringBlockOf(currentBlockPos, BlockNeighbours::YPlus);
	Block* xMinus = m_world->GetNeighbouringBlockOf(currentBlockPos, BlockNeighbours::XMinus); 
	if (zMinus && !zMinus->GetOpaqueness()) {
		AddVertsForQuad3D(verts, pointBottom4, pointBottom3, pointBottom2, pointBottom1, Rgba8(zMinus->GetOutdoorLightIntensityNorm(), zMinus->GetIndoorLightIntensityNorm(), 100), currentDef.m_bottomSprite->GetUVs());
	}
	if (zPlus == nullptr) {
		AddVertsForQuad3D(verts, pointTop1, pointTop2, pointTop3, pointTop4, Rgba8(LightValueMax, LightValueMax, 100), currentDef.m_topSprite->GetUVs());
	} else if (!zPlus->GetOpaqueness()) {
		AddVertsForQuad3D(verts, pointTop1, pointTop2, pointTop3, pointTop4, Rgba8(zPlus->GetOutdoorLightIntensityNorm(), zPlus->GetIndoorLightIntensityNorm(), 100), currentDef.m_topSprite->GetUVs());
	}
	if (yMinus && !yMinus->GetOpaqueness()) {
		AddVertsForQuad3D(verts, pointBottom1, pointBottom2, pointTop2, pointTop1, Rgba8(yMinus->GetOutdoorLightIntensityNorm(), yMinus->GetIndoorLightIntensityNorm(), 100), currentDef.m_sideSprite->GetUVs());
	}
	if (xPlus && !xPlus->GetOpaqueness()) {
		AddVertsForQuad3D(verts, pointBottom2, pointBottom3, pointTop3, pointTop2, Rgba8(xPlus->GetOutdoorLightIntensityNorm(), xPlus->GetIndoorLightIntensityNorm(), 100), currentDef.m_sideSprite->GetUVs());
		}
	if (yPlus && !yPlus->GetOpaqueness()) {
		AddVertsForQuad3D(verts, pointBottom3, pointBottom4, pointTop4, pointTop3, Rgba8(yPlus->GetOutdoorLightIntensityNorm(), yPlus->GetIndoorLightIntensityNorm(), 100), currentDef.m_sideSprite->GetUVs());
	}
	if (xMinus && !xMinus->GetOpaqueness()) {
		AddVertsForQuad3D(verts, pointBottom4, pointBottom1, pointTop1, pointTop4, Rgba8(xMinus->GetOutdoorLightIntensityNorm(), xMinus->GetIndoorLightIntensityNorm(), 100), currentDef.m_sideSprite->GetUVs());
	}

}


void Chunk::ApplyTemplateAt(BlockTemplate bTemplate, IntVec3 localPos) {
	for (BlockTemplateEntry entry : bTemplate.m_entries) {
		IntVec3 nextBlockPos = localPos + entry.m_localPos;
		if (IsValidThreeDimIndex(nextBlockPos)) {
			//WorldActionChangeBlockType(nextBlockPos, entry.m_type);
			Block* changedBlock = GetBlockByCord(nextBlockPos);
			changedBlock->m_type = entry.m_type;
		}
	}
}


float Chunk::GetForestnessZeroToOne(int worldX, int worldY) const { 
	float noiseValue = Compute2dPerlinNoise(float(worldX), float(worldY), 150.f, 5, 0.5f, 2.0f, true, m_world->GetSeed() + 1);
	return SmoothStep3(0.5f + 0.5f * noiseValue);
}
float Chunk::GetTreePresenceZeroToOne(int worldX, int worldY) const {
	float noiseValue = Compute2dPerlinNoise(float(worldX), float(worldY), 5.f, 1, 0.5f, 2.0f, false, m_world->GetSeed() + 2);
	return 0.5f + 0.5f * noiseValue;
}
float Chunk::GetCavePresenceFactor(int worldX, int worldY, int worldZ) const {
	float noiseValue = Compute3dPerlinNoise(float(worldX), float(worldY), float(worldZ * 1.2f), 40.f, 1, 0.4f, 2.0f, false, m_world->GetSeed() + 5);
	return 1.f - fabsf(noiseValue);
}
float Chunk::GetCavePresenceFactorB(int worldX, int worldY, int worldZ) const {
	float noiseValue = Compute3dPerlinNoise(float(worldX), float(worldY), float(worldZ * 16.f), 120.f, 1, 0.4f, 2.0f, false, m_world->GetSeed() + 6);
	return 0.5f + 0.5f * noiseValue;
}
float Chunk::GetHillHeightRatioZeroToOne(int worldX, int worldY) const {
	float noiseValue = Compute2dPerlinNoise(float(worldX), float(worldY), 550.f, 1, 0.5f, 2.0f, true, m_world->GetSeed() + 7);
	return SmoothStep3(0.5f + 0.5f * noiseValue);
}
float Chunk::GetHillHeight(int worldX, int worldY, float hillHeightRatio) const {
	float noiseValue = Compute2dPerlinNoise(float(worldX), float(worldY), 300.f, 7, 0.55f, 2.0f, false, m_world->GetSeed() + 8);
	return fabsf(60.f * hillHeightRatio * noiseValue);
}
float Chunk::GetOceanDepth(int worldX, int worldY) const {
	float noiseValue = Compute2dPerlinNoise(float(worldX), float(worldY), 900.f, 4, 0.4f, 2.0f, false, m_world->GetSeed() + 9);
	return fminf(0.f, 50.f * noiseValue);
}
int Chunk::GetSurfaceHeight(int worldX, int worldY) const {
	int surfaceHeight = GetBaseSurfaceHeight();
	//map hillHeightModifier from [-1, 1] to [0, 1]
	float hillHeightModifier = GetHillHeightRatioZeroToOne(worldX, worldY);
	float hillHeight = GetHillHeight(worldX, worldY, hillHeightModifier);
	float oceanDepth = GetOceanDepth(worldX, worldY);
	//apply ocean and hillHeight
	surfaceHeight += int(oceanDepth + hillHeight);
	return surfaceHeight;
}
float Chunk::GetTemperatureRatioMinusOneToOne(int worldX, int worldY) const { 
	return Compute2dPerlinNoise(float(worldX), float(worldY), 700.f, 5, 0.45f, 2.0f, false, m_world->GetSeed() + 10); 
}
float Chunk::GetHumidityRatioMinusOneToOne(int worldX, int worldY) const { 
	return Compute2dPerlinNoise(float(worldX), float(worldY), 200.f, 8, 0.6f, 2.0f, false, m_world->GetSeed() + 11); 
}
float Chunk::GetTemplenessZeroToOne(int worldX, int worldY) const {
	float noiseValue = Compute2dPerlinNoise(float(worldX), float(worldY), 2.f, 1, 0.5f, 2.0f, true, m_world->GetSeed() + 12);
	return SmoothStep3(0.5f + 0.5f * noiseValue);
}
