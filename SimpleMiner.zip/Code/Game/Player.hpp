#pragma once
#include "Game\Entity.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\IntVec3.hpp"
#include "Engine\Math\RaycastUtils.hpp"

class Camera;
class Block;


//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class Player : public Entity
{
	friend class Game;
	friend class App;

public:
	// Construction/Destruction
	~Player();
	Player(World* parentWorld);
	Player(World* parentWorld, Vec3 startingPosition, EulerAngles startingOrientation);

	void Update(float deltaSeconds) override;
	void Render() const override;
	Camera* GetCamera() const { return m_camera; }
	void Reset() { m_position = m_startingPosition; m_orientationDegrees = m_startingOrientation; }

protected:
	Camera* m_camera = nullptr;
	bool HandleInput(float deltaSeconds);
	RaycastResult3D m_frontalRaycastResult;
	IntVec3 m_raycastHitBlock;
	IntVec3 m_raycastHitBlockBefore;

	const float m_moveSpeedBase = 4.f;
	float m_moveSpeed = 4.f;
	Vec3 m_startingPosition;
	EulerAngles m_startingOrientation;
};