#pragma once
#include "Game\Game.hpp"
#include "Game\Chunk.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\IntVec3.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\RaycastUtils.hpp"
#include <deque>

class Player;
class Entity;
class Chunk;
class RandomNumberGenerator;


class Block;



struct BlockPosition {
	Chunk* m_parentChunk = nullptr;
	IntVec3 m_localCoordInChunk;
	
	Block* GetBlock() const {
		if (m_parentChunk == nullptr) {
			return nullptr;
		} else {
			return m_parentChunk->GetBlockByCord(m_localCoordInChunk);
		}
	}
};

//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class World
{
	friend class Game;

public:
	// Construction/Destruction
	~World();
	World(Game* parentGame);

	void Update(float deltaSeconds);
	void Render() const;

	unsigned int GetSeed() const { return m_seed; }

	//Dealing with chunk
	BlockPosition GetBlockPositionFromWorldBlockIndex(IntVec3 pos) const;
	Block* GetBlockFromWorldBlockIndex(IntVec3 pos) const;
	Block* GetNeighbouringBlockOf(BlockPosition const& selfPos, BlockNeighbours neighbourDirection);
	BlockPosition GetNeighbouringPositionOf(BlockPosition const& selfPos, BlockNeighbours neighbourDirection);
	bool DigAt(IntVec3 pos, float force = 1.f);
	bool BuildAt(IntVec3 pos, uint8_t blockType = 10);
	Chunk* TryGetChunk(IntVec2 pos) const;
	RaycastResult3D RaycastWorld(const Vec3& start, const Vec3& forwardNorm, float maxLength) const;

	//Functions to deal with lightning updates
	void ProcessAllDirtyLightBlocks();
	void ProcessNextDirtyLightBlock();
	void MarkLightingDirty(BlockPosition& targetBlockPosition);
	void RemoveAllBlocksFromChunk(Chunk* theChunk);  //This is called on chunk deletion
	Rgba8 GetCurrentSkyColor() const;
	float GetCurrentSkyColorStrength() const;
	float GetCurrentLightningStrength() const;
	float GetCurrentGlowFlickerStrength() const;

protected:
	Game* m_game = nullptr;
	std::vector<Entity*> m_myEntityVector;
	std::map<IntVec2, Chunk*> m_chunksGenerating;
	std::map<IntVec2, Chunk*> m_chunksActive;
	Player* m_player = nullptr;
	std::deque<BlockPosition> m_lightUpdateQueue;
	WorldRenderExtraInfo m_rendererExtraInto;
	float m_worldDayNightTime = 1000.f;
	unsigned int m_seed = 2;

	//Functions related to world generation
	void StartBuildingNearestMissingChunk(Vec2 center);
	void RemoveChunkTooFar(Vec2 center);
	float GetDistanceSquardToChunk(Vec2 center, IntVec2 chunk) const;
	
	//Functions that helps dealing with entities
	void TryEraseAllGameObjects(bool onlyGarbage = false);
	void TryRenderEntityVector(const std::vector<Entity*>& things) const;
	void TryActivateFinishedChunks();
	void TryUpdateEntityVector(std::vector<Entity*>& things, float deltaSeconds);
	void TryDeleteEntityVector(std::vector<Entity*>& things, bool garbageOnly);
	bool RetreiveAJob();

	//Functions that helps dealing with chunks
	void TryRenderChunkMap() const;
	void TryUpdateChunkMap(float deltaSeconds);
	void TryDeleteChunkMap();
	void TryDeleteUnfinishedChunks();
	void StartBuildingChunk(IntVec2 pos);
	void TryRemoveChunk(IntVec2 pos);
};