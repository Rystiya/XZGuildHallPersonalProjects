
#include "Game\Player.hpp"
#include "Game\World.hpp"
#include "Game\BlockDefinition.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\Camera.hpp"
#include "Engine\Math\MathUtils.hpp"

Player::Player(World* parentWorld) : Entity(parentWorld) {
	m_camera = new Camera(Vec2(-1.f, -1.f), Vec2(1.f, 1.f));
}

Player::Player(World* parentWorld, Vec3 startingPosition, EulerAngles startingOrientation) : Entity(parentWorld) {
	m_camera = new Camera(Vec2(-1.f, -1.f), Vec2(1.f, 1.f));
	m_camera->SetPerspectiveView(g_theWindow->GetClientAspect(), 60.f, 0.1f, 2500.f);
	m_camera->SetRenderBasis(Vec3(0.f, 0.f, 1.f), Vec3(-1.f, 0.f, 0.f), Vec3(0.f, 1.f, 0.f));
	m_startingPosition = startingPosition;
	m_startingOrientation = startingOrientation;
	Reset();
}

Player::~Player() {
	delete m_camera;
}


void Player::Render() const {
	g_theRenderer->BindTexture(nullptr);
	g_theRenderer->UpdateShader(nullptr);
	g_theRenderer->SetModelConstants();

	if (m_frontalRaycastResult.m_didImpact) {
		std::vector<Vertex_PCU> m_vertexes;
		AddVertsForAABB3(m_vertexes, AABB3(m_frontalRaycastResult.m_impactPos - Vec3(0.02f, 0.02f, 0.02f), m_frontalRaycastResult.m_impactPos + Vec3(0.02f, 0.02f, 0.02f)), Rgba8(255, 255, 255));
		AddVertsForAABB3Wireframe(m_vertexes, AABB3(m_raycastHitBlock, IntVec3(1, 1, 1) + m_raycastHitBlock), 0.02f, Rgba8(255, 255, 255));
		g_theRenderer->DrawVertexVector(m_vertexes);
	}
}


void Player::Update(float deltaSeconds) {
	HandleInput(deltaSeconds);
	m_orientationDegrees.m_pitchDegrees = GetClamped(m_orientationDegrees.m_pitchDegrees, -85.f, 85.f);
	m_orientationDegrees.m_rollDegrees = GetClamped(m_orientationDegrees.m_rollDegrees, -45.f, 45.f);

	m_camera->m_position3D = m_position;
	m_camera->m_orientation = m_orientationDegrees;
	
	m_frontalRaycastResult = m_world->RaycastWorld(m_position, m_orientationDegrees.GetForwardVector(), 10.f);
	Vec3 beneathImpactPosition = m_frontalRaycastResult.m_impactPos - m_frontalRaycastResult.m_impactNormal * 0.01f;
	Vec3 aboveImpactPosition = m_frontalRaycastResult.m_impactPos + m_frontalRaycastResult.m_impactNormal * 0.01f;
	m_raycastHitBlock = IntVec3((int)floorf(beneathImpactPosition.x), (int)floorf(beneathImpactPosition.y), (int)floorf(beneathImpactPosition.z));
	m_raycastHitBlockBefore = IntVec3((int)floorf(aboveImpactPosition.x), (int)floorf(aboveImpactPosition.y), (int)floorf(aboveImpactPosition.z));
}



bool Player::HandleInput(float deltaSeconds) {
	XboxController myController = g_theInputSystem->GetController(0);
	m_moveSpeed = m_moveSpeedBase;
	Vec3 forwardDirection;
	Vec3 sideDirection;
	Vec3 topDirection;
	m_orientationDegrees.GetAsVectors_XFwd_YLeft_ZUp(forwardDirection, sideDirection, topDirection);
	forwardDirection = Vec2(forwardDirection).GetNormalized();
	sideDirection = Vec2(sideDirection).GetNormalized();
	topDirection = Vec2(topDirection).GetNormalized();
	if (g_theInputSystem->IsKeyDown(KEYCODE_SHIFT) || myController.GetButton(XboxButtonID::ButtonA).m_isPressed) {
		m_moveSpeed *= 10.f;
	}
	if (g_theInputSystem->IsKeyDown(KEYCODE_CTRL) || myController.GetButton(XboxButtonID::ButtonB).m_isPressed) {
		m_moveSpeed *= 0.2f;
	}
	if (g_theInputSystem->IsKeyDown('H') || myController.GetButton(XboxButtonID::ButtonStart).m_isPressed) {
		Reset();
	}
	if (g_theInputSystem->IsKeyDown('W') || myController.GetLeftStick().GetPosition().y > 0.1f) {
		m_position += forwardDirection * m_moveSpeed * deltaSeconds;
	}
	if (g_theInputSystem->IsKeyDown('S') || myController.GetLeftStick().GetPosition().y < -0.1f) {
		m_position -= forwardDirection * m_moveSpeed * deltaSeconds;
	}
	if (g_theInputSystem->IsKeyDown('A') || myController.GetLeftStick().GetPosition().x < -0.1f) {
		m_position += sideDirection * m_moveSpeed * deltaSeconds;
	}
	if (g_theInputSystem->IsKeyDown('D') || myController.GetLeftStick().GetPosition().x > 0.1f) {
		m_position -= sideDirection * m_moveSpeed * deltaSeconds;
	}
	if (g_theInputSystem->IsKeyDown('E') || myController.GetButton(XboxButtonID::ButtonTopLeft).m_isPressed) {
		m_position.z += m_moveSpeed * deltaSeconds;
	}
	if (g_theInputSystem->IsKeyDown('Q') || myController.GetButton(XboxButtonID::ButtonTopRight).m_isPressed) {
		m_position.z -= m_moveSpeed * deltaSeconds;
	}
	if (g_theInputSystem->WasKeyJustPressed(KEYCODE_LEFTMOUSE) || myController.WasButtonJustPressed(XboxButtonID::ButtonLeft)) {
		m_world->BuildAt(m_raycastHitBlockBefore);
	}
	if (g_theInputSystem->WasKeyJustPressed(KEYCODE_RIGHTMOUSE) || myController.WasButtonJustPressed(XboxButtonID::ButtonRight)) {
		m_world->DigAt(m_raycastHitBlock);
	}
	if (myController.GetRightStick().GetNormalizedMagnitude() < 0.1f) {
		m_orientationDegrees.m_yawDegrees -= float(g_theInputSystem->GetCursorClientDelta().x) * m_moveSpeed * 0.02f;
		m_orientationDegrees.m_pitchDegrees -= float(g_theInputSystem->GetCursorClientDelta().y) * m_moveSpeed * 0.02f;
	} else {
		m_orientationDegrees.m_yawDegrees -= myController.GetRightStick().GetPosition().x * m_moveSpeed * 0.2f;
		m_orientationDegrees.m_pitchDegrees -= myController.GetRightStick().GetPosition().y * m_moveSpeed * 0.2f;
	}
	return false;
}