
#include "Game\BlockDefinition.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Renderer\SpriteDefinition.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <assert.h>



//Block stuff-------------------------------------------------------------------------------------------------
void Block::SetOutdoorLightIntensity(uint8_t intensity) {
	assert(intensity >= 0 && intensity <= LightValueMax);
	uint8_t lightingIndoorOnly = m_lighting &= IndoorLightningMask;
	uint8_t lightingOutdoorOnly = intensity << 4;
	m_lighting = lightingIndoorOnly + lightingOutdoorOnly;
}

void Block::SetIndoorLightIntensity(uint8_t intensity) {
	assert(intensity >= 0 && intensity <= LightValueMax);
	uint8_t lightingIndoorOnly = intensity;
	uint8_t lightingOutdoorOnly = m_lighting &= OutdoorLightningMask;
	m_lighting = lightingIndoorOnly + lightingOutdoorOnly;
}

uint8_t Block::GetOutdoorLightIntensity() const {
	return (m_lighting & OutdoorLightningMask) >> 4;

}
uint8_t Block::GetIndoorLightIntensity() const {
	return m_lighting & IndoorLightningMask;
}
uint8_t Block::GetOutdoorLightIntensityNorm() const {
	return (GetOutdoorLightIntensity() * 255) / LightValueMax;

}
uint8_t Block::GetIndoorLightIntensityNorm() const {
	return (GetIndoorLightIntensity() * 255) / LightValueMax;
}

bool Block::GetSolidness() const { return BlockDefinition::IsSolid(m_type); }
bool Block::GetOpaqueness() const { return BlockDefinition::IsOpaque(m_type); }
uint8_t Block::GetLightEmission() const { return BlockDefinition::GetLightEmission(m_type); }

void Block::SetCanSeeSky(bool flag) {
	SetFlag(flag, 0);
}
void Block::SetIsInLightDirtyQueue(bool flag) {
	SetFlag(flag, 1);
}
void Block::SetIsAtBottom(bool flag) {
	SetFlag(flag, 2);
}
bool Block::GetCanSeeSky() const {
	return GetFlag(0);
}
bool Block::GetIsInLightDirtyQueue() const {
	return GetFlag(1);
}
bool Block::GetIsAtBottom() const {
	return GetFlag(2);
}


void Block::SetFlag(bool canSee, uint8_t pos) {
	uint8_t otherOnes = m_flags &= (ByteMax - (1 << pos));
	uint8_t thisOne = canSee << pos;
	m_flags = otherOnes + thisOne;

}
bool Block::GetFlag(uint8_t pos) const {
	assert(pos >= 0 && pos <= 7);
	uint8_t rawInUint8 = m_flags & (1 << pos);
	return rawInUint8 >> pos;

}

//Block definition stuff-------------------------------------------------------------------------------------------------
//Has to be put here for some reason
static std::vector<BlockDefinition> BlockDefinitions;
static std::vector<BlockTemplate> BlockTemplates;

BlockDefinition::BlockDefinition(std::string name, bool isVisible, bool isSolid, bool isOpaque, IntVec2 top, IntVec2 side, IntVec2 bottom, uint8_t lightEmission) {
	m_typeName = name;
	m_isSolid = isVisible;
	m_isVisible = isSolid;
	m_isOpaque = isOpaque;
	m_lightEmitIntensity = lightEmission;

	m_topSprite = &g_theApp->GetSpriteSheet()->GetSpriteDefFromSimpleGrid(top);
	m_bottomSprite = &g_theApp->GetSpriteSheet()->GetSpriteDefFromSimpleGrid(bottom);
	m_sideSprite = &g_theApp->GetSpriteSheet()->GetSpriteDefFromSimpleGrid(side);
}


void BlockDefinition::AddBlockDefs() {
	BlockDefinitions.emplace_back(BlockDefinition("air", false, false, false, IntVec2(0, 0), IntVec2(0, 0), IntVec2(0, 0)));
	BlockDefinitions.emplace_back(BlockDefinition("stone", true, true, true, IntVec2(33, 32), IntVec2(33, 32), IntVec2(33, 32)));
	BlockDefinitions.emplace_back(BlockDefinition("dirt", true, true, true, IntVec2(32, 34), IntVec2(32, 34), IntVec2(32, 34)));
	BlockDefinitions.emplace_back(BlockDefinition("grass", true, true, true, IntVec2(32, 33), IntVec2(33, 33), IntVec2(32, 34)));
	BlockDefinitions.emplace_back(BlockDefinition("coal", true, true, true, IntVec2(63, 34), IntVec2(63, 34), IntVec2(63, 34)));
	BlockDefinitions.emplace_back(BlockDefinition("iron", true, true, true, IntVec2(63, 35), IntVec2(63, 35), IntVec2(63, 35)));
	BlockDefinitions.emplace_back(BlockDefinition("gold", true, true, true, IntVec2(63, 36), IntVec2(63, 36), IntVec2(63, 36)));
	BlockDefinitions.emplace_back(BlockDefinition("dimond", true, true, true, IntVec2(63, 37), IntVec2(63, 37), IntVec2(63, 37)));
	BlockDefinitions.emplace_back(BlockDefinition("water", true, true, true, IntVec2(32, 44), IntVec2(32, 44), IntVec2(32, 44)));
	BlockDefinitions.emplace_back(BlockDefinition("wood", true, true, true, IntVec2(32, 32), IntVec2(32, 32), IntVec2(32, 32)));
	BlockDefinitions.emplace_back(BlockDefinition("light", true, true, true, IntVec2(46, 34), IntVec2(46, 34), IntVec2(46, 34), LightValueMax));
	BlockDefinitions.emplace_back(BlockDefinition("ice", true, true, true, IntVec2(36, 35), IntVec2(36, 35), IntVec2(36, 35)));
	BlockDefinitions.emplace_back(BlockDefinition("sand", true, true, true, IntVec2(34, 34), IntVec2(35, 35), IntVec2(35, 35)));
	BlockDefinitions.emplace_back(BlockDefinition("cactusTop", true, true, true, IntVec2(39, 36), IntVec2(37, 36), IntVec2(38, 36)));
	BlockDefinitions.emplace_back(BlockDefinition("cactusMid", true, true, true, IntVec2(38, 36), IntVec2(37, 36), IntVec2(38, 36)));
	BlockDefinitions.emplace_back(BlockDefinition("cactusTop", true, true, true, IntVec2(39, 36), IntVec2(37, 36), IntVec2(38, 36)));
	BlockDefinitions.emplace_back(BlockDefinition("cactusSimple", true, true, true, IntVec2(33, 36), IntVec2(33, 36), IntVec2(33, 36)));
	BlockDefinitions.emplace_back(BlockDefinition("oakTruck", true, true, true, IntVec2(38, 33), IntVec2(36, 33), IntVec2(38, 33)));
	BlockDefinitions.emplace_back(BlockDefinition("oakLeaf", true, true, true, IntVec2(32, 35), IntVec2(32, 35), IntVec2(32, 35)));
	BlockDefinitions.emplace_back(BlockDefinition("stoneBrick", true, true, true, IntVec2(42, 32), IntVec2(40, 32), IntVec2(37, 32)));
	static std::vector<BlockTemplateEntry> cactusEntries;
	cactusEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("cactusSimple"), IntVec3(0, 0, 0)));
	cactusEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("cactusSimple"), IntVec3(0, 0, 1)));
	cactusEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("cactusSimple"), IntVec3(0, 0, 2)));
	cactusEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("cactusSimple"), IntVec3(0, 0, 3)));
	cactusEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("cactusSimple"), IntVec3(0, 0, 4)));
	BlockTemplates.emplace_back(BlockTemplate("cactus", cactusEntries));
	static std::vector<BlockTemplateEntry> oakEntries;
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakTruck"), IntVec3(0, 0, 0)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakTruck"), IntVec3(0, 0, 1)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakTruck"), IntVec3(0, 0, 2)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakTruck"), IntVec3(0, 0, 3)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakTruck"), IntVec3(0, 0, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(1, 0, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(-1, 0, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(0, 1, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(0, -1, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(1, 1, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(-1, -1, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(1, -1, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(-1, 1, 4)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(0, 0, 5)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(1, 0, 5)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(-1, 0, 5)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(0, 1, 5)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(0, -1, 5)));
	oakEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("oakLeaf"), IntVec3(0, 0, 6)));
	BlockTemplates.emplace_back(BlockTemplate("oak", oakEntries));
	static std::vector<BlockTemplateEntry> templeEntries;
	for (int indexX = -4; indexX <= 4; indexX++) {
		for (int indexY = -4; indexY <= 4; indexY++) {
			if ((indexX == 4 || indexX == -4) && (indexY == 4 || indexY == -4)) {
				continue;
			}
			//fill the middle part with air
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("air"), IntVec3(indexX, indexY, 1)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("air"), IntVec3(indexX, indexY, 2)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("air"), IntVec3(indexX, indexY, 3)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("air"), IntVec3(indexX, indexY, 4)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("air"), IntVec3(indexX, indexY, 5)));
			//fill foundation
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, -3)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, -2)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, -1)));
			templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, 0)));
		}
	}
	for (int indexX = -4; indexX <= 4; indexX++) {
		for (int indexY = -4; indexY <= 4; indexY++) {
			//fill top
			if (abs(indexX) + abs(indexY) < 6) {
				templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, 6)));
			}
			if (abs(indexX) + abs(indexY) < 5) {
				templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, 7)));
			}
			if (abs(indexX) + abs(indexY) < 4) {
				templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, 8)));
			}
			if (abs(indexX) + abs(indexY) < 3) {
				templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, 9)));
			}
			if (abs(indexX) + abs(indexY) < 2) {
				templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(indexX, indexY, 10)));
			}
		}
	}
	std::vector<IntVec2> columns = {IntVec2(2,2), IntVec2(-2, 2), IntVec2(2, -2), IntVec2(-2, -2), IntVec2(3,0), IntVec2(-3,0), IntVec2(0,3), IntVec2(0,-3)};
	for (int columnIndex = 0; columnIndex < columns.size(); columnIndex++) {
		//fill columns
		templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(columns[columnIndex].x, columns[columnIndex].y, 0)));
		templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(columns[columnIndex].x, columns[columnIndex].y, 1)));
		templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(columns[columnIndex].x, columns[columnIndex].y, 2)));
		templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(columns[columnIndex].x, columns[columnIndex].y, 3)));
		templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(columns[columnIndex].x, columns[columnIndex].y, 4)));
		templeEntries.emplace_back(BlockTemplateEntry(GetDefIndexOf("stoneBrick"), IntVec3(columns[columnIndex].x, columns[columnIndex].y, 5)));
	}
	BlockTemplates.emplace_back(BlockTemplate("temple", templeEntries));
}

BlockDefinition const& BlockDefinition::GetBlockDef(int index) {
	return BlockDefinitions[index];
}

bool BlockDefinition::IsSolid(int index) {
	return BlockDefinitions[index].m_isSolid;
}

bool BlockDefinition::IsOpaque(int index) {
	return BlockDefinitions[index].m_isOpaque;
}

bool BlockDefinition::IsValid(int index) {
	return index >= 0 && index < BlockDefinitions.size();
}

uint8_t BlockDefinition::GetDefIndexOf(std::string name) {
 	for (uint8_t index = 0; index < BlockDefinitions.size(); index++) {
		if (BlockDefinitions[index].m_typeName == name) {
			return index;
		}
	}
	return uint8_t(-1);
}

BlockTemplate const* BlockDefinition::GetBlockTemplate(std::string name) {
	for (int index = 0; index < BlockTemplates.size(); index++) {
		if (BlockTemplates[index].m_templateName == name) {
			return &BlockTemplates[index];
		}
	}
	return nullptr;
}

uint8_t BlockDefinition::GetLightEmission(int index) {
	return BlockDefinitions[index].m_lightEmitIntensity;
}

BlockTemplateEntry::BlockTemplateEntry(uint8_t type, IntVec3 localPos) {
	m_type = type;
	m_localPos = localPos;
}


BlockTemplate::BlockTemplate(std::string name, std::vector<BlockTemplateEntry> entries) {
	m_templateName = name;
	m_entries = entries;
}