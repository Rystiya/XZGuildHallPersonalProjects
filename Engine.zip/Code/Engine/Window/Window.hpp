﻿#pragma once
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\IntVec2.hpp"
#include <string>

class InputSystem;

struct WindowConfig {
	InputSystem* m_inputSystem = nullptr;
	float m_clientAspect = 2.f;
	std::string m_windowTitle = "Starship Tactics";
	bool m_isFullScreen = false;
};



//This thing controls graphics
//-----------------------------------------------------------------------------------------------
class Window
{
public:
	Window(WindowConfig const& config);
	~Window() {}
	void Startup();
	void BeginFrame();
	void EndFrame();
	void Shutdown() {}
	WindowConfig const& GetConfig() const { return m_windowConfig; }
	static Window* GetWindowContext() { return s_mainWindow; }
	Vec2 GetNormalizedCursorPos() const;
	IntVec2 GetCursorPosition() const;
	void SetCursorPosition(IntVec2 position) const;
	IntVec2 GetWindoeCenterPos() const;
	bool GetIsFocused() const;
	void* GetHwnd() const { return m_windowHandle; }
	IntVec2 GetClientDimensions() const { return m_clientDimensions; }
	float GetClientAspect() const { return static_cast<float>(m_clientDimensions.x) / static_cast<float>(m_clientDimensions.y); }

protected:
	static Window* s_mainWindow;
	WindowConfig m_windowConfig;
	void CreateOSWindow();
	void RunMessagePump();
	void* m_windowHandle = nullptr;
	IntVec2 m_clientDimensions = IntVec2(0,0);
	

};


