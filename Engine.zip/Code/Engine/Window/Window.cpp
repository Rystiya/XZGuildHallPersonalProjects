﻿
#include "Engine\Window\Window.hpp"
#include "Engine\Input\InputSystem.hpp"
#include "Engine\Core\EventSystem.hpp"
#include "Engine\Core\EngineCommon.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"
#include "Engine\Math\AABB2.hpp"
#include <cassert>
#include <crtdbg.h>

#define WIN32_LEAN_AND_MEAN		// Always #define this before #including <windows.h>
#include <windows.h> 

Window* Window::s_mainWindow = nullptr; //A pointer to myself?
HDC m_displayContext = nullptr; //Can only be defined here because it needs  <windows.h> 

Window::Window(WindowConfig const& windowConfig)
{
	m_windowConfig = windowConfig;
	s_mainWindow = this;
}

//-----------------------------------------------------------------------------------------------
// Handles Windows (Win32) messages/events; i.e. the OS is trying to tell us something hAppened.
// This function is called by Windows whenever we ask it for notifications
//
LRESULT CALLBACK WindowsMessageHandlingProcedure(HWND windowHandle, UINT wmMessageCode, WPARAM wParam, LPARAM lParam)
{
	Window* windowContext = Window::GetWindowContext();
	GUARANTEE_OR_DIE(windowContext != nullptr, "WindowContext was null");
	InputSystem* input = windowContext->GetConfig().m_inputSystem;
	GUARANTEE_OR_DIE(input != nullptr, "No input system!");

	EventArgs eventData;
	eventData.SetValue("key", Stringf("%d", (unsigned char)wParam));

	switch (wmMessageCode) {
		case WM_CLOSE: {
			FireEvent("exit");
			break;
		}
		case WM_LBUTTONDOWN: {
			eventData.SetValue("key", Stringf("%d", KEYCODE_LEFTMOUSE));
			FireEvent("keyDown", eventData);
			break;
		}
		case WM_RBUTTONDOWN: {
			eventData.SetValue("key", Stringf("%d", KEYCODE_RIGHTMOUSE));
			FireEvent("keyDown", eventData);
			break;
		}
		case WM_MBUTTONDOWN: {
			eventData.SetValue("key", Stringf("%d", KEYCODE_MIDMOUSE));
			FireEvent("keyDown", eventData);
			break;
		}
		case WM_LBUTTONUP: {
			eventData.SetValue("key", Stringf("%d", KEYCODE_LEFTMOUSE));
			FireEvent("keyUp", eventData);
			break;
		}
		case WM_RBUTTONUP: {
			eventData.SetValue("key", Stringf("%d", KEYCODE_RIGHTMOUSE));
			FireEvent("keyUp", eventData);
			break;
		}
		case WM_MBUTTONUP: {
			eventData.SetValue("key", Stringf("%d", KEYCODE_MIDMOUSE));
			FireEvent("keyUp", eventData);
			break;
		}
		case WM_MOUSEWHEEL: {
			eventData.SetValue("key", Stringf("%d", (long)wParam));
			FireEvent("wheelScroll", eventData);
			break;
		}
		case WM_KEYDOWN: {
			FireEvent("keyDown", eventData);
			break;
		}
		case WM_KEYUP: {
			FireEvent("keyUp", eventData);
			break;
		}
		case WM_CHAR: {
			FireEvent("charDown", eventData);
			break;
		}
	}
	// Send back to Windows any unhandled/unconsumed messages we want other Apps to see (e.g. play/pause in music Apps, etc.)
	return DefWindowProc(windowHandle, wmMessageCode, wParam, lParam);
}



void Window::Startup() {
	CreateOSWindow();
}

void Window::BeginFrame() {
	RunMessagePump();
}

void Window::EndFrame() {

}




void Window::CreateOSWindow()
{
	// Define a window style/class
	WNDCLASSEX windowClassDescription;
	memset(&windowClassDescription, 0, sizeof(windowClassDescription));
	windowClassDescription.cbSize = sizeof(windowClassDescription);
	windowClassDescription.style = CS_OWNDC; // Redraw on move, request own Display Context
	windowClassDescription.lpfnWndProc = static_cast<WNDPROC>(WindowsMessageHandlingProcedure); // Register our Windows message-handling function
	windowClassDescription.hInstance = GetModuleHandle(NULL);
	windowClassDescription.hIcon = NULL;
	windowClassDescription.hCursor = NULL;
	windowClassDescription.lpszClassName = TEXT("Simple Window Class");
	RegisterClassEx(&windowClassDescription);

	// #SD1ToDo: Add support for full screen mode (requires different window style flags than windowed mode)
	DWORD windowStyleFlagsTemp;
	DWORD windowStyleExFlagsTemp;
	if (m_windowConfig.m_isFullScreen) {
		windowStyleFlagsTemp = WS_POPUP;
		windowStyleExFlagsTemp = WS_EX_APPWINDOW | WS_EX_TOPMOST;
	}
	else {
		windowStyleFlagsTemp = WS_CAPTION | WS_BORDER | WS_THICKFRAME | WS_SYSMENU | WS_OVERLAPPED;
		windowStyleExFlagsTemp = WS_EX_APPWINDOW;
	}

	const DWORD windowStyleFlags = windowStyleFlagsTemp;
	const DWORD windowStyleExFlags = windowStyleExFlagsTemp;

	// Get desktop rect, dimensions, aspect
	RECT desktopRect;
	RECT windowRect;
	HWND desktopWindowHandle = GetDesktopWindow();
	GetClientRect(desktopWindowHandle, &desktopRect);
	if (m_windowConfig.m_isFullScreen) {
		// Calculate maximum client size (as some % of desktop size)
		constexpr float maxClientFractionOfDesktop = 1.f;
		m_clientDimensions.x = static_cast<int>(desktopRect.right - desktopRect.left);
		m_clientDimensions.y = static_cast<int>(desktopRect.bottom - desktopRect.top);

		// Calculate the outer dimensions of the physical window, including frame et. al.
		windowRect = desktopRect;
	}
	else {
		float desktopWidth = static_cast<float>(desktopRect.right - desktopRect.left);
		float desktopHeight = static_cast<float>(desktopRect.bottom - desktopRect.top);
		float desktopAspect = desktopWidth / desktopHeight;

		// Calculate maximum client size (as some % of desktop size)
		constexpr float maxClientFractionOfDesktop = 1.f;
		m_clientDimensions.x = static_cast<int>(desktopWidth * maxClientFractionOfDesktop);
		m_clientDimensions.y = static_cast<int>(desktopHeight * maxClientFractionOfDesktop);
		if (m_windowConfig.m_clientAspect > desktopAspect)
		{
			// Client window has a wider aspect than desktop; shrink client height to match its width
			m_clientDimensions.y = static_cast<int>(m_clientDimensions.x / m_windowConfig.m_clientAspect);
		}
		else
		{
			// Client window has a taller aspect than desktop; shrink client width to match its height
			m_clientDimensions.x = static_cast<int>(m_clientDimensions.y * m_windowConfig.m_clientAspect);
		}

		// Calculate client rect bounds by centering the client area
		float clientMarginX = 0.5f * (desktopWidth - m_clientDimensions.x);
		float clientMarginY = 0.5f * (desktopHeight - m_clientDimensions.y);
		RECT clientRect;
		clientRect.left = (int)clientMarginX;
		clientRect.right = clientRect.left + (long)m_clientDimensions.x;
		clientRect.top = (int)clientMarginY;
		clientRect.bottom = clientRect.top + (long)m_clientDimensions.y;

		// Calculate the outer dimensions of the physical window, including frame et. al.
		windowRect = clientRect;
	}
	AdjustWindowRectEx(&windowRect, windowStyleFlags, FALSE, windowStyleExFlags);

	WCHAR windowTitle[1024];
	MultiByteToWideChar(GetACP(), 0, m_windowConfig.m_windowTitle.c_str(), -1, windowTitle, sizeof(windowTitle) / sizeof(windowTitle[0]));
	m_windowHandle = CreateWindowEx(
		windowStyleExFlags,
		windowClassDescription.lpszClassName,
		windowTitle,
		windowStyleFlags,
		windowRect.left,
		windowRect.top,
		windowRect.right - windowRect.left,
		windowRect.bottom - windowRect.top,
		NULL,
		NULL,
		GetModuleHandle(NULL),
		NULL);

	ShowWindow((HWND)m_windowHandle, SW_SHOW);
	SetForegroundWindow((HWND)m_windowHandle);
	SetFocus((HWND)m_windowHandle);

	m_displayContext = GetDC((HWND)m_windowHandle);
	SwapBuffers(m_displayContext);

	HCURSOR cursor = LoadCursor(NULL, IDC_ARROW);
	SetCursor(cursor);
}

//-----------------------------------------------------------------------------------------------
// Processes all Windows messages (WM_xxx) for this App that have queued up since last frame.
// For each message in the queue, our WindowsMessageHandlingProcedure (or "WinProc") function
//	is called, telling us what hAppened (key up/down, minimized/restored, gained/lost focus, etc.)
void Window::RunMessagePump()
{
	MSG queuedMessage;
	for (;; )
	{
		const BOOL wasMessagePresent = PeekMessage(&queuedMessage, NULL, 0, 0, PM_REMOVE);
		if (!wasMessagePresent)
		{
			break;
		}

		TranslateMessage(&queuedMessage);
		DispatchMessage(&queuedMessage); // This tells Windows to call our "WindowsMessageHandlingProcedure" (a.k.a. "WinProc") function
	}
}


Vec2 Window::GetNormalizedCursorPos() const {
	HWND windowHandle = (HWND)GetHwnd();
	POINT cursorCoords;
	RECT clientRect;
	::GetCursorPos(&cursorCoords);
	::ScreenToClient(windowHandle, &cursorCoords);
	::GetClientRect(windowHandle, &clientRect);
	float cursorX = static_cast<float>(cursorCoords.x) / static_cast<float>(clientRect.right);
	float cursorY = static_cast<float>(cursorCoords.y) / static_cast<float>(clientRect.bottom);
	Vec2 actualPositionNorm = Vec2(cursorX, 1.f - cursorY);
	float verySmallPortion = 0.005f;
	AABB2 bounds = AABB2(verySmallPortion, verySmallPortion, 1.f - verySmallPortion, 1.f - verySmallPortion);
	Vec2 output = bounds.GetNearestPoint(actualPositionNorm);
	return bounds.GetNearestPoint(actualPositionNorm);
}

IntVec2 Window::GetCursorPosition() const {
	HWND windowHandle = (HWND)GetHwnd();
	POINT cursorCoords;
	RECT clientRect;
	::GetCursorPos(&cursorCoords);
	::ScreenToClient(windowHandle, &cursorCoords);
	::GetClientRect(windowHandle, &clientRect);
	return IntVec2(cursorCoords.x, clientRect.bottom - cursorCoords.y);

}

void Window::SetCursorPosition(IntVec2 position) const {
	SetCursorPos(position.x, position.y);
}

IntVec2  Window::GetWindoeCenterPos() const {
	HWND windowHandle = (HWND)GetHwnd();
	RECT clientRect;
	::GetClientRect(windowHandle, &clientRect);
	return IntVec2(clientRect.right / 2, clientRect.bottom / 2);
}


bool Window::GetIsFocused() const {
	return ::GetActiveWindow() == GetHwnd();
}