#include "Engine\Renderer\SpriteSheet.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Math\AABB2.hpp"



SpriteSheet::SpriteSheet(Texture& texture, IntVec2 const& simpleGridLayout)
	:m_texture(texture)
{
	m_simpleGridSize = simpleGridLayout;
	m_spriteDefs.reserve(m_simpleGridSize.x * m_simpleGridSize.y);
	float xInterval = 1 / static_cast<float>(m_simpleGridSize.x);
	float yInterval = 1 / static_cast<float>(m_simpleGridSize.y);
	for (int y = m_simpleGridSize.y - 1; y >= 0; y--) {
		for (int x = 0; x < m_simpleGridSize.x; x++) {
			int spriteIndex = static_cast<int>(m_spriteDefs.size());
			m_spriteDefs.emplace_back(SpriteDefinition(*this, spriteIndex, Vec2(x * xInterval, y * yInterval), Vec2((x+1) * xInterval, (y+1) * yInterval)));
		}
	}
}

Texture& SpriteSheet::GetTexture() const {
	return m_texture;
}

int SpriteSheet::GetNumSpirtes() const {
	return static_cast<int>(m_spriteDefs.size());
}

SpriteDefinition const& SpriteSheet::GetSpriteDef(int spriteIndex) const {
	return m_spriteDefs[spriteIndex];
}

SpriteDefinition const& SpriteSheet::GetSpriteDefFromSimpleGrid(IntVec2 spriteIndex2D) const {
	return m_spriteDefs[spriteIndex2D.x + m_simpleGridSize.x * spriteIndex2D.y];
}

void SpriteSheet::GetSpriteUVs(Vec2& out_uvAtMins, Vec2& out_uvAtMaxs, int spriteIndex) const {
	m_spriteDefs[spriteIndex].GetUVs(out_uvAtMins, out_uvAtMaxs);
}

AABB2 SpriteSheet::GetSpriteUVs(int spriteIndex) const {
	return m_spriteDefs[spriteIndex].GetUVs();
}