﻿#define WIN32_LEAN_AND_MEAN		// Always #define this before #including <windows.h>
#include <windows.h> 
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Renderer\Shader.hpp"
#include "Engine\Renderer\VertexBuffer.hpp"
#include "Engine\Renderer\IndexBuffer.hpp"
#include "Engine\Renderer\ConstantBuffer.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Renderer\DefaultShader.hpp"
#include "Engine\Core\Image.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Core\FileUtils.hpp"
#include "Engine\Core\EngineCommon.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Math\Mat44.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"
#include "ThirdParty/stb/stb_image.h"


//Added for DirectX support-----------------------------------------------
#define WIN32_LEAN_AND_MEAN		// Always #define this before #including <windows.h>
#include <windows.h>			// #include this (massive, platform-specific) header in very few places
#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")

#if DEBUG
#define ENGINE_DEBUG_RENDER 	// Enable debug draw
#endif

#if defined(ENGINE_DEBUG_RENDER)
#include <dxgidebug.h>
#pragma comment(lib, "dxguid.lib")
#endif


ID3D11InputLayout* m_inputLayout = nullptr;

DWORD m_flags = D3DCOMPILE_OPTIMIZATION_LEVEL3;
//DWORD m_flags = D3DCOMPILE_SKIP_OPTIMIZATION | D3DCOMPILE_DEBUG;

//two vectors of bytes to store our compiled shaders
std::vector<uint8_t> m_vectorShaderByteCode = {};
std::vector<uint8_t> m_pixelShaderByteCode = {};



struct CameraConstants {
	Mat44 ProjectionMatrix;
	Mat44 ViewMatrix;
};

struct ModelConstants {
	Mat44 ModelMatrix;
	float Color[4];
};

struct BasicLightingConstants {
	float SunColor[4];
	float AmbientColor[4];
	float SunDirection[3];
	float SunIntensity;
	float AmbientIntensity;
	float Padding[3];
};
static const int k_cameraConstantsSlot = 2;
static const int k_modelConstantsSlot = 3;
static const int k_lightingConstantsSlot = 4;

//Added for DirectX support-----------------------------------------------






Renderer::Renderer(RendererConfig const& rendererConfig)
{
	m_rendererConfig = rendererConfig;
}

Renderer::~Renderer()
{
}

void Renderer::ClearScreen(Rgba8 const& backgroundColor) {
	//Added for DirectX support-----------------------------------------------
	float tempFloatArrayColor[4] = {};
	Rgba8 greyColor = backgroundColor;
	greyColor.GetAsFloats(tempFloatArrayColor);
	m_deviceContext->ClearRenderTargetView(m_renderTargetView, tempFloatArrayColor);
	m_deviceContext->ClearDepthStencilView(m_depthStencilView, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1, 0);
	//Added for DirectX support-----------------------------------------------
}



void Renderer::DrawVertexArray(int numVertexes, Vertex_PCU const* vertexes) {
	CopyCPUToGPU(vertexes, numVertexes * sizeof(Vertex_PCU), m_immediateVBO);
	m_immediateVBO->SetStride(sizeof(Vertex_PCU));
	DrawVertexBuffer(m_immediateVBO, numVertexes, 0);

}

void Renderer::DrawVertexVector(std::vector<Vertex_PCU> const& vertexes, Shader* shaderToUse) {
	CopyCPUToGPU(vertexes.data(), (int)vertexes.size() * sizeof(Vertex_PCU), m_immediateVBO);
	m_immediateVBO->SetStride(sizeof(Vertex_PCU));
	UpdateShader(shaderToUse);
	DrawVertexBuffer(m_immediateVBO, (int)vertexes.size(), 0);
}

void Renderer::DrawVertexVector(std::vector<Vertex_PCU> const& vertexes, std::vector<unsigned int> const& indexes, Shader* shaderToUse) {
	CopyCPUToGPU(vertexes.data(), (int)vertexes.size() * sizeof(Vertex_PCU), m_immediateVBO);
	m_immediateVBO->SetStride(sizeof(Vertex_PCU));
	IndexBuffer* immediateIBO = CreateIndexBuffer(50);
	CopyCPUToGPU(indexes.data(), (int)indexes.size() * IndexBuffer::GetStride(), immediateIBO);
	UpdateShader(shaderToUse);
	DrawIndexBuffer(m_immediateVBO, immediateIBO, (int)indexes.size());
	delete immediateIBO;
}

void Renderer::DrawVertexVector(std::vector<Vertex_PNCU> const& vertexes, Shader* shaderToUse) {
	CopyCPUToGPU(vertexes.data(), (int)vertexes.size() * sizeof(Vertex_PNCU), m_immediateVBO);
	m_immediateVBO->SetStride(sizeof(Vertex_PNCU));
	UpdateShader(shaderToUse);
	DrawVertexBuffer(m_immediateVBO, (int)vertexes.size(), 0);
}

void Renderer::DrawVertexVector(std::vector<Vertex_PNCU> const& vertexes, std::vector<unsigned int> const& indexes, Shader* shaderToUse) {
	CopyCPUToGPU(vertexes.data(), (int)vertexes.size() * sizeof(Vertex_PNCU), m_immediateVBO);
	m_immediateVBO->SetStride(sizeof(Vertex_PNCU));
	IndexBuffer* immediateIBO = CreateIndexBuffer(50);
	CopyCPUToGPU(indexes.data(), (int)indexes.size() * IndexBuffer::GetStride(), immediateIBO);
	UpdateShader(shaderToUse);
	DrawIndexBuffer(m_immediateVBO, immediateIBO, (int)indexes.size());
	delete immediateIBO;
}



void Renderer::DrawVertexBuffer(VertexBuffer* vbo, int vertexCount, int vertexOffset) {
	CheckRendererSettings();
	BindVertexBuffer(vbo);
	m_deviceContext->Draw(vertexCount, UINT(vertexOffset));
}
void Renderer::DrawIndexBuffer(VertexBuffer* vbo, IndexBuffer* ibo, int indexCount) {
	CheckRendererSettings();
	BindVertexBuffer(vbo);
	BindIndexBuffer(ibo);
	m_deviceContext->DrawIndexed(indexCount, 0, 0);
}



void Renderer::BeginCamera(const Camera& camera) {
	//Added for DirectX support-----------------------------------------------
	//Setting viewport 
	D3D11_VIEWPORT viewPort1 = D3D11_VIEWPORT();
	if (!camera.m_viewPort.IsValid()) {
		viewPort1.TopLeftX = 0;
		viewPort1.TopLeftY = 0;
		viewPort1.Width = static_cast<float>(m_rendererConfig.m_window->GetClientDimensions().x);
		viewPort1.Height = static_cast<float>(m_rendererConfig.m_window->GetClientDimensions().y);
	}
	else {
		viewPort1.TopLeftX = camera.m_viewPort.m_mins.x;
		viewPort1.TopLeftY = camera.m_viewPort.m_mins.y;
		viewPort1.Width = camera.m_viewPort.m_maxs.x - camera.m_viewPort.m_mins.x;
		viewPort1.Height = camera.m_viewPort.m_maxs.y - camera.m_viewPort.m_mins.y;
	}
	viewPort1.MinDepth = 0;
	viewPort1.MaxDepth = 1;
	m_deviceContext->RSSetViewports(1, &viewPort1);

	//Setting camera
	CameraConstants localCameraConstants = CameraConstants();
	localCameraConstants.ProjectionMatrix = camera.GetProjectionMatrix();
	localCameraConstants.ViewMatrix = camera.GetViewMatrix();
	CopyCPUToGPU(&localCameraConstants, sizeof(CameraConstants), m_cameraCBO);
	BindConstantBuffer(k_cameraConstantsSlot, m_cameraCBO);
	//Added for DirectX support-----------------------------------------------
}

void Renderer::EndCamera(const Camera& camera) {
	(void)(camera);
}

void Renderer::BeginFrame() {
	//Added for DirectX support-----------------------------------------------
	m_deviceContext->OMSetRenderTargets(1, &m_renderTargetView, m_depthStencilView);
	//Added for DirectX support-----------------------------------------------

}
void Renderer::EndFrame() {
	//Added for DirectX support-----------------------------------------------
 	m_swapChain->Present(0, 0);
	//Added for DirectX support-----------------------------------------------
 }
void Renderer::Startup() {

	//Added for DirectX support-----------------------------------------------
	unsigned int deviceFlags = 0;
#if defined(ENGINE_DEBUG_RENDER)
	deviceFlags |= D3D11_CREATE_DEVICE_DEBUG;

	//Debugging stuff
	m_dxgiDebugModule = (void*)::LoadLibraryA("dxgidebug.dll");
	if (m_dxgiDebugModule == nullptr) {
		ERROR_AND_DIE("Could not load dxgidebug.dll");
	}
	typedef HRESULT(WINAPI* GetDebugModuleCB) (REFIID, void**);
	((GetDebugModuleCB)::GetProcAddress((HMODULE)m_dxgiDebugModule, "DXGIGetDebugInterface")) (_uuidof(IDXGIDebug), &m_dxgiDebug);
	if (m_dxgiDebug == nullptr) {
		ERROR_AND_DIE("Could not load debug module");
	}

	//Enable debug mode and disable optimization if in debug mode
	m_flags = D3DCOMPILE_DEBUG;
	m_flags |= D3DCOMPILE_SKIP_OPTIMIZATION;
#endif

	//Creating device and swap chain
	DXGI_MODE_DESC bufferDesc = DXGI_MODE_DESC();
	bufferDesc.Width = m_rendererConfig.m_window->GetClientDimensions().x;
	bufferDesc.Width = m_rendererConfig.m_window->GetClientDimensions().y;
	bufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	DXGI_SAMPLE_DESC sampleDesc = DXGI_SAMPLE_DESC();
	sampleDesc.Count = 1;
	DXGI_SWAP_CHAIN_DESC swapChainDesc = DXGI_SWAP_CHAIN_DESC();
	swapChainDesc.BufferDesc = bufferDesc;
	swapChainDesc.SampleDesc = sampleDesc;
	swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
	swapChainDesc.BufferCount = 2;
	swapChainDesc.OutputWindow = (HWND)m_rendererConfig.m_window->GetHwnd();
	swapChainDesc.Windowed = true;
	swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_FLIP_DISCARD;
	HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, NULL, deviceFlags, 0, 0, D3D11_SDK_VERSION, &swapChainDesc, &m_swapChain, &m_device, nullptr, &m_deviceContext);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Could not create swap chain!");
	}


	//Creating render target view 
	ID3D11Texture2D* backBuffer;
	hr = m_swapChain->GetBuffer(0, _uuidof(ID3D11Texture2D), (void**)&backBuffer);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Could not get swap chain buffer!");
	}
	hr = m_device->CreateRenderTargetView(backBuffer, NULL, &m_renderTargetView);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Could not create render target view for swap chain buffer!");
	}
	DX_SAFE_RELEASE(backBuffer);

	//Create and bind default shader
	m_defaultShader = CreateShader("Default", m_shaderSource);
	BindShader(m_defaultShader);
	m_immediateVBO = CreateVertexBuffer(50);
	//Create and bind default texture
	m_defaultTexture = CreateTextureFromImage(Image(IntVec2(1,1), Rgba8(255,255,255,255)));
	BindTexture(m_defaultTexture);


	//Initialize constant buffers
	m_cameraCBO = CreateConstantBuffer(sizeof(CameraConstants));
	m_modelCBO = CreateConstantBuffer(sizeof(ModelConstants));
	m_lightingCBO = CreateConstantBuffer(sizeof(BasicLightingConstants));


	D3D11_TEXTURE2D_DESC textureDesc = D3D11_TEXTURE2D_DESC();
	textureDesc.Width = m_rendererConfig.m_window->GetClientDimensions().x;
	textureDesc.Height = m_rendererConfig.m_window->GetClientDimensions().y;
	textureDesc.MipLevels = 1;
	textureDesc.ArraySize = 1;
	textureDesc.Usage = D3D11_USAGE_DEFAULT;
	textureDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
	textureDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
	textureDesc.SampleDesc.Count = 1;
	m_device->CreateTexture2D(&textureDesc, nullptr, &m_depthStencilTexture);
	m_device->CreateDepthStencilView(m_depthStencilTexture, nullptr, &m_depthStencilView);

	//Different default settings for 3D and 2D games
	m_desiredDepthMode = DepthMode::DEPTHMODE_DISABLED;
	m_desiredRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_NONE;
#if defined(ENGINE_IS_3DGAME)
	m_desiredDepthMode = DepthMode::DEPTHMODE_ENABLED;
	m_desiredRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_BACK;
#endif

	//Make and set rasterizer state
	MakeRasterizerStates();
	SetRasterizerMode(m_desiredRasterizerMode);
	//Make and set blend state
	MakeBlendStates();
	SetBlendMode(m_desiredBlendMode);
	//Make and set sampler state
	MakeSamplerStates();
	SetSamplerMode(m_desiredSamplerMode);
	//Make and set depth state
	MakeDepthStencilStates();
	SetDepthStencilMode(m_desiredDepthMode);


	SetModelConstants();	//Set it to default for the sake of backward compatibility
	//Added for DirectX support-----------------------------------------------


}
void Renderer::Shutdown() {
	//Added for DirectX support-----------------------------------------------
	DX_SAFE_RELEASE(m_swapChain);
	DX_SAFE_RELEASE(m_deviceContext);
	DX_SAFE_RELEASE(m_device);
	DX_SAFE_RELEASE(m_renderTargetView);

	DX_SAFE_RELEASE(m_depthStencilView);
	DX_SAFE_RELEASE(m_depthStencilTexture);


	for (int index = 0; index < m_loadedShaders.size(); index++) {
		if (m_loadedShaders[index] != nullptr) {
			delete(m_loadedShaders[index]);
		}
	}
	for (int index = 0; index < m_loadedTextures.size(); index++) {
		if (m_loadedTextures[index] != nullptr) {
			delete(m_loadedTextures[index]);
		}
	}
	for (int index = 0; index < m_loadedFonts.size(); index++) {
		if (m_loadedFonts[index] != nullptr) {
			delete(m_loadedFonts[index]);
		}
	}
	for (int index = 0; index < m_blendStates.size(); index++) {
		DX_SAFE_RELEASE(m_blendStates[index]);
	}
	for (int index = 0; index < m_samplerStates.size(); index++) {
		DX_SAFE_RELEASE(m_samplerStates[index]);
	}
	for (int index = 0; index < m_rasterizerStates.size(); index++) {
		DX_SAFE_RELEASE(m_rasterizerStates[index]);
	}
	for (int index = 0; index < m_depthStencilStates.size(); index++) {
		DX_SAFE_RELEASE(m_depthStencilStates[index]);
	}
	
	delete m_immediateVBO;
	delete m_cameraCBO;
	delete m_modelCBO;
	delete m_lightingCBO;
	//delete m_defaultShader;
	//delete m_defaultTexture;

#if defined(ENGINE_DEBUG_RENDER)
	((IDXGIDebug*)m_dxgiDebug)->ReportLiveObjects(DXGI_DEBUG_ALL, (DXGI_DEBUG_RLO_FLAGS)(DXGI_DEBUG_RLO_DETAIL | DXGI_DEBUG_RLO_IGNORE_INTERNAL));
	((IDXGIDebug*)m_dxgiDebug)->Release();
	m_dxgiDebug = nullptr;
	::FreeLibrary((HMODULE)m_dxgiDebugModule);
	m_dxgiDebugModule = nullptr;
#endif
	//Added for DirectX support-----------------------------------------------
}




//Helper functions------------------------------------------------------------------------
void Renderer::UpdateVertexList(int vertexCount, Vertex_PCU* corners, Vec3* const shape, Vec3 const& position, float angleDegrees, float scale) const {
	Vec2 localBasisX = Vec2(CosDegrees(angleDegrees), SinDegrees(angleDegrees));
	Vec2 localBasisY = localBasisX.GetRotated90Degrees();
	for (int index = 0; index < vertexCount; index++) {
		Vec3 shapeInGobalSpace = shape[index] * scale;
		TransformPositionXY3D(shapeInGobalSpace, localBasisX, localBasisY, Vec2());
		corners[index].m_position = position + shapeInGobalSpace;
	}
}

void Renderer::UpdateVertexVector(std::vector<Vertex_PCU>& vertexes, Vec3* const shape, Vec3 const& position, float angleDegrees, float scale) const {
	UpdateVertexList((int)vertexes.size(), vertexes.data(), shape, position, angleDegrees, scale);
}

void Renderer::DrawRing(Vec2 const& center, float radius, int edgeCount, float width, Rgba8 const& color) {
	std::vector<Vertex_PCU> vertexes;
	AddVertsForRing(vertexes, center, radius, edgeCount, width, color);
	DrawVertexVector(vertexes);
}


void Renderer::DrawDisk(Vec2 const& startLocation, float radius, int edgeCount, Rgba8 const& color, Rgba8 const& edgeColor) {
	std::vector<Vertex_PCU> vertexes;
	AddVertsForDisk(vertexes, startLocation, radius, edgeCount, color, edgeColor);
	DrawVertexVector(vertexes);
}

void Renderer::DrawLine(Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& color) {
	std::vector<Vertex_PCU> vertexes;
	AddVertsForLine2D(vertexes, startLocation, endLocation, width, color);
	DrawVertexVector(vertexes);
}


void Renderer::RenderHealthBar(Vec2 drawPosition, float unitRadius, float HP, float maxHp, float barThickness) {
	std::vector<Vertex_PCU> vertexes;
	AddVertsForHealthBar(vertexes, drawPosition, unitRadius, HP, maxHp, barThickness);
	DrawVertexVector(vertexes);
}
void Renderer::RenderEnergyBar(Vec2 drawPosition, float unitRadius, float energy, float maxEnergy, float barThickness) {
	std::vector<Vertex_PCU> vertexes;
	AddVertsForEnergyBar(vertexes, drawPosition, unitRadius, energy, maxEnergy, barThickness);
	DrawVertexVector(vertexes);
}

void Renderer::AddVertsForHealthBar(std::vector<Vertex_PCU>& vertexes, Vec2 drawPosition, float unitRadius, float HP, float maxHp, float rendarThickness) const {
	Vec2 healthBarLocation = drawPosition;
	healthBarLocation.y -= unitRadius * 0.75f + rendarThickness * 0.5f;
	float healthBarLength = unitRadius * 1.6f;
	float healthBarLeft = healthBarLocation.x - healthBarLength / 2;
	float healthBarRight = healthBarLocation.x + healthBarLength / 2;
	float healthBarFillSpot = healthBarLeft + healthBarLength * static_cast<float>(HP) / static_cast<float>(maxHp);
	//Draw health bar itself
	AddVertsForLine2D(vertexes, Vec2(healthBarLeft, healthBarLocation.y), Vec2(healthBarFillSpot, healthBarLocation.y), rendarThickness, Rgba8(255, 0, 0, 165));
	//Draw health bar edges
	AddVertsBarMargin(vertexes, healthBarLeft, healthBarRight, healthBarLocation.y, rendarThickness, Rgba8(255, 255, 255, 165));
}


void Renderer::AddVertsForEnergyBar(std::vector<Vertex_PCU>& vertexes, Vec2 drawPosition, float unitRadius, float energy, float maxEnergy, float rendarThickness) const {
	Vec2 energyBarLocation = drawPosition;
	energyBarLocation.y -= unitRadius * 0.75f - rendarThickness * 0.5f;
	float energyBarLength = unitRadius * 1.6f;
	float energyBarLeft = energyBarLocation.x - energyBarLength * 0.5f;
	float energyBarRight = energyBarLocation.x + energyBarLength * 0.5f;
	float energyBarFillSpot = energyBarLeft + energyBarLength * static_cast<float>(energy) / static_cast<float>(maxEnergy);
	//Draw energy bar itself
	AddVertsForLine2D(vertexes, Vec2(energyBarLeft, energyBarLocation.y), Vec2(energyBarFillSpot, energyBarLocation.y), rendarThickness, Rgba8(0, 0, 255, 165));
	//Draw energy bar edges
	AddVertsBarMargin(vertexes, energyBarLeft, energyBarRight, energyBarLocation.y, rendarThickness, Rgba8(255, 255, 255, 165));
}


void Renderer::AddVertsBarMargin(std::vector<Vertex_PCU>& vertexes, float barLeft, float barRight, float barY, float rendarThickness, Rgba8 lineColor) const {
	AddVertsForLine2D(vertexes, Vec2(barLeft, barY + rendarThickness / 2), Vec2(barRight, barY + rendarThickness / 2), rendarThickness / 5, lineColor);
	AddVertsForLine2D(vertexes, Vec2(barLeft, barY - rendarThickness / 2), Vec2(barRight, barY - rendarThickness / 2), rendarThickness / 5, lineColor);
	AddVertsForLine2D(vertexes, Vec2(barLeft, barY + rendarThickness / 2), Vec2(barLeft, barY - rendarThickness / 2), rendarThickness / 5, lineColor);
	AddVertsForLine2D(vertexes, Vec2(barRight, barY + rendarThickness / 2), Vec2(barRight, barY - rendarThickness / 2), rendarThickness / 5, lineColor);
}


Texture* Renderer::GetTextureForFileName(char const* imageFilePath) {
	for (int index = 0; index < m_loadedTextures.size(); index++) {
		if (m_loadedTextures[index]->m_name == imageFilePath) {
			return m_loadedTextures[index];
		}
	}
	return nullptr;
}


Texture* Renderer::CreateOrGetTextureFromFile(char const* imageFilePath) {
	return CreateTextureFromImage(Image(imageFilePath));
}


Texture* Renderer::CreateTextureFromImage(const Image& image) {
	DXGI_SAMPLE_DESC sampleDescription = DXGI_SAMPLE_DESC();
	sampleDescription.Count = 1;
	D3D11_TEXTURE2D_DESC textureDescription = D3D11_TEXTURE2D_DESC();
	textureDescription.Width = image.GetDimensions().x;
	textureDescription.Height = image.GetDimensions().y;
	textureDescription.MipLevels = 1;
	textureDescription.ArraySize = 1;
	textureDescription.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	textureDescription.Usage = D3D11_USAGE_IMMUTABLE;
	textureDescription.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	textureDescription.SampleDesc = sampleDescription;
	D3D11_SUBRESOURCE_DATA subresourceData = D3D11_SUBRESOURCE_DATA();
	subresourceData.pSysMem = image.GetRawData();
	subresourceData.SysMemPitch = image.GetDimensions().x * image.GetNumChannels();

	Texture* outputTexture = new Texture();
	//ERROR_RECOVERABLE("Texture name: " + outputTexture->m_name + ".");
	HRESULT hr = m_device->CreateTexture2D(&textureDescription, &subresourceData, &(outputTexture->m_texture));
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Failed to create texture!");
	}

	hr = m_device->CreateShaderResourceView(outputTexture->m_texture, NULL, &outputTexture->m_shaderResourceView);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Failed to create shader resource view for texture!");
	}
	outputTexture->m_name = image.m_imageFilePath;
	m_loadedTextures.emplace_back(outputTexture);
	return outputTexture;
}

BitmapFont* Renderer::CreateOrGetBitmapFont(char const* bitmapFontFilePathWithNoExtension) {
	std::string fileName = std::string(bitmapFontFilePathWithNoExtension) + ".png";
	Texture* fontTexture = CreateOrGetTextureFromFile(fileName.c_str());
	BitmapFont* result = new BitmapFont(fileName.c_str(), *fontTexture);
	m_loadedFonts.emplace_back(result);  //Keep track of it so it can be deleted
	return result;
}


//------------------------------------------------------------------------------------------------
Texture* Renderer::CreateTextureFromFile(char const* imageFilePath)
{
	IntVec2 dimensions = IntVec2(0,0);		// This will be filled in for us to indicate image width & height
	int bytesPerTexel = 0; // This will be filled in for us to indicate how many color components the image had (e.g. 3=RGB=24bit, 4=RGBA=32bit)
	int numComponentsRequested = 0; // don't care; we support 3 (24-bit RGB) or 4 (32-bit RGBA)

	// Load (and decompress) the image RGB(A) bytes from a file on disk into a memory buffer (array of bytes)
	stbi_set_flip_vertically_on_load(1); // We prefer uvTexCoords has origin (0,0) at BOTTOM LEFT
	unsigned char* texelData = stbi_load(imageFilePath, &dimensions.x, &dimensions.y, &bytesPerTexel, numComponentsRequested);
	// Check if the load was successful
	GUARANTEE_OR_DIE(texelData, Stringf("Failed to load image \"%s\"", imageFilePath));

	Texture* newTexture = CreateTextureFromData(imageFilePath, dimensions, bytesPerTexel, texelData);

	// Free the raw image texel data now that we've sent a copy of it down to the GPU to be stored in video memory
	stbi_image_free(texelData);

	return newTexture;
}

//------------------------------------------------------------------------------------------------
Texture* Renderer::CreateTextureFromData(char const* name, IntVec2 dimensions, int bytesPerTexel, uint8_t* texelData)
{
	// Check if the load was successful
	GUARANTEE_OR_DIE(texelData, Stringf("CreateTextureFromData failed for \"%s\" - texelData was null!", name));
	GUARANTEE_OR_DIE(bytesPerTexel >= 3 && bytesPerTexel <= 4, Stringf("CreateTextureFromData failed for \"%s\" - unsupported BPP=%i (must be 3 or 4)", name, bytesPerTexel));
	GUARANTEE_OR_DIE(dimensions.x > 0 && dimensions.y > 0, Stringf("CreateTextureFromData failed for \"%s\" - illegal texture dimensions (%i x %i)", name, dimensions.x, dimensions.y));

	Texture* newTexture = new Texture();
	newTexture->m_name = name; // NOTE: m_name must be a std::string, otherwise it may point to temporary data!
	newTexture->m_dimensions = dimensions;

	//To be done

	m_loadedTextures.emplace_back(newTexture);
	return newTexture;
}

//-----------------------------------------------------------------------------------------------
void Renderer::BindTexture(Texture* texture) {
	if (texture == nullptr) {
		texture = m_defaultTexture;
	}
	m_deviceContext->PSSetShaderResources(0,1,&texture->m_shaderResourceView);
}


void Renderer::CheckRendererSettings() {
	if (m_desiredBlendMode != m_currentBlendMode) {
		SetBlendMode(m_desiredBlendMode);
	}
	if (m_desiredDepthMode != m_currentDepthMode) {
		SetDepthStencilMode(m_desiredDepthMode);
	}
	if (m_desiredRasterizerMode != m_currentRasterizerMode) {
		SetRasterizerMode(m_desiredRasterizerMode);
	}
	if (m_desiredSamplerMode != m_currentSamplerMode) {
		SetSamplerMode(m_desiredSamplerMode);
	}
}

//How do we draw over existing stuff, addictive or alpha? 
void Renderer::SetBlendMode(BlendMode blendMode) {
	float blendFactor[4] = { 0,0,0,0};
	m_deviceContext->OMSetBlendState(m_blendStates[blendMode], blendFactor, 0xffffffff);
	m_currentBlendMode = blendMode;
}

void Renderer::MakeBlendStates() {
	m_blendStates.resize(BlendMode::BLENDMODE_COUNT);
	for (int index = 0; index < BlendMode::BLENDMODE_COUNT; index++) {
		D3D11_BLEND_DESC blendDesc = D3D11_BLEND_DESC();
		blendDesc.RenderTarget[0].BlendEnable = true;
		if (index == BlendMode::BLENDMODE_OPAQUE) {
			blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
			blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ZERO;
		}
		if (index == BlendMode::BLENDMODE_ALPHA) {
			blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
			blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
		}
		if (index == BlendMode::BLENDMODE_ADDITIVE) {
			blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
			blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
		}
		blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
		blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
		blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
		blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
		blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
		HRESULT hr = m_device->CreateBlendState(&blendDesc, &(m_blendStates[index]));
		if (!SUCCEEDED(hr)) {
			ERROR_AND_DIE("Create blend state failed!");
		}
	}
}

void Renderer::SetSamplerMode(SamplerMode samplerMode) {
	m_deviceContext->PSSetSamplers(0, 1, &(m_samplerStates[samplerMode]));
	m_currentSamplerMode = samplerMode;
}

void Renderer::MakeSamplerStates() {
	m_samplerStates.resize(SamplerMode::SAMPLEMODE_COUNT);
	for (int index = 0; index < SamplerMode::SAMPLEMODE_COUNT; index++) {
		D3D11_SAMPLER_DESC samplerDesc = D3D11_SAMPLER_DESC();
		if (index == SamplerMode::SAMPLEMODE_POINT_CLAMP) {
			samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
			samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
			samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
			samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
		}
		if (index == SamplerMode::SAMPLEMODE_BILINEAR_WRAP) {
			samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
			samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
			samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
			samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
		}
		samplerDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
		samplerDesc.MaxLOD = D3D11_FLOAT32_MAX;
		m_deviceContext->PSSetSamplers(0, 1, &(m_samplerStates[index]));
		HRESULT hr = m_device->CreateSamplerState(&samplerDesc, &(m_samplerStates[index]));
		if (!SUCCEEDED(hr)) {
			ERROR_AND_DIE("Create sampler state failed!");
		}
	}
}

void Renderer::SetRasterizerMode(RasterizerMode rasterizerMode) {
	m_deviceContext->RSSetState(m_rasterizerStates[rasterizerMode]);
	m_currentRasterizerMode = rasterizerMode;
}

void Renderer::MakeRasterizerStates() {
	m_rasterizerStates.resize(RasterizerMode::RASTERIZERMODE_COUNT);
	for (int index = 0; index < RasterizerMode::RASTERIZERMODE_COUNT; index++) {
		D3D11_RASTERIZER_DESC rasterizerDesc = D3D11_RASTERIZER_DESC();
		if (index == RasterizerMode::RASTERIZERMODE_SOLID_CULL_NONE) {
			rasterizerDesc.CullMode = D3D11_CULL_NONE;
			rasterizerDesc.FillMode = D3D11_FILL_SOLID;
		}
		if (index == RasterizerMode::RASTERIZERMODE_SOLID_CULL_BACK) {
			rasterizerDesc.CullMode = D3D11_CULL_BACK;
			rasterizerDesc.FillMode = D3D11_FILL_SOLID;
		}
		if (index == RasterizerMode::RASTERIZERMODE_WIREFRAME_CULL_NONE) {
			rasterizerDesc.CullMode = D3D11_CULL_NONE;
			rasterizerDesc.FillMode = D3D11_FILL_WIREFRAME;
		}
		if (index == RasterizerMode::RASTERIZERMODE_WIREFRAME_CULL_BACK) {
			rasterizerDesc.CullMode = D3D11_CULL_BACK;
			rasterizerDesc.FillMode = D3D11_FILL_WIREFRAME;
		}
		rasterizerDesc.DepthClipEnable = true;
		rasterizerDesc.FrontCounterClockwise = true;
		rasterizerDesc.AntialiasedLineEnable = true;
		HRESULT hr = m_device->CreateRasterizerState(&rasterizerDesc, &(m_rasterizerStates[index]));
		if (!SUCCEEDED(hr)) {
			ERROR_AND_DIE("Create rasterizer state failed!");
		}
	}
}

void Renderer::SetDepthStencilMode(DepthMode depthMode) {
	m_deviceContext->OMSetDepthStencilState(m_depthStencilStates[depthMode], 0);
	m_currentDepthMode = depthMode;
}

void Renderer::MakeDepthStencilStates() {
	m_depthStencilStates.resize(DepthMode::DEPTHMODE_COUNT);
	for (int index = 0; index < DepthMode::DEPTHMODE_COUNT; index++) {
		D3D11_DEPTH_STENCIL_DESC depthDesc = D3D11_DEPTH_STENCIL_DESC();
		if (index == DepthMode::DEPTHMODE_ENABLED) {
			depthDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
			depthDesc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
		}
		if (index == DepthMode::DEPTHMODE_DISABLED) {
			depthDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
			depthDesc.DepthFunc = D3D11_COMPARISON_ALWAYS;
		}
		depthDesc.DepthEnable = true;
		HRESULT hr = m_device->CreateDepthStencilState(&depthDesc, &m_depthStencilStates[index]);
		if (!SUCCEEDED(hr)) {
			ERROR_AND_DIE("Create depth stencil state failed!");
		}
	}
}



//Added for DirectX support-----------------------------------------------
void Renderer::BindShader(Shader* shader) {
	if (shader == nullptr) {
		shader = m_defaultShader;
	}
	if (shader == m_currentShader) {
		return;
	}
	m_deviceContext->VSSetShader(shader->m_vertexShader, NULL, 0);
	m_deviceContext->PSSetShader(shader->m_pixelShader, NULL, 0);
	m_deviceContext->IASetInputLayout(shader->m_inputLayout);
	m_currentShader = shader;
}

void Renderer::UpdateShader(Shader* shaderToUse) {
	if (shaderToUse == nullptr) {
		if (m_currentShader == nullptr) {
			BindShader(m_defaultShader);
		}
		return;
	}
	if (shaderToUse != m_currentShader) {
		BindShader(shaderToUse);
	}

}

void  Renderer::UseDefaultShader() {
	UpdateShader(m_defaultShader);
}
Shader* Renderer::CreateShader(char const* shaderName, char const* source) {
	ShaderConfig config = ShaderConfig();
	config.m_name = shaderName;
	Shader* createdShader = new Shader(config);
	//The vector is just a dynamic array of bytes where we can pass data between functions.
	std::vector<unsigned char> outputDummyVector1;
	CompileShaderToByteCode(outputDummyVector1, shaderName, source, config.m_vertexEntryPoint.c_str(), "vs_5_0");
	HRESULT hr = m_device->CreateVertexShader(&outputDummyVector1[0], outputDummyVector1.size(), nullptr, &createdShader->m_vertexShader);
	std::vector<unsigned char> outputDummyVector2;
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Shader creation failed!");
	}
	CompileShaderToByteCode(outputDummyVector2, shaderName, source, config.m_pixelEntryPoint.c_str(), "ps_5_0");
	hr = m_device->CreatePixelShader(&outputDummyVector2[0], outputDummyVector2.size(), nullptr, &createdShader->m_pixelShader);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Shader creation failed!");
	}

	//Creating input layout
	D3D11_INPUT_ELEMENT_DESC inputElementDescDefault[] = {
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Vertex_PCU, m_position), D3D11_INPUT_PER_VERTEX_DATA, 0},
		{"COLOR", 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, offsetof(Vertex_PCU, m_color), D3D11_INPUT_PER_VERTEX_DATA, 0},
		{"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(Vertex_PCU, m_uvTexCoords), D3D11_INPUT_PER_VERTEX_DATA, 0},
	};
	D3D11_INPUT_ELEMENT_DESC inputElementDescWithNormal[] = {
		{"POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Vertex_PNCU, m_position), D3D11_INPUT_PER_VERTEX_DATA, 0},
		{"NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Vertex_PNCU, m_surfaceNormal), D3D11_INPUT_PER_VERTEX_DATA, 0},
		{"COLOR", 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, offsetof(Vertex_PNCU, m_color), D3D11_INPUT_PER_VERTEX_DATA, 0},
		{"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(Vertex_PNCU, m_uvTexCoords), D3D11_INPUT_PER_VERTEX_DATA, 0},
	};
	if (std::string(shaderName).find("Lit") == std::string::npos) {
		hr = m_device->CreateInputLayout(inputElementDescDefault, 3, &outputDummyVector1[0], outputDummyVector1.size(), &m_inputLayout);
	} else {
		hr = m_device->CreateInputLayout(inputElementDescWithNormal, 4, &outputDummyVector1[0], outputDummyVector1.size(), &m_inputLayout);
	}
	if (!SUCCEEDED(hr) || m_inputLayout == nullptr) {
		ERROR_AND_DIE("Failed to create input layout!");
	}
	createdShader->m_inputLayout = m_inputLayout;
	m_loadedShaders.emplace_back(createdShader);
	return createdShader;

}

Shader* Renderer::CreateShader(char const* shaderName) {
	std::string shaderFileNamePath = shaderName;
	shaderFileNamePath = shaderFileNamePath + ".hlsl";
	std::string contentString;
	FileReadToString(contentString, shaderFileNamePath);
	return CreateShader(shaderName, contentString.c_str());
}


void Renderer::SetModelConstants(const Mat44& modelMatrix, const Rgba8& modelColor) {
	//Setting 
	ModelConstants localModelConstants = ModelConstants();
	localModelConstants.ModelMatrix = modelMatrix;
	localModelConstants.Color[0] = modelColor.r / 255.f;
	localModelConstants.Color[1] = modelColor.g / 255.f;
	localModelConstants.Color[2] = modelColor.b / 255.f;
	localModelConstants.Color[3] = modelColor.a / 255.f;
	CopyCPUToGPU(&localModelConstants, sizeof(ModelConstants), m_modelCBO);
	BindConstantBuffer(k_modelConstantsSlot, m_modelCBO);
}

void Renderer::SetLightingConstants(const Vec3& sunDirection, float sunIntensity, float ambientIntensity, const Rgba8& sunColor, const Rgba8& ambientColor) {

	BasicLightingConstants localLightingConstants = BasicLightingConstants();
	localLightingConstants.SunDirection[0] = sunDirection.x;
	localLightingConstants.SunDirection[1] = sunDirection.y;
	localLightingConstants.SunDirection[2] = sunDirection.z;

	localLightingConstants.SunIntensity = sunIntensity;
	localLightingConstants.AmbientIntensity = ambientIntensity;

	localLightingConstants.SunColor[0] = sunColor.r / 255.f;
	localLightingConstants.SunColor[1] = sunColor.g / 255.f;
	localLightingConstants.SunColor[2] = sunColor.b / 255.f;
	localLightingConstants.SunColor[3] = sunColor.a / 255.f;
	localLightingConstants.AmbientColor[0] = ambientColor.r / 255.f;
	localLightingConstants.AmbientColor[1] = ambientColor.g / 255.f;
	localLightingConstants.AmbientColor[2] = ambientColor.b / 255.f;
	localLightingConstants.AmbientColor[3] = ambientColor.a / 255.f;
	CopyCPUToGPU(&localLightingConstants, sizeof(BasicLightingConstants), m_lightingCBO);
	BindConstantBuffer(k_lightingConstantsSlot, m_lightingCBO);
}





bool Renderer::CompileShaderToByteCode(std::vector<unsigned char>& outByteCode, char const* name,
	char const* source, char const* entryPoint, char const* target) {
	ID3DBlob* blob1 = nullptr;
	ID3DBlob* blob2 = nullptr;
	//DWORD flags = D3DCOMPILE_DEBUG;
	//flags |= D3DCOMPILE_SKIP_OPTIMIZATION;
	//flags |= D3DCOMPILE_WARNINGS_ARE_ERRORS;
	HRESULT hr = D3DCompile(source, strlen(source), name, nullptr, nullptr, entryPoint, target, m_flags, 0, &blob1, &blob2);
	if (!SUCCEEDED(hr)) {
		std::string errorMessage = reinterpret_cast<const char*>(blob2->GetBufferPointer());
		ERROR_AND_DIE("Shader compile failed! \n" + errorMessage);
	}
	outByteCode.resize(blob1->GetBufferSize());
	memcpy(&outByteCode[0], blob1->GetBufferPointer(), blob1->GetBufferSize());
	return true;
}


//Vertex buffer stuff
VertexBuffer* Renderer::CreateVertexBuffer(const size_t size) {
	VertexBuffer* output = new VertexBuffer(UINT(size));
	D3D11_BUFFER_DESC theBufferDesc = D3D11_BUFFER_DESC();
	theBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	theBufferDesc.ByteWidth = UINT(size);
	theBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	theBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	m_device->CreateBuffer(&theBufferDesc, nullptr, &output->m_buffer);
	return output;
}
IndexBuffer* Renderer::CreateIndexBuffer(const size_t size) {
	IndexBuffer* output = new IndexBuffer(UINT(size));
	D3D11_BUFFER_DESC theBufferDesc = D3D11_BUFFER_DESC();
	theBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	theBufferDesc.ByteWidth = UINT(size);
	theBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	theBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	m_device->CreateBuffer(&theBufferDesc, nullptr, &output->m_buffer);
	return output;
}


void Renderer::CopyCPUToGPU(const void* data, size_t size, VertexBuffer*& vbo) {
	D3D11_MAPPED_SUBRESOURCE subResource;
	if (vbo->m_size < size) {
		delete vbo;
		vbo = CreateVertexBuffer(size);
	}
	HRESULT hr = m_deviceContext->Map(vbo->m_buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &subResource);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Vertex buffer map failed!");
	}
	memcpy(subResource.pData, data, size);
	m_deviceContext->Unmap(vbo->m_buffer, 0);
}
void Renderer::CopyCPUToGPU(const void* data, size_t size, IndexBuffer*& ibo) {
	D3D11_MAPPED_SUBRESOURCE subResource;
	if (ibo->m_size < size) {
		delete ibo;
		ibo = CreateIndexBuffer(size);
	}
	HRESULT hr = m_deviceContext->Map(ibo->m_buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &subResource);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Index buffer map failed!");
	}
	memcpy(subResource.pData, data, size);
	m_deviceContext->Unmap(ibo->m_buffer, 0);
}

void Renderer::BindVertexBuffer(VertexBuffer* vbo) {
	UINT stride = vbo->GetStride();
	UINT zeroUINT = 0;
	m_deviceContext->IASetVertexBuffers(0, 1, &vbo->m_buffer, &stride, &zeroUINT);
	m_deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
}

void Renderer::BindIndexBuffer(IndexBuffer* ibo) {
	m_deviceContext->IASetIndexBuffer(ibo->m_buffer, DXGI_FORMAT_R32_UINT, 0);
	m_deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
}

//Constant buffer stuff

ConstantBuffer* Renderer::CreateConstantBuffer(const size_t size) {
	ConstantBuffer* output = new ConstantBuffer(UINT(size));
	D3D11_BUFFER_DESC theBufferDesc = D3D11_BUFFER_DESC();
	theBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	theBufferDesc.ByteWidth = UINT(size);
	theBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	theBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	theBufferDesc.StructureByteStride = sizeof(UINT);
	HRESULT hr = m_device->CreateBuffer(&theBufferDesc, nullptr, &output->m_buffer);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Buffer creation failed! \n");
	}
	return output;
}
void Renderer::CopyCPUToGPU(const void* data, size_t size, ConstantBuffer*& cbo) {
	D3D11_MAPPED_SUBRESOURCE subResource;
	if (cbo->m_size < size) {
		ERROR_AND_DIE("Constant buffer too small!");
	}
	HRESULT hr = m_deviceContext->Map(cbo->m_buffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &subResource);
	if (!SUCCEEDED(hr)) {
		ERROR_AND_DIE("Buffer map failed!");
	}
	memcpy(subResource.pData, data, size);
	m_deviceContext->Unmap(cbo->m_buffer, 0);
}
void Renderer::BindConstantBuffer(int slot, ConstantBuffer* cbo) {
	m_deviceContext->VSSetConstantBuffers(slot, 1, &(cbo->m_buffer));
	m_deviceContext->PSSetConstantBuffers(slot, 1, &(cbo->m_buffer));
}

//Added for DirectX support-----------------------------------------------