#pragma once
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Renderer\SpriteSheet.hpp"
#include <string>
#include <vector>
struct Vertex_PCU;
struct Vec2;
struct AABB2;
struct Rgb8;
struct Mat44;

enum TextDrawMode { SHRINK_TO_FIT, OVERRUN };

class BitmapFont
{
friend class Renderer; // Only the Renderer can create new BitmapFont objects!

	~BitmapFont();
private:
	BitmapFont(char const* fontFilePathNameWithNoExtension, Texture& fontTexture);  //The private constructor


public:
	Texture& GetTexture() const;

	float GetTextWidth(float cellHeight, std::string const& text, float cellAspect = 1.f) const;
	void AddVertsForText2D(std::vector<Vertex_PCU>& verts, Vec2 const& topLeft, float cellHeight, std::string const& text, Rgba8 const& tint = Rgba8(), float cellAspect = 1.f) const;
	void AddVertsForTextInBox2D(std::vector<Vertex_PCU>& verts, AABB2 const& box, float cellHeight, std::string const& text, Rgba8 const& tint = Rgba8(),
		float cellAspect = 1.f, Vec2 const& alignment = Vec2(.5f, .5f), TextDrawMode mode = TextDrawMode::SHRINK_TO_FIT, int maxGlyphsToDraw = INT_MAX) const;
	void AddVertsForTextBillboard(std::vector<Vertex_PCU>& verts, Vec2 const& billBoardSize, Mat44 billboardTransform, float cellHeight, std::string const& text, Rgba8 const& tint = Rgba8(),
		float cellAspect = 1.f, Vec2 const& alignment = Vec2(.5f, .5f), TextDrawMode mode = TextDrawMode::SHRINK_TO_FIT, int maxGlyphsToDraw = INT_MAX) const;


protected:
	float GetGlyphAspect(int glyphUnicode) const;

	std::string	m_fontFilePathNameWithNoExtension;
	SpriteSheet m_fontGlyphsSpriteSheet;
};
