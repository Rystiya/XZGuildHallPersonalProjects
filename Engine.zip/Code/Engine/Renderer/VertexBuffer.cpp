﻿
#include "Engine\Renderer\VertexBuffer.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Core\EngineCommon.hpp"

//Added for DirectX support-----------------------------------------------
#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "d3dcompiler.lib")


//Added for DirectX support-----------------------------------------------


VertexBuffer::VertexBuffer(size_t size)
	: m_size(size)
{
	m_stride = sizeof(Vertex_PCU);
}

VertexBuffer::~VertexBuffer() {
	DX_SAFE_RELEASE(m_buffer);
}

