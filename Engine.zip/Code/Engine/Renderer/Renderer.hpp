﻿#pragma once
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Renderer\Camera.hpp"
#include "Engine\Renderer\BitmapFont.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Window\Window.hpp"
#include "Engine\Core\EngineCommon.hpp"
#include <vector>

//Added for DirectX support-----------------------------------------------
//Add "\" after each line when coding multi-line macro 
#define DX_SAFE_RELEASE(dxObject) { if ((dxObject) != nullptr) { (dxObject)->Release(); (dxObject) = nullptr;  } }
struct ID3D11RasterizerState;
struct ID3D11RenderTargetView;
struct ID3D11Device;
struct ID3D11DeviceContext;
struct IDXGISwapChain;
struct ID3D11BlendState;
struct ID3D11SamplerState;
struct ID3D11DepthStencilState;
struct ID3D11DepthStencilView;
struct ID3D11Texture2D;

class Shader;
class VertexBuffer;
class IndexBuffer;
class ConstantBuffer;
class Image;
//Added for DirectX support-----------------------------------------------

struct RendererConfig {
	Window* m_window = nullptr;
};
struct IntVec2;


//Opaque might have already been defined elsewhere
#if defined(OPAQUE)
#undef OPAQUE
#endif
enum BlendMode { BLENDMODE_OPAQUE, BLENDMODE_ALPHA, BLENDMODE_ADDITIVE, BLENDMODE_COUNT };
enum SamplerMode { SAMPLEMODE_POINT_CLAMP, SAMPLEMODE_BILINEAR_WRAP, SAMPLEMODE_COUNT };
enum RasterizerMode { RASTERIZERMODE_SOLID_CULL_NONE, RASTERIZERMODE_SOLID_CULL_BACK, RASTERIZERMODE_WIREFRAME_CULL_NONE, RASTERIZERMODE_WIREFRAME_CULL_BACK, RASTERIZERMODE_COUNT };
enum DepthMode { DEPTHMODE_DISABLED, DEPTHMODE_ENABLED, DEPTHMODE_COUNT };

//This thing controls graphics
//-----------------------------------------------------------------------------------------------
class Renderer
{
	public:


		Renderer(RendererConfig const& config);
		~Renderer();
		void ClearScreen(Rgba8 const& backgroundColor = Rgba8(0, 0, 0, 255));
		//old function, don't use
		void DrawVertexArray(int numVertexes, Vertex_PCU const* vertexes);
		//Use these
		void DrawVertexVector(std::vector<Vertex_PCU> const& vertexes, Shader* shaderToUse = nullptr);
		void DrawVertexVector(std::vector<Vertex_PCU> const& vertexes, std::vector<unsigned int> const& indexes, Shader* shaderToUse = nullptr);
		void DrawVertexVector(std::vector<Vertex_PNCU> const& vertexes, Shader* shaderToUse = nullptr);
		void DrawVertexVector(std::vector<Vertex_PNCU> const& vertexes, std::vector<unsigned int> const& indexes, Shader* shaderToUse = nullptr);
		void UpdateShader(Shader* shaderToUse);
		void UseDefaultShader();

		void Startup();
		void BeginFrame();
		void EndFrame();
		void Shutdown();
		void BeginCamera(const Camera& camera);
		void EndCamera(const Camera& camera);


		//Helper functions
		void UpdateVertexList(int vertexCount, Vertex_PCU* corners, Vec3* const shape, Vec3 const& position, float angleDegrees = 0.f, float scale = 1.f) const;
		void UpdateVertexVector(std::vector<Vertex_PCU>& vertexes, Vec3* const shape, Vec3 const& position, float angleDegrees = 0.f, float scale = 1.f) const;
		void DrawRing(Vec2 const& center, float radius, int edgeCount, float width, Rgba8 const& color = Rgba8());
		void DrawLine(Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& color = Rgba8());
		void DrawDisk(Vec2 const& startLocation, float radius, int edgeCount, Rgba8 const& color = Rgba8(), Rgba8 const& edgeColor = Rgba8());

		void RenderHealthBar(Vec2 drawPosition, float unitRadius, float HP, float maxHp, float barThickness = 1.f);
		void RenderEnergyBar(Vec2 drawPosition, float unitRadius, float energy, float maxEnergy, float barThickness = 1.f);
		void AddVertsForHealthBar(std::vector<Vertex_PCU>& vertexes, Vec2 drawPosition, float unitRadius, float HP, float maxHp, float barThickness = 0.75) const;
		void AddVertsForEnergyBar(std::vector<Vertex_PCU>& vertexes, Vec2 drawPosition, float unitRadius, float energy, float maxEnergy, float barThickness = 0.75) const;
		void AddVertsBarMargin(std::vector<Vertex_PCU>& vertexes, float barLeft, float barRight, float barY, float rendarThickness, Rgba8 lineColor = Rgba8(255, 255, 255, 200)) const;

		RendererConfig const& GetConfig() const { return m_rendererConfig;};


		//Texture stuff
		void BindTexture(Texture* texture);
		Texture* CreateOrGetTextureFromFile(char const* imageFilePath);
		Texture* CreateTextureFromImage(const Image& image);
		BitmapFont* CreateOrGetBitmapFont(char const* bitmapFontFilePathWithNoExtension);


		//Added for DirectX support-----------------------------------------------
		Shader* CreateShader(char const* shaderName);
		Shader* CreateShader(char const* shaderName, char const* source);
		//Add entity transform and color to constant buffer
		void SetModelConstants(const Mat44& modelMatrix = Mat44(), const Rgba8& modelColor = Rgba8());
		void SetLightingConstants(const Vec3& sunDirection = Vec3(), float sunIntensity = 0.5f, float ambientIntensity = 0.5f, const Rgba8& sunColor = Rgba8(), const Rgba8& ambientColor = Rgba8());

		BlendMode m_desiredBlendMode = BlendMode::BLENDMODE_ALPHA;
		SamplerMode m_desiredSamplerMode = SamplerMode::SAMPLEMODE_POINT_CLAMP;
		RasterizerMode m_desiredRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_BACK;
		DepthMode m_desiredDepthMode = DepthMode::DEPTHMODE_ENABLED;


		void BindShader(Shader* shader);
		bool CompileShaderToByteCode(std::vector<unsigned char>& outByteCode, char const* name,
			char const* source, char const* entryPoint, char const* target);
		void DrawVertexBuffer(VertexBuffer* vbo, int vertexCount, int vertexOffset = 0);
		void DrawIndexBuffer(VertexBuffer* vbo, IndexBuffer* ibo, int indexCount);

		//Vertex buffer stuff
		VertexBuffer* CreateVertexBuffer(const size_t size);
		IndexBuffer* CreateIndexBuffer(const size_t size);
		void CopyCPUToGPU(const void* data, size_t size, VertexBuffer*& vbo);
		void CopyCPUToGPU(const void* data, size_t size, IndexBuffer*& ibo);
		void BindVertexBuffer(VertexBuffer* vbo);
		void BindIndexBuffer(IndexBuffer* vbo);

		//Constant buffer stuff
		ConstantBuffer* CreateConstantBuffer(const size_t size);
		void CopyCPUToGPU(const void* data, size_t size, ConstantBuffer*& cbo);
		void BindConstantBuffer(int slot, ConstantBuffer* cbo);
		//Added for DirectX support-----------------------------------------------

		

	private:
		int m_windowWidth;
		int m_windowHeight;
		RendererConfig m_rendererConfig;

		//Texture stuff
		std::vector<Texture*> m_loadedTextures;
		std::vector< BitmapFont* > m_loadedFonts;
		Texture* CreateTextureFromFile(char const* imageFilePath);
		Texture* CreateTextureFromData(char const* name, IntVec2 dimensions, int bytesPerTexel, uint8_t* texelData);
		Texture* GetTextureForFileName(char const* imageFilePath);



		//Added for DirectX support-----------------------------------------------

		void* m_dxgiDebugModule = nullptr;
		void* m_dxgiDebug = nullptr;
		Texture* m_defaultTexture = nullptr;
		Shader* m_defaultShader = nullptr;

		std::vector<Shader*> m_loadedShaders;
		Shader const* m_currentShader = nullptr;

		//Camera stuff
		ConstantBuffer* m_cameraCBO = nullptr;
		ConstantBuffer* m_modelCBO = nullptr;
		ConstantBuffer* m_lightingCBO = nullptr;

		//Vertex buffer stuff
		VertexBuffer* m_immediateVBO = nullptr;

		//Depth buffer stuff
		ID3D11DepthStencilView* m_depthStencilView = nullptr;
		ID3D11Texture2D* m_depthStencilTexture = nullptr;
		//Added for DirectX support-----------------------------------------------
		

		//Added for DirectX support-----------------------------------------------
		void CheckRendererSettings();
		//BlendMode stuff
		std::vector<ID3D11BlendState*> m_blendStates;
		BlendMode m_currentBlendMode = BlendMode::BLENDMODE_ALPHA;
		void MakeBlendStates();
		void SetBlendMode(BlendMode blendMode);
		//SamplerMode stuff
		std::vector<ID3D11SamplerState*> m_samplerStates;
		SamplerMode m_currentSamplerMode = SamplerMode::SAMPLEMODE_POINT_CLAMP;
		void MakeSamplerStates();
		void SetSamplerMode(SamplerMode samplerMode);
		//RasterizerMode stuff
		std::vector<ID3D11RasterizerState*> m_rasterizerStates;
		RasterizerMode m_currentRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_BACK;
		void MakeRasterizerStates();
		void SetRasterizerMode(RasterizerMode rasterizerMode);
		//DepthMode stuff
		std::vector<ID3D11DepthStencilState*> m_depthStencilStates;
		DepthMode m_currentDepthMode = DepthMode::DEPTHMODE_ENABLED;
		void MakeDepthStencilStates();
		void SetDepthStencilMode(DepthMode depthMode);



		ID3D11RenderTargetView* m_renderTargetView = nullptr;
		ID3D11Device* m_device = nullptr;
		ID3D11DeviceContext* m_deviceContext = nullptr;
		IDXGISwapChain* m_swapChain = nullptr;
		//Added for DirectX support-----------------------------------------------


};


