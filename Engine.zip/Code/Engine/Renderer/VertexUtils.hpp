#pragma once
#include <vector>
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\AABB3.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"


struct OBB2;
struct Capsule2;
struct Vertex_PCU;
struct Vertex_PNCU;
struct FloatRange;
struct Mat44;
struct Rgba8;

void ConvertVertexFromZtopToXtop(std::vector<Vertex_PCU>& vertexes);
void TransformVertexArray3D(std::vector<Vertex_PCU>& vertexes, const Mat44& transform);
void TransformVertexArray3D(std::vector<Vertex_PNCU>& vertexes, const Mat44& transform);
void RecolorVertexArray3D(std::vector<Vertex_PCU>& vertexes, const Rgba8& newColor);
AABB2 GetVertexBounds2D(const std::vector<Vertex_PCU>& vertexes);
void AddVertsForRing(std::vector<Vertex_PCU>& vertexes, Vec2 const& center, float radius, int edgeCount, float width, Rgba8 const& color = Rgba8());
void AddVertsForLine2D(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& color = Rgba8());
void AddVertsForLine2D(std::vector<Vertex_PCU>& vertexes, Vec2 const& rectangleStartLeft, Vec2 const& rectangleStartRight, Vec2 const& rectangleEndLeft, Vec2 const& rectangleEndRight, Rgba8 const& startLeft, Rgba8 const& startRight, Rgba8 const& endLeft, Rgba8 const& endRight);
void AddVertsForLine2DMultiColor(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& colorStart = Rgba8(), Rgba8 const& colorEnd = Rgba8(), Rgba8 const& colorSide = Rgba8());
void AddVertsForLine3D(std::vector<Vertex_PCU>& vertexes, Vec3 const& startLocation, Vec3 const& endLocation, float width, Rgba8 const& color = Rgba8());
void AddVertsForAABB2(std::vector<Vertex_PCU>& vertexes, AABB2 const& bounds, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForAABB2Wireframe(std::vector<Vertex_PCU>& vertexes, AABB2 const& bounds, float lineThickness, Rgba8 const& color = Rgba8());
void AddVertsForAABB3(std::vector<Vertex_PCU>& vertexes, AABB3 const& bounds, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForAABB3(std::vector<Vertex_PCU>& vertexes, std::vector<unsigned int>& indexes, AABB3 const& bounds, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForAABB3Wireframe(std::vector<Vertex_PCU>& vertexes, AABB3 const& bounds, float lineThickness, Rgba8 const& color = Rgba8());
void AddVertsForCylinderZ(std::vector<Vertex_PCU>& vertexes, Vec2 centerXY, FloatRange const& minmaxZ, float radius, int numSlices = 12, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForCylinder(std::vector<Vertex_PCU>& vertexes, Vec3 const& start, Vec3 const& end, float radius, int numSlices = 12, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForConeZ(std::vector<Vertex_PCU>& vertexes, Vec2 centerXY, float height, float radius, int numSlices = 12, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForCone(std::vector<Vertex_PCU>& vertexes, Vec3 start, Vec3 end, float radius, int numSlices = 12, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForCylinderZWireframe(std::vector<Vertex_PCU>& vertexes, Vec2 centerXY, FloatRange const& minmaxZ, float radius, float lineThickness, int numSlices = 12, Rgba8 const& color = Rgba8());
void AddVertsForQuad3D(std::vector<Vertex_PCU>& vertexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color = Rgba8(255, 255, 255, 255), const AABB2& uvBounds = AABB2(0.f, 0.f, 1.f, 1.f));
void AddVertsForQuad3D(std::vector<Vertex_PCU>& vertexes, std::vector<unsigned int>& indexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color = Rgba8(255, 255, 255, 255), const AABB2& uvBounds = AABB2(0.f, 0.f, 1.f, 1.f));
void AddVertsForQuad3D(std::vector<Vertex_PNCU>& vertexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color = Rgba8(255, 255, 255, 255), const AABB2& uvBounds = AABB2(0.f, 0.f, 1.f, 1.f));
void AddVertsForQuad3D(std::vector<Vertex_PNCU>& vertexes, std::vector<unsigned int>& indexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color = Rgba8(255, 255, 255, 255), const AABB2& uvBounds = AABB2(0.f, 0.f, 1.f, 1.f));
void AddVertsForLitQuad3D(std::vector<Vertex_PNCU>& vertexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color = Rgba8(255, 255, 255, 255), const AABB2& uvBounds = AABB2(0.f, 0.f, 1.f, 1.f));
void AddVertsForOBB2(std::vector<Vertex_PCU>& vertexes, Vec2 centerPosition, Vec2 forwardNormal, float halfLength, float halfWidth, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForOBB2(std::vector<Vertex_PCU>& vertexes, OBB2 theBox, Rgba8 const& color = Rgba8(), AABB2 const& uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f)));
void AddVertsForDisk(std::vector<Vertex_PCU>& vertexes, Vec3 const& startLocation, float radius, int edgeCount = 20, Rgba8 const& color = Rgba8(), Rgba8 const& edgeColor = Rgba8(), bool flipSides = false);
void AddVertsForSphere(std::vector<Vertex_PCU>& vertexes, Vec3 const& center, float radius, int numSlices = 24, int numStacks = 12, Rgba8 const& color = Rgba8(), const AABB2& UVs = AABB2(0.f, 0.f, 1.f, 1.f));
void AddVertsForSphereWireframe(std::vector<Vertex_PCU>& vertexes, Vec3 const& center, float radius, float lineThickness, int numSlices = 24, int numStacks = 12, Rgba8 const& color = Rgba8());
void AddVertsForSector2(std::vector<Vertex_PCU>& vertexes, Vec3 const& startLocation, float radius, int edgeCount, float centerDegrees, float spreadDegrees, Rgba8 const& color = Rgba8(), Rgba8 const& edgeColor = Rgba8(), bool flipSides = false);
void AddVertsForCapsule2(std::vector<Vertex_PCU>& vertexes, Capsule2 const& theCapsule, int halfEdgeCount, Rgba8 const& color = Rgba8());
