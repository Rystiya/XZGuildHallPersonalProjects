#pragma once
//-----------------------------------------------------------------------------------------------
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Renderer\SpriteDefinition.hpp"
#include <vector>

class Texture;
struct AABB2;

class SpriteSheet
{

public:
	explicit SpriteSheet(Texture& texture, IntVec2 const& simpleGridLayout);
	~SpriteSheet() {}
	//Getters
	Texture& GetTexture() const;
	int GetNumSpirtes() const;
	SpriteDefinition const& GetSpriteDef(int spriteIndex) const;
	SpriteDefinition const& GetSpriteDefFromSimpleGrid(IntVec2 spriteIndex2D) const;
	void GetSpriteUVs(Vec2& out_uvAtMins, Vec2& out_uvAtMaxs, int spriteIndex) const;
	AABB2 GetSpriteUVs(int spriteIndex) const;


protected:
	Texture& m_texture;
	std::vector<SpriteDefinition> m_spriteDefs;
	IntVec2 m_simpleGridSize = IntVec2(0,0);   //Will remain as default value if it's not a simple grid layout


};