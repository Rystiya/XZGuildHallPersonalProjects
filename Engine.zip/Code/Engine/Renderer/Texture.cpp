#include "Engine\Renderer\Texture.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Core\EngineCommon.hpp"


// #include this (massive, platform-specific) header in very few places
#include <d3d11.h>


Texture::~Texture() {
	DX_SAFE_RELEASE(m_texture);
	DX_SAFE_RELEASE(m_shaderResourceView);
}