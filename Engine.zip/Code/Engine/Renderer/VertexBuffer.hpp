﻿#pragma once
#include "Engine\Core\EngineCommon.hpp"
#include <vector>
#include <string>

struct ID3D11Buffer;

class VertexBuffer {
	friend class Renderer;

public:
	VertexBuffer(size_t size);
	VertexBuffer(const VertexBuffer& copy) = delete;
	virtual ~VertexBuffer();

	unsigned int GetStride() { return m_stride; }
	void SetStride(unsigned int newStride) { m_stride = newStride; }

	ID3D11Buffer* m_buffer = nullptr;
	size_t m_size = 0;

protected:
	unsigned int m_stride = 0;


};