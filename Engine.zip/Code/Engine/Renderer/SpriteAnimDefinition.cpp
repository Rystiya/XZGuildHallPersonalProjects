#include "Engine\Core\EngineCommon.hpp"
#include "Engine\Renderer\SpriteAnimDefinition.hpp"


SpriteAnimDefinition::SpriteAnimDefinition(SpriteSheet const& sheet, int startSpriteIndex, int endSpriteIndex, float framesPerSecond, 
	SpriteAnimPlaybackType playbackType): m_spriteSheet(sheet) {
	m_startSpriteIndex = startSpriteIndex;
	m_endSpriteIndex = endSpriteIndex;
	m_secondsPerFrame = 1 / framesPerSecond;
	m_playbackType = playbackType;
}

SpriteDefinition const& SpriteAnimDefinition::GetSpriteDefAtTime(float seconds) const {
	int currentFrame = 0;
	int framesPassed = (int) (seconds / m_secondsPerFrame);
	int frameDistance = m_endSpriteIndex - m_startSpriteIndex;
	if (m_playbackType == SpriteAnimPlaybackType::ONCE) {
		currentFrame = std::min(m_startSpriteIndex + framesPassed, m_endSpriteIndex);
	}
	if (m_playbackType == SpriteAnimPlaybackType::LOOP) {
		framesPassed = framesPassed % (1 + frameDistance);
		currentFrame = m_startSpriteIndex + framesPassed;
	}
	if (m_playbackType == SpriteAnimPlaybackType::PINGPONGONCE) {
		framesPassed = std::min(framesPassed, 2 * frameDistance - 1);
		currentFrame = m_startSpriteIndex + (frameDistance - std::abs(framesPassed - frameDistance));
	}
	if (m_playbackType == SpriteAnimPlaybackType::PINGPONG) {
		framesPassed = framesPassed % (2 * frameDistance);
		currentFrame = m_startSpriteIndex + (frameDistance - std::abs(framesPassed - frameDistance));
	}
	return m_spriteSheet.GetSpriteDef(currentFrame);
}


bool SpriteAnimDefinition::HasEnded(float seconds) const {
	if (m_playbackType == SpriteAnimPlaybackType::ONCE) {
		int framesPassed = static_cast<int>(seconds / m_secondsPerFrame);
		//+1 helps avoid bugs
		return m_startSpriteIndex + framesPassed > m_endSpriteIndex + 1;
	}
	if (m_playbackType == SpriteAnimPlaybackType::PINGPONGONCE) {
		int framesPassed = static_cast<int>(seconds / m_secondsPerFrame);
		//+1 helps avoid bugs
		return m_startSpriteIndex + framesPassed / 2 > m_endSpriteIndex + 1;
	}
	return false;
}