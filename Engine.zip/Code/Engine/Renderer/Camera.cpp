#include "Engine\Renderer\Camera.hpp"
#include "Engine\Math\Mat44.hpp"
#include "Engine\Math\MathUtils.hpp"

Camera::Camera(Vec2 const& bottomLeft, Vec2 const& topRight){
	SetOrthoView(bottomLeft, topRight);
}



//Orthographic projection-------------------------------------------------------------------------------------
void Camera::SetOrthoView(Vec2 const& bottomLeft, Vec2 const& topRight, float near, float far)
{
	m_othoNear = near;
	m_othoFar = far;
	m_orthoArea.m_mins = bottomLeft;
	m_orthoArea.m_maxs = topRight;
	m_mode = eMode_Orthographic;
}


void Camera::SetOrthoCenter(Vec3 const& centerLocation) {
	//Breaks starship when uncommented... 
	//m_position3D = centerLocation;
	m_orthoArea.SetCenter(Vec2(centerLocation.x, centerLocation.y));
}

void Camera::SetOrthoSize(Vec2 newSize) {
	//m_position3D = Vec3(newSize.x, newSize.y, m_position.z);
	m_orthoArea.SetDimensions(newSize);
}

void Camera::MoveOrthoCenterToAtSpeed(Vec2 const& targetLocation, float maxSpeed, float byTime) {
	Vec2 distanceToTarget = targetLocation - GetOrthoCenter();
	Vec2 movementVector = distanceToTarget.GetClamped(maxSpeed * byTime);
	m_orthoArea.SetCenter(GetOrthoCenter() + movementVector);
}

//Getters
Vec2 Camera::GetOrthoBottomLeft() const {
	return m_orthoArea.m_mins + ScreenShakeVector;
}
Vec2 Camera::GetOrthoTopRight() const {
	return m_orthoArea.m_maxs + ScreenShakeVector;
}
Vec2 Camera::GetOrthoSize() const {
	return m_orthoArea.m_maxs - m_orthoArea.m_mins;
}
Vec2 Camera::GetOrthoCenter() const {
	return m_orthoArea.GetCenter();
}

AABB2 Camera::GetOrthoBound() const {
	return m_orthoArea;
}

//Perspective projection-------------------------------------------------------------------------------------

void Camera::SetPerspectiveView(float aspect, float fov, float near, float far)
{
	m_perspectiveAspect = aspect;
	m_perspectiveYDegrees = fov;
	m_perspectiveNear = near;
	m_perspectiveFar = far;
	m_mode = eMode_Perspective;
}

void Camera::SetFieldOfView(float fov) {
	m_perspectiveYDegrees = fov;
}


void Camera::SetViewPort(AABB2 viewPort) {
	m_viewPort = viewPort;
	m_perspectiveAspect = (viewPort.m_maxs.x - viewPort.m_mins.x) / (viewPort.m_maxs.y - viewPort.m_mins.y);
}

//Get matrixes----------------------------------------------------------------------------------------------------------

Mat44 Camera::GetOrthographicMatrix() const {
	return Mat44::CreateOrthoProjection(m_orthoArea.m_mins.x, m_orthoArea.m_maxs.x, m_orthoArea.m_mins.y, m_orthoArea.m_maxs.y, m_othoNear, m_othoFar);
}

Mat44 Camera::GetPerspectiveMatrix() const {
	return Mat44::CreatePerspectiveProjection(m_perspectiveYDegrees, m_perspectiveAspect, m_perspectiveNear, m_perspectiveFar);
}

Mat44 Camera::GetProjectionMatrix() const {
	Mat44 projectionMatrix;
	if (m_mode == eMode_Perspective) {
		projectionMatrix = GetPerspectiveMatrix();
	} else {
		projectionMatrix = GetOrthographicMatrix();

	}
	projectionMatrix.Append(GetRenderMatrix());
	projectionMatrix.Append(Mat44::CreateTranslation2D(ScreenShakeVector));
	return projectionMatrix;
}


Mat44 Camera::GetOwnTranslationAndOrientationMatrix() const {
	Mat44 cameraMatrix = m_orientation.GetAsMatrix_XFwd_YLeft_ZUp();
	cameraMatrix.SetTranslation3D(m_position3D);
	return cameraMatrix;
}


//Audio assist----------------------------------------------------------------------------------------------------------
float Camera::GetNormalizedXPositionRelativeToCamera(float positionX) const {
	float relativePosition = RangeMap(positionX, m_orthoArea.m_mins.x, m_orthoArea.m_maxs.x, -1.0f, 1.0f);
	return GetClamped(relativePosition, -1.f, 1.f);
}

float Camera::GetAudioVolumnGivenThisCamera(float positionX, float positionY) const {
	return GetAudioVolumnGivenThisCamera(Vec2(positionX, positionY));
}

float Camera::GetAudioVolumnGivenThisCamera(Vec2 position) const {
	float cameraRadiusSquard = (m_orthoArea.m_maxs - m_orthoArea.m_mins).GetLengthSquared() * 0.25f;
	Vec2 cameraCenter = m_orthoArea.m_maxs * 0.5 + m_orthoArea.m_mins * 0.5;
	float soundSourceDistance = (position - cameraCenter).GetLengthSquared();
	if (soundSourceDistance < cameraRadiusSquard) {
		return 1.0f;
	}
	if (soundSourceDistance > 2.25f * cameraRadiusSquard) {
		return 0.f;
	}
	return RangeMap(soundSourceDistance, cameraRadiusSquard, 2.25f * cameraRadiusSquard, 1.0f, 0.3f);
}


//Render Matrix-------------------------------------------------------------------------------------
//Different xyz representation is used by game and renderer
void  Camera::SetRenderBasis(Vec3 const& iBasis, Vec3 const& jBasis, Vec3 const& kBasis) {
	m_renderIBasis = iBasis;
	m_renderJBasis = jBasis;
	m_renderKBasis = kBasis;	
}
Mat44  Camera::GetRenderMatrix() const {
	return Mat44(m_renderIBasis, m_renderJBasis, m_renderKBasis, Vec3(0.f,0.f,0.f));
}


//View matrix------------------------------------------------------------------------------
void Camera::SetTransform(const Vec3& position, const EulerAngles& orientation) {
	m_position3D = position;
	m_orientation = orientation;
}
Mat44 Camera::GetViewMatrix() const {
	Mat44 transformMatrix = m_orientation.GetAsMatrix_XFwd_YLeft_ZUp();
	transformMatrix.SetTranslation3D(m_position3D);
	return transformMatrix.GetOrthonormalInverse();
}