
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\OBB2.hpp"
#include "Engine\Math\Capsule2.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Math\FloatRange.hpp"
#include "Engine\Math\Mat44.hpp"
#include <math.h>



void ConvertVertexFromZtopToXtop(std::vector<Vertex_PCU>& vertexes) {
	for (int index = 0; index < vertexes.size(); index++) {
		float temp;
		temp = vertexes[index].m_position.x;
		vertexes[index].m_position.x = vertexes[index].m_position.y;
		vertexes[index].m_position.y = temp;
		temp = vertexes[index].m_position.x;
		vertexes[index].m_position.x = vertexes[index].m_position.z;
		vertexes[index].m_position.z = temp;
	}
}

void TransformVertexArray3D(std::vector<Vertex_PCU>& vertexes, const Mat44& transform) {
	for (int index = 0; index < vertexes.size(); index++) {
		vertexes[index].m_position = transform.TransformPosition3D(vertexes[index].m_position);
	}
}
void TransformVertexArray3D(std::vector<Vertex_PNCU>& vertexes, const Mat44& transform) {
	for (int index = 0; index < vertexes.size(); index++) {
		vertexes[index].m_position = transform.TransformPosition3D(vertexes[index].m_position);
	}
}

void RecolorVertexArray3D(std::vector<Vertex_PCU>& vertexes, const Rgba8& newColor) {
	for (int index = 0; index < vertexes.size(); index++) {
		vertexes[index].m_color = newColor;
	}
}

AABB2 GetVertexBounds2D(const std::vector<Vertex_PCU>& vertexes) {
	if (vertexes.size() == 0) {
		return AABB2();
	}
	AABB2 bounds = AABB2(vertexes[0].m_position, vertexes[0].m_position);
	for (int index = 1; index < vertexes.size(); index++) {
		bounds.StretchToIncludePoint(vertexes[0].m_position);
	}
	return bounds;
}


void AddVertsForRing(std::vector<Vertex_PCU>& vertexes, Vec2 const& center, float radius, int edgeCount, float width, Rgba8 const& color) {
	float degreeEachPie = 360.f / edgeCount;
	for (int pieIndex = 0; pieIndex < edgeCount; pieIndex++) {
		Vec2 corner1 = center + Vec2::MakeFromPolarDegrees(degreeEachPie * static_cast<float>(pieIndex), radius);
		Vec2 corner2 = center + Vec2::MakeFromPolarDegrees(degreeEachPie * static_cast<float>(pieIndex + 1), radius);
		AddVertsForLine2D(vertexes, corner1, corner2, width, color);
	}
}

//The square
void AddVertsForAABB2(std::vector<Vertex_PCU>& vertexes, AABB2 const& bounds, Rgba8 const& color, AABB2 const& uvBounds) {
	AddVertsForQuad3D(vertexes, Vec2(bounds.m_mins.x, bounds.m_mins.y), Vec2(bounds.m_maxs.x, bounds.m_mins.y), Vec2(bounds.m_maxs.x, bounds.m_maxs.y), Vec2(bounds.m_mins.x, bounds.m_maxs.y), color, uvBounds);
}
//The cube
void AddVertsForAABB3(std::vector<Vertex_PCU>& vertexes, AABB3 const& bounds, Rgba8 const& color, AABB2 const& uvBounds) {
	Vec3 pointStart1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointStart2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointStart3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointStart4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointEnd1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointEnd2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointEnd3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_maxs.z);
	Vec3 pointEnd4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_maxs.z);
	AddVertsForQuad3D(vertexes, pointStart4, pointStart3, pointStart2, pointStart1, color, uvBounds);
	AddVertsForQuad3D(vertexes, pointEnd1, pointEnd2, pointEnd3, pointEnd4, color, uvBounds);
	AddVertsForQuad3D(vertexes, pointStart1, pointStart2, pointEnd2, pointEnd1, color, uvBounds);
	AddVertsForQuad3D(vertexes, pointStart2, pointStart3, pointEnd3, pointEnd2, color, uvBounds);
	AddVertsForQuad3D(vertexes, pointStart3, pointStart4, pointEnd4, pointEnd3, color, uvBounds);
	AddVertsForQuad3D(vertexes, pointStart4, pointStart1, pointEnd1, pointEnd4, color, uvBounds);
}
//The cube
void AddVertsForAABB3(std::vector<Vertex_PCU>& vertexes, std::vector<unsigned int>& indexes, AABB3 const& bounds, Rgba8 const& color, AABB2 const& uvBounds) {
	Vec3 pointStart1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointStart2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointStart3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointStart4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointEnd1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointEnd2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointEnd3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_maxs.z);
	Vec3 pointEnd4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_maxs.z);
	AddVertsForQuad3D(vertexes, indexes, pointStart4, pointStart3, pointStart2, pointStart1, color, uvBounds);
	AddVertsForQuad3D(vertexes, indexes, pointEnd1, pointEnd2, pointEnd3, pointEnd4, color, uvBounds);
	AddVertsForQuad3D(vertexes, indexes, pointStart1, pointStart2, pointEnd2, pointEnd1, color, uvBounds);
	AddVertsForQuad3D(vertexes, indexes, pointStart2, pointStart3, pointEnd3, pointEnd2, color, uvBounds);
	AddVertsForQuad3D(vertexes, indexes, pointStart3, pointStart4, pointEnd4, pointEnd3, color, uvBounds);
	AddVertsForQuad3D(vertexes, indexes, pointStart4, pointStart1, pointEnd1, pointEnd4, color, uvBounds);
}

void AddVertsForAABB2Wireframe(std::vector<Vertex_PCU>& vertexes, AABB2 const& bounds, float lineThickness, Rgba8 const& color) {
	AddVertsForLine2D(vertexes, bounds.m_mins, Vec2(bounds.m_mins.x, bounds.m_maxs.y), lineThickness, color);
	AddVertsForLine2D(vertexes, bounds.m_mins, Vec2(bounds.m_maxs.x, bounds.m_mins.y), lineThickness, color);
	AddVertsForLine2D(vertexes, bounds.m_maxs, Vec2(bounds.m_mins.x, bounds.m_maxs.y), lineThickness, color);
	AddVertsForLine2D(vertexes, bounds.m_maxs, Vec2(bounds.m_maxs.x, bounds.m_mins.y), lineThickness, color);
}
void AddVertsForAABB3Wireframe(std::vector<Vertex_PCU>& vertexes, AABB3 const& bounds, float lineThickness, Rgba8 const& color) {
	Vec3 pointStart1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointStart2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_mins.z);
	Vec3 pointStart3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointStart4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_mins.z);
	Vec3 pointEnd1 = Vec3(bounds.m_mins.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointEnd2 = Vec3(bounds.m_maxs.x, bounds.m_mins.y, bounds.m_maxs.z);
	Vec3 pointEnd3 = Vec3(bounds.m_maxs.x, bounds.m_maxs.y, bounds.m_maxs.z);
	Vec3 pointEnd4 = Vec3(bounds.m_mins.x, bounds.m_maxs.y, bounds.m_maxs.z);
	AddVertsForLine3D(vertexes, pointStart1, pointStart2, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart2, pointStart3, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart3, pointStart4, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart4, pointStart1, lineThickness, color);
	AddVertsForLine3D(vertexes, pointEnd1, pointEnd2, lineThickness, color);
	AddVertsForLine3D(vertexes, pointEnd2, pointEnd3, lineThickness, color);
	AddVertsForLine3D(vertexes, pointEnd3, pointEnd4, lineThickness, color);
	AddVertsForLine3D(vertexes, pointEnd4, pointEnd1, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart1, pointEnd1, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart2, pointEnd2, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart3, pointEnd3, lineThickness, color);
	AddVertsForLine3D(vertexes, pointStart4, pointEnd4, lineThickness, color);

}


void AddVertsForCylinderZ(std::vector<Vertex_PCU>& vertexes, Vec2 centerXY, FloatRange const& minmaxZ, float radius, int numSlices, Rgba8 const& color, AABB2 const& uvBounds) {
	AddVertsForDisk(vertexes, Vec3(centerXY.x, centerXY.y, minmaxZ.m_min), radius, numSlices, color, color, true);
	AddVertsForDisk(vertexes, Vec3(centerXY.x, centerXY.y, minmaxZ.m_max), radius, numSlices, color, color);
	float degreeInterval = 360.f / numSlices;
	for (int index = 0; index < numSlices; index++) {
		Vec2 xyVec1 = Vec2(CosDegrees(index * degreeInterval), SinDegrees(index * degreeInterval)) * radius + centerXY;
		Vec2 xyVec2 = Vec2(CosDegrees((index + 1) * degreeInterval), SinDegrees((index + 1) * degreeInterval)) * radius + centerXY;
		float xInterval = (uvBounds.m_maxs.x - uvBounds.m_mins.x) / numSlices;
		float uvXmin = uvBounds.m_mins.x + index * xInterval;
		float uvXmax = uvBounds.m_mins.x + (index + 1) * xInterval;
		AddVertsForQuad3D(vertexes, Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_min), Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_min), Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_max), Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_max), color, AABB2(Vec2(uvXmin, uvBounds.m_mins.y), Vec2(uvXmax, uvBounds.m_maxs.y)));
	}
}

void AddVertsForCylinder(std::vector<Vertex_PCU>& vertexes, Vec3 const& start, Vec3 const& end, float radius, int numSlices, Rgba8 const& color, AABB2 const& uvBounds) {
	std::vector<Vertex_PCU> vertexTemp;
	Vec3 deltaVector = end - start;
	AddVertsForCylinderZ(vertexTemp, Vec2(0.f, 0.f), FloatRange(0.f, deltaVector.GetLength()), radius, numSlices, color, uvBounds);
	ConvertVertexFromZtopToXtop(vertexTemp);
	Mat44 transformMatrix = Mat44::CreateTranslation3D(start);
	transformMatrix.Append(GetRotationMatFromVectorDirection(deltaVector));
	TransformVertexArray3D(vertexTemp, transformMatrix);
	for (int index = 0; index < vertexTemp.size(); index++) {
		vertexes.emplace_back(vertexTemp[index]);
	}
}

void AddVertsForConeZ(std::vector<Vertex_PCU>& vertexes, Vec2 centerXY, float height, float radius, int numSlices, Rgba8 const& color, AABB2 const& uvBounds) {
	float degreeInterval = 360.f / numSlices;
	for (int index = 0; index < numSlices; index++) {
		Vec2 xyVec1 = Vec2(CosDegrees(index * degreeInterval), SinDegrees(index * degreeInterval)) * radius + centerXY;
		Vec2 xyVec2 = Vec2(CosDegrees((index + 1) * degreeInterval), SinDegrees((index + 1) * degreeInterval)) * radius + centerXY;
		float xInterval = (uvBounds.m_maxs.x - uvBounds.m_mins.x) / numSlices;
		float uvXmin = uvBounds.m_mins.x + index * xInterval;
		float uvXmax = uvBounds.m_mins.x + (index + 1) * xInterval;
		vertexes.emplace_back(Vertex_PCU(Vec3(centerXY.x, centerXY.y, height), color, Vec2(uvXmin * 0.5f + uvXmax * 0.5f, uvBounds.m_maxs.y)));
		vertexes.emplace_back(Vertex_PCU(xyVec1, color, Vec2(uvXmin, uvBounds.m_mins.y)));
		vertexes.emplace_back(Vertex_PCU(xyVec2, color, Vec2(uvXmax, uvBounds.m_mins.y)));
		vertexes.emplace_back(Vertex_PCU(xyVec2, color, Vec2(uvXmax, uvBounds.m_mins.y)));
		vertexes.emplace_back(Vertex_PCU(xyVec1, color, Vec2(uvXmin, uvBounds.m_mins.y)));
		vertexes.emplace_back(Vertex_PCU(centerXY, color, Vec2(uvXmin * 0.5f + uvXmax * 0.5f, uvBounds.m_maxs.y)));
	}
}

void AddVertsForCone(std::vector<Vertex_PCU>& vertexes, Vec3 start, Vec3 end, float radius, int numSlices, Rgba8 const& color, AABB2 const& uvBounds) {
	std::vector<Vertex_PCU> vertexTemp;
	Vec3 deltaVector = end - start;
	AddVertsForConeZ(vertexTemp, Vec2(0.f, 0.f), deltaVector.GetLength(), radius, numSlices, color, uvBounds);
	ConvertVertexFromZtopToXtop(vertexTemp);
	Mat44 transformMatrix = Mat44::CreateTranslation3D(start);
	transformMatrix.Append(GetRotationMatFromVectorDirection(deltaVector));
	TransformVertexArray3D(vertexTemp, transformMatrix);
	for (int index = 0; index < vertexTemp.size(); index++) {
		vertexes.emplace_back(vertexTemp[index]);
	}
}

void AddVertsForCylinderZWireframe(std::vector<Vertex_PCU>& vertexes, Vec2 centerXY, FloatRange const& minmaxZ, float radius, float lineThickness, int numSlices, Rgba8 const& color) {
	float degreeInterval = 360.f / numSlices;
	for (int index = 0; index < numSlices; index++) {
		Vec2 xyVec1 = Vec2(CosDegrees(index * degreeInterval), SinDegrees(index * degreeInterval)) * radius + centerXY;
		Vec2 xyVec2 = Vec2(CosDegrees((index + 1) * degreeInterval), SinDegrees((index + 1) * degreeInterval)) * radius + centerXY;
		AddVertsForLine3D(vertexes, Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_min), Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_min), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_max), Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_max), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_min), Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_max), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_min), Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_max), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_min), Vec3(centerXY.x, centerXY.y, minmaxZ.m_min), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_min), Vec3(centerXY.x, centerXY.y, minmaxZ.m_min), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec1.x, xyVec1.y, minmaxZ.m_max), Vec3(centerXY.x, centerXY.y, minmaxZ.m_max), lineThickness, color);
		AddVertsForLine3D(vertexes, Vec3(xyVec2.x, xyVec2.y, minmaxZ.m_max), Vec3(centerXY.x, centerXY.y, minmaxZ.m_max), lineThickness, color);
	}
}


void AddVertsForQuad3D(std::vector<Vertex_PCU>& vertexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color, const AABB2& uvBounds) {
	vertexes.emplace_back(Vertex_PCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(bottomRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y)));
	vertexes.emplace_back(Vertex_PCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y)));
	vertexes.emplace_back(Vertex_PCU(topLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y)));
	vertexes.emplace_back(Vertex_PCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y)));
}

void AddVertsForQuad3D(std::vector<Vertex_PCU>& vertexes, std::vector<unsigned int>& indexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color, const AABB2& uvBounds) {
	unsigned int indexStart = unsigned int (vertexes.size());
	vertexes.emplace_back(Vertex_PCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(bottomRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y)));
	vertexes.emplace_back(Vertex_PCU(topLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y)));
	indexes.emplace_back(indexStart);
	indexes.emplace_back(indexStart+1);
	indexes.emplace_back(indexStart+2);
	indexes.emplace_back(indexStart+2);
	indexes.emplace_back(indexStart+3);
	indexes.emplace_back(indexStart);
}

void AddVertsForQuad3D(std::vector<Vertex_PNCU>& vertexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color, const AABB2& uvBounds) {
	Vec3 surfaceNorm = -1.f * CrossProduct3D(bottomRight - bottomLeft, topLeft - bottomLeft);
	surfaceNorm = surfaceNorm.GetNormalized();
	vertexes.emplace_back(Vertex_PNCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(bottomRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y), surfaceNorm));
}

void AddVertsForQuad3D(std::vector<Vertex_PNCU>& vertexes, std::vector<unsigned int>& indexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color, const AABB2& uvBounds) {
	Vec3 surfaceNorm = -1.f * CrossProduct3D(bottomRight - bottomLeft, topLeft - bottomLeft);
	surfaceNorm = surfaceNorm.GetNormalized();
	unsigned int indexStart = static_cast<unsigned int>(vertexes.size());
	vertexes.emplace_back(Vertex_PNCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(bottomRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y), surfaceNorm));
	indexes.emplace_back(indexStart);
	indexes.emplace_back(indexStart + 1);
	indexes.emplace_back(indexStart + 2);
	indexes.emplace_back(indexStart + 2);
	indexes.emplace_back(indexStart + 3);
	indexes.emplace_back(indexStart);
}

void AddVertsForLitQuad3D(std::vector<Vertex_PNCU>& vertexes, const Vec3& bottomLeft, const Vec3& bottomRight, const Vec3& topRight, const Vec3& topLeft, const Rgba8 color, const AABB2& uvBounds) {
	Vec3 surfaceNorm = -1.f * CrossProduct3D(bottomRight - bottomLeft, topLeft - bottomLeft);
	surfaceNorm = surfaceNorm.GetNormalized();
	Vec3 surfaceNormLeft = (bottomLeft - bottomRight).GetNormalized();
	Vec3 surfaceNormRight = surfaceNormLeft * -1.f;
	float mediumUVx = (uvBounds.m_mins.x + uvBounds.m_maxs.x) * 0.5f;
	Vec3 topMedium = (topLeft + topRight) * 0.5f;
	Vec3 bottomMedium = (bottomLeft + bottomRight) * 0.5f;
	//Quad left
	vertexes.emplace_back(Vertex_PNCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y), surfaceNormLeft));
	vertexes.emplace_back(Vertex_PNCU(bottomMedium, color, Vec2(mediumUVx, uvBounds.m_mins.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topMedium, color, Vec2(mediumUVx, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topMedium, color, Vec2(mediumUVx, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(topLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y), surfaceNormLeft));
	vertexes.emplace_back(Vertex_PNCU(bottomLeft, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y), surfaceNormLeft));
	//Quad right
	vertexes.emplace_back(Vertex_PNCU(bottomMedium, color, Vec2(mediumUVx, uvBounds.m_mins.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(bottomRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y), surfaceNormRight));
	vertexes.emplace_back(Vertex_PNCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y), surfaceNormRight));
	vertexes.emplace_back(Vertex_PNCU(topRight, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y), surfaceNormRight));
	vertexes.emplace_back(Vertex_PNCU(topMedium, color, Vec2(mediumUVx, uvBounds.m_maxs.y), surfaceNorm));
	vertexes.emplace_back(Vertex_PNCU(bottomMedium, color, Vec2(mediumUVx, uvBounds.m_mins.y), surfaceNorm));
}

void AddVertsForOBB2(std::vector<Vertex_PCU>& vertexes, Vec2 centerPosition, Vec2 forwardNormal, float halfLength, float halfWidth, Rgba8 const& color, AABB2 const& uvBounds) {
	Vec2 verticalNormal = forwardNormal.GetRotated90Degrees();
	vertexes.emplace_back(Vertex_PCU(centerPosition - halfLength * forwardNormal - halfWidth * verticalNormal, color, Vec2(uvBounds.m_mins.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(centerPosition + halfLength * forwardNormal - halfWidth * verticalNormal, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(centerPosition - halfLength * forwardNormal + halfWidth * verticalNormal, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y)));
	vertexes.emplace_back(Vertex_PCU(centerPosition + halfLength * forwardNormal - halfWidth * verticalNormal, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_mins.y)));
	vertexes.emplace_back(Vertex_PCU(centerPosition + halfLength * forwardNormal + halfWidth * verticalNormal, color, Vec2(uvBounds.m_maxs.x, uvBounds.m_maxs.y)));
	vertexes.emplace_back(Vertex_PCU(centerPosition - halfLength * forwardNormal + halfWidth * verticalNormal, color, Vec2(uvBounds.m_mins.x, uvBounds.m_maxs.y)));
}

void AddVertsForOBB2(std::vector<Vertex_PCU>& vertexes, OBB2 theBox, Rgba8 const& color, AABB2 const& uvBounds) {
	AddVertsForOBB2(vertexes, theBox.m_center, theBox.m_iBasisNormal, theBox.m_halfDimensions.x, theBox.m_halfDimensions.y, color, uvBounds);
}

void AddVertsForLine2D(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& color) {
	Vec2 rectangleForwardEdgeVec = endLocation - startLocation;
	Vec2 rectangleDiagonalEdgeVec = rectangleForwardEdgeVec.GetNormalized().GetRotated90Degrees() * width;
	Vec2 rectangleStartLeft = startLocation - rectangleDiagonalEdgeVec * 0.5f;
	Vec2 rectangleStartRight = startLocation + rectangleDiagonalEdgeVec * 0.5f;
	Vec2 rectangleEndLeft = rectangleStartLeft + rectangleForwardEdgeVec;
	Vec2 rectangleEndRight = rectangleStartRight + rectangleForwardEdgeVec;
	AddVertsForLine2D(vertexes, rectangleStartLeft, rectangleStartRight, rectangleEndLeft, rectangleEndRight, color, color, color, color);
}

void AddVertsForLine2D(std::vector<Vertex_PCU>& vertexes, Vec2 const& rectangleStartLeft, Vec2 const& rectangleStartRight, Vec2 const& rectangleEndLeft, Vec2 const& rectangleEndRight, Rgba8 const& startLeft, Rgba8 const& startRight, Rgba8 const& endLeft, Rgba8 const& endRight) {
	vertexes.emplace_back(Vertex_PCU(rectangleStartLeft, startLeft, Vec2(0.f, 0.f)));
	vertexes.emplace_back(Vertex_PCU(rectangleStartRight, startRight, Vec2(0.f, 0.f)));
	vertexes.emplace_back(Vertex_PCU(rectangleEndLeft, endLeft, Vec2(0.f, 0.f)));
	vertexes.emplace_back(Vertex_PCU(rectangleEndRight, endRight, Vec2(0.f, 0.f)));
	vertexes.emplace_back(Vertex_PCU(rectangleEndLeft, endLeft, Vec2(0.f, 0.f)));
	vertexes.emplace_back(Vertex_PCU(rectangleStartRight, startRight, Vec2(0.f, 0.f)));
}

void AddVertsForLine2DMultiColor(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& colorStart, Rgba8 const& colorEnd, Rgba8 const& colorSide) {
	Vec2 rectangleForwardEdgeVec = endLocation - startLocation;
	Vec2 rectangleDiagonalEdgeVec = rectangleForwardEdgeVec.GetNormalized().GetRotated90Degrees() * width;
	Vec2 rectangleStartLeft = startLocation - rectangleDiagonalEdgeVec * 0.5f;
	Vec2 rectangleStartRight = startLocation + rectangleDiagonalEdgeVec * 0.5f;
	Vec2 rectangleMidLeft = rectangleStartLeft + 0.5f * rectangleForwardEdgeVec;
	Vec2 rectangleMidRight = rectangleStartRight + 0.5f * rectangleForwardEdgeVec;
	Vec2 rectangleMid = startLocation + 0.5f * rectangleForwardEdgeVec;
	Vec2 rectangleEndLeft = rectangleStartLeft + rectangleForwardEdgeVec;
	Vec2 rectangleEndRight = rectangleStartRight + rectangleForwardEdgeVec;
	Rgba8 colorMid = colorStart * 0.5f + colorEnd * 0.5f;
	AddVertsForLine2D(vertexes, rectangleStartLeft, startLocation, rectangleMidLeft, rectangleMid, colorSide, colorStart, colorSide, colorMid);
	AddVertsForLine2D(vertexes, startLocation, rectangleStartRight, rectangleMid, rectangleMidRight, colorStart, colorSide, colorMid, colorSide);
	AddVertsForLine2D(vertexes, rectangleMidLeft, rectangleMid, rectangleEndLeft, endLocation, colorSide, colorMid, colorSide, colorEnd);
	AddVertsForLine2D(vertexes, rectangleMid, rectangleMidRight, endLocation, rectangleEndRight, colorMid, colorSide, colorEnd, colorSide);
}

void AddVertsForLine3D(std::vector<Vertex_PCU>& vertexes, Vec3 const& startLocation, Vec3 const& endLocation, float width, Rgba8 const& color) {
	Vec3 spineToEdgeA = CrossProduct3D(endLocation - startLocation, Vec3(0.f, 0.f, 1.f));
	if (spineToEdgeA.GetLengthSquared() <= 0.f) {
		spineToEdgeA = CrossProduct3D(endLocation - startLocation, Vec3(0.f, 1.f, 0.f));
	}
	Vec3 spineToEdgeB = CrossProduct3D(endLocation - startLocation, spineToEdgeA);
	spineToEdgeA = spineToEdgeA.GetNormalized() * (width * 1.42f);
	spineToEdgeB = spineToEdgeB.GetNormalized() * (width * 1.42f);
	Vec3 pointStart1 = startLocation + spineToEdgeA;
	Vec3 pointStart2 = startLocation + spineToEdgeB;
	Vec3 pointStart3 = startLocation - spineToEdgeA;
	Vec3 pointStart4 = startLocation - spineToEdgeB;
	Vec3 pointEnd1 = endLocation + spineToEdgeA;
	Vec3 pointEnd2 = endLocation + spineToEdgeB;
	Vec3 pointEnd3 = endLocation - spineToEdgeA;
	Vec3 pointEnd4 = endLocation - spineToEdgeB;
	AddVertsForQuad3D(vertexes, pointStart4, pointStart3, pointStart2, pointStart1, color);
	AddVertsForQuad3D(vertexes, pointEnd1, pointEnd2, pointEnd3, pointEnd4, color);
	AddVertsForQuad3D(vertexes, pointStart1, pointStart2, pointEnd2, pointEnd1, color);
	AddVertsForQuad3D(vertexes, pointStart2, pointStart3, pointEnd3, pointEnd2, color);
	AddVertsForQuad3D(vertexes, pointStart3, pointStart4, pointEnd4, pointEnd3, color);
	AddVertsForQuad3D(vertexes, pointStart4, pointStart1, pointEnd1, pointEnd4, color);
}


void AddVertsForDisk(std::vector<Vertex_PCU>& vertexes, Vec3 const& startLocation, float radius, int edgeCount, Rgba8 const& color, Rgba8 const& edgeColor, bool flipSides) {
	//-180.f is for compatibility with cylinder draw
	AddVertsForSector2(vertexes, startLocation, radius, edgeCount, -180.f, 180.f, color, edgeColor, flipSides);
}

void AddVertsForSector2(std::vector<Vertex_PCU>& vertexes, Vec3 const& startLocation, float radius, int edgeCount, float centerDegrees, float spreadDegrees, Rgba8 const& color, Rgba8 const& edgeColor, bool flipSides) {
	float minDegree = AddAngle(centerDegrees, -1.f * spreadDegrees);
	//float maxDegree = AddAngle(centerDegrees, spreadDegrees);
	float degreeInterval = spreadDegrees * 2.f / edgeCount;
	for (int index = 0; index < edgeCount; index++) {
		AABB2 uvBounds = AABB2(Vec2(0.f, 0.f), Vec2(1.f, 1.f));
		float xInterval = (uvBounds.m_maxs.x - uvBounds.m_mins.x) / edgeCount;
		float uvXmin = uvBounds.m_mins.x + index * xInterval;
		float uvXmax = uvBounds.m_mins.x + (index + 1) * xInterval;
		Vertex_PCU vertexEdge1 = Vertex_PCU(startLocation + Vec3(CosDegrees(minDegree + index * degreeInterval), SinDegrees(minDegree + index * degreeInterval), 0.f) * radius, edgeColor, Vec2(uvXmin, uvBounds.m_maxs.y));
		Vertex_PCU vertexEdge2 = Vertex_PCU(startLocation + Vec3(CosDegrees(minDegree + index * degreeInterval + degreeInterval), SinDegrees(minDegree + index * degreeInterval + degreeInterval), 0.f) * radius, edgeColor, Vec2(uvXmax, uvBounds.m_maxs.y));
		if (!flipSides) {
			vertexes.emplace_back(vertexEdge1);
			vertexes.emplace_back(vertexEdge2);
		}
		else {
			vertexes.emplace_back(vertexEdge2);
			vertexes.emplace_back(vertexEdge1);
		}
		vertexes.emplace_back(Vertex_PCU(startLocation, color, Vec2(uvXmax*0.5f + uvXmin*0.5f, uvBounds.m_mins.y)));
	}
}

void AddVertsForCapsule2(std::vector<Vertex_PCU>& vertexes, Capsule2 const& theCapsule, int halfEdgeCount, Rgba8 const& color) {
	AddVertsForOBB2(vertexes, theCapsule.m_myBone.GetCenter(), theCapsule.m_myBone.GetDirection(), theCapsule.m_myBone.GetLength() * 0.5f, theCapsule.m_radius, color);
	AddVertsForSector2(vertexes, theCapsule.m_myBone.m_end, theCapsule.m_radius, halfEdgeCount, theCapsule.m_myBone.GetDirection().GetOrientationDegrees(), 90, color, color);
	AddVertsForSector2(vertexes, theCapsule.m_myBone.m_start, theCapsule.m_radius, halfEdgeCount, (theCapsule.m_myBone.GetDirection() * -1.f).GetOrientationDegrees(), 90, color, color);
}

void AddVertsForSphere(std::vector<Vertex_PCU>& vertexes, Vec3 const& center, float radius, int numSlices, int numStacks, Rgba8 const& color, const AABB2& UVs) {
	float intervalHorizontal = 360.f / numSlices;
	float intervalVertical = 180.f / numStacks;
	float intervalUVxy = (UVs.m_maxs.x - UVs.m_mins.x) / numSlices;
	float intervalUVz = (UVs.m_maxs.y - UVs.m_mins.y) / numStacks;
	for (int indexXY = 0; indexXY < numSlices; indexXY++) {
		for (int indexZ = 0; indexZ < numStacks; indexZ++) {
			Vec3 bottomLeft = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * indexZ, intervalHorizontal * indexXY, radius) + center;
			Vec3 bottomRight = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * indexZ, intervalHorizontal * (indexXY + 1), radius) + center;
			Vec3 topLeft = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * (indexZ + 1), intervalHorizontal * indexXY, radius) + center;
			Vec3 topRight = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * (indexZ + 1), intervalHorizontal * (indexXY + 1), radius) + center;
			AABB2 uvSection = AABB2(UVs.m_mins.x + intervalUVxy * indexXY, UVs.m_mins.y + intervalUVz * indexZ, UVs.m_mins.x + intervalUVxy * (indexXY + 1), UVs.m_mins.y + intervalUVz * (indexZ + 1));
			AddVertsForQuad3D(vertexes, bottomLeft, bottomRight, topRight, topLeft, color, uvSection);
		}
	}
}


void AddVertsForSphereWireframe(std::vector<Vertex_PCU>& vertexes, Vec3 const& center, float radius, float lineThickness, int numSlices, int numStacks, Rgba8 const& color) {
	float intervalHorizontal = 360.f / numSlices;
	float intervalVertical = 180.f / numStacks;
	for (int indexXY = 0; indexXY < numSlices; indexXY++) {
		for (int indexZ = 0; indexZ < numStacks; indexZ++) {
			Vec3 bottomLeft = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * indexZ, intervalHorizontal * indexXY, radius) + center;
			Vec3 bottomRight = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * indexZ, intervalHorizontal * (indexXY + 1), radius) + center;
			Vec3 topLeft = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * (indexZ + 1), intervalHorizontal * indexXY, radius) + center;
			Vec3 topRight = Vec3::MakeFromPolarDegrees(-90.f + intervalVertical * (indexZ + 1), intervalHorizontal * (indexXY + 1), radius) + center;

			AddVertsForLine3D(vertexes, bottomLeft, bottomRight, lineThickness, color);
			AddVertsForLine3D(vertexes, bottomRight, topRight, lineThickness, color);
			AddVertsForLine3D(vertexes, topRight, topLeft, lineThickness, color);
			AddVertsForLine3D(vertexes, topLeft, bottomLeft, lineThickness, color);
		}
	}
}