#include "Engine\Renderer\BitmapFont.hpp"
#include "Engine\Core\EngineCommon.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\Mat44.hpp"


BitmapFont::~BitmapFont() {
}

BitmapFont::BitmapFont(char const* fontFilePathNameWithNoExtension, Texture& fontTexture)
	: m_fontFilePathNameWithNoExtension(fontFilePathNameWithNoExtension)
	, m_fontGlyphsSpriteSheet(SpriteSheet(fontTexture, IntVec2(16, 16))) {
}


float BitmapFont::GetGlyphAspect(int glyphUnicode) const {
	(void)glyphUnicode;  //Unused for now
	return 1.f;  //Temporary solution
}

Texture& BitmapFont::GetTexture() const { 
	return m_fontGlyphsSpriteSheet.GetTexture(); 
}


float BitmapFont::GetTextWidth(float cellHeight, std::string const& text, float cellAspect) const {
	return cellHeight * text.length() * cellAspect;
}


void BitmapFont::AddVertsForText2D(std::vector<Vertex_PCU>& verts, Vec2 const& topLeft, float cellHeight, std::string const& text, Rgba8 const& tint, float cellAspect) const {
	Vec2 currentTopLeft = topLeft;
	for (int index = 0; index < text.length(); index++) {
		if (text[index] == '\n') {
			currentTopLeft.y -= cellHeight;
			currentTopLeft.x = topLeft.x;
			continue;
		}
		AABB2 glyphUV = m_fontGlyphsSpriteSheet.GetSpriteUVs(text[index]);
		glyphUV.SetDimensions(glyphUV.GetDimensions() * 0.98f);
		AddVertsForAABB2(verts, AABB2(currentTopLeft.x, currentTopLeft.y - cellHeight, currentTopLeft.x + cellHeight * cellAspect, currentTopLeft.y), tint, glyphUV);
		currentTopLeft.x += cellHeight * cellAspect;
	}
}

void BitmapFont::AddVertsForTextInBox2D(std::vector<Vertex_PCU>& verts, AABB2 const& box, float cellHeight, std::string const& text, Rgba8 const& tint,
	float cellAspect, Vec2 const& alignment, TextDrawMode mode, int maxGlyphsToDraw) const {
	Strings seperatedInputs = SplitStringOnDelimiter(text, '\n');
	int longestLineLength = 0;
	for (int index = 0; index < seperatedInputs.size(); index++) {
		longestLineLength = std::max(longestLineLength, (int)seperatedInputs[index].size());
	}
	Vec2 textAreaSize = Vec2(cellHeight * cellAspect * longestLineLength, seperatedInputs.size() * cellHeight);
	Vec2 boxSize = box.GetDimensions();
	//Limit text area size by shrinking text font
	if (mode == TextDrawMode::SHRINK_TO_FIT) {
		float shinkRate = std::min(boxSize.x / textAreaSize.x, boxSize.y / textAreaSize.y);
		if (shinkRate < 1.f) {
			boxSize *= shinkRate;
			cellHeight *= shinkRate;
		}
	}
	Vec2 totalMargin = boxSize - textAreaSize;
	Vec2 topLeftMargin = totalMargin * alignment;
	Vec2 textAreaTopLeft = Vec2(box.m_mins.x + topLeftMargin.x, box.m_maxs.y - topLeftMargin.y);
	//Limit the number of characters to draw. Does not affect the size and position of the text area
	std::string textToBeRendered = text.substr(0, maxGlyphsToDraw);
	AddVertsForText2D(verts, textAreaTopLeft, cellHeight, textToBeRendered, tint, cellAspect);
}


void BitmapFont::AddVertsForTextBillboard(std::vector<Vertex_PCU>& verts, Vec2 const& billBoardSize, Mat44 billboardTransform, float cellHeight, std::string const& text, Rgba8 const& tint,
	float cellAspect, Vec2 const& alignment, TextDrawMode mode, int maxGlyphsToDraw) const {
	std::vector<Vertex_PCU> vertexTemp;
	Vec2 offset = Vec2(billBoardSize.x * (0.5f - alignment.x), billBoardSize.y * (0.5f - alignment.y));
	AABB2 bounds = AABB2(billBoardSize.x * alignment.x, billBoardSize.y * alignment.y, billBoardSize.x * (1.f - alignment.x), billBoardSize.y * (1.f - alignment.y));
	AddVertsForTextInBox2D(vertexTemp, bounds, cellHeight, text, tint, cellAspect, alignment, mode, maxGlyphsToDraw);
	TransformVertexArray3D(vertexTemp, billboardTransform);
	for (int index = 0; index < vertexTemp.size(); index++) {
		verts.emplace_back(vertexTemp[index]);
	}
}