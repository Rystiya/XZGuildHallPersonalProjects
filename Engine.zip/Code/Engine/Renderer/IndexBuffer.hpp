﻿#pragma once
#include "Engine\Core\EngineCommon.hpp"
#include <vector>
#include <string>

struct ID3D11Buffer;

class IndexBuffer {
	friend class Renderer;

public:
	IndexBuffer(size_t size);
	IndexBuffer(const IndexBuffer& copy) = delete;
	virtual ~IndexBuffer();

	static unsigned int GetStride();

	ID3D11Buffer* m_buffer = nullptr;
	size_t m_size = 0;



};