#pragma once

#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Math\EulerAngles.hpp"

class RandomNumberGenerator;
struct Mat44;
struct EulerAngles;

//This is just the location and other stats relating to the angle of view.
//It does not do rendering.
//-----------------------------------------------------------------------------------------------
class Camera
{
	friend class Player;
	friend class Renderer;

	enum Mode {
		eMode_Orthographic,
		eMode_Perspective,
		eMode_Count,
	};



public:
	~Camera() {}									
	Camera() {}						
	
	//View port-------------------------------------------------------------------------------------
	void SetViewPort(AABB2 viewPort);
	AABB2 const& GetViewPort() { return m_viewPort; }


	//Orthographic projection-------------------------------------------------------------------------------------
	Camera(Vec2 const& bottomLeft, Vec2 const& topRight);							// copy constructor (from another vec2)
	void SetOrthoView(Vec2 const& bottomLeft, Vec2 const& topRight, float near = 0.0f, float far = 1.0f);
	void SetOrthoCenter(Vec3 const& centerLocation);
	void SetOrthoSize(Vec2 newSize);
	void MoveOrthoCenterToAtSpeed(Vec2 const& targetLocation, float maxSpeed, float byTime);
	Vec2 GetOrthoBottomLeft() const;
	Vec2 GetOrthoTopRight() const;
	Vec2 GetOrthoSize() const;
	Vec2 GetOrthoCenter() const;
	AABB2 GetOrthoBound() const;
	Vec2 GetSize() const { return (m_orthoArea.m_maxs - m_orthoArea.m_mins); }
	Vec2 ScreenShakeVector = Vec2(0.f, 0.f);
	

	//Perspective projection-------------------------------------------------------------------------------------
	void SetPerspectiveView(float aspect, float fov, float near, float far);
	void SetFieldOfView(float fov);


	//Get matrixes------------------------------------------------------------------------------
	Mat44 GetOrthographicMatrix() const;
	Mat44 GetPerspectiveMatrix() const;
	Mat44 GetProjectionMatrix() const;
	Mat44 GetOwnTranslationAndOrientationMatrix() const;

	//Render Matrix-------------------------------------------------------------------------------------
	//Different xyz representation is used by game and renderer
	void SetRenderBasis(Vec3 const& iBasis, Vec3 const& jBasis, Vec3 const& kBasis);
	Mat44 GetRenderMatrix() const;

	//Audio assist------------------------------------------------------------------------------
	float GetNormalizedXPositionRelativeToCamera(float positionX) const;
	float GetAudioVolumnGivenThisCamera(float positionX, float positionY) const;
	float GetAudioVolumnGivenThisCamera(Vec2 position) const;

	//View matrix------------------------------------------------------------------------------
	void SetTransform(const Vec3& position, const EulerAngles& orientation);
	Mat44 GetViewMatrix() const;

	//View Matrix-------------------------------------------------------------------------------------
	Vec3 m_position3D = Vec3();
	EulerAngles m_orientation = EulerAngles();

private:
	Mode m_mode = eMode_Orthographic;
	//If m_viewPort is invalid, the render will use the whole screen by default.
	AABB2 m_viewPort = AABB2(0.0f, 0.0f, -1.f, -1.f);

	//Orthographic projection-------------------------------------------------------------------------------------
	AABB2 m_orthoArea = AABB2(0.0f, 0.0f, 1000.0f, 1000.0f);
	float m_othoNear = 0.f;
	float m_othoFar = 0.f;

	//Perspective projection-------------------------------------------------------------------------------------
	float m_perspectiveAspect = 0.f;
	float m_perspectiveYDegrees = 0.f;
	float m_perspectiveNear = 0.f;
	float m_perspectiveFar = 0.f;

	//Render Matrix-------------------------------------------------------------------------------------
	Vec3 m_renderIBasis = Vec3(1.f, 0.f, 0.f);
	Vec3 m_renderJBasis = Vec3(0.f, 1.f, 0.f);
	Vec3 m_renderKBasis = Vec3(0.f, 0.f, 1.f);



};


