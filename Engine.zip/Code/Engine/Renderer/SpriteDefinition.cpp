#include "Engine\Renderer\SpriteSheet.hpp"
#include "Engine\Renderer\SpriteDefinition.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Math\AABB2.hpp"



SpriteDefinition::SpriteDefinition(SpriteSheet const& spriteSheet, int spriteIndex, Vec2 const& uvAtMins, Vec2 const& uvAtMaxs)
	: m_spriteSheet(spriteSheet)
	, m_spriteIndex(spriteIndex)
{
	//Shrink the texture area to avoid the flickering-edge bug.
	Vec2 center = (uvAtMins + uvAtMaxs) * 0.5f;
	float shrinkMarginRatio = 0.01f;
	m_uvAtMins = uvAtMins * (1.0f - shrinkMarginRatio) + shrinkMarginRatio * center;
	m_uvAtMaxs = uvAtMaxs * (1.0f - shrinkMarginRatio) + shrinkMarginRatio * center;
}

void SpriteDefinition::GetUVs(Vec2& out_uvAtMins, Vec2& out_uvAtMaxs) const {
	out_uvAtMins = m_uvAtMins;
	out_uvAtMaxs = m_uvAtMaxs;
}

AABB2 SpriteDefinition::GetUVs(float shrinkMarginRatio) const {
	//Shrink the texture area to avoid the flickering-edge bug.
	Vec2 center = (m_uvAtMins + m_uvAtMaxs) * 0.5f;
	Vec2 uvAtMins = m_uvAtMins * (1.0f - shrinkMarginRatio) + shrinkMarginRatio * center;
	Vec2 uvAtMaxs = m_uvAtMaxs * (1.0f - shrinkMarginRatio) + shrinkMarginRatio * center;
	return AABB2(uvAtMins, uvAtMaxs);
}

SpriteSheet const& SpriteDefinition::GetSpriteSheet() const {
	return m_spriteSheet;
}

Texture& SpriteDefinition::GetTexture() const {
	return m_spriteSheet.GetTexture();
}

float SpriteDefinition::GetAspect() const {
	return (m_uvAtMaxs.x - m_uvAtMins.x) / (m_uvAtMaxs.y - m_uvAtMins.y);
}