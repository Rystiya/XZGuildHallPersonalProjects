#include "Engine\Input\XboxController.hpp"
#define WIN32_LEAN_AND_MEAN
#include <Windows.h> // must #include Windows.h before #including Xinput.h
#include <Xinput.h> // include the Xinput API header file (interface)
#pragma comment( lib, "xinput9_1_0" ) // Link in the xinput.lib static library // #Eiserloh: Xinput 1_4 doesn't work in Windows 7; use version 9_1_0 explicitly for broadest compatibility


//UpdateButton(XBOX_Button_A, state.xButtons, XINPUT_GAMEPAD_A)


XboxController::XboxController() {
	m_leftStick =  *(new AnalogJoystick());
	m_rightStick = *(new AnalogJoystick());
	for (int index = 0; index < (int)XboxButtonID::NUM; index++) {
		m_buttons[index] = *(new KeyButtonState());
	}
}
XboxController::~XboxController() {
}
bool XboxController::IsConnected() const {
	return m_isConnected;
}
int XboxController::GetControllerID() const {
	return m_id;
}
AnalogJoystick const& XboxController::GetLeftStick() const {
	return m_leftStick;
}
AnalogJoystick const& XboxController::GetRightStick() const {
	return m_rightStick;
}
float XboxController::GetLeftTrigger() const {
	return m_leftTrigger;
}
float XboxController::GetRightTrigger() const {
	return m_rightTrigger;
}
float XboxController::GetLeftTriggerLastFrame() const {
	return m_leftTriggerOld;
}
float XboxController::GetRightTriggerLastFrame() const {
	return m_rightTriggerOld;
}
KeyButtonState const& XboxController::GetButton(XboxButtonID buttonKey) const {
	return m_buttons[(int)buttonKey];
}
bool XboxController::IsButtonDown(XboxButtonID buttonKey) const {
	return m_buttons[(int)buttonKey].m_isPressed;
}
bool XboxController::WasButtonJustPressed(XboxButtonID buttonKey) const {
	KeyButtonState const& currentButton = GetButton(buttonKey);
	return currentButton.m_isPressed && !currentButton.m_wasPressedLastFrame;
}
bool XboxController::WasButtonJustReleased(XboxButtonID buttonKey) const {
	KeyButtonState const& currentButton = GetButton(buttonKey);
	return !currentButton.m_isPressed && currentButton.m_wasPressedLastFrame;
}

void XboxController::Update() {
	for (int index = 0; index < (int)XboxButtonID::NUM; index++) {
		m_buttons[index].m_wasPressedLastFrame = m_buttons[index].m_isPressed;
	}
	m_leftTriggerOld = m_leftTrigger;
	m_rightTriggerOld = m_rightTrigger;
	XINPUT_STATE xboxControllerState = {};
	DWORD errorStatus = XInputGetState(m_id, &xboxControllerState);
	if (errorStatus != ERROR_SUCCESS) {
		m_isConnected = false;
		Reset();
	} else {
		m_isConnected = true;
	}
	XINPUT_GAMEPAD const& inputSource = xboxControllerState.Gamepad;
	UpdateJoystick(m_leftStick, inputSource.sThumbLX, inputSource.sThumbLY);
	UpdateJoystick(m_rightStick, inputSource.sThumbRX, inputSource.sThumbRY);
	UpdateTrigger(m_leftTrigger, inputSource.bLeftTrigger);
	UpdateTrigger(m_rightTrigger, inputSource.bRightTrigger);
	UpdateButton(XboxButtonID::ButtonA, inputSource.wButtons, XINPUT_GAMEPAD_A);
	UpdateButton(XboxButtonID::ButtonB, inputSource.wButtons, XINPUT_GAMEPAD_B);
	UpdateButton(XboxButtonID::ButtonX, inputSource.wButtons, XINPUT_GAMEPAD_X);
	UpdateButton(XboxButtonID::ButtonY, inputSource.wButtons, XINPUT_GAMEPAD_Y);
	UpdateButton(XboxButtonID::ButtonBack, inputSource.wButtons, XINPUT_GAMEPAD_BACK);
	UpdateButton(XboxButtonID::ButtonStart, inputSource.wButtons, XINPUT_GAMEPAD_START);
	UpdateButton(XboxButtonID::ButtonTopLeft, inputSource.wButtons, XINPUT_GAMEPAD_LEFT_SHOULDER);
	UpdateButton(XboxButtonID::ButtonTopRight, inputSource.wButtons, XINPUT_GAMEPAD_RIGHT_SHOULDER);
	UpdateButton(XboxButtonID::ButtonStickLeft, inputSource.wButtons, XINPUT_GAMEPAD_LEFT_THUMB);
	UpdateButton(XboxButtonID::ButtonStickRight, inputSource.wButtons, XINPUT_GAMEPAD_RIGHT_THUMB);
	UpdateButton(XboxButtonID::ButtonRight, inputSource.wButtons, XINPUT_GAMEPAD_DPAD_RIGHT);
	UpdateButton(XboxButtonID::ButtonUp, inputSource.wButtons, XINPUT_GAMEPAD_DPAD_UP);
	UpdateButton(XboxButtonID::ButtonLeft, inputSource.wButtons, XINPUT_GAMEPAD_DPAD_LEFT);
	UpdateButton(XboxButtonID::ButtonDown, inputSource.wButtons, XINPUT_GAMEPAD_DPAD_DOWN);


}
void XboxController::Reset() {
	UpdateJoystick(m_leftStick, 0, 0);
	UpdateJoystick(m_rightStick, 0, 0);
	UpdateTrigger(m_leftTrigger, 0);
	UpdateTrigger(m_rightTrigger, 0);
	for (int index = 0; index < (int)XboxButtonID::NUM; index++) {
		m_buttons[index].m_isPressed = false;
		m_buttons[index].m_wasPressedLastFrame = false;
	}
}
void XboxController::EndFrame() {
}


void XboxController::UpdateJoystick(AnalogJoystick& out_fakeJoystickObject, short rawX, short rawY) {
	out_fakeJoystickObject.UpdatePosition(rawX, rawY);
}
void XboxController::UpdateTrigger(float& out_trigger_value, unsigned char raw_value) {
	out_trigger_value = raw_value;
}
void XboxController::UpdateButton(XboxButtonID buttonKey, unsigned short buttonFlags, unsigned short buttonFlag) {
	m_buttons[(int)buttonKey].m_isPressed = buttonFlags & buttonFlag;

}