#include "Engine\Input\AnalogJoystick.hpp"
#include "Engine\Math\MathUtils.hpp"



Vec2 AnalogJoystick::GetPosition() const {
	return m_correctedNormalizedPosition;
}
Vec2 AnalogJoystick::GetPolarPosition() const {
	return m_correctedPolarPosition;
}
float AnalogJoystick::GetNormalizedMagnitude() const {
	return m_correctedNormalizedPosition.GetLength();
}
float AnalogJoystick::GetOrientationDegrees() const {
	return m_correctedNormalizedPosition.GetOrientationDegrees();
}
Vec2 AnalogJoystick::GetRawUncorrectedPosition() const {
	return m_rawNormalizedPosition;
}
float AnalogJoystick::GetInnerDeadZoneFraction() const {
	return m_innerDeadZoneFraction;
}
float AnalogJoystick::GetOuterDeadZoneFraction() const {
	return m_outerDeadZoneFraction;
}
void AnalogJoystick::Reset() {
	m_rawNormalizedPosition = Vec2(0.f, 0.f);
	m_correctedNormalizedPosition = Vec2(0.f, 0.f);
	m_correctedPolarPosition = Vec2(0.f, 0.f);
}
void AnalogJoystick::SetDeadZoneThresholds(float normalizedInnerDeadzoneThreshold, float normalizedOuterDeadzoneThreshold) {
	m_innerDeadZoneFraction = normalizedInnerDeadzoneThreshold;
	m_outerDeadZoneFraction = normalizedOuterDeadzoneThreshold;
}
void AnalogJoystick::UpdatePosition(float rawNormalizedX, float rawNormalizedY) {
	m_rawNormalizedPosition = Vec2(rawNormalizedX, rawNormalizedY) / JoystickMaxValue;
	float normalizedLength = m_rawNormalizedPosition.GetLength();
	float correctedNormalizedLength = RangeMapClamped(m_rawNormalizedPosition.GetLength(), m_innerDeadZoneFraction, m_outerDeadZoneFraction, 0.f, 1.f);
	float correctedAngle = m_rawNormalizedPosition.GetOrientationDegrees();
	m_correctedPolarPosition = Vec2(correctedNormalizedLength, correctedAngle);
	//Is TINY_POSITIVE_NUMBER right here?
	float correctionRatio = (correctedNormalizedLength + TINY_POSITIVE_NUMBER) / (normalizedLength + TINY_POSITIVE_NUMBER);
	m_correctedNormalizedPosition = m_rawNormalizedPosition * correctionRatio;
}
