#pragma once
#include "Engine\Input\XboxController.hpp"
#include "Engine\Core\NamedStrings.hpp"
#include "Engine\Core\EventSystem.hpp"
#include "Engine\Math\IntVec2.hpp"
#include <string>

extern unsigned char const KEYCODE_LEFTMOUSE;
extern unsigned char const KEYCODE_RIGHTMOUSE;
extern unsigned char const KEYCODE_MIDMOUSE;
extern unsigned char const KEYCODE_ENTER;
extern unsigned char const KEYCODE_BACKSPACE;
extern unsigned char const KEYCODE_SPACE;
extern unsigned char const KEYCODE_INSERT;
extern unsigned char const KEYCODE_DELETE;
extern unsigned char const KEYCODE_HOME;
extern unsigned char const KEYCODE_END;
extern unsigned char const KEYCODE_F1;
extern unsigned char const KEYCODE_F2;
extern unsigned char const KEYCODE_F3;
extern unsigned char const KEYCODE_F4;
extern unsigned char const KEYCODE_F5;
extern unsigned char const KEYCODE_F6;
extern unsigned char const KEYCODE_F7;
extern unsigned char const KEYCODE_F8;
extern unsigned char const KEYCODE_F9;
extern unsigned char const KEYCODE_F10;
extern unsigned char const KEYCODE_F11;
extern unsigned char const KEYCODE_ESC;
extern unsigned char const KEYCODE_SHIFT;
extern unsigned char const KEYCODE_CTRL;
extern unsigned char const KEYCODE_ALT;
extern unsigned char const KEYCODE_UPARROW;
extern unsigned char const KEYCODE_DOWNARROW;
extern unsigned char const KEYCODE_LEFTARROW;
extern unsigned char const KEYCODE_RIGHTARROW;
extern unsigned char const KEYCODE_PLUS;
extern unsigned char const KEYCODE_MINUS;
extern unsigned char const KEYCODE_TAB;
extern unsigned char const KEYCODE_TILDE;


constexpr int NUM_KEYCODES = 256;
constexpr int NUM_XBOX_CONTROLLERS = 4;

class Window;
struct MouseState {
	IntVec2 m_cursorClientPosition;
	IntVec2 m_cursorClientDelta;
	long m_cursorClientMidPosition;
	long m_cursorClientMidDelta;
	bool m_currentHidden = false;
	bool m_desireHidden = false;
	bool m_currentRelative = false;
	bool m_desireRelative = false;

	};

struct InputSystemConfig {
};



class InputSystem
{
public:
	InputSystem(InputSystemConfig const& inputConfig);
	~InputSystem();
	void Startup();
	void Update(float deltaSeconds = 0.02f);
	void Shutdown();
	void BeginFrame();
	void EndFrame();
	bool WasKeyJustPressed(unsigned char keyCode) const;
	bool WasKeyJustDoubleReleased(unsigned char keyCode) const;
	bool WasKeyJustSingleReleased(unsigned char keyCode) const;
	bool WasKeyJustReleased(unsigned char keyCode) const;
	bool IsKeyDown(unsigned char keyCode) const;
	void HandleKeyPressed(unsigned char keyCode);
	void HandleKeyReleased(unsigned char keyCode);
	void HandleMouseWheel(long wheelChangeDegrees);
	//Must be public for eventSystem to access it?
	static bool HandleKeyPressedEvent(EventArgs& eventData);
	static bool HandleKeyReleasedEvent(EventArgs& eventData);
	static bool HandleMouseWheelEvent(EventArgs& eventData);
	XboxController const& GetController(int controllerID);

	//Mouse related stuff
	void SetCursorMode(bool hidden, bool relative) { m_mouseState.m_desireHidden = hidden; m_mouseState.m_desireRelative = relative; }
	//Returns the current frame cursor delta in pixels, relative to the client region
	IntVec2 GetCursorClientDelta() const { return m_mouseState.m_cursorClientDelta; }
	//Returns the delta degrees of mouse wheel
	int GetCursorClientMidDelta() const;
	//Returns the cursor position in pixels, relative to the client region
	IntVec2 GetCursorClientPosition() const { return m_mouseState.m_cursorClientPosition; }
	//Returns the current degrees of mouse wheel
	long GetCursorClientMidPosition() const { return m_mouseState.m_cursorClientMidPosition; }
	//Returns the cursor position, normalized to range [0,1].
	Vec2 GetCursorNormalizedPosition() const;




	InputSystemConfig const& GetConfig() const { return m_inputConfig; };
	static constexpr float DOUBLE_PRESS_TIME_LIMIT = 0.25f;

protected:
	float m_timePassed = 0.f;
	float m_timeOfLastKeyReleased = -10.f * DOUBLE_PRESS_TIME_LIMIT;
	unsigned char m_lastKeyReleased = 0;
	bool m_lastKeyWasDoubleReleased = false;

	KeyButtonState m_keyStates[NUM_KEYCODES];
	XboxController m_controllers[NUM_XBOX_CONTROLLERS];
	InputSystemConfig m_inputConfig;
	MouseState m_mouseState;
	Window* m_currentWindow;
};