#pragma once
#include "Engine\Input\AnalogJoystick.hpp"
#include "Engine\Input\KeyButtonState.hpp"


enum class XboxButtonID {ButtonA = 0, ButtonB = 1, ButtonX = 2, ButtonY = 3, ButtonBack = 4, ButtonStart = 5, 
	ButtonTopLeft = 6, ButtonTopRight = 7, ButtonStickLeft = 8, ButtonStickRight = 9,
	ButtonRight = 10, ButtonUp = 11, ButtonLeft = 12, ButtonDown = 13, NUM = 14};


class XboxController
{	
	friend class InputSystem;

public:
	XboxController();
	~XboxController();
	bool IsConnected() const;
	int GetControllerID() const;
	AnalogJoystick const& GetLeftStick() const;
	AnalogJoystick const& GetRightStick() const;
	float GetLeftTrigger() const;
	float GetRightTrigger() const;
	float GetLeftTriggerLastFrame() const;
	float GetRightTriggerLastFrame() const;
	KeyButtonState const& GetButton(XboxButtonID buttonID) const;
	bool IsButtonDown(XboxButtonID buttonID) const;
	bool WasButtonJustPressed(XboxButtonID buttonID) const;
	bool WasButtonJustReleased(XboxButtonID buttonID) const;


private:
	void Update();
	void Reset();
	void EndFrame();
	void UpdateJoystick(AnalogJoystick& out_fakeJoystickObject, short rawX, short rawY);
	void UpdateTrigger(float& out_trigger_value, unsigned char raw_value);
	void UpdateButton(XboxButtonID buttonID, unsigned short buttonFlags, unsigned short buttonFlag);   //buttonFlags is a fb00001000... kinda of value

	int m_id = -1;
	bool m_isConnected = false;
	float m_leftTrigger = 0.f;
	float m_rightTrigger = 0.f;
	float m_leftTriggerOld = 0.f;
	float m_rightTriggerOld = 0.f;
	KeyButtonState m_buttons[(int)XboxButtonID::NUM];
	AnalogJoystick m_leftStick;
	AnalogJoystick m_rightStick;



	

};