#pragma once
#include "Engine\Math\Vec2.hpp"

class AnalogJoystick
{
public:
	AnalogJoystick() {}
	~AnalogJoystick() {}

	Vec2 GetPosition() const;
	Vec2 GetPolarPosition() const;
	float GetNormalizedMagnitude() const;
	float GetOrientationDegrees() const;

	Vec2 GetRawUncorrectedPosition() const;
	float GetInnerDeadZoneFraction() const;
	float GetOuterDeadZoneFraction() const;

	void Reset();
	void SetDeadZoneThresholds(float normalizedInnerDeadzoneThreshold, float normalizedOuterDeadzoneThreshold);
	void UpdatePosition(float rawNormalizedX, float rawNormalizedY);
	
protected:
	Vec2 m_rawNormalizedPosition = Vec2(0.f, 0.f); //Lack accuracy
	Vec2 m_correctedNormalizedPosition = Vec2(0.f, 0.f); //Added deadzone
	Vec2 m_correctedPolarPosition = Vec2(0.f, 0.f); //Added deadzone
	float m_innerDeadZoneFraction = 0.3f; //movement < this will be considered zero.
	float m_outerDeadZoneFraction = 0.95f; //movement > this will be considered max.
	static constexpr float JoystickMaxValue = 32767.f;
};