#include "Engine\Input\InputSystem.hpp"
#include "Engine\Input\XboxController.hpp"
#include "Engine\Window\Window.hpp"
#include "Engine\Core\EngineCommon.hpp"
#define WIN32_LEAN_AND_MEAN
#include <Windows.h> // must #include Windows.h before #including Xinput.h


extern unsigned char const KEYCODE_LEFTMOUSE = VK_LBUTTON;
extern unsigned char const KEYCODE_RIGHTMOUSE = VK_RBUTTON;
extern unsigned char const KEYCODE_MIDMOUSE = VK_MBUTTON;
extern unsigned char const KEYCODE_ENTER = VK_RETURN;
extern unsigned char const KEYCODE_BACKSPACE = VK_BACK;
extern unsigned char const KEYCODE_SPACE = VK_SPACE;
extern unsigned char const KEYCODE_INSERT = VK_INSERT;
extern unsigned char const KEYCODE_DELETE = VK_DELETE;
extern unsigned char const KEYCODE_HOME = VK_HOME;
extern unsigned char const KEYCODE_END = VK_END;
extern unsigned char const KEYCODE_F1 = VK_F1;
extern unsigned char const KEYCODE_F2 = VK_F2;
extern unsigned char const KEYCODE_F3 = VK_F3;
extern unsigned char const KEYCODE_F4 = VK_F4;
extern unsigned char const KEYCODE_F5 = VK_F5;
extern unsigned char const KEYCODE_F6 = VK_F6;
extern unsigned char const KEYCODE_F7 = VK_F7;
extern unsigned char const KEYCODE_F8 = VK_F8;
extern unsigned char const KEYCODE_F9 = VK_F9;
extern unsigned char const KEYCODE_F10 = VK_F10;
extern unsigned char const KEYCODE_F11 = VK_F11;
extern unsigned char const KEYCODE_ESC = VK_ESCAPE;
extern unsigned char const KEYCODE_SHIFT = VK_SHIFT;
extern unsigned char const KEYCODE_CTRL = VK_CONTROL;
extern unsigned char const KEYCODE_ALT = VK_MENU;
extern unsigned char const KEYCODE_UPARROW = VK_UP;
extern unsigned char const KEYCODE_DOWNARROW = VK_DOWN;
extern unsigned char const KEYCODE_LEFTARROW = VK_LEFT;
extern unsigned char const KEYCODE_RIGHTARROW = VK_RIGHT;
extern unsigned char const KEYCODE_PLUS = VK_OEM_PLUS;
extern unsigned char const KEYCODE_MINUS = VK_OEM_MINUS;
extern unsigned char const KEYCODE_TAB = VK_TAB;
extern unsigned char const KEYCODE_TILDE = 0xC0;

extern InputSystem* g_theInputSystem;

InputSystem::InputSystem(InputSystemConfig const& inputConfig) {
	m_inputConfig = inputConfig;
}
InputSystem::~InputSystem() {
}


//Primary functions-------------------------------------------------------------------
void InputSystem::Startup() {
	//Set everything to false to avoid error
	for (int index = 0; index < NUM_KEYCODES; index++) {
		m_keyStates[index] = *(new KeyButtonState());
	}
	for (int index = 0; index < NUM_XBOX_CONTROLLERS; index++) {
		m_controllers[index] = *(new XboxController());
		m_controllers[index].m_id = index;
	}
	SubscribeEventCallbackFunction("keyDown", InputSystem::HandleKeyPressedEvent);
	SubscribeEventCallbackFunction("keyUp", InputSystem::HandleKeyReleasedEvent);
	SubscribeEventCallbackFunction("wheelScroll", InputSystem::HandleMouseWheelEvent);
}
void InputSystem::Shutdown() {
	UnSubscribeEventCallbackFunction("keyDown", InputSystem::HandleKeyPressedEvent);
	UnSubscribeEventCallbackFunction("keyUp", InputSystem::HandleKeyReleasedEvent);
	UnSubscribeEventCallbackFunction("wheelScroll", InputSystem::HandleMouseWheelEvent);

}


void InputSystem::BeginFrame() {
	//Dealing with the cursor
	m_currentWindow = Window::GetWindowContext();
	if (m_mouseState.m_currentHidden != m_mouseState.m_desireHidden) {
		m_mouseState.m_currentHidden = m_mouseState.m_desireHidden;
		if (m_mouseState.m_currentHidden) {
			while (ShowCursor(false) >= 0) {}
		} else {
			while (ShowCursor(true) < 0) {}
		}
	}
	if (m_mouseState.m_currentRelative != m_mouseState.m_desireRelative) {
		m_mouseState.m_currentRelative = m_mouseState.m_desireRelative;
		m_mouseState.m_cursorClientDelta = IntVec2();
		m_mouseState.m_cursorClientPosition = IntVec2();
	} else if (m_mouseState.m_currentRelative) {
		m_mouseState.m_cursorClientDelta = m_currentWindow->GetCursorPosition() - m_mouseState.m_cursorClientPosition;
		m_currentWindow->SetCursorPosition(m_currentWindow->GetWindoeCenterPos());
	} else if (! m_mouseState.m_currentRelative) {
		m_mouseState.m_cursorClientDelta = IntVec2();
	}
	m_mouseState.m_cursorClientPosition = m_currentWindow->GetCursorPosition();
}
void InputSystem::EndFrame() {
	for (int index = 0; index < NUM_KEYCODES; index++) {
		m_keyStates[index].m_wasPressedLastFrame = m_keyStates[index].m_isPressed;
	}
	for (int index = 0; index < NUM_XBOX_CONTROLLERS; index++) {
		m_controllers[index].EndFrame();
	}
	m_mouseState.m_cursorClientMidDelta = 0;
}

void  InputSystem::Update(float deltaSeconds) {
	m_timePassed += deltaSeconds;
	for (int index = 0; index < NUM_XBOX_CONTROLLERS; index++) {
		m_controllers[index].Update();
	}
}

//Helper functions-------------------------------------------------------------------
bool InputSystem::WasKeyJustPressed(unsigned char keyCode) const {
	return m_keyStates[(int)keyCode].m_isPressed && ! m_keyStates[(int)keyCode].m_wasPressedLastFrame;
}
bool InputSystem::WasKeyJustDoubleReleased(unsigned char keyCode) const {
	return WasKeyJustReleased(keyCode) && m_lastKeyWasDoubleReleased;
}
bool InputSystem::WasKeyJustSingleReleased(unsigned char keyCode) const {
	return !WasKeyJustDoubleReleased(keyCode) && WasKeyJustReleased(keyCode);
}
bool InputSystem::WasKeyJustReleased(unsigned char keyCode) const {
	return ! m_keyStates[(int)keyCode].m_isPressed && m_keyStates[(int)keyCode].m_wasPressedLastFrame;
}
bool InputSystem::IsKeyDown(unsigned char keyCode) const {
	return m_keyStates[(int)keyCode].m_isPressed;
}
void InputSystem::HandleKeyPressed(unsigned char keyCode) {
	m_keyStates[(int)keyCode].m_isPressed = true;
}

void InputSystem::HandleKeyReleased(unsigned char keyCode) {
	m_keyStates[(int)keyCode].m_isPressed = false;
	m_lastKeyWasDoubleReleased = false;
	if (keyCode == m_lastKeyReleased && m_timePassed - m_timeOfLastKeyReleased < DOUBLE_PRESS_TIME_LIMIT) {
		m_lastKeyWasDoubleReleased = true;
	}
	m_lastKeyReleased = keyCode;
	m_timeOfLastKeyReleased = m_timePassed;
}
void InputSystem::HandleMouseWheel(long wheelChangeDegrees) {
	m_mouseState.m_cursorClientMidDelta = wheelChangeDegrees;
	m_mouseState.m_cursorClientMidPosition += wheelChangeDegrees;
}

bool InputSystem::HandleKeyPressedEvent(EventArgs& eventData) {
	if (!g_theInputSystem) {
		return false;
	}
	g_theInputSystem->HandleKeyPressed((unsigned char)eventData.GetValue("key", -1));
	return true;
}
bool InputSystem::HandleKeyReleasedEvent(EventArgs& eventData) {
	if (!g_theInputSystem) {
		return false;
	}
	g_theInputSystem->HandleKeyReleased((unsigned char)eventData.GetValue("key", -1));
	return true;
}
bool InputSystem::HandleMouseWheelEvent(EventArgs& eventData) {
	if (!g_theInputSystem) {
		return false;
	}
	g_theInputSystem->HandleMouseWheel((long)eventData.GetValue("key", -1));
	return true;
}


XboxController const& InputSystem::GetController(int controllerID) {
	return m_controllers[controllerID];
}

int InputSystem::GetCursorClientMidDelta() const {
	return GET_WHEEL_DELTA_WPARAM(m_mouseState.m_cursorClientMidDelta); 
}

Vec2 InputSystem::GetCursorNormalizedPosition() const { 
	return m_currentWindow->GetNormalizedCursorPos();
}
