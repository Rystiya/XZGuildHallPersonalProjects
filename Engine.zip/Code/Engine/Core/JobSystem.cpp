#include "Engine\Core\JobSystem.hpp"
#include "Engine\Core\EngineCommon.hpp"

JobSystem* g_theJobSystem = nullptr;

JobSystem::~JobSystem() { 
}

void JobSystem::StartUp() {
	int numOfCores = std::thread::hardware_concurrency();
	int desiredWorkers = 0;
	if (numOfCores > 4) {
		desiredWorkers = numOfCores - 2;
	}
	else {
		desiredWorkers = numOfCores - 1;
	}
	desiredWorkers = std::min(desiredWorkers, m_config.maxNumberOfWorkers);
	ExpandWorkerCountTo(desiredWorkers);
	m_isQuiting = false;
}

//This function deletes all unretrieved jobs. Retreived jobs should be destroyed by the game's main thread itself.
void JobSystem::Shutdown() { 
	m_isQuiting = true;
	for (int workerID = 0; workerID < m_workers.size(); workerID++) {
		delete m_workers[workerID];
	}
	m_workers.clear();
	m_jobsToDoMutex.lock();
	while (m_jobsToDo.size() > 0) {
		Job* result = m_jobsToDo.front();
		m_jobsToDo.pop();
		delete result;
	}
	m_jobsToDoMutex.unlock();
	m_jobsCompletedMutex.lock();
	while (m_jobsCompleted.size() > 0) {
		Job* result = m_jobsCompleted.front();
		m_jobsCompleted.pop();
		delete result;
	}
	m_jobsCompletedMutex.unlock();
}

void JobSystem::ExpandWorkerCountTo(int numWorkerThreads) {
	for (int workerID = 0; workerID < numWorkerThreads; workerID++) {
		if (m_workers.size() > workerID) {
			continue;
		}
		JobWorker* worker = new JobWorker(this, workerID);
		m_workers.push_back(worker);
	}
}

void JobSystem::PostNewJob(Job* job) {
	m_jobsToDoMutex.lock();
	m_jobsToDo.push(job);
	job->m_state = JobState::QUEUED;
	m_jobsToDoMutex.unlock();
}

Job* JobSystem::WorkerClaimOneJob() {
	Job* result = nullptr;
	m_jobsToDoMutex.lock();
	if (m_jobsToDo.size() > 0) {
		result = m_jobsToDo.front();
		m_jobsToDo.pop();
		result->m_state = JobState::CLAIMED;
	}
	m_jobsToDoMutex.unlock();
	return result;

}

void JobSystem::WorkerPostFinishedJob(Job* job) {
	m_jobsCompletedMutex.lock();
	m_jobsCompleted.push(job);
	job->m_state = JobState::FINISHED;
	m_jobsCompletedMutex.unlock();
}

Job* JobSystem::MainRetreiveOneJob() {
	Job* result = nullptr;
	m_jobsCompletedMutex.lock();
	if (m_jobsCompleted.size() > 0) {
		result = m_jobsCompleted.front();
		m_jobsCompleted.pop();
		result->m_state = JobState::RETRIEVED;
	}
	m_jobsCompletedMutex.unlock();
	return result;

}

JobWorker::JobWorker(JobSystem* boss, int workerID) {
	m_boss = boss; 
	m_workerID = workerID;
	m_thread = new std::thread(JobWorker::ThreadMain, this);
}


JobWorker::~JobWorker() {
	m_thread->join();
}


void JobWorker::ThreadMain(JobWorker* worker) {
	while (!worker->m_boss->GetIsQuiting()) {
		Job* jobToDo = worker->m_boss->WorkerClaimOneJob();
		if (jobToDo != nullptr) {
			jobToDo->Execute();
			worker->m_boss->WorkerPostFinishedJob(jobToDo);
		}
		else {
			std::this_thread::sleep_for(std::chrono::microseconds(3));
		}
	}
}