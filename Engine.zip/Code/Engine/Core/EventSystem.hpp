#pragma once
#include "Engine\Core\NamedStrings.hpp"
#include <string>
#include <vector>
#include <mutex>

typedef NamedStrings EventArgs;
typedef bool (*EventCallbackFunction) (EventArgs&);
//using EventCallbackFunction = bool (*) (EventArgs);
//Unused for now
struct EventSystemConfig {
	std::string m_eventSystemName = "Event system!";
};
//Unused for now
struct EventSubscription {
	EventCallbackFunction subscribingFunction = nullptr;
};
typedef std::vector<EventSubscription> SubscriptionList;

class EventSystem;
extern EventSystem* g_theEventSystem;


//-----------------------------------------------------------------------------------------------
class EventSystem
{
public: 
	EventSystem(EventSystemConfig const& config) { m_config = config; }
	~EventSystem() {}
	void Startup() {}
	void Shutdown() {}
	void BeginFrame() {}
	void EndFrame() {}

	void SubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr);
	void UnSubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr);
	void FireEvent(std::string const& eventName, EventArgs& args);
	void FireEvent(std::string const& eventName) { EventArgs args = EventArgs();  FireEvent(eventName, args); }
	std::vector<std::string> GetEventNameList();

protected:
	EventSystemConfig m_config;
	std::map<std::string, SubscriptionList> m_subscriptionListsByEventName;
private:
	std::mutex m_protectionMutex;
};


//Classless version of class functions, so anyone can call them without EventSystem::
void SubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr);
void UnSubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr);
void FireEvent(std::string const& eventName, EventArgs& args);
void FireEvent(std::string const& eventName);

