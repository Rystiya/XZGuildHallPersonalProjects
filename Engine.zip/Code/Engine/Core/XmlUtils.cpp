#include "Engine\Core\XmlUtils.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\FloatRange.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Core\NamedStrings.hpp"


int ParseXmlAttribute(XmlElement const& element, char const* attributeName, int defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return atoi(fetchedString);
	}
	return defaultValue;
}
char ParseXmlAttribute(XmlElement const& element, char const* attributeName, char defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return fetchedString[0];
	}
	return defaultValue;
}
bool ParseXmlAttribute(XmlElement const& element, char const* attributeName, bool defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		if (fetchedString[0] == 'y' || fetchedString[0] == 't' || fetchedString[0] == 'Y' || fetchedString[0] == 'T') {
			return true;
		}
		if (fetchedString[0] == 'n' || fetchedString[0] == 'f' || fetchedString[0] == 'N' || fetchedString[0] == 'F') {
			return false;
		}
	}
	return defaultValue;

}
float ParseXmlAttribute(XmlElement const& element, char const* attributeName, float defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return (float)atof(fetchedString);
	}
	return defaultValue;
}
FloatRange ParseXmlAttribute(XmlElement const& element, char const* attributeName, FloatRange defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return FloatRange(fetchedString);
	}
	return defaultValue;
}
Rgba8 ParseXmlAttribute(XmlElement const& element, char const* attributeName, Rgba8 const& defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return Rgba8(fetchedString);
	}
	return defaultValue;
}
Vec2 ParseXmlAttribute(XmlElement const& element, char const* attributeName, Vec2 const& defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return Vec2(fetchedString);
	}
	return defaultValue;
}
IntVec2 ParseXmlAttribute(XmlElement const& element, char const* attributeName, IntVec2 const& defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return IntVec2(fetchedString);
	}
	return defaultValue;
}
std::string ParseXmlAttribute(XmlElement const& element, char const* attributeName, std::string const& defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return std::string(fetchedString);
	}
	return defaultValue;

}
Strings ParseXmlAttribute(XmlElement const& element, char const* attributeName, Strings const& defaultValues) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return SplitStringOnDelimiter(std::string(fetchedString));
	}
	return defaultValues;

}
std::string ParseXmlAttribute(XmlElement const& element, char const* attributeName, char const* defaultValue) {
	const char* fetchedString = element.Attribute(attributeName);
	if (fetchedString != nullptr) {
		return std::string(fetchedString);
	}
	return std::string(defaultValue);

}

//Put contents of xml file into a data structure named strings
void LoadXmlFileIntoStringMap(NamedStrings& targetStringMap, std::string const& xmlFilePath) {
	XmlDocument tempDoc;
	tempDoc.LoadFile(xmlFilePath.c_str());
	XmlElement* examinedElement = tempDoc.RootElement();
	if (examinedElement != nullptr) {
		targetStringMap.PopulateFromXmlElementAttributes(*examinedElement);
		examinedElement = examinedElement->NextSiblingElement();
	}
}
