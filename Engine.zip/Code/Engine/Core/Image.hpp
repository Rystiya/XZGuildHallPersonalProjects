#pragma once

#include "Engine\Math\IntVec2.hpp"
#include "Engine\Core\Rgba8.hpp"
#include <string>
#include <vector>

//-----------------------------------------------------------------------------------------------
class Image 
{
	friend class Renderer;

public:
	Image() {}
	~Image() {}
	Image(const char* imageFilePath);
	Image(IntVec2 size, Rgba8 color);
	IntVec2 GetDimensions() const { return m_dimensions; }
	const std::string& GetImageFilePath() const { return m_imageFilePath; }
	const void* GetRawData()  const { return m_texelRgba8Data.data(); }
	Rgba8 GetColorAtPosition(IntVec2 position) { int index = position.x + m_dimensions.x * position.y;  return m_texelRgba8Data[index]; }
	int GetNumChannels()  const { return m_channals; }

private:
	std::string m_imageFilePath = "";
	IntVec2 m_dimensions = IntVec2(1,1);
	int m_channals = 4;
	std::vector<Rgba8> m_texelRgba8Data = std::vector<Rgba8>{};
};

