#pragma once
#include "Engine\Core\Clock.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Core\EventSystem.hpp"
#include <string>
#include <vector>
#include <mutex>

class Renderer;
class Camera;
class BitmapFont;
class Stopwatch;
struct AABB2;
struct Vertex_PCU;

class DevConsole;
extern DevConsole* g_theDevConsole;



//One line of text to be displayed on dev console
struct DevConsoleLine {
	Rgba8 m_color;
	std::string m_text;
};

struct DevConsoleConfig
{
	Renderer* m_renderer = nullptr;
	Camera* m_camera = nullptr;
	std::string m_fontName = "SquirrelFixedFont";
	float m_fontAspect = 0.4f;
	float m_linesOnScreen = 40.0f;
	int m_maxCommandHistory = 128;

};


//-----------------------------------------------------------------------------------------------
class DevConsole
{
public: 
	DevConsole(DevConsoleConfig const& config);
	~DevConsole();
	void Startup();
	void Shutdown();
	void BeginFrame() {}
	void EndFrame() {}

	//Try parse and execute this line of text
	void Execute(std::string const& consoleCommandText);
	void AddLine(Rgba8 const& color, std::string const& text);
	void AddUnclearableLine(Rgba8 const& color, std::string const& text);

	//bounds are in terms of the m_camera.
	void Render(AABB2 const& bounds);
	void Render();

	//Whether the console is active
	void ToggleOpen();
	bool GetIsOpen() const;


	static bool HandleKeyPressedEvent(EventArgs& args);
	static bool HandleCharInputEvent(EventArgs& args);
	static bool HandleClearCommandEvent(EventArgs& args);
	static bool HandleHelpCommandEvent(EventArgs& args);


protected:
	std::mutex m_protectionMutex;
	bool IsCaretVisible() const;
	void AddALineToConsoleBound(std::vector<Vertex_PCU>& vertexes, AABB2 entireBound, int currentLine, std::string text, Rgba8 color);
	void DrawCaret(AABB2 entireBound);

	DevConsoleConfig m_config;
	bool m_isOpen = false;
	//All lines added to the dev console (to be displayed).
	std::vector<DevConsoleLine> m_lines = {};
	std::vector<DevConsoleLine> m_baseLines = {};
	//Current input line, not yet processed
	std::string m_inputText = "";
	//Index of the caret
	int m_caretPosition = 0;
	//History of all commands execeted (does not get cleared like the m_lines?)
	std::vector<std::string> m_commandHistory;
	//Current index in command history (used for scrolling).
	int m_historyIndex = -1;
	Stopwatch* m_caretStopwatch = nullptr;
	BitmapFont* m_font = nullptr;

};


