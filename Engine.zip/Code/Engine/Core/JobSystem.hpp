#pragma once

#include <queue>
#include <vector>
#include <mutex>
#include <thread>

class JobWorker;
class JobSystem;
extern JobSystem* g_theJobSystem;

enum class JobState { TOBEQUEUED, QUEUED, CLAIMED, FINISHED, RETRIEVED, COUNT };

struct JobSystemConfig
{
	int maxNumberOfWorkers = 0;
};


class Job {
public:
	Job(int ID) { m_ID = ID; }
	virtual ~Job() {}
	virtual void Execute() = 0;

	int m_ID = 0;
	std::atomic<JobState> m_state = JobState::TOBEQUEUED;
};

class JobSystem
{
public:
	JobSystem(JobSystemConfig config) { m_config = config; }
	~JobSystem();

	void StartUp();
	void BeginFrame() {}
	void EndFrame() {}
	void Shutdown();

	void PostNewJob(Job* job);
	Job* WorkerClaimOneJob();
	void WorkerPostFinishedJob(Job* job);
	Job* MainRetreiveOneJob();

	int64_t GetNumberOfJobsInQueue() const { return m_jobsToDo.size(); }
	int64_t GetNumberOfJobsCompleted() const { return m_jobsCompleted.size(); }
	int64_t GetNumberOfWorkers() const { return m_workers.size(); }
	bool GetIsQuiting() const { return m_isQuiting; }

private:
	void ExpandWorkerCountTo(int numWorkerThreads);
	//Atomic is necessary
	std::atomic<bool> m_isQuiting = false;
	JobSystemConfig m_config;
	std::vector<JobWorker*> m_workers;

	std::queue<Job*> m_jobsToDo;
	std::mutex m_jobsToDoMutex;
	std::queue<Job*> m_jobsCompleted;
	std::mutex m_jobsCompletedMutex;

};


class JobWorker {
public:
	JobWorker(JobSystem* boss, int workerID);
	~JobWorker();

	static void ThreadMain(JobWorker* worker);

	JobSystem* m_boss = nullptr;
	int m_workerID = -1;
	std::thread* m_thread = nullptr;
};
