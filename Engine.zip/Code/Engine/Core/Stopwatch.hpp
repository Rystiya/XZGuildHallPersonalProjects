#pragma once

class Clock;

class Stopwatch
{
public:
	explicit Stopwatch(float duration);
	Stopwatch(const Clock* clock, float duration);
	void Start();
	void Restart();
	void Stop() { m_startTime = -1.f; }

	float GetElapsedFraction() const { return GetElapsedTime() / m_duration; }
	float GetElapsedTime() const;
	bool IsStopped() const { return m_startTime < 0.0f; }
	bool HasDurationElapsed() const { return GetElapsedFraction() >= 1 && !IsStopped(); }
	bool DecrementDurationIfElapsed();

protected:
	const Clock* m_clock = nullptr;
	float m_startTime = 0.0f;
	float m_duration = 0.0f;

};