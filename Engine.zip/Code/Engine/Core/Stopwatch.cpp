#include "Engine\Core\Stopwatch.hpp"
#include "Engine\Core\Clock.hpp"
#include "Engine\Core\EngineCommon.hpp"


Stopwatch::Stopwatch(float duration) 
	:m_clock(&Clock::GetSystemClock())
	, m_duration(duration) 
{
}
Stopwatch::Stopwatch(const Clock* clock, float duration) 
	:m_clock(clock)
	,m_duration(duration)
{
}

void Stopwatch::Start() {
	m_startTime = m_clock->GetTotalSeconds();
}
void Stopwatch::Restart() {
	if (!IsStopped()) {
		Start();
	}
}
float Stopwatch::GetElapsedTime() const {
	if (!IsStopped()) {
		return  m_clock->GetTotalSeconds() - m_startTime;
	}
	return 0.f;
}
bool Stopwatch::DecrementDurationIfElapsed() {
	if (!IsStopped() && HasDurationElapsed()) {
		m_startTime += m_duration;
		return true;
	}
	return false;

}