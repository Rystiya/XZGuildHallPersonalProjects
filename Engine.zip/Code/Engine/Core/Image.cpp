
#include "Engine\Core\Image.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"
#include "Engine\Core\EngineCommon.hpp"

#define STB_IMAGE_IMPLEMENTATION // Exactly one .CPP (this Image.cpp) should #define this before #including stb_image.h
#include "ThirdParty/stb/stb_image.h"


Image::Image(const char* imageFilePath) {
	m_imageFilePath = imageFilePath;
	stbi_set_flip_vertically_on_load(1); // We prefer uvTexCoords has origin (0,0) at BOTTOM LEFT
	unsigned char* data = stbi_load(imageFilePath, &m_dimensions.x, &m_dimensions.y, &m_channals, 0);
	if (!data) {
		ERROR_AND_DIE("Could not load image" + std::string(imageFilePath));
	}
	m_texelRgba8Data.clear();
	m_texelRgba8Data.reserve(m_dimensions.x* m_dimensions.y);
	for (int i = 0; i < m_dimensions.x * m_dimensions.y; i++) {
		int colorStartPosition = m_channals * i;
		unsigned char ocacity = 255;
		if (m_channals > 3) {
			ocacity = data[colorStartPosition + 3];
		}
		Rgba8 color = Rgba8(data[colorStartPosition], data[colorStartPosition+1], data[colorStartPosition+2], ocacity);
		m_texelRgba8Data.emplace_back(color);
	}
	m_channals = 4;

}

Image::Image(IntVec2 size, Rgba8 color) {
	m_dimensions = size;
	m_texelRgba8Data.clear();
	m_texelRgba8Data.reserve(m_dimensions.x * m_dimensions.y);
	for (int i = 0; i < m_dimensions.x * m_dimensions.y; i++) {
		m_texelRgba8Data.emplace_back(color);
	}
}