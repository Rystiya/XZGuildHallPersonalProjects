#include "Engine\Core\NamedStrings.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Core\Rgba8.hpp"


void NamedStrings::PopulateFromXmlElementAttributes(XmlElement const& element) {
	const XmlAttribute* concernedAttribute = element.FirstAttribute();
	while (concernedAttribute != nullptr) {
		SetValue(concernedAttribute->Name(), concernedAttribute->Value());
		concernedAttribute = concernedAttribute->Next();
	}
}
void NamedStrings::SetValue(std::string const& keyName, std::string const& newValue) {
	m_keyValuePairs[keyName] = newValue;
}

std::string NamedStrings::GetValue(std::string const& keyName, std::string const& defaultValue) const {
	auto findResult = m_keyValuePairs.find(keyName);
	if (findResult != m_keyValuePairs.end()) {
		return findResult->second;
	}
	return defaultValue;
}
bool NamedStrings::GetValue(std::string const& keyName, bool defaultValue) const {
	std::string foundString = GetValue(keyName, "");
	if (foundString.size() > 0) {
		if (foundString[0] == 'y' || foundString[0] == 't' || foundString[0] == 'Y' || foundString[0] == 'T') {
			return true;
		}
		if (foundString[0] == 'n' || foundString[0] == 'f' || foundString[0] == 'N' || foundString[0] == 'F') {
			return false;
		}
	}
	return defaultValue;
}
int NamedStrings::GetValue(std::string const& keyName, int defaultValue) const {
	std::string foundString = GetValue(keyName, "");
	if (foundString.size() > 0) {
		return atoi(foundString.c_str());
	}
	return defaultValue;
}
float NamedStrings::GetValue(std::string const& keyName, float defaultValue) const {
	std::string foundString = GetValue(keyName, "");
	if (foundString.size() > 0) {
		return (float)atof(foundString.c_str());
	}
	return defaultValue;
}
std::string NamedStrings::GetValue(std::string const& keyName, char const* defaultValue) const {
	std::string foundString = GetValue(keyName, std::string(defaultValue));
	return foundString;
}
Rgba8 NamedStrings::GetValue(std::string const& keyName, Rgba8 const& defaultValue) const {
	std::string foundString = GetValue(keyName, "");
	if (foundString.size() > 0) {
		return Rgba8(foundString.c_str());
	}
	return defaultValue;
}
Vec2 NamedStrings::GetValue(std::string const& keyName, Vec2 const& defaultValue) const {
	std::string foundString = GetValue(keyName, "");
	if (foundString.size() > 0) {
		return Vec2(foundString.c_str());
	}
	return defaultValue;
}
IntVec2 NamedStrings::GetValue(std::string const& keyName, IntVec2 const& defaultValue) const {
	std::string foundString = GetValue(keyName, "");
	if (foundString.size() > 0) {
		return IntVec2(foundString.c_str());
	}
	return defaultValue;
}