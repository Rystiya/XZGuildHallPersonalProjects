#pragma once
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Core\EventSystem.hpp"
#include <string>
#include <vector>

enum class DebugRenderMode { ALWAYS, USE_DEPTH, X_RAY };

class Renderer;
class Camera;
class BitmapFont;
class Stopwatch;
struct AABB2;
struct Vertex_PCU;
class DevConsole;
struct Mat44;

struct DebugRenderConfig {
	Renderer* m_renderer = nullptr;
	bool m_startHidden = false;
};

//Setup
void DebugRenderSystemStartup(const DebugRenderConfig& config);
void DebugRenderSystemShutdown();
//Control
void DebugRenderSetVisible();
void DebugRenderSetHidden();
void DebugRenderClear();
//Output
void DebugRenderBeginFrame();
void DebugRenderWorld(const Camera& camera);
void DebugRenderScreen(const Camera& camera);
void DebugRenderEndFrame();
//Geometry
void DebugAddWorldPoint(const Vec3& pos, float radius = 1.f, 
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH);
void DebugAddWorldLine(const Vec3& start, const Vec3& end, float radius = 1.f, 
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH);
void DebugAddWorldWireCylinder(const Vec3& base, const Vec3& top, float radius = 1.f, float duration = 3.f,
	const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH);
void DebugAddWorldSphere(const Vec3& center, float radius = 1.f,
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH, bool wireFrame = false);
void DebugAddWorldArrow(const Vec3& start, const Vec3& end, float radius = 1.f, 
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH, bool wireFrame = false);
void DebugAddWorldText(const std::string&text, const Mat44& transform, float textHeight, const Vec2& alignment, 
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH);
void DebugAddWorldBillboardText(const std::string& text, const Vec3& origin, float textHeight, const Vec2& alignment, 
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8(), DebugRenderMode mode = DebugRenderMode::USE_DEPTH);
void DebugAddScreenText(const std::string& text, const Vec2 position, float size, const Vec2& alignment, 
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8());
void DebugAddMessage(const std::string& text,
	float duration = 3.f, const Rgba8& startColor = Rgba8(), const Rgba8& endColor = Rgba8());

//Console commands
bool Command_DebugRenderClear(EventArgs& args);
bool Command_DegbugRenderToggle(EventArgs& args);