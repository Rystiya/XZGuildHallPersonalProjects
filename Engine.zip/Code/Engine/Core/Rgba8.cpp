#include "Engine\Core\Rgba8.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\StringUtils.hpp"


Rgba8::Rgba8(unsigned char rInit, unsigned char gInit, unsigned char bInit, unsigned char aInit)
	: r(rInit)
	, g(gInit)
	, b(bInit)
	, a(aInit)
{
}

Rgba8::Rgba8(char const* text) {
	SetFromText(text);
}

//Rgba8::Rgba8(int rInit, int gInit, int bInit, int aInit) {
	//Rgba8(unsigned char (rInit), unsigned char (gInit), unsigned char (bInit), unsigned char (aInit));
//}


void Rgba8::Randomize(RandomNumberGenerator& rnd, float randomizeFactor, bool aValueIncluded) {
	r = (unsigned char)GetClamped(int(r * rnd.RollRandomFloatInRange(1 - randomizeFactor, 1 + randomizeFactor)), 0, 255);
	g = (unsigned char)GetClamped(int(g * rnd.RollRandomFloatInRange(1 - randomizeFactor, 1 + randomizeFactor)), 0, 255);
	b = (unsigned char)GetClamped(int(b * rnd.RollRandomFloatInRange(1 - randomizeFactor, 1 + randomizeFactor)), 0, 255);
	if (aValueIncluded) {
		a = (unsigned char)GetClamped(int(a * rnd.RollRandomFloatInRange(1 - randomizeFactor, 1 + randomizeFactor)), 0, 255);
	}
}


void Rgba8::TimesByFloat(float timedBy, bool aValueIncluded) {
	r = (unsigned char)GetClamped(int(r * timedBy), 0, 255);
	g = (unsigned char)GetClamped(int(g * timedBy), 0, 255);
	b = (unsigned char)GetClamped(int(b * timedBy), 0, 255);
	if (aValueIncluded) {
		a = (unsigned char)GetClamped(int(a * timedBy), 0, 255);
	}
}


void Rgba8::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	r = (unsigned char) atoi(seperateedStrings[0].c_str());
	g = (unsigned char) atoi(seperateedStrings[1].c_str());
	b = (unsigned char) atoi(seperateedStrings[2].c_str());
	if (seperateedStrings.size() > 3) {
		a = (unsigned char) atoi(seperateedStrings[3].c_str());
	}
}


void Rgba8::GetAsFloats(float* colorAsFloats) {
	colorAsFloats[0] = ((float)r) / 255;
	colorAsFloats[1] = ((float)g) / 255;
	colorAsFloats[2] = ((float)b) / 255;
	colorAsFloats[3] = ((float)a) / 255;
}

void Rgba8::TurnBlack(float byRatio) {
	r = (unsigned char)GetClamped(int(r * (1.f - byRatio)), 0, 255);
	g = (unsigned char)GetClamped(int(g * (1.f - byRatio)), 0, 255);
	b = (unsigned char)GetClamped(int(b * (1.f - byRatio)), 0, 255);
}
void Rgba8::TurnWhite(float byRatio) {
	r = (unsigned char)GetClamped(int(r * (1.f - byRatio) + 255 * byRatio), 0, 255);
	g = (unsigned char)GetClamped(int(g * (1.f - byRatio) + 255 * byRatio), 0, 255);
	b = (unsigned char)GetClamped(int(b * (1.f - byRatio) + 255 * byRatio), 0, 255);
}
void Rgba8::TurnGrey(float byRatio) {
	float averageRGB = (static_cast<float>(r) + static_cast<float>(g) + static_cast<float>(b)) / 3.f;
	r = (unsigned char)GetClamped(int(r * (1.f - byRatio) + averageRGB * byRatio), 0, 255);
	g = (unsigned char)GetClamped(int(g * (1.f - byRatio) + averageRGB * byRatio), 0, 255);
	b = (unsigned char)GetClamped(int(b * (1.f - byRatio) + averageRGB * byRatio), 0, 255);
}


bool Rgba8::operator==(const Rgba8& compare) const
{
	return (r == compare.r && g == compare.g && b == compare.b && a == compare.a);
}

Rgba8 Rgba8::operator+(const Rgba8& other) const
{
	return Rgba8((unsigned char)GetClamped(int(r + other.r), 0, 255), (unsigned char)GetClamped(int(g + other.g), 0, 255), (unsigned char)GetClamped(int(b + other.b), 0, 255), (unsigned char)GetClamped(int(a + other.a), 0, 255));
}

Rgba8 Rgba8::operator*(float ratio) const
{
	return Rgba8((unsigned char)GetClamped(int(r * ratio), 0, 255), (unsigned char)GetClamped(int(g * ratio), 0, 255), (unsigned char)GetClamped(int(b * ratio), 0, 255), (unsigned char)GetClamped(int(a * ratio), 0, 255));
}