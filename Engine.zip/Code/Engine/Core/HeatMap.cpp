#include "Engine\Core\HeatMap.hpp"
#include "Engine\Core\EngineCommon.hpp"


HeatMap::HeatMap(IntVec2 const& dimensions, float initialValue) {
	m_dimentions = dimensions;
	for (int index = 0; index < m_dimentions.x * m_dimentions.y; index++) {
		m_values.emplace_back(initialValue);
	}
}


void HeatMap::SetAllValues(float valueToSet) {
	for (int index = 0; index < m_dimentions.x * m_dimentions.y; index++) {
		m_values[index] = valueToSet;
	}
}


void HeatMap::SetValueAt(float valueToSet, IntVec2 cordinates) {
	m_values[Get1DIndexFrom2DIndex(cordinates)] = valueToSet;
}

void HeatMap::AddValueAt(float valueToAdd, IntVec2 cordinates) {
	m_values[Get1DIndexFrom2DIndex(cordinates)] += valueToAdd;
}

float HeatMap::GetValueAt(IntVec2 cordinates) const {
	return m_values[Get1DIndexFrom2DIndex(cordinates)];
}



int HeatMap::Get1DIndexFrom2DIndex(IntVec2 the2DIndex) const {
	return the2DIndex.x + m_dimentions.x * the2DIndex.y;
}