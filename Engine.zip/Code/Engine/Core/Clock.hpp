#pragma once
#include <vector>

class Clock
{
public:
	//Default constructor use the system clock as parent
	Clock();
	explicit Clock(Clock& parent);
	//Destructor delete children but does not notify parent
	~Clock();
	Clock(const Clock& copy) = delete;

	void Reset();

	bool IsPaused() { return m_isPaused; }
	void Pause() { m_isPaused = true; }
	void UnPause() { m_isPaused = false; }
	void TogglePause() { m_isPaused = !m_isPaused; }

	void StepSingleFrame() { m_isPaused = false; m_pauseNextFrame = true; }

	void SetTimeScale(float timeScale) { m_timeScale = timeScale; }
	float GetTimeScale() const { return m_timeScale; }
	void SetMaxTimeStep(float maxTimeStep) { m_maxTimeStep = maxTimeStep; }

	float GetDeltaSeconds() const { return m_lastDeltaSeconds; }
	float GetBaseDeltaSeconds() const { return m_lastBaseDeltaSeconds; }
	float GetTotalSeconds() const { return m_totalSeconds; }
	int GetFrameCount() const { return (int)m_totalFrameCount; }

	//The system clock, also the default parent of this class
	static Clock& GetSystemClock();
	static void TickSystemClock();

protected:
	//Calculate delta seconds then call advance
	void Tick();
	//calculate delta seconds based on pausing and time scale, then advance children
	void Advance(float baseDeltaSeconds);

	void AddChild(Clock* childClock) { m_children.emplace_back(childClock); }
	void RemoveChild(Clock* childClock);
	void ClearAllChildren();
	void ReparentAllChildren();

	Clock* m_parent = nullptr;
	std::vector<Clock*> m_children;
	bool m_isPaused = false;
	bool m_pauseNextFrame = false;
	float m_timeScale = 1.f;
	float m_lastUpdateTimeInSeconds = 0.f;
	float m_lastDeltaSeconds = 0.f;
	float m_lastBaseDeltaSeconds = 0.f;
	float m_totalSeconds = 0.f;
	float m_maxTimeStep = 0.1f;
	size_t m_totalFrameCount = 0;



};