#pragma once

class RandomNumberGenerator;

//-----------------------------------------------------------------------------------------------
struct Rgba8
{
public: // red green blue transperency. use char because they are in 0-255
	unsigned char r = 255;
	unsigned char g = 255;
	unsigned char b = 255;
	unsigned char a = 255;

public:
	// Construction/Destruction
	~Rgba8() {}												// destructor (do nothing)
	Rgba8() {}												// default constructor (do nothing)
	Rgba8(unsigned char rInit, unsigned char gInit, unsigned char bInit, unsigned char aInit = 255);		// explicit constructor (from x, y)
	Rgba8(char const* text);
	//Rgba8(int rInit, int gInit, int bInit, int aInit = 255);		// explicit constructor (from x, y)
	void Randomize(RandomNumberGenerator& rnd, float randomizeFactor = 0.2f, bool aValueIncluded = false);
	void TimesByFloat(float timedBy = 0.5f, bool aValueIncluded = false);
	void SetFromText(char const* text);
	void GetAsFloats(float* colorAsFloats);
	void TurnBlack(float byRatio);
	void TurnWhite(float byRatio);
	void TurnGrey(float byRatio);

	bool		operator==(const Rgba8& compare) const;		
	Rgba8		operator+(const Rgba8& other) const;
	Rgba8		operator*(float ratio) const;
};


