#include "Engine\Core\Vertex_PCU.hpp"
//#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\EngineCommon.hpp"


//-----------------------------------------------------------------------------------------------
Vertex_PCU::Vertex_PCU(Vec3 const& position, Rgba8 const& tint, Vec2 const& uvTexCoords)
	: m_position(position)
	, m_color(tint)
	, m_uvTexCoords(uvTexCoords)
{
}

Vertex_PCU::Vertex_PCU(Vec2 const& position, Rgba8 const& tint, Vec2 const& uvTexCoords)
	: m_position(Vec2(position))
	, m_color(tint)
	, m_uvTexCoords(uvTexCoords)
{
}

Vertex_PCU::Vertex_PCU(Vertex_PNCU const& copyFrom)
	: m_position(copyFrom.m_position)
	, m_color(copyFrom.m_color)
	, m_uvTexCoords(copyFrom.m_uvTexCoords)
{
}

Vertex_PCU::Vertex_PCU(Vertex_PCU const& copyFrom)
	: m_position(copyFrom.m_position)
	, m_color(copyFrom.m_color)
	, m_uvTexCoords(copyFrom.m_uvTexCoords)
{
}

Vertex_PCU::Vertex_PCU()
{
	m_position = Vec3(1.f,1.f,1.f);
	m_color = Rgba8(255, 255, 255, 255);
	m_uvTexCoords = Vec2(0.f, 0.f);
}

//-----------------------------------------------------------------------------------------------
Vertex_PNCU::Vertex_PNCU(Vec3 const& position, Rgba8 const& tint, Vec2 const& uvTexCoords, Vec3 const& surfaceNormal)
	: Vertex_PCU(position, tint, uvTexCoords)
	, m_surfaceNormal(surfaceNormal)
{
}

Vertex_PNCU::Vertex_PNCU(Vec2 const& position, Rgba8 const& tint, Vec2 const& uvTexCoords, Vec3 const& surfaceNormal)
	: Vertex_PCU(position, tint, uvTexCoords)
	, m_surfaceNormal(surfaceNormal)
{
}

Vertex_PNCU::Vertex_PNCU() : Vertex_PCU()
{
	m_surfaceNormal = Vec3(0.f, 0.f, 1.f);
}
