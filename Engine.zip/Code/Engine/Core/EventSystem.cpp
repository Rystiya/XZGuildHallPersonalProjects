#include "Engine\Core\EventSystem.hpp"
#include "Engine\Core\EngineCommon.hpp"


EventSystem* g_theEventSystem = nullptr;



void EventSystem::SubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr) {
	m_protectionMutex.lock();
	m_subscriptionListsByEventName[eventName].emplace_back(EventSubscription{functionPtr});
	m_protectionMutex.unlock();
}

void EventSystem::UnSubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr) {
	m_protectionMutex.lock();
	SubscriptionList currentSubscriptionList = m_subscriptionListsByEventName[eventName];
	for (int index = 0; index < currentSubscriptionList.size(); index++) {
		if (currentSubscriptionList[index].subscribingFunction == functionPtr) {
			//Erase will move other elements to fill in the gap, which is slow, but will not cause bugs
			currentSubscriptionList.erase(currentSubscriptionList.begin() + index);
		}
	}
	m_protectionMutex.unlock();
}

void EventSystem::FireEvent(std::string const& eventName, EventArgs& args) {
	m_protectionMutex.lock();
	//If the key is invalid, an empty/default element will be added, which should be harmless...
	SubscriptionList currentSubscriptionList = m_subscriptionListsByEventName[eventName];
	for (int index = 0; index < currentSubscriptionList.size(); index++) {
		EventCallbackFunction currentFunction = currentSubscriptionList[index].subscribingFunction;
		//Run the stored functions, and break if the event is consumed
		if (currentFunction(args)) {
			break;
		}
	}
	m_protectionMutex.unlock();
}

std::vector<std::string> EventSystem::GetEventNameList() {
	m_protectionMutex.lock();
	std::vector<std::string> allKeys;
	for (auto eventItem = m_subscriptionListsByEventName.begin(); eventItem != m_subscriptionListsByEventName.end(); eventItem++) {
		allKeys.emplace_back(eventItem->first);
	}
	m_protectionMutex.unlock();
	return allKeys;
}


void SubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr) { 
	g_theEventSystem->SubscribeEventCallbackFunction(eventName, functionPtr); 
}
void UnSubscribeEventCallbackFunction(std::string const& eventName, EventCallbackFunction functionPtr) {
	g_theEventSystem->UnSubscribeEventCallbackFunction(eventName, functionPtr); 
}
void FireEvent(std::string const& eventName, EventArgs& args) {
	g_theEventSystem->FireEvent(eventName, args); 
}
void FireEvent(std::string const& eventName) {
	g_theEventSystem->FireEvent(eventName); 
}
std::vector<std::string> GetEventNameList() {
	return g_theEventSystem->GetEventNameList();
}