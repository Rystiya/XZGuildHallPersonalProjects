#include "Engine\Core\EngineCommon.hpp"

NamedStrings g_gameConfigBlackboard = NamedStrings();
