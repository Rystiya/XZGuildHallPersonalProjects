#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Renderer\Camera.hpp"
#include "Engine\Renderer\BitmapFont.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Core\EngineCommon.hpp"
#include "Engine\Core\Time.hpp"
#include <mutex>

class DebugProp;
class DebugRenderSystem;

DebugRenderSystem* g_theDebugRenderSystem = nullptr;
Texture* g_debugSystemFontTexture = nullptr;
BitmapFont* g_debugSystemFont = nullptr;
float g_debugMessageFontSizeFactor = 1.f;


//The debug draw prop class-------------------------------------------------------------------------------------------------------------
class DebugProp
{
public:
	// Construction/Destruction
	~DebugProp() {}
	DebugProp() {}
	DebugProp(Rgba8 startColor, Rgba8 endColor, float duration, DebugRenderMode mode = DebugRenderMode::USE_DEPTH);

	std::vector<Vertex_PCU> m_vertexes;
	Texture* m_texture = nullptr;
	void Update(float deltaSeconds);
	void Render(Renderer* renderer, Mat44 cameraMatrix = Mat44()) const;

	Rgba8 m_startColor;
	Rgba8 m_endColor;
	float m_maxLife = 3.f;
	float m_currentLife = 0.f;
	bool m_isTrash = false;
	bool m_isInScreenSpace = false;
	Vec3 m_pivot;
	RasterizerMode m_cullBackAndFillSetting = RasterizerMode::RASTERIZERMODE_SOLID_CULL_BACK;
	BillboardType m_billboardType = BillboardType::NONE;
	DebugRenderMode m_mode = DebugRenderMode::USE_DEPTH;
};


DebugProp::DebugProp(Rgba8 startColor, Rgba8 endColor, float duration, DebugRenderMode mode) {
	m_startColor = startColor;
	m_endColor = endColor;
	m_maxLife = duration;
	m_mode = mode;
}

void DebugProp::Update(float deltaSeconds) {
	if (m_maxLife > -1.f * TINY_POSITIVE_NUMBER && m_currentLife > m_maxLife + TINY_POSITIVE_NUMBER) {
		m_isTrash = true;
	}
  	m_currentLife += deltaSeconds;
}


void DebugProp::Render(Renderer* renderer, Mat44 cameraMatrix) const {
	//Set color
	Rgba8 currentColor;
	if (m_maxLife < TINY_POSITIVE_NUMBER) {
		currentColor = m_startColor;
	}
	else {
		float lifeFraction = m_currentLife / m_maxLife;
		currentColor.r = LerpByte(m_startColor.r, m_endColor.r, lifeFraction);
		currentColor.g = LerpByte(m_startColor.g, m_endColor.g, lifeFraction);
		currentColor.b = LerpByte(m_startColor.b, m_endColor.b, lifeFraction);
		currentColor.a = LerpByte(m_startColor.a, m_endColor.a, lifeFraction);
		//RecolorVertexArray3D(m_vertexes, m_currentColor);
	}
	//actually rendering
	renderer->m_desiredRasterizerMode = m_cullBackAndFillSetting;
	Mat44 dynamicTransform = Mat44();
	if (m_billboardType != BillboardType::NONE) {
		dynamicTransform = GetBillboardMatrix(m_billboardType, cameraMatrix, m_pivot);
	}
	renderer->SetModelConstants(dynamicTransform, currentColor);
	renderer->BindTexture(m_texture);
	if (m_mode == DebugRenderMode::ALWAYS) {
		renderer->m_desiredDepthMode = DepthMode::DEPTHMODE_DISABLED;
		renderer->m_desiredBlendMode = BlendMode::BLENDMODE_ALPHA;
		renderer->DrawVertexVector(m_vertexes);
		renderer->m_desiredDepthMode = DepthMode::DEPTHMODE_ENABLED;
	}
	if (m_mode == DebugRenderMode::USE_DEPTH) {
		renderer->m_desiredDepthMode = DepthMode::DEPTHMODE_ENABLED;
		renderer->m_desiredBlendMode = BlendMode::BLENDMODE_ALPHA;
		renderer->DrawVertexVector(m_vertexes);
	}
	if (m_mode == DebugRenderMode::X_RAY) {
		renderer->m_desiredDepthMode = DepthMode::DEPTHMODE_DISABLED;
		renderer->m_desiredBlendMode = BlendMode::BLENDMODE_ALPHA;
		renderer->DrawVertexVector(m_vertexes);
		renderer->m_desiredDepthMode = DepthMode::DEPTHMODE_ENABLED;
		renderer->m_desiredBlendMode = BlendMode::BLENDMODE_OPAQUE;
		renderer->DrawVertexVector(m_vertexes);
	}
	renderer->m_desiredRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_BACK;
	renderer->SetModelConstants();
	renderer->BindTexture(nullptr);
}

//The debug draw system class-------------------------------------------------------------------------------------------------------------
class DebugRenderSystem
{
public:
	// Construction/Destruction
	~DebugRenderSystem();
	DebugRenderSystem(DebugRenderConfig config);

	std::vector<DebugProp*> m_props;
	void BeginFrame() {}
	void Update(float deltaSeconds);
	void Render(const Camera& camera, bool inScreenSpace = false);
	void Clear();
	void EndFrame() {}
	int AddProp(DebugProp* newProp);

	DebugRenderConfig m_config;
	bool m_isEnabled = false;
private:

	std::mutex m_protectionMutex;
};

DebugRenderSystem::DebugRenderSystem(DebugRenderConfig config) {
	m_config = config;
	m_isEnabled = ! config.m_startHidden;
	g_debugSystemFontTexture = m_config.m_renderer->CreateOrGetTextureFromFile("Data/Images/SquirrelFixedFont.png");
	g_debugSystemFont = m_config.m_renderer->CreateOrGetBitmapFont("Data/Images/SquirrelFixedFont");
}

DebugRenderSystem::~DebugRenderSystem() {
	Clear();
}

void DebugRenderSystem::Update(float deltaSeconds) {
	m_protectionMutex.lock();
	for (int index = 0; index < m_props.size(); index++) {
		if (m_props[index] != nullptr) {
			m_props[index]->Update(deltaSeconds); 
			if (m_props[index]->m_isTrash) {
				delete m_props[index];
				m_props[index] = nullptr;
			}
		}
	}
	m_protectionMutex.unlock();
}

void DebugRenderSystem::Clear() {
	m_protectionMutex.lock();
	for (int index = 0; index < m_props.size(); index++) {
		if (m_props[index] != nullptr) {
			delete m_props[index];
			m_props[index] = nullptr;
		}
	}
	m_protectionMutex.unlock();
}

void DebugRenderSystem::Render(const Camera& camera, bool inScreenSpace) {
	m_protectionMutex.lock();
	m_config.m_renderer->UseDefaultShader();
	if (!m_isEnabled) {
		return;
	}
	Mat44 cameraMatrix = camera.GetOwnTranslationAndOrientationMatrix();
	for (int index = 0; index < m_props.size(); index++) {
		if (m_props[index] != nullptr && m_props[index]->m_isInScreenSpace == inScreenSpace) {
			m_props[index]->Render(m_config.m_renderer, cameraMatrix);
		}
	}
	m_protectionMutex.unlock();
}


int DebugRenderSystem::AddProp(DebugProp* newProp) {
	m_protectionMutex.lock();
	for (int index = 0; index < m_props.size(); index++) {
		if (m_props[index] == nullptr) {
			m_props[index] = newProp;
			m_protectionMutex.unlock();
			return index;
		}
	}
	m_props.emplace_back(newProp);
	m_protectionMutex.unlock();
	return static_cast<int>(m_props.size()) - 1;
}


//The class-less functions-------------------------------------------------------------------------------------------------------------

void DebugRenderSystemStartup(const DebugRenderConfig& config) {
	g_theDebugRenderSystem = new DebugRenderSystem(config);
	SubscribeEventCallbackFunction("clearDebugRender", Command_DebugRenderClear);
	SubscribeEventCallbackFunction("toogleDebugRender", Command_DegbugRenderToggle);
	//g_theDebugRenderSystem->Run();
}

void DebugRenderSystemShutdown() {
	UnSubscribeEventCallbackFunction("clearDebugRender", Command_DebugRenderClear);
	UnSubscribeEventCallbackFunction("toogleDebugRender", Command_DegbugRenderToggle);
	delete g_theDebugRenderSystem;
}


//Control
void DebugRenderSetVisible() {
	g_theDebugRenderSystem->m_isEnabled = true;
}
void DebugRenderSetHidden() {
	g_theDebugRenderSystem->m_isEnabled = false;
}
void DebugRenderClear() {
	g_theDebugRenderSystem->Clear();
}

//Get delta seconds
float CalculateUpdateAmount() {
	//static variable timePrevious is kept each time this is run.
	static float timePrevious = static_cast<float>(GetCurrentTimeSeconds()); //This is only assigned when run for the first time
	float timeNow = static_cast<float>(GetCurrentTimeSeconds());
	float deltaSeconds = timeNow - timePrevious;
	timePrevious = timeNow;
	return deltaSeconds;
}

//Output
void DebugRenderBeginFrame() {
	g_theDebugRenderSystem->BeginFrame();
	float deltaSeconds = CalculateUpdateAmount();
	g_theDebugRenderSystem->Update(deltaSeconds);
}
void DebugRenderWorld(const Camera& camera) {
	g_theDebugRenderSystem->m_config.m_renderer->BeginCamera(camera);
	g_theDebugRenderSystem->Render(camera, false);
	g_theDebugRenderSystem->m_config.m_renderer->EndCamera(camera);
}
void DebugRenderScreen(const Camera& camera) {
	g_theDebugRenderSystem->m_config.m_renderer->BeginCamera(camera);
	g_theDebugRenderSystem->Render(camera, true);
	g_theDebugRenderSystem->m_config.m_renderer->EndCamera(camera);
}
void DebugRenderEndFrame() {
	g_theDebugRenderSystem->EndFrame();
}

//Geometry
void DebugAddWorldPoint(const Vec3& pos, float radius, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	AddVertsForSphere(newProp->m_vertexes, pos, radius, 4, 4);
	g_theDebugRenderSystem->AddProp(newProp);
}
void DebugAddWorldLine(const Vec3& start, const Vec3& end, float radius, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	AddVertsForLine3D(newProp->m_vertexes, start, end, radius);
	g_theDebugRenderSystem->AddProp(newProp);
}
void DebugAddWorldWireCylinder(const Vec3& base, const Vec3& top, float radius, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	AddVertsForCylinder(newProp->m_vertexes, top, base, radius);
	newProp->m_cullBackAndFillSetting = RASTERIZERMODE_WIREFRAME_CULL_BACK;
	g_theDebugRenderSystem->AddProp(newProp);
}
void DebugAddWorldSphere(const Vec3& center, float radius, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode, bool wireFrame) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	AddVertsForSphere(newProp->m_vertexes, center, radius, 30, 16);
	newProp->m_cullBackAndFillSetting = RASTERIZERMODE_SOLID_CULL_BACK;
	if (wireFrame) {
		newProp->m_cullBackAndFillSetting = RASTERIZERMODE_WIREFRAME_CULL_BACK;
	}
	g_theDebugRenderSystem->AddProp(newProp);
}
void DebugAddWorldArrow(const Vec3& start, const Vec3& end, float radius, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode, bool wireFrame) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	AddVertsForLine3D(newProp->m_vertexes, start, end, radius);
	AddVertsForCone(newProp->m_vertexes, start * 0.05f + end * 0.95f, start * -0.05f + end * 1.05f, radius * 3.f);
	newProp->m_cullBackAndFillSetting = RASTERIZERMODE_SOLID_CULL_BACK;
	if (wireFrame) {
		newProp->m_cullBackAndFillSetting = RASTERIZERMODE_WIREFRAME_CULL_BACK;
	}
	g_theDebugRenderSystem->AddProp(newProp);
}
void DebugAddWorldText(const std::string& text, const Mat44& transform, float textHeight, const Vec2& alignment, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	std::vector<Vertex_PCU> tempVertexes;
	g_debugSystemFont->AddVertsForTextInBox2D(tempVertexes, AABB2(0.f, 0.f, 0.f, 0.f), textHeight, text, Rgba8(), 0.8f, Vec2(), TextDrawMode::OVERRUN);
	AABB2 boundHorizontalZero = GetVertexBounds2D(tempVertexes);
	g_debugSystemFont->AddVertsForTextInBox2D(newProp->m_vertexes, boundHorizontalZero, textHeight, text, Rgba8(), 0.8f, alignment, TextDrawMode::OVERRUN);
	TransformVertexArray3D(newProp->m_vertexes, transform);
	newProp->m_texture = g_debugSystemFontTexture;
	newProp->m_cullBackAndFillSetting = RASTERIZERMODE_SOLID_CULL_NONE;
	g_theDebugRenderSystem->AddProp(newProp);

}
void DebugAddWorldBillboardText(const std::string& text, const Vec3& origin, float textHeight, const Vec2& alignment, float duration, const Rgba8& startColor, const Rgba8& endColor, DebugRenderMode mode) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, mode);
	g_debugSystemFont->AddVertsForTextInBox2D(newProp->m_vertexes, AABB2(0.f, 0.f, 0.f, 0.f), textHeight, text, Rgba8(), 0.8f, alignment, TextDrawMode::OVERRUN);
	AABB2 boundHorizontalZero = GetVertexBounds2D(newProp->m_vertexes);
	ConvertVertexFromZtopToXtop(newProp->m_vertexes);
	//TransformVertexArray3D(newProp->m_vertexes, Mat44::CreateTranslation3D(origin));
	newProp->m_texture = g_debugSystemFontTexture;
	newProp->m_billboardType = BillboardType::WORLD_UP_CAMERA_FACING;
	newProp->m_pivot = origin;
	newProp->m_cullBackAndFillSetting = RASTERIZERMODE_SOLID_CULL_NONE;
	g_theDebugRenderSystem->AddProp(newProp);
}
void DebugAddScreenText(const std::string& text, const Vec2 position, float size, const Vec2& alignment, float duration, const Rgba8& startColor, const Rgba8& endColor) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, DebugRenderMode::ALWAYS);
	std::vector<Vertex_PCU> tempVertexes;
	g_debugSystemFont->AddVertsForTextInBox2D(tempVertexes, AABB2(-1.f, -1.f, 1.f, 1.f), size, text, Rgba8(), 0.4f, Vec2(), TextDrawMode::OVERRUN);
	AABB2 boundHorizontalZero = GetVertexBounds2D(tempVertexes);
	boundHorizontalZero.SetCenter(position);
	g_debugSystemFont->AddVertsForTextInBox2D(newProp->m_vertexes, boundHorizontalZero, size, text, Rgba8(), 0.4f, alignment, TextDrawMode::OVERRUN);
	newProp->m_isInScreenSpace = true;
	newProp->m_texture = g_debugSystemFontTexture;
	newProp->m_cullBackAndFillSetting = RASTERIZERMODE_SOLID_CULL_NONE;
	g_theDebugRenderSystem->AddProp(newProp);
}
//Still broken
void DebugAddMessage(const std::string& text, float duration, const Rgba8& startColor, const Rgba8& endColor) {
	DebugProp* newProp = new DebugProp(startColor, endColor, duration, DebugRenderMode::ALWAYS);
	g_debugSystemFont->AddVertsForTextInBox2D(newProp->m_vertexes, AABB2(0.f, 0.f, 1.f, 1.f), 2.f, text, Rgba8(), 0.8f, Vec2(), TextDrawMode::OVERRUN);
	newProp->m_isInScreenSpace = true;
	newProp->m_texture = g_debugSystemFontTexture;
	g_theDebugRenderSystem->AddProp(newProp);
}



//Console commands
bool Command_DebugRenderClear(EventArgs& args) {
	(void)args;
	g_theDebugRenderSystem->Clear();
	return true;
}
bool Command_DegbugRenderToggle(EventArgs& args) {
	(void)args;
	g_theDebugRenderSystem->m_isEnabled = !g_theDebugRenderSystem->m_isEnabled;
	return true;
}