#include "Engine\Core\StringUtils.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Core\Rgba8.hpp"


#include <stdarg.h>


//-----------------------------------------------------------------------------------------------
constexpr int STRINGF_STACK_LOCAL_TEMP_LENGTH = 2048;


//Dynamic string stuff -----------------------------------------------------------------------------------------------
const std::string Stringf( char const* format, ... )
{
	char textLiteral[ STRINGF_STACK_LOCAL_TEMP_LENGTH ];
	va_list variableArgumentList;
	va_start( variableArgumentList, format );
	vsnprintf_s( textLiteral, STRINGF_STACK_LOCAL_TEMP_LENGTH, _TRUNCATE, format, variableArgumentList );	
	va_end( variableArgumentList );
	textLiteral[ STRINGF_STACK_LOCAL_TEMP_LENGTH - 1 ] = '\0'; // In case vsnprintf overran (doesn't auto-terminate)

	return std::string( textLiteral );
}

const std::string Stringf( int maxLength, char const* format, ... )
{
	char textLiteralSmall[ STRINGF_STACK_LOCAL_TEMP_LENGTH ];
	char* textLiteral = textLiteralSmall;
	if( maxLength > STRINGF_STACK_LOCAL_TEMP_LENGTH )
		textLiteral = new char[ maxLength ];

	va_list variableArgumentList;
	va_start( variableArgumentList, format );
	vsnprintf_s( textLiteral, maxLength, _TRUNCATE, format, variableArgumentList );	
	va_end( variableArgumentList );
	textLiteral[ maxLength - 1 ] = '\0'; // In case vsnprintf overran (doesn't auto-terminate)

	std::string returnValue( textLiteral );
	if( maxLength > STRINGF_STACK_LOCAL_TEMP_LENGTH )
		delete[] textLiteral;

	return returnValue;
}


//Read text stuff -----------------------------------------------------------------------------------------------
Strings SplitStringOnDelimiter(std::string const& originalString, char delimiterToSplitOn, bool strip) {
	Strings result = {};
	int charsProcessed = 0;
	while (true) {
		int newIndexReached = (int)originalString.find_first_of(delimiterToSplitOn, charsProcessed);
		if (newIndexReached >= 0 && newIndexReached < originalString.size()) {  //End isn't reached
			result.emplace_back(originalString.substr(charsProcessed, newIndexReached - charsProcessed));
			if (strip) {
				auto trash = std::remove(result.back().begin(), result.back().end(), ' ');
			}
			charsProcessed = newIndexReached + 1;
		}
		else {  //End is reached
			result.emplace_back(originalString.substr(charsProcessed, originalString.size()));
			if (strip) {
				auto trash = std::remove(result.back().begin(), result.back().end(), ' ');
			}
			break;
		}
	}
	return result;
}



std::string GetLoweredString(std::string const& inputString) {
	std::string output = "";
	for (int index = 0; index < inputString.length(); index++) {
		output.push_back((char)tolower(inputString[index]));
	}
	return output;
}
std::string GetUpperedString(std::string const& inputString) {
	std::string output = "";
	for (int index = 0; index < inputString.length(); index++) {
		output.push_back((char)toupper(inputString[index]));
	}
	return output;
}