#pragma once
//-----------------------------------------------------------------------------------------------
#include "Engine\Math\IntVec2.hpp"
#include <vector>

class HeatMap
{
	friend class Renderer; // Only the Renderer can create new BitmapFont objects!

public:
	HeatMap(IntVec2 const& dimensions, float initialValue = -1.f);
	~HeatMap() {}
	void SetAllValues(float valueToSet);
	void SetValueAt(float valueToSet, IntVec2 cordinates);
	void AddValueAt(float valueToAdd, IntVec2 cordinates);
	float GetValueAt(IntVec2 cordinates) const;
	IntVec2 GetDimensions() const { return m_dimentions; }



protected:
	std::vector<float> m_values;
	IntVec2 m_dimentions;
	
	int Get1DIndexFrom2DIndex(IntVec2 the2DIndex) const;

};
