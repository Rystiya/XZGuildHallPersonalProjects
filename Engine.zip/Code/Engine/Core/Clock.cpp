#include "Engine\Core\Clock.hpp"
#include "Engine\Core\Time.hpp"
#include "Engine\Core\EngineCommon.hpp"

Clock g_theSystemClock;

Clock::Clock() {
	if (this == &g_theSystemClock) {
		m_parent = nullptr;
	}
	else {
		m_parent = &g_theSystemClock;
		m_parent->AddChild(this);
	}
}

Clock::Clock(Clock& parent)
{
	m_parent = &parent;
	m_parent->AddChild(this);
}

Clock::~Clock() {
	ClearAllChildren();
}

Clock& Clock::GetSystemClock() { return g_theSystemClock; }
void Clock::TickSystemClock() { g_theSystemClock.Tick(); }


void Clock::ClearAllChildren() {
	for (int index = 0; index < m_children.size(); index++) {
		if (m_children[index] != nullptr) {
			delete m_children[index];
		}
	}
}

void Clock::ReparentAllChildren() {
	for (int index = 0; index < m_children.size(); index++) {
		if (m_children[index] != nullptr) {
			m_children[index]->m_parent = m_parent;
		}
	}
}



void Clock::Reset() {
	m_lastUpdateTimeInSeconds = static_cast<float>(GetCurrentTimeSeconds());
	m_totalSeconds = 0.f;
	m_lastDeltaSeconds = 0.f;
	m_totalFrameCount = 0;
}

void Clock::RemoveChild(Clock* childClock) {
	for (int index = 0; index < m_children.size(); index++) {
		if (m_children[index] == childClock) {
			delete m_children[index];
			m_children[index] = nullptr;
		}
	}
}

void Clock::Tick() {
	float currentTime = static_cast<float>(GetCurrentTimeSeconds());
	float deltaTime = currentTime - m_lastUpdateTimeInSeconds;
	m_lastUpdateTimeInSeconds = currentTime;
	Advance(deltaTime);
}

void Clock::Advance(float baseDeltaSeconds) {
	if (m_isPaused) {
		baseDeltaSeconds = 0.f;
	}
	if (m_pauseNextFrame) {
		m_isPaused = true;
	}
	float deltaSeconds = baseDeltaSeconds * m_timeScale;
	m_totalFrameCount++;
	m_totalSeconds += deltaSeconds;
	m_lastDeltaSeconds = deltaSeconds;
	m_lastBaseDeltaSeconds = baseDeltaSeconds;
	m_lastUpdateTimeInSeconds = static_cast<float>(GetCurrentTimeSeconds());
	for (int index = 0; index < m_children.size(); index++) {
		if (m_children[index] != nullptr) {
			m_children[index]->Advance(deltaSeconds);
		}
	}
}
