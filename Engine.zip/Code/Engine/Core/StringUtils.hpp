#pragma once
//-----------------------------------------------------------------------------------------------
#include <vector>
#include <string>

struct Vec2;
struct Vec3;
struct IntVec2;
struct AABB2;
struct Rgba8;

typedef std::vector< std::string >	Strings;

//Dynamic string stuff -----------------------------------------------------------------------------------------------
const std::string Stringf( char const* format, ... );
const std::string Stringf( int maxLength, char const* format, ... );
 
//Read text -----------------------------------------------------------------------------------------------
Strings SplitStringOnDelimiter(std::string const& originalString, char delimiterToSplitOn = ',', bool strip = false);


std::string GetLoweredString(std::string const& inputString);
std::string GetUpperedString(std::string const& inputString);