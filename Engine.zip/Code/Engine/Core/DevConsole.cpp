#include "Engine\Core\DevConsole.hpp"
#include "Engine\Core\Stopwatch.hpp"
#include "Engine\Core\Clock.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Input\InputSystem.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Renderer\Camera.hpp"
#include "Engine\Renderer\BitmapFont.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Core\EngineCommon.hpp"

const Rgba8 ERROR_COLOR = Rgba8(255, 0, 0);
const Rgba8 WARNING_COLOR = Rgba8(255, 255, 0);
const Rgba8 INFO_MAJOR_COLOR = Rgba8(150, 200, 255);
const Rgba8 INFO_MINOR_COLOR = Rgba8(100, 150, 200);
const Rgba8 COMMAND_ECHO_COLOR = Rgba8(255, 150, 255);
const Rgba8 INPUT_TEXT_COLOR = Rgba8(200, 200, 255);
const Rgba8 INPUT_CARET_COLOR = Rgba8(255, 255, 255);
const Rgba8 DEV_CONSOLE_BACKGROUND_COLOR = Rgba8(0, 0, 0, 150);


DevConsole* g_theDevConsole = nullptr;


DevConsole::DevConsole(DevConsoleConfig const& config) {
	m_config = config;
	Clock& tempClock = Clock::GetSystemClock();
	m_caretStopwatch = new Stopwatch(&tempClock, 0.5f);
}
DevConsole::~DevConsole() {
	delete m_caretStopwatch;
	//This is done by renderer
	//delete m_font;
}

//Try parse and execute this line of text
void DevConsole::Execute(std::string const& consoleCommandText) {
	m_protectionMutex.lock();
	if (consoleCommandText == "") {
		ToggleOpen();
		return;
	}
	Strings commandNameList = g_theEventSystem->GetEventNameList();
	if (std::find(commandNameList.begin(), commandNameList.end(), consoleCommandText) != commandNameList.end()) {
		m_lines.emplace_back(DevConsoleLine{ COMMAND_ECHO_COLOR, consoleCommandText });
		m_commandHistory.emplace_back(m_inputText);
		m_historyIndex = static_cast<int>(m_commandHistory.size());
		g_theEventSystem->FireEvent(consoleCommandText);
	}
	else {
		m_lines.emplace_back(DevConsoleLine{ ERROR_COLOR, "Invalid command: \'" + consoleCommandText + "\'!"});
	}

	m_protectionMutex.unlock();
}
void DevConsole::Startup() {
	m_font = m_config.m_renderer->CreateOrGetBitmapFont(("Data/Images/" + m_config.m_fontName).c_str());
	AddUnclearableLine(INFO_MAJOR_COLOR, "Type 'help' for a list of events.");
	SubscribeEventCallbackFunction("keyDown", DevConsole::HandleKeyPressedEvent);
	SubscribeEventCallbackFunction("charDown", DevConsole::HandleCharInputEvent);
	SubscribeEventCallbackFunction("help", DevConsole::HandleHelpCommandEvent);
	SubscribeEventCallbackFunction("clear", DevConsole::HandleClearCommandEvent);
}
void DevConsole::Shutdown() {
	UnSubscribeEventCallbackFunction("keyDown", DevConsole::HandleKeyPressedEvent);
	UnSubscribeEventCallbackFunction("charDown", DevConsole::HandleCharInputEvent);
	UnSubscribeEventCallbackFunction("help", DevConsole::HandleHelpCommandEvent);
	UnSubscribeEventCallbackFunction("clear", DevConsole::HandleClearCommandEvent);
}

void DevConsole::AddLine(Rgba8 const& color, std::string const& text) {
	m_protectionMutex.lock();
	m_lines.push_back({ color, text });
	m_protectionMutex.unlock();
}
void DevConsole::AddUnclearableLine(Rgba8 const& color, std::string const& text) {
	m_protectionMutex.lock();
	m_baseLines.push_back({ color, text });  
	m_lines.push_back({ color, text });
	m_protectionMutex.unlock();
}

void DevConsole::ToggleOpen() {
	m_protectionMutex.lock();
	m_isOpen = !m_isOpen;
	m_protectionMutex.unlock();
}
bool DevConsole::GetIsOpen() const {
	return m_isOpen;
}

//bounds are in terms of the m_camera.
void DevConsole::Render(AABB2 const& bounds) {
	m_protectionMutex.lock();
	m_config.m_renderer->BeginCamera(*(m_config.m_camera));
	//Begin

	if (!GetIsOpen()) {
		m_protectionMutex.unlock();
		return;
	}

	std::vector<Vertex_PCU> vertexes;
	//Draw the background
	float bgStartX = bounds.m_mins.x;
	float bgEndX = bounds.m_maxs.x;
	float bgCenterY = (bounds.m_mins.y + bounds.m_maxs.y) / 2;
	float bgWidthY = bounds.m_mins.y - bounds.m_maxs.y;
	AddVertsForLine2D(vertexes, Vec2(bgStartX, bgCenterY), Vec2(bgEndX, bgCenterY), bgWidthY, DEV_CONSOLE_BACKGROUND_COLOR);
	m_config.m_renderer->BindTexture(nullptr);
	m_config.m_renderer->DrawVertexVector(vertexes);
	//Add the text
	vertexes.clear();
	AddALineToConsoleBound(vertexes, bounds, 1, m_inputText, INPUT_TEXT_COLOR);
	for (int index = 0; index < m_config.m_linesOnScreen && index < m_lines.size(); index++) {
		int currentLine = static_cast<int>(m_lines.size()) - 1 - index;
		AddALineToConsoleBound(vertexes, bounds, index + 2, m_lines[currentLine].m_text, m_lines[currentLine].m_color);
	}
	//Draw text
	m_config.m_renderer->BindTexture(&(m_font->GetTexture()));
	m_config.m_renderer->DrawVertexVector(vertexes);
	m_config.m_renderer->BindTexture(nullptr);
	//Draw the caret
	DrawCaret(bounds);
	//End
	m_config.m_renderer->EndCamera(*(m_config.m_camera));
	m_protectionMutex.unlock();
}

void DevConsole::Render() {
	Render(AABB2(m_config.m_camera->GetOrthoBottomLeft(), m_config.m_camera->GetOrthoBottomLeft() * 0.25f + m_config.m_camera->GetOrthoTopRight() * 0.75f));
}




bool DevConsole::HandleKeyPressedEvent(EventArgs& args) {
	int inputChar = args.GetValue("key", -1);
	if (inputChar == KEYCODE_TILDE) {
		g_theDevConsole->ToggleOpen();
		return true;
	}
	//Only check the toogleOpen event if not opened
	if (!g_theDevConsole || !g_theDevConsole->GetIsOpen()) {
		return false;
	}
	if (inputChar == KEYCODE_ENTER) {
		g_theDevConsole->Execute(g_theDevConsole->m_inputText);
		g_theDevConsole->m_inputText = "";
		g_theDevConsole->m_caretPosition = 0;
		return true;
	}
	if (inputChar == KEYCODE_ESC) {
		if (g_theDevConsole->m_inputText == "") {
			g_theDevConsole->ToggleOpen();
		}
		else {
			g_theDevConsole->m_inputText = "";
		}
		return true;
	}
	if (inputChar == KEYCODE_BACKSPACE && g_theDevConsole->m_caretPosition > 0) {
		g_theDevConsole->m_inputText.erase(g_theDevConsole->m_caretPosition - 1, 1);
		g_theDevConsole->m_caretPosition -= 1;
		return true;
	}
	if (inputChar == KEYCODE_DELETE && g_theDevConsole->m_caretPosition < g_theDevConsole->m_inputText.size()) {
		g_theDevConsole->m_inputText.erase(g_theDevConsole->m_caretPosition, 1);
		return true;
	}
	if (inputChar == KEYCODE_HOME && g_theDevConsole->m_caretPosition > 0) {
		g_theDevConsole->m_caretPosition = 0;
		return true;
	}
	if (inputChar == KEYCODE_END && g_theDevConsole->m_caretPosition < g_theDevConsole->m_inputText.size()) {
		g_theDevConsole->m_caretPosition = (int)g_theDevConsole->m_inputText.size();
		return true;
	}
	if (inputChar == KEYCODE_LEFTARROW && g_theDevConsole->m_caretPosition > 0) {
		g_theDevConsole->m_caretPosition -= 1;
		return true;
	}
	if (inputChar == KEYCODE_RIGHTARROW && g_theDevConsole->m_caretPosition < g_theDevConsole->m_inputText.size()) {
		g_theDevConsole->m_caretPosition += 1;
		return true;
	}
	if (inputChar == KEYCODE_UPARROW && g_theDevConsole->m_historyIndex > 0 && g_theDevConsole->m_commandHistory.size() > 0) {
		g_theDevConsole->m_historyIndex -= 1;
		g_theDevConsole->m_inputText = g_theDevConsole->m_commandHistory[g_theDevConsole->m_historyIndex];
		return true;
	}
	if (inputChar == KEYCODE_DOWNARROW) {
		g_theDevConsole->m_inputText = "";
		if (g_theDevConsole->m_historyIndex < g_theDevConsole->m_commandHistory.size() - 1) {
			g_theDevConsole->m_historyIndex += 1;
			g_theDevConsole->m_inputText = g_theDevConsole->m_commandHistory[g_theDevConsole->m_historyIndex];
		}
		return true;
	}
	return true;
}
bool DevConsole::HandleCharInputEvent(EventArgs& args) {
	if (!g_theDevConsole || !g_theDevConsole->GetIsOpen()) {
		return false;
	}
	char inputChar = (char)args.GetValue("key", -1);
	if (isalpha(inputChar)) {
		std::string newContent = { inputChar };
		g_theDevConsole->m_inputText.insert(g_theDevConsole->m_caretPosition, newContent);
		g_theDevConsole->m_caretPosition += 1;
		g_theDevConsole->m_caretStopwatch->Restart();
		return true;
	}
	return true;
}
bool DevConsole::HandleClearCommandEvent(EventArgs& args) {
	(void) args;
	if (!g_theDevConsole || !g_theDevConsole->GetIsOpen()) {
		return false;
	}
	g_theDevConsole->m_lines = g_theDevConsole->m_baseLines;
	return true;
}
bool DevConsole::HandleHelpCommandEvent(EventArgs& args) {
	(void)args;
	if (!g_theDevConsole || !g_theEventSystem || !g_theDevConsole->GetIsOpen()) {
		return false;
	}
	g_theDevConsole->m_lines.emplace_back(DevConsoleLine{ INFO_MAJOR_COLOR, "Registered events:" });
	Strings commandNameList = g_theEventSystem->GetEventNameList();
	for (int index = 0; index < commandNameList.size(); index++) {
		g_theDevConsole->m_lines.emplace_back(DevConsoleLine{ INFO_MINOR_COLOR, commandNameList[index] });
	}
	return false;
}
bool DevConsole::IsCaretVisible() const {
	float currentTimeInInterval = m_caretStopwatch->GetElapsedFraction();
	return (int(currentTimeInInterval)) % 2 == 1;
}
void DevConsole::DrawCaret(AABB2 entireBound) {
	std::vector<Vertex_PCU> vertexes;
	if (!IsCaretVisible()) {
		return;
	}

	float lineHeight = (entireBound.m_maxs.y - entireBound.m_mins.y) / m_config.m_linesOnScreen;
	float charWidth = lineHeight * m_config.m_fontAspect;
	float ymin = entireBound.m_mins.y;
	float ymax = entireBound.m_mins.y + lineHeight;
	float xmin = charWidth * (m_caretPosition - 0.075f);
	float xmax = charWidth * (m_caretPosition + 0.075f);
	AABB2 caretBounds = AABB2(Vec2(xmin, ymin), Vec2(xmax, ymax));
	AddVertsForAABB2(vertexes, caretBounds, INPUT_CARET_COLOR);
	m_config.m_renderer->DrawVertexVector(vertexes);


}



void DevConsole::AddALineToConsoleBound(std::vector<Vertex_PCU>& vertexes, AABB2 entireBound, int currentLine, std::string text, Rgba8 color) {
	float lineHeight = (entireBound.m_maxs.y - entireBound.m_mins.y) / m_config.m_linesOnScreen;
	AABB2 currentBounds = AABB2(Vec2(entireBound.m_mins.x, entireBound.m_mins.y + (currentLine - 1) * lineHeight), Vec2(entireBound.m_maxs.x, entireBound.m_mins.y + currentLine * lineHeight));
	m_font->AddVertsForTextInBox2D(vertexes, currentBounds, lineHeight, text, color, m_config.m_fontAspect, Vec2(0.f, 0.f), TextDrawMode::SHRINK_TO_FIT); 
}