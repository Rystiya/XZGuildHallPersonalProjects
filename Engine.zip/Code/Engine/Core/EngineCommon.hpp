#pragma once
//-----------------------------------------------------------------------------------------------
#include "Engine\Core\NamedStrings.hpp"
#include "Engine\Core\EventSystem.hpp"
#include "Game/EngineBuildPreferences.hpp"

extern NamedStrings g_gameConfigBlackboard; // declared in EngineCommon.hpp, defined in EngineCommon.cpp