#include "Engine\Core\FileUtils.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"
#include <stdio.h>

//Note: file are read from the Run folder in game file!

int FileReadToBuffer(std::vector<uint8_t>& outBuffer, const std::string& filename, bool quitIfFileNotFound) {
	FILE* fp;
	if (fopen_s(&fp, filename.c_str(), "rb") != 0) {
		if (quitIfFileNotFound) {
			ERROR_AND_DIE("Error when reading file: " + filename);
		} else {
			return -1;
		}
	}
	fseek(fp, 0, SEEK_END);
	long lSize = ftell(fp);
	rewind(fp);
	outBuffer.resize(lSize);
	size_t result = fread(&outBuffer[0], 1, lSize, fp);
	fclose(fp);
	if (result != lSize) {
		ERROR_AND_DIE("Error when reading file: " + filename);
	}
	return (int)result;
}

int FileReadToString(std::string& outString, const std::string& filename, bool quitIfFileNotFound) {
	FILE* fp;
	if (fopen_s(&fp, filename.c_str(), "rb") != 0) {
		if (quitIfFileNotFound) {
			ERROR_AND_DIE("Error when reading file: " + filename);
		}
		else {
			return -1;
		}
	}
	fseek(fp, 0, SEEK_END);
	long lSize = ftell(fp);
	rewind(fp);
	outString.resize(lSize);
	size_t result = fread(&outString[0], 1, lSize, fp);
	fclose(fp);
	if (result != lSize) {
		ERROR_AND_DIE("Error when reading file: " + filename);
	}
	return (int)result;
}

bool FileWriteFromBuffer(std::vector<uint8_t>& inBuffer, const std::string& filename) {
	FILE* fp;
	if (fopen_s(&fp, filename.c_str(), "wb") != 0) {
		ERROR_AND_DIE("Error when opening file: " + filename);
	}
	for (int index = 0; index < inBuffer.size(); index++) {
		fwrite(&inBuffer[index], sizeof(uint8_t), 1, fp);
	}
	fclose(fp);
	return true;
}

bool FileWriteFromString(std::string& inString, const std::string& filename) {
	FILE* fp;
	if (fopen_s(&fp, filename.c_str(), "wb") != 0) {
		ERROR_AND_DIE("Error when opening file: " + filename);
	}
	fwrite(&inString, sizeof(inString), 1, fp);
	fclose(fp);
	return true;

}