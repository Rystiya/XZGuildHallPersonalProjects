#pragma once
//-----------------------------------------------------------------------------------------------
#include "Engine\Core\EngineCommon.hpp"
#include <vector>
#include <string>

int FileReadToBuffer(std::vector<uint8_t>& outBuffer, const std::string& filename, bool quitIfFileNotFound = true);
int FileReadToString(std::string& outString, const std::string& filename, bool quitIfFileNotFound = true);

bool FileWriteFromBuffer(std::vector<uint8_t>& inBuffer, const std::string& filename);
bool FileWriteFromString(std::string& inString, const std::string& filename);