#pragma once
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Core\EngineCommon.hpp"

struct Vertex_PCU;
struct Vertex_PNCU;



//-----------------------------------------------------------------------------------------------
struct Vertex_PCU
{
public: // position, color, etc
	Vec3 m_position;
	Rgba8 m_color;
	Vec2 m_uvTexCoords;

	// Construction/Destruction
	~Vertex_PCU() {}	
	Vertex_PCU();
	Vertex_PCU(Vertex_PCU const& copyFrom);
	Vertex_PCU(Vertex_PNCU const& copyFrom);
	explicit Vertex_PCU(Vec3 const& position, Rgba8 const& tint = Rgba8(), Vec2 const& uvTexCoords = Vec2(0.f, 0.f));
	explicit Vertex_PCU(Vec2 const& position, Rgba8 const& tint = Rgba8(), Vec2 const& uvTexCoords = Vec2(0.f, 0.f));
};


struct Vertex_PNCU: public Vertex_PCU
{
public: 

	Vec3 m_surfaceNormal;

	// Construction/Destruction
	virtual ~Vertex_PNCU() {}
	Vertex_PNCU();
	explicit Vertex_PNCU(Vec3 const& position, Rgba8 const& tint = Rgba8(), Vec2 const& uvTexCoords = Vec2(0.f, 0.f), Vec3 const& surfaceNormal = Vec3(0.f, 0.f, 1.f));
	explicit Vertex_PNCU(Vec2 const& position, Rgba8 const& tint = Rgba8(), Vec2 const& uvTexCoords = Vec2(0.f, 0.f), Vec3 const& surfaceNormal = Vec3(0.f, 0.f, 1.f));

};
