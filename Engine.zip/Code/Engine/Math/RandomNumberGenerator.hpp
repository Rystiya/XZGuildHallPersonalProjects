#pragma once
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\FloatRange.hpp"
#include <vector>

//-----------------------------------------------------------------------------------------------
class RandomNumberGenerator
{
public:
	RandomNumberGenerator(unsigned int seed = 0);

	//The most basic function called everyone else
	unsigned int GetUnsignedIntNoise();

	//Such as roll any int in [0,10)
	int RollRandomIntLessThan(int maxNotInclusive);
	//Such as roll any int in [4,8]
	int RollRandomIntInRange(int minInlcusive, int maxInclusive);
	int RollRandomIntInRange(IntVec2 inputRange) { return RollRandomIntInRange(inputRange.x, inputRange.y); }
	int RollRandomIntOneOrNegativeOne();
	float RollRandomFloatZeroToOne();
	float RollRandomFloatInRange(int minInlcusive, int maxInclusive);
	float RollRandomFloatInRange(float minInlcusive, float maxInclusive);
	float RollRandomFloatInRange(Vec2 inputRange) { return RollRandomFloatInRange(inputRange.x, inputRange.y); }
	float RollRandomFloatInRange(FloatRange inputRange) { return RollRandomFloatInRange(inputRange.m_min, inputRange.m_max); }
	int ChooseItemFromWeightedList(std::vector<float> const& weights);

private:
	//Used to reproduce results. Should we able to set and get these things?
	unsigned int m_seed = 0;
	int m_position = 0;

};


