#pragma once
#include "Engine\Math\Vec2.hpp"
#include <vector>

class RandomNumberGenerator;
struct AABB2;
struct CubicHermiteCurve2D
{
	Vec2 m_startPos;
	Vec2 m_velocityStart;
	Vec2 m_velocityEnd;
	Vec2 m_endPos;
};


class Curve
{
public:
	virtual ~Curve() {}
	Curve() {}
	//Static functions
	static float GetApproximateLengthForSegments(std::vector<Vec2> const& segments);
	static Vec2 EvaluateAtDistanceForSegments(std::vector<Vec2> const& segments, float distanceAlongCurve);
	static Vec2 EvaluateAtTimeForSegments(std::vector<Vec2> const& segments, float tZeroToOne);

	virtual Vec2 EvaluateAtParametric(float tZeroToOne) const = 0;
	virtual std::vector<Vec2> const GetAsPoints() const = 0;
	virtual bool IsValid() const = 0;

	virtual float GetApproximateLength(int numSubdivisions = 64) const;
	virtual Vec2 EvaluateAtApproximateDistanceInaccurate(float distanceAlongCurve, int numSubdivisions = 64) const;
	virtual Vec2 EvaluateAtApproximateDistanceAccurate(float distanceAlongCurve, int numSubdivisions = 64) const;
	virtual std::vector<Vec2> GetAsSegments(int numSubdivisions = 64) const;

};



class BezierCurve : public Curve
{
public:
	~BezierCurve() {}
	BezierCurve() {}
	BezierCurve(Vec2 startPos, Vec2 guidePos, Vec2 endPos);
	BezierCurve(Vec2 startPos, Vec2 guide1Pos, Vec2 guide2Pos, Vec2 endPos);
	BezierCurve(std::vector<Vec2> const& points);
	explicit BezierCurve(CubicHermiteCurve2D const& fromHermite);

	void InitializeAsCubicCurve(CubicHermiteCurve2D const& fromHermite);
	void InitializeAsRandomSmoothCubicCurve(Vec2 start, Vec2 end, RandomNumberGenerator* rnd);

	//Const functions
	Vec2 EvaluateAtParametric(float tZeroToOne) const override;
	std::vector<Vec2> const GetAsPoints() const override { return m_points; }
	bool IsValid() const override { return m_points.size() >= 2; }



protected:
	std::vector<Vec2> m_points;
};



class BezierCurveSpline : public Curve
{
public:
	~BezierCurveSpline() {}
	BezierCurveSpline() {}
	BezierCurveSpline(std::vector<BezierCurve> const& curves);
	BezierCurveSpline(std::vector<Vec2> const& keyPoints);
	BezierCurveSpline(Vec2 startPos, Vec2 endPos, int segmentCount, RandomNumberGenerator* rnd);

	void InitializeWithSegmentPoints(std::vector<Vec2> const& segmentPoints);
	void InitializeWithSegmentCount(Vec2 startPos, Vec2 endPos, int segmentCount, RandomNumberGenerator* rnd);

	//Const functions
	Vec2 EvaluateAtParametric(float tZeroToOne) const override;
	std::vector<Vec2> const GetAsPoints() const override;
	bool IsValid() const override { return m_curves.size() >= 2; }


protected:
	std::vector<BezierCurve> m_curves;
};
