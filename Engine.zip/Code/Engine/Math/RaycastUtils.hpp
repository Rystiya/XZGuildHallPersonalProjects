#pragma once

#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include <vector>


struct IntVec2;
struct AABB2;
struct Rgba8;
struct Vertex_PCU;
struct FloatRange;



struct RaycastResult
{
	bool	m_didImpact = false;
	float	m_impactDist = 0.f;
};
struct RaycastResult2D:RaycastResult
{
	Vec2	m_impactPos = Vec2();
	Vec2	m_impactNormal = Vec2();
};

struct RaycastResult3D :RaycastResult
{
	Vec3	m_impactPos = Vec2();
	Vec3	m_impactNormal = Vec2();
};
bool RaycastResultIsCloser(RaycastResult resultA, RaycastResult resultB);



struct SimpleRayCastResult2D {
public:
	bool m_contact;
	Vec2 m_contactPosition;
};


void AddVertsForArrow2D(std::vector<Vertex_PCU>& verts, Vec2 tailPos, Vec2 tipPos, float arrowSize, float lineThickness, Rgba8 const& drawColor);
void AddVertsForArrow2D(std::vector<Vertex_PCU>& verts, Vec2 tailPos, Vec2 tipPos, float arrowSize, float lineThickness);
RaycastResult2D RaycastVsLine(Vec2 startPos, Vec2 fwdNormal, float maxDist, Vec2 targetLineA, Vec2 targetLineB);
RaycastResult2D RaycastVsAABB2(Vec2 startPos, Vec2 fwdNormal, float maxDist, AABB2 targetBox);
RaycastResult2D RaycastVsDisc2D(Vec2 startPos, Vec2 fwdNormal, float maxDist, Vec2 discCenter, float discRadius, float rayWidth = 0.f);
RaycastResult3D RaycastVsDiscXY3D(Vec3 startPos, Vec3 fwdNormal, float maxDist, Vec3 discCenter, float discRadius, float rayWidth = 0.f);
RaycastResult3D RaycastVsCylinderZ(Vec3 startPos, Vec3 fwdNormal, float maxDist, Vec3 discCenter, float discRadius, float cylinderHeight, bool collideIfInside = false);