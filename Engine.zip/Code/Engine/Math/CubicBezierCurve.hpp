#pragma once
#include "Engine\Math\Vec2.hpp"

struct AABB3;

struct CubicBezierCurve
{

	~CubicBezierCurve() {}
	CubicBezierCurve();
};