#include "Engine\Math\BezierCurve.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"



//Abstract curve class--------------------------------------------------------------------------------------
float Curve::GetApproximateLengthForSegments(std::vector<Vec2> const& segments) {
	float result = 0.f;
	if (segments.size() < 2) {
		return result;
	}
	for (int segmentID = 0; segmentID < static_cast<int>(segments.size()) - 1; segmentID++) {
		result += GetDistance2D(segments[segmentID], segments[segmentID + 1]);
	}
	return result;
}

Vec2 Curve::EvaluateAtDistanceForSegments(std::vector<Vec2> const& segments, float distanceAlongCurve) {
	float cumulativeSegmentLength = 0.f;
	for (int segmentID = 0; segmentID < static_cast<int>(segments.size()) - 1; segmentID++) {
		float currentSegmentLength = GetDistance2D(segments[segmentID], segments[segmentID + 1]);
		if (cumulativeSegmentLength + currentSegmentLength > distanceAlongCurve) {
			float progressOnCurrentSegment = (distanceAlongCurve - cumulativeSegmentLength) / currentSegmentLength;
			return segments[segmentID] + progressOnCurrentSegment * (segments[segmentID + 1] - segments[segmentID]);
		}
		else {
			cumulativeSegmentLength += currentSegmentLength;
		}
	}
	return Vec2();
}

Vec2 Curve::EvaluateAtTimeForSegments(std::vector<Vec2> const& segments, float tZeroToOne) {
	//Note segments have n nodes, thus n - 1 segments
	float currentTotalProgress = tZeroToOne * (segments.size() - 1);
	int currentSegmentID = static_cast<int>(currentTotalProgress);
	float currentSegmentProgress = currentTotalProgress - currentSegmentID;
	if (segments.size() <= 0 || currentSegmentID >= segments.size() - 1) {
		return Vec2();
	}
	return segments[currentSegmentID] * (1.f - currentSegmentProgress) + segments[currentSegmentID + 1] * currentSegmentProgress;
}

float Curve::GetApproximateLength(int numSubdivisions) const {
	if (!IsValid()) {
		return 0.f;
	}
	std::vector<Vec2> segments = GetAsSegments(numSubdivisions);
	return GetApproximateLengthForSegments(segments);
}

std::vector<Vec2> Curve::GetAsSegments(int numSubdivisions) const {
	std::vector<Vec2> result;
	if (numSubdivisions < 3 || !IsValid()) {
		return result;
	}
	float tInterval = 1.0f / numSubdivisions;
	for (int segmentID = 0; segmentID < numSubdivisions + 1; segmentID++) {
		float currentT = segmentID * tInterval;
		Vec2 currentOutput = EvaluateAtParametric(currentT);
		result.emplace_back(currentOutput);
	}
	return result;
}


Vec2 Curve::EvaluateAtApproximateDistanceInaccurate(float distanceAlongCurve, int numSubdivisions) const {
	if (distanceAlongCurve < 0.f || !IsValid()) {
		return Vec2();
	}
	return EvaluateAtDistanceForSegments(GetAsSegments(numSubdivisions), distanceAlongCurve);
}

Vec2 Curve::EvaluateAtApproximateDistanceAccurate(float distanceAlongCurve, int numSubdivisions) const {
	float totalDistance = GetApproximateLength(numSubdivisions);
	float roughT = distanceAlongCurve / totalDistance;
	if (roughT < 0.f || roughT > 1.f || !IsValid()) {
		return Vec2();
	}
	return EvaluateAtParametric(roughT);
}

//BezierCurve class------------------------------------------------------------------------------------------
BezierCurve::BezierCurve(Vec2 startPos, Vec2 guidePos, Vec2 endPos)
{
	m_points.emplace_back(startPos);
	m_points.emplace_back(guidePos);
	m_points.emplace_back(endPos);
}

BezierCurve::BezierCurve(Vec2 startPos, Vec2 guide1Pos, Vec2 guide2Pos, Vec2 endPos)
{
	m_points.emplace_back(startPos);
	m_points.emplace_back(guide1Pos);
	m_points.emplace_back(guide2Pos);
	m_points.emplace_back(endPos);
}

BezierCurve::BezierCurve(std::vector<Vec2> const& points)
{
	m_points = points;
}

BezierCurve::BezierCurve(CubicHermiteCurve2D const& fromHermite)
{
	InitializeAsCubicCurve(fromHermite);
}

void BezierCurve::InitializeAsCubicCurve(CubicHermiteCurve2D const& fromHermite) {
	m_points.resize(0);
	m_points.emplace_back(fromHermite.m_startPos);
	m_points.emplace_back(fromHermite.m_startPos + fromHermite.m_velocityStart / 3.f);
	m_points.emplace_back(fromHermite.m_endPos - fromHermite.m_velocityEnd / 3.f);
	m_points.emplace_back(fromHermite.m_endPos);
}

void BezierCurve::InitializeAsRandomSmoothCubicCurve(Vec2 start, Vec2 end, RandomNumberGenerator* rnd) {
	CubicHermiteCurve2D hermiteCurve;
	hermiteCurve.m_startPos = start;
	hermiteCurve.m_endPos = end;
	hermiteCurve.m_velocityStart = 2.99f * Vec2(rnd->RollRandomFloatInRange(0.f, end.x - start.x), rnd->RollRandomFloatInRange(0.f, end.y - start.y));
	hermiteCurve.m_velocityEnd = 2.99f * Vec2(rnd->RollRandomFloatInRange(0.f, end.x - start.x), rnd->RollRandomFloatInRange(0.f, end.y - start.y));
	InitializeAsCubicCurve(hermiteCurve);
}

Vec2 BezierCurve::EvaluateAtParametric(float tZeroToOne) const {
	return ComputeBezier2D(m_points, tZeroToOne);
}


//BezierCurveSpline class------------------------------------------------------------------------------------------
BezierCurveSpline::BezierCurveSpline(std::vector<BezierCurve> const& curves) {
	m_curves = curves;
}
BezierCurveSpline::BezierCurveSpline(std::vector<Vec2> const& keyPoints) {
	InitializeWithSegmentPoints(keyPoints);
}

BezierCurveSpline::BezierCurveSpline(Vec2 startPos, Vec2 endPos, int segmentCount, RandomNumberGenerator* rnd) {
	InitializeWithSegmentCount(startPos, endPos, segmentCount, rnd);
}

//const functions
Vec2 BezierCurveSpline::EvaluateAtParametric(float tZeroToOne) const {
	float totalProgress = tZeroToOne * m_curves.size();
	int currentCurveID = GetClamped(int(totalProgress), 0, static_cast<int>(m_curves.size()) - 1);
	float particalProgress = GetClamped(totalProgress - currentCurveID, 0.f, 1.f);
	return m_curves[currentCurveID].EvaluateAtParametric(particalProgress);
}


std::vector<Vec2> const BezierCurveSpline::GetAsPoints() const {
	std::vector<Vec2> result;
	for (int index = 0; index < m_curves.size(); index++) {
		result.emplace_back(m_curves[index].GetAsPoints()[0]);
	}
	std::vector<Vec2> lastPoint = m_curves[int(m_curves.size()) - 1].GetAsPoints();
	result.emplace_back(lastPoint[lastPoint.size() - 1]);
	return result;
}

void BezierCurveSpline::InitializeWithSegmentPoints(std::vector<Vec2> const& segmentPoints) {
	//Determine velocities
	std::vector<Vec2> segmentPointsVelocity;
	segmentPointsVelocity.emplace_back(Vec2());
	for (int index = 1; index < static_cast<int>(segmentPoints.size()) - 1; index++) {
		segmentPointsVelocity.emplace_back((segmentPoints[index + 1] - segmentPoints[index - 1]) * 0.5f);
	}
	segmentPointsVelocity.emplace_back(Vec2());
	//Determine curves
	for (int index = 0; index < segmentPoints.size() - 1; index++) {
		CubicHermiteCurve2D hermiteCurve;
		hermiteCurve.m_startPos = segmentPoints[index];
		hermiteCurve.m_endPos = segmentPoints[index + 1];
		hermiteCurve.m_velocityStart = segmentPointsVelocity[index];
		hermiteCurve.m_velocityEnd = segmentPointsVelocity[index + 1];
		m_curves.emplace_back(BezierCurve(hermiteCurve));
	}
}

void BezierCurveSpline::InitializeWithSegmentCount(Vec2 startPos, Vec2 endPos, int segmentCount, RandomNumberGenerator* rnd) {
	if (segmentCount < 2) {
		return;
	}
	std::vector<Vec2> keyPoints;
	keyPoints.emplace_back(startPos);
	float xmin = fminf(startPos.x, endPos.x);
	float ymin = fminf(startPos.y, endPos.y);
	float xmax = fmaxf(startPos.x, endPos.x);
	float ymax = fmaxf(startPos.y, endPos.y);
	for (int index = 0; index < segmentCount - 1; index++) {
		keyPoints.emplace_back(Vec2(rnd->RollRandomFloatInRange(xmin * 0.05f + xmax * 0.95f, xmin * 0.95f + xmax * 0.05f), rnd->RollRandomFloatInRange(ymin * 0.05f + ymax * 0.95f, ymin * 0.95f + ymax * 0.05f)));
	}
	keyPoints.emplace_back(endPos);
	InitializeWithSegmentPoints(keyPoints);
}