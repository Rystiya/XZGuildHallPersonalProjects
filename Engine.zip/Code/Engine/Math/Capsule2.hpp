#pragma once
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\LineSegment2.hpp"


//-----------------------------------------------------------------------------------------------
struct Capsule2
{
public:
	LineSegment2 m_myBone = LineSegment2(Vec2(), Vec2(), false, false);
	float m_radius = 1.f;

public:
	// Construction/Destruction
	~Capsule2() {}												// destructor (do nothing)
	explicit Capsule2(float radius = 0.1f, Vec2 startVec = Vec2(), Vec2 endVec = Vec2(), bool isInfniteFront = false, bool isInfniteBack = false);

	bool IsPointInside(Vec2 referencePosition) const;
	Vec2 const GetNearestPoint(Vec2 const& referencePosition) const;
	void Translate(Vec2 translation);
	void SetCenter(Vec2 newCenter);
	void RotateAboutCenter(float rotationDeltaDegrees);

};


