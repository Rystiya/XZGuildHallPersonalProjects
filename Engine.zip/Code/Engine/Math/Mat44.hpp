#pragma once
#include "Engine\Math\Vec4.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\Vec2.hpp"

enum Mat44Pos { Ix, Iy, Iz, Iw, Jx, Jy, Jz, Jw, Kx, Ky, Kz, Kw, Tx, Ty, Tz, Tw, numValues };


//[Ix, Jx, Kx, Tx] * [x,
//[Iy, Jy, Ky, Ty]    y,
//[Iz, Jz, Kz, Tz]    z,
//[Iw, Jw, Kw, Tw]    w]

struct Mat44
{

	~Mat44() {}

	//Constructors 
	Mat44();
	explicit Mat44(Vec2 const& iBasis2D, Vec2 const& jBasis2D, Vec2 const& translation2D);
	explicit Mat44(Vec3 const& iBasis3D, Vec3 const& jBasis3D, Vec3 const& kBasis3D, Vec3 const& translation3D);
	explicit Mat44(Vec4 const& iBasis4D, Vec4 const& jBasis4D, Vec4 const& kBasis4D, Vec4 const& translation4D);
	explicit Mat44(float const* allBasisMajor);
	//More constructors
	static Mat44 const CreateTranslation2D(Vec2 const& translationXY);
	static Mat44 const CreateTranslation3D(Vec3 const& translationXYZ);
	static Mat44 const CreateUniformScale2D(float uniformScaleXY);
	static Mat44 const CreateUniformScale3D(float uniformScaleXYZ);
	static Mat44 const CreateNonUniformScale2D(Vec2 const& nonUniformScaleXY);
	static Mat44 const CreateNonUniformScale3D(Vec3 const& nonUniformScaleXYZ);
	static Mat44 const CreateZRotationDegrees(float rotationDegreesAboutZ);
	static Mat44 const CreateYRotationDegrees(float rotationDegreesAboutY);
	static Mat44 const CreateXRotationDegrees(float rotationDegreesAboutX);
	static Mat44 const CreateOrthoProjection(float left, float right, float bottom, float top, float zNear, float zFar);
	static Mat44 const CreatePerspectiveProjection(float fovYDegrees, float aspect, float zNear, float zFar);



	//Getters
	float* GetAsFloatArray();
	float const* GetAsFloatArray() const;
	Vec2 const GetIBasis2D() const;
	Vec2 const GetJBasis2D() const;
	Vec2 const GetTranslation2D() const;
	Vec3 const GetIBasis3D() const;
	Vec3 const GetJBasis3D() const;
	Vec3 const GetKBasis3D() const;
	Vec3 const GetTranslation3D() const;
	Vec4 const GetIBasis4D() const;
	Vec4 const GetJBasis4D() const;
	Vec4 const GetKBasis4D() const;
	Vec4 const GetTranslation4D() const;
	Mat44 const GetOrthonormalInverse() const;
	Mat44 const GetTransposed() const;


	Vec2 const GetXBasis2D() const;
	Vec2 const GetYBasis2D() const;
	Vec3 const GetXBasis3D() const;
	Vec3 const GetYBasis3D() const;
	Vec3 const GetZBasis3D() const;
	Vec4 const GetXBasis4D() const;
	Vec4 const GetYBasis4D() const;
	Vec4 const GetZBasis4D() const;
	Vec4 const GetWBasis4D() const;

	Mat44 GetAppend(Mat44 const& appendThis);



	//None const functions
	void SetTranslation2D(Vec2 const& translationXY);
	void SetTranslation3D(Vec3 const& translationXYZ);
	void SetIJ2D(Vec2 const& iBasis2D, Vec2 const& jBasis2D);
	void SetIJT2D(Vec2 const& iBasis2D, Vec2 const& jBasis2D, Vec2 const& translationXY);
	void SetIJK3D(Vec3 const& iBasis3D, Vec3 const& jBasis3D, Vec3 const& kBasis3D);
	void SetIJKT3D(Vec3 const& iBasis3D, Vec3 const& jBasis3D, Vec3 const& kBasis3D, Vec3 const& translationXYZ);
	void SetIJKT4D(Vec4 const& iBasis4D, Vec4 const& jBasis4D, Vec4 const& kBasis4D, Vec4 const& translation4D);
	void CopyFrom(Mat44 copyFrom);
	void Transpose();
	void Orthonormalize_XFwd_YLeft_ZUp();

	void Append(Mat44 const& appendThis);
	void AppendZRotation(float degreesRotationAboutZ);
	void AppendYRotation(float degreesRotationAboutY);
	void AppendXRotation(float degreesRotationAboutX);
	void AppendTranslation2D(Vec2 const& translationXY);
	void AppendTranslation3D(Vec3 const& translationXYZ);
	void AppendScaleUniform2D(float uniformScaleXY);
	void AppendScaleUniform3D(float uniformScaleXYZ);
	void AppendScaleNonUniform2D(Vec2 const& nonUniformScaleXY);
	void AppendScaleNonUniform3D(Vec3 const& nonUniformScaleXYZ);

	//Const functions
	Vec2 TransformVectorQuantity2D(Vec2 localVec) const;
	Vec2 TransformPosition2D(Vec2 localVec) const;
	Vec3 TransformVectorQuantity3D(Vec3 localVec) const;
	Vec3 TransformPosition3D(Vec3 localVec) const;
	Vec4 TransformHomogeneous3D(Vec4 localVec) const;


private:
	float m_values[16] = {};
	//Others
	void SetValue(int index, float valueToSet) { m_values[index] = valueToSet; }
	void AddValue(int index, float valueToAdd) { m_values[index] += valueToAdd; }
};