#include "Engine\Math\LineSegment2.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>


//Basic stuff---------------------------------------------------------
LineSegment2::LineSegment2(Vec2 startVec, Vec2 endVec, bool isInfniteFront, bool isInfniteBack)
	: m_start(startVec)
	, m_end(endVec)
	, m_isInfniteEnd(isInfniteFront)
	, m_isInfniteStart(isInfniteBack)
{
}


float LineSegment2::GetLength() const {
	return	(m_end - m_start).GetLength();
}
Vec2 LineSegment2::GetDirection() const {
	return	(m_end - m_start).GetNormalized();
}
Vec2 LineSegment2::GetCenter() const {
	return 0.5f * (m_start + m_end);
}

float LineSegment2::GetDistance(Vec2 referencePosition) const {
	Vec2 nearestPoint = GetNearestPoint(referencePosition);
	return GetDistance2D(referencePosition, nearestPoint);
}

Vec2 const LineSegment2::GetNearestPoint(Vec2 const& referencePosition) const {
	//Case1
	Vec2 startToEndVec = m_end - m_start;
	Vec2 startToPosition = referencePosition - m_start;
	if (DotProduct2D(startToEndVec, startToPosition) < 0 && !m_isInfniteEnd) {
		return m_start;
	}
	//Case2
	Vec2 endToStartVec = m_start - m_end;
	Vec2 endToPosition = referencePosition - m_end;
	if (DotProduct2D(endToStartVec, endToPosition) < 0 && !m_isInfniteStart) {
		return m_end;
	}
	//Case3
	Vec2 vecDirection = startToEndVec.GetNormalized();
	Vec2 startToPositionOnVec = vecDirection * DotProduct2D(startToPosition, vecDirection);
	return m_start + startToPositionOnVec;
}
void LineSegment2::Translate(Vec2 translation) {
	m_start += translation;
	m_end += translation;
}
void LineSegment2::SetCenter(Vec2 newCenter) {
	Vec2 oldHalfLocalVec = 0.5f * (m_start - m_end);
	m_start = newCenter + oldHalfLocalVec;
	m_end = newCenter - oldHalfLocalVec;
}
void LineSegment2::RotateAboutCenter(float rotationDeltaDegrees) {
	Vec2 oldCenter = GetCenter();
	Vec2 oldHalfLocalVec = 0.5f * (m_start - m_end);
	Vec2 newHalfLocalVec = oldHalfLocalVec.GetRotatedDegrees(rotationDeltaDegrees);
	m_start = oldCenter + newHalfLocalVec;
	m_end = oldCenter - newHalfLocalVec;

}