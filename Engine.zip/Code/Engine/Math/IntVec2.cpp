
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\IntVec3.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>

IntVec2::IntVec2(IntVec2 const& copyFrom)
	: x(copyFrom.x)
	, y(copyFrom.y) 
{
}
IntVec2::IntVec2(IntVec3 const& copyFrom)
	: x(copyFrom.x)
	, y(copyFrom.y)
{
}
IntVec2::IntVec2(int initialX, int initialY)
	: x(initialX)
	, y(initialY)
{
}

IntVec2::IntVec2(const Vec2& copy)
	: x((int)copy.x)
	, y((int)copy.y)
{
}

IntVec2::IntVec2(char const* text) {
	SetFromText(text);
}

//Getters 
float IntVec2::GetLength() const {
	float floatX = static_cast<float>(x);
	float floatY = static_cast<float>(y);
	return static_cast<float>(sqrt(floatX * floatX + floatY * floatY));
}
int IntVec2::GetTaxicabLength() const {
	return abs(x) + abs(y);
}
int IntVec2::GetLengthSquared() const {
	return x * x + y * y;
}
float IntVec2::GetOrientationRadians() const {
	return Atan2Radians(static_cast<float>(y), static_cast<float>(x));
}
float IntVec2::GetOrientationDegrees() const {
	return Atan2Degrees(static_cast<float>(y), static_cast<float>(x));
}
IntVec2 IntVec2::GetRotated90Degrees() const {
	IntVec2 output = *this;
	output.Rotate90Degrees();
	return output;
}
IntVec2 IntVec2::GetRotatedMinus90Degrees() const {
	IntVec2 output = *this;
	output.RotateMinus90Degrees();
	return output;
}

//Setters
void IntVec2::Rotate90Degrees() {
	int temp = x;
	x = -y;
	y = temp;
}
void IntVec2::RotateMinus90Degrees() {
	int temp = x;
	x = y;
	y = -1 * temp;
}

//Operators
void IntVec2::operator=(const IntVec2& setTo) {
	x = setTo.x;
	y = setTo.y;
}
bool IntVec2::operator==(const IntVec2& comparedAgainst) const {
	return (x == comparedAgainst.x) && (y == comparedAgainst.y);
}
bool IntVec2::operator!=(const IntVec2& comparedAgainst) const {
	return !(*this == comparedAgainst);
}
bool IntVec2::operator<(const IntVec2& comparedAgainst) const {
	return (x + y < comparedAgainst.x + comparedAgainst.y) || ((x < comparedAgainst.x) && (x + y == comparedAgainst.x + comparedAgainst.y));
}
bool IntVec2::operator>(const IntVec2& comparedAgainst) const {
	return (x + y > comparedAgainst.x + comparedAgainst.y) || ((x > comparedAgainst.x) && (x + y == comparedAgainst.x + comparedAgainst.y));
}
void IntVec2::operator+=(const IntVec2& addBy) {
	x += addBy.x;
	y += addBy.y;
}
void IntVec2::operator-=(const IntVec2& minusBy) {
	x -= minusBy.x;
	y -= minusBy.y;
}
IntVec2 IntVec2::operator+(const IntVec2& addBy) {
	return IntVec2(x + addBy.x, y + addBy.y);
}
IntVec2 IntVec2::operator-(const IntVec2& minusBy) {
	return IntVec2(x - minusBy.x, y - minusBy.y);
}


void IntVec2::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	x = atoi(seperateedStrings[0].c_str());
	y = atoi(seperateedStrings[1].c_str());
}