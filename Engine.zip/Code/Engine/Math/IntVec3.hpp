#pragma once

struct Vec2;
struct Vec3;
#include "Engine\Math\IntVec2.hpp"

struct IntVec3
{
public:
	int x = 0;
	int y = 0;
	int z = 0;

	~IntVec3() {}
	IntVec3() {}
	IntVec3(IntVec2 const& copyFrom);
	IntVec3(IntVec3 const& copyFrom);
	explicit IntVec3(int initialX, int initialY, int initialZ = 0);
	explicit IntVec3(const Vec3& copy);
	IntVec3(char const* text);

	//Getters 
	float GetLength() const;
	int GetTaxicabLength() const;
	int GetLengthSquared() const;

	//Setters
	void SetFromText(char const* text);

	//Operators
	void operator=(const IntVec3& setTo);
	//Operators
	bool operator==(const IntVec3& comparedAgainst);
	bool operator!=(const IntVec3& comparedAgainst);
	void operator+=(const IntVec3& addBy);
	void operator-=(const IntVec3& minusBy);
	IntVec3 operator+(const IntVec3& addBy);
	IntVec3 operator-(const IntVec3& minusBy);

};