#pragma once
#include "Engine\Math\Vec4.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Mat44.hpp"


struct EulerAngles
{
public:
	EulerAngles() = default;
	EulerAngles(Vec3 yawPitchRoll);
	EulerAngles(float yawDegrees, float pitchDegrees, float rollDegrees);
	void GetAsVectors_XFwd_YLeft_ZUp(Vec3& out_forwardIBasis, Vec3& out_leftJBasis, Vec3& out_upKBasis) const;  //Inputs are output-locations.
	Mat44 GetAsMatrix_XFwd_YLeft_ZUp() const;
	Vec3 GetForwardVector() const { return GetAsMatrix_XFwd_YLeft_ZUp().GetIBasis3D(); }
	Vec3 GetSidewardVector() const { return GetAsMatrix_XFwd_YLeft_ZUp().GetJBasis3D(); }
	Vec3 GetUpwardVector() const { return GetAsMatrix_XFwd_YLeft_ZUp().GetKBasis3D(); }

	
public:
	float m_yawDegrees = 0.f;
	float m_pitchDegrees = 0.f;
	float m_rollDegrees = 0.f;

	const EulerAngles	operator+(const EulerAngles& angleToAdd) const;
	const EulerAngles	operator-(const EulerAngles& angleToSubtract) const;
	const EulerAngles	operator*(float uniformScale) const;
	const EulerAngles	operator/(float inverseScale) const;

	void Reset() {m_yawDegrees = 0.f; m_pitchDegrees = 0.f; m_rollDegrees = 0.f;	}
	void Clamp(float maxValue);


};