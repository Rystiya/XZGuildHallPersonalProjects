#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\IntVec3.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\StringUtils.hpp"


//Basic stuff ---------------------------------------------
Vec3::Vec3( const Vec3& copyFrom)
	: x(copyFrom.x)
	, y(copyFrom.y)
	, z(copyFrom.z)
{
}
Vec3::Vec3(const Vec2& copyFrom)
	: x(copyFrom.x)
	, y(copyFrom.y)
	, z(0)
{
}
Vec3::Vec3(char const* text) {
	SetFromText(text);
}
Vec3::Vec3()
	: x(0)
	, y(0)
	, z(0)
{
}
Vec3::Vec3(float initialX, float initialY)
	: x(initialX)
	, y(initialY)
	, z(0)
{
}
Vec3::Vec3( float initialX, float initialY, float initialZ)
	: x(initialX)
	, y(initialY)
	, z(initialZ)
{
}
Vec3::Vec3(const IntVec3& copy)
	: x((float)copy.x)
	, y((float)copy.y)
	, z((float)copy.z)
{
}
const Vec3 Vec3::operator + ( const Vec3& vecToAdd ) const
{
	return Vec3(x + vecToAdd.x, y + vecToAdd.y, z + vecToAdd.z);
}
const Vec3 Vec3::operator-( const Vec3& vecToSubtract ) const
{
	return Vec3(x - vecToSubtract.x, y - vecToSubtract.y, z - vecToSubtract.z);
}
const Vec3 Vec3::operator-() const
{
	return Vec3( -x, -y, -z);
}
const Vec3 Vec3::operator*( float uniformScale ) const
{
	return Vec3( x* uniformScale, y* uniformScale, z * uniformScale);
}
const Vec3 Vec3::operator*( const Vec3& vecToMultiply ) const
{
	return Vec3(x * vecToMultiply.x, y * vecToMultiply.y, z * vecToMultiply.z);
}
const Vec3 Vec3::operator/( float inverseScale ) const
{	
	float uniformScale = 1 / inverseScale;
	return Vec3( x * uniformScale, y * uniformScale, z * uniformScale);
}
void Vec3::operator+=( const Vec3& vecToAdd )
{
	x += vecToAdd.x;
	y += vecToAdd.y;
	z += vecToAdd.z;
}
void Vec3::operator-=( const Vec3& vecToSubtract )
{
	x -= vecToSubtract.x;
	y -= vecToSubtract.y;
	z -= vecToSubtract.z;
}
void Vec3::operator*=( const float uniformScale )
{
	x *= uniformScale;
	y *= uniformScale;
	z *= uniformScale;
}
void Vec3::operator/=( const float uniformDivisor )
{
	float uniformScale = 1 / uniformDivisor;
	x *= uniformScale;
	y *= uniformScale;
	z *= uniformScale;
}
void Vec3::operator=( const Vec3& copyFrom )
{
	x = copyFrom.x;
	y = copyFrom.y;
	z = copyFrom.z;
}
const Vec3 operator*( float uniformScale, const Vec3& vecToScale )
{
	return Vec3(vecToScale.x * uniformScale, vecToScale.y * uniformScale, vecToScale.z * uniformScale);
}
bool Vec3::operator==( const Vec3& compare ) const
{
	return (x == compare.x && y == compare.y && z == compare.z);
}
bool Vec3::operator!=( const Vec3& compare ) const
{
	return (x != compare.x || y != compare.y || z != compare.z);
}


//Advanced stuff------------------------------------
float Vec3::GetLength() const {
	return GetDistance3D(Vec3(0, 0, 0), *this);
}
float Vec3::GetLengthXY() const {
	return GetDistance3D(Vec3(0, 0, z), *this);
}
float Vec3::GetLengthSquared() const {
	return GetDistanceSquared3D(Vec3(0, 0, 0), *this);
}
float Vec3::GetLengthXYSquared() const {
	return GetDistanceSquared3D(Vec3(0, 0, z), *this);
}
float Vec3::GetAngleAboutZRadians() const {
	return Atan2Radians(y, x);
}
float Vec3::GetAngleAboutZDegrees() const {
	return Atan2Degrees(y, x);
}
Vec3 const Vec3::GetRotatedAboutZRadians(float deltaRadians) const {
	return GetRotatedAboutZDegrees(ConvertRadiansToDegrees(deltaRadians));
}
Vec3 const Vec3::GetRotatedAboutZDegrees(float deltaDegrees) const {
	Vec2 VecXY = Vec2(x, y);
	VecXY.RotateDegrees(deltaDegrees);
	return Vec3(VecXY.x, VecXY.y, z);
}
Vec3 const Vec3::GetClamped(float maxLength) const {
	float length = GetLength();
	if (length <= maxLength) {
		return Vec3(*this);
	}
	float multiplier = maxLength / length;
	return Vec3(x * multiplier, y * multiplier, z * multiplier);
}
Vec3 const Vec3::GetNormalized() const {
	float length = GetLength();
	if (length == 0.f) {
		return Vec3();
	}
	float multiplier = 1 / length;
	return Vec3(x * multiplier, y * multiplier, z * multiplier);
}


void Vec3::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	x = (float)atof(seperateedStrings[0].c_str());
	y = (float)atof(seperateedStrings[1].c_str());
	z = (float)atof(seperateedStrings[2].c_str());
}

void Vec3::SetXYFromVec2(Vec2 const& copyFrom) {
	x = copyFrom.x;
	y = copyFrom.y;
}


const Vec3 Vec3::MakeFromPolarDegrees(float latitudeDegrees, float longitudeDegrees, float length) {
	return MakeFromPolarRadians(ConvertDegreesToRadians(latitudeDegrees), ConvertDegreesToRadians(longitudeDegrees), length);
}

const Vec3 Vec3::MakeFromPolarRadians(float latitudeDegrees, float longitudeDegrees, float length) {
	float height = length * SinRadians(latitudeDegrees);
	float forward = length * CosRadians(latitudeDegrees);
	float forwardY = forward * SinRadians(longitudeDegrees);
	float forwardX = forward * CosRadians(longitudeDegrees);
	return Vec3(forwardX, forwardY, height);
}