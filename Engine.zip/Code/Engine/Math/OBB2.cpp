#include "Engine\Math\OBB2.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>

OBB2::OBB2(OBB2 const& copyFrom) 
	: m_center(copyFrom.m_center)
	, m_iBasisNormal(copyFrom.m_iBasisNormal)
	, m_halfDimensions(copyFrom.m_halfDimensions)
{
}
OBB2::OBB2(Vec2 center, Vec2 iBasisNormal, Vec2 halfDimensions)
	: m_center(center)
	, m_iBasisNormal(iBasisNormal)
	, m_halfDimensions(halfDimensions)
{
}

bool OBB2::IsPointInside(Vec2 const& point) const {
	Vec2 localCord = GetLocalPosForWorldPos(point);
	return fabsf(localCord.x) < m_halfDimensions.x && fabsf(localCord.y) < m_halfDimensions.y;
}

Vec2 const OBB2::GetNearestPoint(Vec2 const& referencePosition) const {
	Vec2 localCord = GetLocalPosForWorldPos(referencePosition);
	localCord.x = GetClamped(localCord.x, -1 * m_halfDimensions.x, m_halfDimensions.x);
	localCord.y = GetClamped(localCord.y, -1 * m_halfDimensions.y, m_halfDimensions.y);
	return GetWorldPosForLocalPos(localCord);
}

void OBB2::GetCornerPoints(Vec2* out_fourCornerWorldPositions) const {
	Vec2 m_iBasisVertical = m_iBasisNormal.GetRotated90Degrees();
	Vec2 topRight = GetWorldPosForLocalPos(Vec2(m_halfDimensions.x, m_halfDimensions.y));
	Vec2 topLeft = GetWorldPosForLocalPos(Vec2(-1.f * m_halfDimensions.x, m_halfDimensions.y));
	Vec2 bottomLeft = GetWorldPosForLocalPos(Vec2(-1.f * m_halfDimensions.x, -1.f * m_halfDimensions.y));
	Vec2 bottomRight = GetWorldPosForLocalPos(Vec2(m_halfDimensions.x, -1.f * m_halfDimensions.y));
	out_fourCornerWorldPositions = new Vec2[4]{ topRight , topLeft , bottomLeft , bottomRight };
}

Vec2 OBB2::GetLocalPosForWorldPos(Vec2 worldPos) const {
	Vec2 relativeGlobalCord = worldPos - m_center;
	float localCordX = DotProduct2D(relativeGlobalCord, m_iBasisNormal);
	float localCordY = DotProduct2D(relativeGlobalCord, m_iBasisNormal.GetRotated90Degrees());
	return Vec2(localCordX, localCordY);
}

Vec2 OBB2::GetWorldPosForLocalPos(Vec2 localPos) const {
	return m_center + localPos.x * m_iBasisNormal + localPos.y * m_iBasisNormal.GetRotated90Degrees();
}

void OBB2::RotateAboutCenter(float rotationDeltaDegrees) {
	m_iBasisNormal.RotateDegrees(rotationDeltaDegrees);
}


