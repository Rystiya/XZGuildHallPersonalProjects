#pragma once



struct IntRange
{
public:
	int m_min = 0;
	int m_max = 0;

	~IntRange() {}
	IntRange() {}
	IntRange(int min, int max);
	IntRange(IntRange const& copyFrom);
	IntRange(char const* text);

	//Operators
	void operator=(const IntRange& setTo);
	bool operator==(const IntRange& comparedAgainst);
	bool operator!=(const IntRange& comparedAgainst);
	bool IsOnRange(float value);
	bool IsOverlappingWithRange(IntRange anotherRange);

	static const IntRange ZERO;
	static const IntRange ONE;
	static const IntRange ZERO_TO_ONE;

	void SetFromText(char const* text);
};