#include "Engine\Math\MathUtils.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\OBB2.hpp"
#include "Engine\Math\Capsule2.hpp"
#include "Engine\Math\Mat44.hpp"
#include <math.h>
//#include "Engine\Core\EngineCommon.hpp"

#define PI 3.14159265


//Clamp and lerp stuff-----------------------------------------------------------------------------------------------
float GetClamped(float value, float minValue, float maxValue) {
	if (value > maxValue) {
		return maxValue;
	}
	if (value < minValue) {
		return minValue;
	}
	return value;
}int GetClamped(int value, int minValue, int maxValue) {
	if (value > maxValue) {
		return maxValue;
	}
	if (value < minValue) {
		return minValue;
	}
	return value;
}
float GetClampedZeroToOne(float value) {
	return GetClamped(value, 0.f, 1.f);
}
float Interpolate(float start, float end, float fractionTowardEnd) {
	return start * (1 - fractionTowardEnd) + end * fractionTowardEnd;
}
float GetFractionWithinRange(float value, float rangeStart, float rangeEnd) {
	return (value - rangeStart) / (rangeEnd - rangeStart);
}
float RangeMap(float inValue, float inStart, float inEnd, float outStart, float outEnd) {
	float fraction = GetFractionWithinRange(inValue, inStart, inEnd);
	return Interpolate(outStart, outEnd, fraction);
}
float RangeMapClamped(float inValue, float inStart, float inEnd, float outStart, float outEnd) {
	float fraction = GetFractionWithinRange(inValue, inStart, inEnd);
	fraction = GetClampedZeroToOne(fraction);
	return Interpolate(outStart, outEnd, fraction);
}
unsigned char LerpByte(unsigned char startByte, unsigned char endByte, float fraction) {
	float resultFloat = startByte * (1.f - fraction) + endByte * fraction;
	int resultInt = GetClamped(int(resultFloat), 0, 255);
	return (unsigned char)resultInt;
}
int RoundDownToInt(float value) {
	return static_cast<int>(floorf(value));
}



//Angle stuff-----------------------------------------------------------------------------------------------
float ConvertDegreesToRadians(float degrees) {
	return (degrees * static_cast<float>(PI) / 180);
}
float ConvertRadiansToDegrees(float radians) {
	return (radians * 180 / static_cast<float>(PI));
}
float aCosDegrees(float ratio) {
	return ConvertDegreesToRadians(aCosRadians(ratio));
}
float CosDegrees(float degrees) {
	return cosf(ConvertDegreesToRadians(degrees));
}
float SinDegrees(float degrees) {
	return sinf(ConvertDegreesToRadians(degrees));
}
float aCosRadians(float ratio) {
	if (ratio >= 1.f) {
		return 0.f;
	}
	return acosf(ratio);
}
float CosRadians(float radians) {
	return cosf(radians);
}
float SinRadians(float radians) {
	return sinf(radians);
}
//Atan2 Should be able to distinguish between (x, y) and (-x, -y)....
float Atan2Degrees(float y, float x) {
	return ConvertRadiansToDegrees(Atan2Radians(y, x));
}
float Atan2Degrees(Vec2 inputVector) {
	return ConvertRadiansToDegrees(Atan2Radians(inputVector.y, inputVector.x));
}
//Atan2 Should be able to distinguish between (x, y) and (-x, -y)....
float Atan2Radians(float y, float x) {
	return atan2f(y, x);
}
float GetAngleDegreesBetweenVectors2D(Vec2 const& a, Vec2 const& b) {
	if (a.GetLengthSquared() <= 0.f || b.GetLengthSquared() <= 0.f) {
		return 0.f;
	}
	float cosValue = DotProduct2D(a, b) / (a.GetLength() * b.GetLength());
	float acosRadiansValue = 0.f;
	if (cosValue < 1.f) {
		acosRadiansValue = acosf(cosValue);
	}
	return ConvertRadiansToDegrees(acosRadiansValue);
}

//2D/3D stuff-----------------------------------------------------------------------------------------------
//Don't forget const&
float GetDistance2D(Vec2 const& positionA, Vec2 const& positionB) {
	return sqrtf(GetDistanceSquared2D(positionA, positionB));
}
//no need of calculate squared everytime, should be much faster....
float GetDistanceSquared2D(Vec2 const& positionA, Vec2 const& positionB) {
	return (positionA.x - positionB.x) * (positionA.x - positionB.x) + (positionA.y - positionB.y) * (positionA.y - positionB.y);
}
float GetDistance3D(Vec3 const& positionA, Vec3 const& positionB) {
	return sqrtf(GetDistanceSquared3D(positionA, positionB));
}
float GetDistanceSquared3D(Vec3 const& positionA, Vec3 const& positionB) {
	return (positionA.x - positionB.x) * (positionA.x - positionB.x) + (positionA.y - positionB.y) * (positionA.y - positionB.y) + (positionA.z - positionB.z) * (positionA.z - positionB.z);
}
//Incase you what to do 2D distance calculation, but you are using Vec3?
float GetDistanceXY3D(Vec3 const& positionA, Vec3 const& positionB) {
	return sqrtf(GetDistanceXYSquared3D(positionA, positionB));
}
float GetDistanceXYSquared3D(Vec3 const& positionA, Vec3 const& positionB) {
	return (positionA.x - positionB.x) * (positionA.x - positionB.x) + (positionA.y - positionB.y) * (positionA.y - positionB.y);
}

int GetTaxicabDistance2D(IntVec2 const& pointA, IntVec2 const& pointB) {
	return abs(pointA.x - pointB.x) + abs(pointA.y - pointB.y);
}
float DotProduct2D(Vec2 const& a, Vec2 const& b) {
	return a.x * b.x + a.y * b.y;
}
float DotProduct3D(Vec3 const& a, Vec3 const& b) {
	return a.x * b.x + a.y * b.y + a.z * b.z;
}
float DotProduct4D(Vec4 const& a, Vec4 const& b) {
	return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
}
float CrossProduct2D(Vec2 const& a, Vec2 const& b) {
	return a.x * b.y - a.y * b.x;
}
Vec3 CrossProduct3D(Vec3 const& a, Vec3 const& b) {
	return Vec3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
float Multiply3D(Vec3 const& a, Vec3 const& b) {
	return a.x* b.x + a.y * b.y + a.z * b.z;
}
float GetProjectedLength2D(Vec2 const& vectorToProject, Vec2 const& vectorToProjectOnto) {
	return DotProduct2D(vectorToProject, vectorToProjectOnto) / vectorToProjectOnto.GetLength();
}
Vec2 GetProjectedOnto2D(Vec2 const& vectorToProject, Vec2 const& vectorToProjectOnto) {
	return vectorToProjectOnto.GetNormalized() * GetProjectedLength2D(vectorToProject, vectorToProjectOnto);
}

float GetProjectedLength3D(Vec3 const& vectorToProject, Vec3 const& vectorToProjectOnto) {
	return DotProduct3D(vectorToProject, vectorToProjectOnto) / vectorToProjectOnto.GetLength();
}
Vec3 GetProjectedOnto3D(Vec3 const& vectorToProject, Vec3 const& vectorToProjectOnto) {
	return vectorToProjectOnto.GetNormalized() * GetProjectedLength3D(vectorToProject, vectorToProjectOnto);
}


//Geometric stuff-----------------------------------------------------------------------------------------------
bool DoDiscsOverlap(Vec2 const& centerA, float radiusA, Vec2 const& centerB, float radiusB) {
	float distance = GetDistance2D(centerA, centerB);
	return distance < radiusA + radiusB;
}
bool DoSpheresOverlap(Vec3 const& centerA, float radiusA, Vec3 const& centerB, float radiusB) {
	float distance = GetDistance3D(centerA, centerB);
	return distance < radiusA + radiusB;
}
bool IsPointInsideDisc2D(Vec2 const& point, Vec2 const& discCenter, float discRadius) {
	return (discCenter - point).GetLengthSquared() < discRadius * discRadius;
}
bool IsPointInsideOrientedSector2D(Vec2 const& point, Vec2 const& sectorTip, float sectorForwardDegrees, float sectorApertureDegrees, float sectorRadius) {
	if (!IsPointInsideDisc2D(point, sectorTip, sectorRadius)) {
		return false;
	}
	float degreeDifference = GetShortestAngularDispDegreesAbs(sectorForwardDegrees, (point- sectorTip).GetOrientationDegrees());
	return degreeDifference < sectorApertureDegrees * 0.5f;
}
bool IsPointInsideDirectedSector2D(Vec2 const& point, Vec2 const& sectorTip, Vec2 const& sectorForwardNormal, float sectorApertureDegrees, float sectorRadius) {
	if (!IsPointInsideDisc2D(point, sectorTip, sectorRadius)) {
		return false;
	}
	float degreeDifference = GetAngleDegreesBetweenVectors2D(point - sectorTip, sectorForwardNormal);
	return fabsf(degreeDifference) < sectorApertureDegrees * 0.5f;
}
Vec2 GetNearestPointOnDisc2D(Vec2 const& referencePosition, Vec2 const& discCenter, float discRadius) {
	float distanceSquared = GetDistanceSquared2D(discCenter, referencePosition);
	if (distanceSquared <= discRadius * discRadius) {
		return referencePosition;
	}
	Vec2 vectToPoint = referencePosition - discCenter;
	return discCenter + vectToPoint.GetClamped(discRadius);
}
bool PushDiscOutOfFixedPoint2D(Vec2& discCenter, float discRadius, Vec2 const& fixedPoint) {
	float distanceSquard = GetDistanceSquared2D(discCenter, fixedPoint);
	if (distanceSquard >= discRadius * discRadius) {
		return false;
	}
	Vec2 pushVectorNorm = (discCenter - fixedPoint).GetNormalized();
	discCenter += pushVectorNorm * (discRadius - sqrtf(distanceSquard));
	return true;
}
bool PushDiscOutOfFixedDisc2D(Vec2& mobileDiscCenter, float mobileDiscRadius, Vec2 const& fixedDiscCenter, float fixedDiscRadius) {
	float distanceSquard = GetDistanceSquared2D(mobileDiscCenter, fixedDiscCenter);
	if (distanceSquard > (fixedDiscRadius + mobileDiscRadius) * (fixedDiscRadius + mobileDiscRadius)) {
		return false;
	}
	float pushDistance = mobileDiscRadius + fixedDiscRadius - sqrtf(distanceSquard);
	Vec2 pushAVectorNorm = (mobileDiscCenter - fixedDiscCenter).GetNormalized();
	mobileDiscCenter += pushDistance * pushAVectorNorm;
	return true;
}
bool PushDiscsOutOfEachOther2D(Vec2& aCenter, float aRadius, Vec2& bCenter, float bRadius, float massA, float massB) {
	Vec3 centerA3D = (Vec3)aCenter;
	Vec3 centerB3D = (Vec3)bCenter;
	bool result = PushDiscsOutOfEachOther3D(centerA3D, aRadius, centerB3D, bRadius, massA, massB);
	aCenter = centerA3D;
	bCenter = centerB3D;
	return result;
}
bool PushDiscsOutOfEachOther3D(Vec3& aCenter, float aRadius, Vec3& bCenter, float bRadius, float massA, float massB) {
	float distanceSquard = GetDistanceSquared3D(aCenter, bCenter);
	if (distanceSquard > (aRadius + bRadius) * (aRadius + bRadius)) {
		return false;
	}
	SanitizeMassForCollision(massA, massB);
	float pushDistance = aRadius + bRadius - sqrtf(distanceSquard);
	Vec2 pushAVectorNorm = (aCenter - bCenter).GetNormalized();
	float pushADistance = pushDistance * massB / (massA + massB);
	aCenter += pushADistance * pushAVectorNorm;
	float pushBDistance = -1 * pushDistance * massA / (massA + massB);
	bCenter += pushBDistance * pushAVectorNorm;
	return true;
}

bool IsPointInsideAABB2(AABB2 const& theBox, Vec2 const& point) {
	return theBox.IsPointInside(point);
}
bool PushDiscOutOfFixedAABB2D(Vec2& mobileDiscCenter, float discRadius, AABB2 const& fixedBox) {
	float distanceSquard = GetDistanceSquared2D(mobileDiscCenter, fixedBox.GetCenter());
	float wayTooFarDistance = discRadius + 0.5f * (fixedBox.GetDimensions().x + fixedBox.GetDimensions().y);
	if (distanceSquard > wayTooFarDistance * wayTooFarDistance) {
		return false;  //Should return quickly for most checks
	}
	Vec2 pointToPushAgainst = fixedBox.GetNearestPoint(mobileDiscCenter);
	if (fixedBox.IsPointInside(mobileDiscCenter) || !IsPointInsideDisc2D(pointToPushAgainst, mobileDiscCenter, discRadius)) {
		return false;
	}
	PushDiscOutOfFixedPoint2D(mobileDiscCenter, discRadius, pointToPushAgainst);
	return true;
}

bool PushDiscOutOfFixedAABB2D(Vec3& mobileDiscCenter, float discRadius, AABB2 const& fixedBox) {
	Vec2 positionXY = Vec2(mobileDiscCenter);
	bool result = PushDiscOutOfFixedAABB2D(positionXY, discRadius, fixedBox);
	mobileDiscCenter.SetXYFromVec2(positionXY);
	return result;
}

bool PushDiscOutOfFixedOBB2(Vec2& mobileDiscCenter, float discRadius, OBB2 const& fixedBox) {
	float distanceSquard = GetDistanceSquared2D(mobileDiscCenter, fixedBox.m_center);
	float wayTooFarDistance = discRadius + fixedBox.m_halfDimensions.x + fixedBox.m_halfDimensions.y;
	if (distanceSquard > wayTooFarDistance * wayTooFarDistance) {
		return false;  //Should return quickly for most checks
	}
	Vec2 pointToPushAgainst = fixedBox.GetNearestPoint(mobileDiscCenter);
	if (fixedBox.IsPointInside(mobileDiscCenter) || !IsPointInsideDisc2D(pointToPushAgainst, mobileDiscCenter, discRadius)) {
		return false;
	}
	PushDiscOutOfFixedPoint2D(mobileDiscCenter, discRadius, pointToPushAgainst);
	return true;
}

bool PushDiscOutOfFixedOBB2(Vec3& mobileDiscCenter, float discRadius, OBB2 const& fixedBox) {
	Vec2 positionXY = Vec2(mobileDiscCenter);
	bool result = PushDiscOutOfFixedOBB2(positionXY, discRadius, fixedBox);
	mobileDiscCenter = Vec2(positionXY);
	return result;
}

bool PushDiscOutOfFixedCapsule2(Vec2& mobileDiscCenter, float discRadius, Capsule2 const& fixedCapsule) {
	float distanceSquard = GetDistanceSquared2D(mobileDiscCenter, fixedCapsule.m_myBone.GetCenter());
	float wayTooFarDistance = discRadius + fixedCapsule.m_myBone.GetLength() * 0.5f + fixedCapsule.m_radius;
	if (distanceSquard > wayTooFarDistance * wayTooFarDistance) {
		return false;  //Should return quickly for most checks
	}
	Vec2 pointToPushAgainst = fixedCapsule.GetNearestPoint(mobileDiscCenter);
	if (fixedCapsule.IsPointInside(mobileDiscCenter) || !IsPointInsideDisc2D(pointToPushAgainst, mobileDiscCenter, discRadius)) {
		return false;
	}
	PushDiscOutOfFixedPoint2D(mobileDiscCenter, discRadius, pointToPushAgainst);
	return true;
}

bool PushDiscOutOfFixedCapsule2(Vec3& mobileDiscCenter, float discRadius, Capsule2 const& fixedCapsule) {
	Vec2 positionXY = Vec2(mobileDiscCenter);
	bool result = PushDiscOutOfFixedCapsule2(positionXY, discRadius, fixedCapsule);
	mobileDiscCenter = Vec2(positionXY);
	return result;
}

bool TryCollideBallsIntoEachOther2D(Vec2& centerA, Vec2& centerB, Vec2& velocityA, Vec2& velocityB, float radiusA, float radiusB, float elasticityA, float elasticityB, float frictionA, float frictionB, float massA, float massB) {
	Vec3 centerA3D = Vec3(centerA);
	Vec3 centerB3D = Vec3(centerB);
	Vec3 velocityA3D = Vec3(velocityA);
	Vec3 velocityB3D = Vec3(velocityB);
	bool output = TryCollideBallsIntoEachOther(centerA3D, centerB3D, velocityA3D, velocityB3D, radiusA, radiusB, elasticityA, elasticityB, frictionA, frictionB, massA, massB);
	centerA = centerA3D;
	centerB = centerB3D;
	velocityA = velocityA3D;
	velocityB = velocityB3D;
	return output;
}

bool TryCollideBallsIntoEachOther(Vec3& centerA, Vec3& centerB, Vec3& velocityA, Vec3& velocityB, float radiusA, float radiusB, float elasticityA, float elasticityB, float frictionA, float frictionB, float massA, float massB) {
	SanitizeMassForCollision(massA, massB);
	//Push out of each other
	if (!PushDiscsOutOfEachOther3D(centerA, radiusA, centerB, radiusB, massA, massB)) {
		return false;
	}
	//Correct velocity
	Vec3 directionBToANorm = centerB - centerA;
	if (directionBToANorm == Vec3()) {
		directionBToANorm.x += TINY_POSITIVE_NUMBER;
	}
	CalculateVelocityForBallCollision(velocityA, velocityB, massA, massB, elasticityA, elasticityB, frictionA, frictionB, directionBToANorm);
	return true;
}

bool TryCollideBallsIntoOBB2(Vec3& centerA, float radiusA, OBB2 thing, Vec3& velocityA, Vec3& velocityB, float elasticityA, float elasticityB, float frictionA, float frictionB, float massA, float massB) {
	//Push out of each other
	if (!PushDiscOutOfFixedOBB2(centerA, radiusA, thing)) {
		return false;
	}
	//Correct velocity, assume colliding with an infinitly small ball at collision point
	Vec3 impactPoint = thing.GetNearestPoint(centerA);
	TryCollideBallsIntoEachOther(centerA, impactPoint, velocityA, velocityB, radiusA, 0.f, elasticityA, elasticityB, frictionA, frictionB, massA, massB);
	return true;
}

bool TryCollideBallsIntoCapsule2(Vec3& centerA, float radiusA, Capsule2 thing, Vec3& velocityA, Vec3& velocityB, float elasticityA, float elasticityB, float frictionA, float frictionB, float massA, float massB) {
	//Push out of each other
	if (!PushDiscOutOfFixedCapsule2(centerA, radiusA, thing)) {
		return false;
	}
	//Correct velocity
	Vec3 impactPoint = thing.GetNearestPoint(centerA);
	TryCollideBallsIntoEachOther(centerA, impactPoint, velocityA, velocityB, radiusA, 0.f, elasticityA, elasticityB, frictionA, frictionB, massA, massB);
	return true;
}


void CollideBallsIntoStaticSurface(Vec3 const& surfaceFacing, Vec3& velocityA, Vec3 const& velocityB, float elasticityA, float elasticityB, float frictionA, float frictionB) {
	if (DotProduct3D(velocityA - velocityB, surfaceFacing) >= 0.f) {
		return;
	}
	
	Vec3 relativeVelocity = velocityA - velocityB;

	float collisionElasticity = elasticityA * elasticityB;
	float collisionFriction = frictionA * frictionB;

	Vec3 relativeVelocityVertical = GetProjectedOnto3D(relativeVelocity, surfaceFacing);
	Vec3 velocityAHorizontal = relativeVelocity - relativeVelocityVertical;
	relativeVelocityVertical *= -1 * collisionElasticity;
	velocityAHorizontal *= collisionFriction;
	velocityA = relativeVelocityVertical + velocityAHorizontal + velocityB;
	return;
}


void SanitizeMassForCollision(float& massA, float& massB) {
	if (massA == 0.f && massB == 0.f) {
		massA = 1.f;
		massB = 1.f;
	}
	if (massB < 0.f) {
		massA = 0.f;
		massB = 1.f;
	}
	if (massA < 0.f) {
		massA = 1.f;
		massB = 0.f;
	}
}

void CalculateVelocityForBallCollision(Vec3& velocityA, Vec3& velocityB, float massA, float massB, float elasticityA, float elasticityB, float frictionA, float frictionB, Vec3 const& directionBToANorm) {
	if (DotProduct3D(velocityB - velocityA, directionBToANorm) > 0.f) {
		return;
	}
	float collisionElasticity = elasticityA * elasticityB;
	float collisionFriction = frictionA * frictionB;
	Vec3 averageVelocity = (velocityA * massA + velocityB * massB) / (massA + massB);
	velocityA -= averageVelocity;
	velocityB -= averageVelocity;
	Vec3 velocityAVertical = GetProjectedOnto3D(velocityA, directionBToANorm);
	Vec3 velocityAHorizontal = velocityA - velocityAVertical;
	velocityAVertical *= -1.f * collisionElasticity;
	velocityAHorizontal *= 1.f - collisionFriction;
	velocityA = velocityAVertical + velocityAHorizontal + averageVelocity;
	Vec3 velocityBVertical = GetProjectedOnto3D(velocityB, -1.f * directionBToANorm);
	Vec3 velocityBHorizontal = velocityB - velocityBVertical;
	velocityBVertical *= -1 * collisionElasticity;
	velocityBHorizontal *= 1.f - collisionFriction;
	velocityB = velocityBVertical + velocityBHorizontal + averageVelocity;
}

//Transform stuff-----------------------------------------------------------------------------------------------
//Increase scale, rotate, etc
void TransformPosition2D(Vec2& posToTransform, float uniformScale, float rotationDegrees, Vec2 const& translation) {
	posToTransform.x *= uniformScale;
	posToTransform.y *= uniformScale;
	if (rotationDegrees != 0) {
		float posToTransformSize = posToTransform.GetLength();
		float posToTransformDegrees = posToTransform.GetOrientationDegrees();
		posToTransformDegrees += rotationDegrees;
		posToTransform = Vec2::MakeFromPolarDegrees(posToTransformDegrees, posToTransformSize);
	}
	posToTransform.x += translation.x;
	posToTransform.y += translation.y;
	return;
}
//Convert from a different coordinate system, where i, j is its normalized x, y vectors.
void TransformPosition2D(Vec2& posToTransform, Vec2 const& iBasis, Vec2 const& jBasis, Vec2 const& translation) {
	posToTransform = posToTransform.x * iBasis + posToTransform.y * jBasis + translation;
}
//2D rotation just like above, but with Vec3
void TransformPositionXY3D(Vec3& posToTransform, float scaleXY, float zRotationDegrees, Vec2 const& translationXY) {
	Vec2 vecXY = Vec2(posToTransform.x, posToTransform.y);
	TransformPosition2D(vecXY, scaleXY, zRotationDegrees, translationXY);
	posToTransform.x = vecXY.x;
	posToTransform.y = vecXY.y;
}
void TransformPositionXY3D(Vec3& posToTransform, Vec2 const& iBasis, Vec2 const& jBasis, Vec2 const& translationXY) {
	Vec2 Vec2Version = Vec2(posToTransform.x, posToTransform.y);
	Vec2Version = Vec2Version.x * iBasis + Vec2Version.y * jBasis + translationXY;
	posToTransform = Vec3(Vec2Version.x, Vec2Version.y, posToTransform.z);
}



//Turn stuff-----------------------------------------------------------------------------------------------
float GetClockwiseDistance(float angleFrom, float angleTo) {
	angleFrom = NormalizeAngle(angleFrom);
	angleTo = NormalizeAngle(angleTo);
	if (angleTo >= angleFrom) {
		return angleTo - angleFrom;
	} 
	return angleTo - angleFrom + 360;
}
float GetAClockwiseDistance(float angleFrom, float angleTo) {
	return GetClockwiseDistance(angleTo, angleFrom);
}

float AddAngle(float angle1, float angle2) {
	float answer = angle1 + angle2;
	return NormalizeAngle(answer);
}

float ClampAngle(float originalAngle, float minAngle, float maxAngle) {
	originalAngle = NormalizeAngle(originalAngle);
	minAngle = NormalizeAngle(minAngle);
	maxAngle = NormalizeAngle(maxAngle);
	return GetClamped(originalAngle, minAngle, maxAngle);
}
float NormalizeAngle(float angle) {
	while (angle < -180.f) {
		angle += 360.f;
	}
	while (angle > 180.f) {
		angle -= 360.f;
	}
	return angle;

}
float GetShortestAngularDispDegreesAbs(float angleFrom, float angleTo) {
	return fminf(GetClockwiseDistance(angleFrom, angleTo), GetAClockwiseDistance(angleFrom, angleTo));
}
float GetShortestAngularDispDegrees(float angleFrom, float angleTo) {
	float ctd = GetClockwiseDistance(angleFrom, angleTo);
	float actd = GetAClockwiseDistance(angleFrom, angleTo);
	if (ctd < actd) {
		return ctd;
	}
	return -1 * actd;
}
float GetTurnedTowardDegrees(float currentDegrees, float goalDegrees, float maxDeltaDegrees) {
	float clockwiseDistance = GetClockwiseDistance(currentDegrees, goalDegrees);
	float aClockwiseDistance = GetAClockwiseDistance(currentDegrees, goalDegrees);
	if (clockwiseDistance < maxDeltaDegrees || aClockwiseDistance < maxDeltaDegrees) {
		return goalDegrees;
	}
	if (clockwiseDistance < aClockwiseDistance) {
		return (AddAngle(currentDegrees, maxDeltaDegrees));
	} else {
		return (AddAngle(currentDegrees, -1 * maxDeltaDegrees));
	}
}


float GetTurnAccelerationTowardsTargetDegrees(float targetDegrees, float currentDegrees, float currentTurnSpeed, float maxTurnAcceleration, bool preventOverTurn, float preventOverTurnWithFrameRate) {
	float clockwiseDistance = GetClockwiseDistance(currentDegrees, targetDegrees);
	float aClockwiseDistance = GetAClockwiseDistance(currentDegrees, targetDegrees);
	float turnBrakeTime = currentTurnSpeed / maxTurnAcceleration;
	float turnBrakeDistance = currentTurnSpeed * turnBrakeTime * 0.5f;
	float result = 0;
	if (preventOverTurn &&(clockwiseDistance < 1.f || aClockwiseDistance < 1.f)) {
		//Try not to overturn.
		result = GetClamped(currentTurnSpeed * preventOverTurnWithFrameRate * -1.f, -1.f * maxTurnAcceleration, maxTurnAcceleration); 
	} 
	else if (clockwiseDistance < aClockwiseDistance) {
		//Try turn clock wise, but try slow down if about to over-turn
		result = maxTurnAcceleration;
		if (clockwiseDistance < turnBrakeDistance && currentTurnSpeed > 0.f) {
			result *= -1.f;
		}
	}
	else {
		//Try turn anti clock wise, but try slow down if about to over-turn
		result = -1.f * maxTurnAcceleration;
		if (aClockwiseDistance < turnBrakeDistance && currentTurnSpeed < 0.f) {
			result *= -1.f;
		}
	}
	return result;
}




//Normalize/denormalize stuff
float NormalizeByte(unsigned char byteValue) {
	return static_cast<float>(byteValue) / 255.f;
}
unsigned char DenormalizeByte(float zeroToOne) {
	return unsigned char(fmin(floor(zeroToOne * 256), 255));
}


//For debug render
Mat44 GetBillboardMatrix(BillboardType billboardType, Mat44 const& cameraMatrix, const Vec3& billboardPosition, const Vec2& billboardSale) {
	Mat44 resultMatrix;
	switch (billboardType) {
		case BillboardType::FULL_CAMERA_OPPOSING: {
			resultMatrix.SetIJK3D(cameraMatrix.GetIBasis3D() * -1.f, cameraMatrix.GetJBasis3D() * -1.f, cameraMatrix.GetKBasis3D());
			break;
		}
		case BillboardType::WORLD_UP_CAMERA_FACING: {
			Vec3 iBasis = Vec3(Vec2(cameraMatrix.GetTranslation3D() - billboardPosition).GetNormalized());
			Vec3 kBasis = Vec3(0.f, 0.f, 1.f);
			Vec3 jBasis = CrossProduct3D(iBasis, kBasis).GetNormalized() * -1.f;
			resultMatrix.SetIJK3D(iBasis, jBasis, kBasis);
			break;
		}
		case BillboardType::WORLD_UP_CAMERA_OPPOSING: {
			Vec3 iBasis = cameraMatrix.GetIBasis2D().GetNormalized() * -1.f;
			Vec3 kBasis = Vec3(0.f, 0.f, 1.f);
			Vec3 jBasis = CrossProduct3D(iBasis, kBasis).GetNormalized() * -1.f;
			resultMatrix.SetIJK3D(iBasis, jBasis, kBasis);
			break;
		}
		case BillboardType::FULL_CAMERA_FACING: {
			resultMatrix = GetRotationMatFromVectorDirection(Vec2(cameraMatrix.GetTranslation3D() - billboardPosition));
			break;
		}
	}
	//Set the right scale and pivot
	resultMatrix.AppendScaleNonUniform2D(billboardSale);
	//resultMatrix.AppendTranslation3D(billboardPosition);
	return resultMatrix;

}



Mat44 GetRotationMatFromVectorDirection(Vec3 direction) {
	Mat44 resultMatrix;
	Vec3 iBasis = Vec3(direction.GetNormalized());
	if (abs(DotProduct3D(iBasis, Vec3(0.f, 0.f, 1.f)) < 0.99f)) {
		Vec3 jBasis = CrossProduct3D(iBasis, Vec3(0.f, 0.f, 1.f)).GetNormalized();
		Vec3 kBasis = CrossProduct3D(iBasis, jBasis).GetNormalized();
		resultMatrix.SetIJK3D(iBasis, jBasis, kBasis);
	}
	else {
		Vec3 kBasis = CrossProduct3D(iBasis, Vec3(0.f, 1.f, 0.f)).GetNormalized();
		Vec3 jBasis = CrossProduct3D(iBasis, kBasis).GetNormalized();
		resultMatrix.SetIJK3D(iBasis, jBasis, kBasis);
	}
	return resultMatrix;
}


//For curves
float ComputeBezier1D(std::vector<float> const& controlPoints, float tZeroToOne) {
	std::vector<float> localControlPoints = controlPoints;
	int currentValidControlPoints = static_cast<int>(localControlPoints.size());
	while (currentValidControlPoints > 1) {
		currentValidControlPoints -= 1;
		for (int index = 0; index < currentValidControlPoints; index++) {
			localControlPoints[index] = Interpolate(localControlPoints[index], localControlPoints[index + 1], tZeroToOne);
		}
	}
	return localControlPoints[0];
}

Vec2 ComputeBezier2D(std::vector<Vec2> const& controlPoints, float tZeroToOne) {
	std::vector<Vec2> localControlPoints = controlPoints;
	int currentValidControlPoints = static_cast<int>(localControlPoints.size());
	while (currentValidControlPoints > 1) {
		for (int index = 0; index < currentValidControlPoints - 1; index++) {
			localControlPoints[index].x = Interpolate(localControlPoints[index].x, localControlPoints[index + 1].x, tZeroToOne);
			localControlPoints[index].y = Interpolate(localControlPoints[index].y, localControlPoints[index + 1].y, tZeroToOne);
		}
		currentValidControlPoints -= 1;
	}
	return localControlPoints[0];
}

int PowerInt(int base, int power) {
	int result = 1;
	if (power < 0) {
		base = 1 / base;
		power *= -1;
	}
	for (int index = 0; index < power; index++) {
		result *= base;
	}
	return result;
}
float PowerInt(float base, int power) {
	float result = 1;
	if (power < 0) {
		base = 1 / base;
		power *= -1;
	}
	for (int index = 0; index < power; index++) {
		result *= base;
	}
	return result;
}

float SmoothStart(float tZeroToOne, int order) {
	return PowerInt(tZeroToOne, order);
}
float SmoothStop(float tZeroToOne, int order) {
	return 1.f - SmoothStart(1.f - tZeroToOne, order);
}
float SmoothStep(float tZeroToOne, int order) {
	std::vector<float> controlPoints;
	for (int pointIndex = 0; pointIndex < (order + 1) / 2; pointIndex++) {
		controlPoints.emplace_back(0.f);
	}
	for (int pointIndex = 0; pointIndex < (order + 1) / 2; pointIndex++) {
		controlPoints.emplace_back(1.f);
	}
	return ComputeBezier1D(controlPoints, tZeroToOne);
}
float SmoothStep3(float tZeroToOne) { return SmoothStep(tZeroToOne, 3); }
float SmoothStep5(float tZeroToOne) { return SmoothStep(tZeroToOne, 5); }
float SmoothHesitate(float tZeroToOne, int order) {
	std::vector<float> controlPoints;
	controlPoints.emplace_back(0.f);
	for (int pointIndex = 0; pointIndex < order - 1; pointIndex++) {
		controlPoints.emplace_back(0.5f);
	}
	controlPoints.emplace_back(1.f);
	return ComputeBezier1D(controlPoints, tZeroToOne);
}
float SmoothWiggle(float tZeroToOne, int order) {
	float tMirrored = 2.f * fminf(fmodf(tZeroToOne, 1.f), 1.f - fmodf(tZeroToOne, 1.f));
	return Interpolate(SmoothStep(tZeroToOne, order), SmoothHesitate(tZeroToOne, order), SmoothHesitate(tMirrored, order - 1));
}
float SmoothRecursive(float tZeroToOne, int order) {
	if (order == 0) {
		return tZeroToOne;
	}
	float previousValue = SmoothRecursive(tZeroToOne, order - 1);
	float intepolator = SmoothHesitate(tZeroToOne, order);
	return Interpolate(tZeroToOne, previousValue * previousValue, (1.f - intepolator * intepolator));
}