#pragma once
#include "Engine\Core\Vertex_PCU.hpp"
#include <vector>

struct Vec2;
struct Vec3;
struct IntVec2;
struct AABB2;

void AddVertsForRing(std::vector<Vertex_PCU>& vertexes, Vec2 const& center, float radius, int edgeCount, float width, Rgba8 const& color = Rgba8());
void AddVertsForLine(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& color = Rgba8());
void AddVertsForAABB2(std::vector<Vertex_PCU>& vertexes, AABB2 const& bounds, Rgba8 const& color = Rgba8());
void AddVertsForOBB2(std::vector<Vertex_PCU>& vertexes, Vec2 centerPosition, Vec2 forwardNormal, float halfLength, float halfWidth, Rgba8 const& color = Rgba8());
void AddVertsForDisk(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, float radius, int edgeCount, Rgba8 const& color = Rgba8(), Rgba8 const& edgeColor = Rgba8());
