#pragma once

struct Vec2;
struct IntVec3;

struct IntVec2
{
public:
	int x = 0;
	int y = 0;

	~IntVec2() {}
	IntVec2() {}
	IntVec2(IntVec2 const& copyFrom);
	IntVec2(IntVec3 const& copyFrom);
	explicit IntVec2(int initialX, int initialY);
	explicit IntVec2(const Vec2& copy);
	IntVec2(char const* text);

	//Getters 
	float GetLength() const;
	int GetTaxicabLength() const;
	int GetLengthSquared() const;
	float GetOrientationRadians() const;
	float GetOrientationDegrees() const;
	IntVec2 GetRotated90Degrees() const;
	IntVec2 GetRotatedMinus90Degrees() const;

	//Setters
	void Rotate90Degrees();
	void RotateMinus90Degrees();
	void SetFromText(char const* text);

	//Operators
	void operator=(const IntVec2& setTo);
	//Operators
	bool operator==(const IntVec2& comparedAgainst) const;
	bool operator!=(const IntVec2& comparedAgainst) const;
	bool operator<(const IntVec2& comparedAgainst) const;
	bool operator>(const IntVec2& comparedAgainst) const;
	void operator+=(const IntVec2& addBy);
	void operator-=(const IntVec2& minusBy);
	IntVec2 operator+(const IntVec2& addBy);
	IntVec2 operator-(const IntVec2& minusBy);


};