
#include "Engine\Math\IntVec3.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>

IntVec3::IntVec3(IntVec3 const& copyFrom)
	: x(copyFrom.x)
	, y(copyFrom.y)
	, z(copyFrom.z)
{
}
IntVec3::IntVec3(IntVec2 const& copyFrom)
	: x(copyFrom.x)
	, y(copyFrom.y)
{
}
IntVec3::IntVec3(int initialX, int initialY, int initialZ)
	: x(initialX)
	, y(initialY)
	, z(initialZ)
{
}

IntVec3::IntVec3(const Vec3& copy)
	: x((int)copy.x)
	, y((int)copy.y)
	, z((int)copy.z)
{
}

IntVec3::IntVec3(char const* text) {
	SetFromText(text);
}

//Getters 
float IntVec3::GetLength() const {
	float floatX = static_cast<float>(x);
	float floatY = static_cast<float>(y);
	float floatZ = static_cast<float>(y);
	return static_cast<float>(sqrt(floatX * floatX + floatY * floatY + floatZ * floatZ));
}
int IntVec3::GetTaxicabLength() const {
	return abs(x) + abs(y) + abs(z);
}
int IntVec3::GetLengthSquared() const {
	return x * x + y * y + z * z;
}

//Operators
void IntVec3::operator=(const IntVec3& setTo) {
	x = setTo.x;
	y = setTo.y;
	z = setTo.z;
}
bool IntVec3::operator==(const IntVec3& comparedAgainst) {
	return x == comparedAgainst.x && y == comparedAgainst.y && z == comparedAgainst.z;
}
bool IntVec3::operator!=(const IntVec3& comparedAgainst) {
	return x != comparedAgainst.x || y != comparedAgainst.y || z != comparedAgainst.z;
}
void IntVec3::operator+=(const IntVec3& addBy) {
	x += addBy.x;
	y += addBy.y;
	z += addBy.z;
}
void IntVec3::operator-=(const IntVec3& minusBy) {
	x -= minusBy.x;
	y -= minusBy.y;
	z -= minusBy.z;
}
IntVec3 IntVec3::operator+(const IntVec3& addBy) {
	return IntVec3(x + addBy.x, y + addBy.y, z + addBy.z);
}
IntVec3 IntVec3::operator-(const IntVec3& minusBy) {
	return IntVec3(x - minusBy.x, y - minusBy.y, z - minusBy.z);
}


void IntVec3::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	x = atoi(seperateedStrings[0].c_str());
	y = atoi(seperateedStrings[1].c_str());
	z = atoi(seperateedStrings[2].c_str());
}