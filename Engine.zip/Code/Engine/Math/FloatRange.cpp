
#include "Engine\Math\FloatRange.hpp"
#include "Engine\Core\StringUtils.hpp"

const FloatRange FloatRange::ZERO = FloatRange(0, 0);
const FloatRange FloatRange::ONE = FloatRange(1, 1);
const FloatRange FloatRange::ZERO_TO_ONE = FloatRange(0, 1);


FloatRange::FloatRange(FloatRange const& copyFrom)
	: m_min(copyFrom.m_min)
	, m_max(copyFrom.m_max)
{
}
FloatRange::FloatRange(float min, float max)
	: m_min(min)
	, m_max(max)
{
}
FloatRange::FloatRange(char const* text) {
	SetFromText(text);
}




//Operators
void FloatRange::operator=(const FloatRange& setTo) {
	m_min = setTo.m_min;
	m_max = setTo.m_max;
}
bool FloatRange::operator==(const FloatRange& comparedAgainst) {
	return m_min == comparedAgainst.m_min && m_max == comparedAgainst.m_max;
}
bool FloatRange::operator!=(const FloatRange& comparedAgainst) {
	return m_min != comparedAgainst.m_min || m_max != comparedAgainst.m_max;
}
bool FloatRange::IsOnRange(float value) {
	return m_min <= value && m_max >= value;
}
bool FloatRange::IsOverlappingWithRange(FloatRange anotherRange) {
	return m_min <= anotherRange.m_max && m_max >= anotherRange.m_min;
}


void FloatRange::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, '~', true);
	m_min = (float)atof(seperateedStrings[0].c_str());
	m_max = (float)atof(seperateedStrings[1].c_str());
}