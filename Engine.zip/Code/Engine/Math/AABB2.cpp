#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\AABB3.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\StringUtils.hpp"


AABB2::AABB2(AABB2 const& copyFrom) 
	: m_mins(copyFrom.m_mins)
	, m_maxs(copyFrom.m_maxs)
{
}
AABB2::AABB2(AABB3 const& copyFrom)
	: m_mins(copyFrom.m_mins)
	, m_maxs(copyFrom.m_maxs)
{
}
AABB2::AABB2(float minX, float minY, float maxX, float maxY) {
	m_mins = Vec2(minX, minY);
	m_maxs = Vec2(maxX, maxY);
}
AABB2::AABB2(Vec2 const& mins, Vec2 const& maxs) {
	m_mins = mins;
	m_maxs = maxs;
}
AABB2::AABB2(char const* text) {
	SetFromText(text);
}

//Accessors
bool AABB2::IsPointInside(Vec2 const& point) const {
	if (point.x < m_mins.x or point.y < m_mins.y) {
		return false;
	}
	if (point.x > m_maxs.x or point.y > m_maxs.y) {
		return false;
	}
	return true;
}
Vec2 const AABB2::GetCenter() const {
	float tempX = (m_mins.x + m_maxs.x) / 2;
	float tempY = (m_mins.y + m_maxs.y) / 2;
	return Vec2(tempX, tempY);
}
Vec2 const AABB2::GetDimensions() const {
	return Vec2(m_maxs.x - m_mins.x, m_maxs.y - m_mins.y);
}
float const AABB2::GetAspect() const {
	return (m_maxs.x - m_mins.x) / (m_maxs.y - m_mins.y);
}
Vec2 const AABB2::GetNearestPoint(Vec2 const& referencePosition) const {
	float tempX = GetClamped(referencePosition.x, m_mins.x, m_maxs.x);
	float tempY = GetClamped(referencePosition.y, m_mins.y, m_maxs.y);
	return Vec2(tempX, tempY);
}
Vec2 const AABB2::GetPointAtUV(Vec2 const& uv) const {
	float tempX = Interpolate(m_mins.x, m_maxs.x, uv.x);
	float tempY = Interpolate(m_mins.y, m_maxs.y, uv.y);
	return Vec2(tempX, tempY);
}
Vec2 const AABB2::GetUVForPoint(Vec2 const& point) const {
	float tempX = GetFractionWithinRange(point.x, m_mins.x, m_maxs.x);
	float tempY = GetFractionWithinRange(point.y, m_mins.y, m_maxs.y);
	return Vec2(tempX, tempY);
}

bool AABB2::IsPointOutOfAABB2Fast(Vec2 position, float leaveMargin) const {
	bool result = false;
	if (position.x + leaveMargin < m_mins.x) {
		result = true;
	}
	if (position.x - leaveMargin > m_maxs.x) {
		result = true;
	}
	if (position.y + leaveMargin < m_mins.y) {
		result = true;
	}
	if (position.y - leaveMargin > m_maxs.y) {
		result = true;
	}
	return result;
}

//Mutators
void AABB2::Translate(Vec2 const& translationToApply) {
	m_mins += translationToApply;
	m_maxs += translationToApply;
}
void AABB2::SetCenter(Vec2 const& newCenter) {
	Translate(newCenter - GetCenter());
}
void AABB2::SetDimensions(Vec2 const& newDimensions) {
	Vec2 center = GetCenter();
	m_mins = center - newDimensions / 2;
	m_maxs = center + newDimensions / 2;

}
void AABB2::StretchToIncludePoint(Vec2 const& point) {
	if (point.x < m_mins.x) {
		m_mins.x = point.x;
	}
	if (point.y < m_mins.y) {
		m_mins.y = point.y;
	}
	if (point.x > m_maxs.x) {
		m_maxs.x = point.x;
	}
	if (point.y > m_maxs.y) {
		m_maxs.y = point.y;
	}
}


AABB2 AABB2::GetScaledBy(float scale) const {
	return AABB2(m_mins.x * scale, m_mins.y * scale, m_maxs.x * scale, m_maxs.y * scale);
}


void AABB2::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	m_mins.x = (float)atof(seperateedStrings[0].c_str());
	m_mins.y = (float)atof(seperateedStrings[1].c_str());
	m_maxs.x = (float)atof(seperateedStrings[2].c_str());
	m_maxs.y = (float)atof(seperateedStrings[3].c_str());
}

