#include "Engine\Math\Mat44.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>

Mat44::Mat44()
{
	m_values[Ix] = 1.f;
	m_values[Jy] = 1.f;
	m_values[Kz] = 1.f;
	m_values[Tw] = 1.f;
}

Mat44::Mat44(Vec2 const& iBasis2D, Vec2 const& jBasis2D, Vec2 const& translation2D):Mat44() {
	m_values[Ix] = iBasis2D.x;
	m_values[Iy] = iBasis2D.y;
	m_values[Jx] = jBasis2D.x;
	m_values[Jy] = jBasis2D.y;
	m_values[Tx] = translation2D.x;
	m_values[Ty] = translation2D.y;

}
Mat44::Mat44(Vec3 const& iBasis3D, Vec3 const& jBasis3D, Vec3 const& kBasis3D, Vec3 const& translation3D):Mat44() {
	m_values[Ix] = iBasis3D.x;
	m_values[Iy] = iBasis3D.y;
	m_values[Iz] = iBasis3D.z;
	m_values[Jx] = jBasis3D.x;
	m_values[Jy] = jBasis3D.y;
	m_values[Jz] = jBasis3D.z;
	m_values[Kx] = kBasis3D.x;
	m_values[Ky] = kBasis3D.y;
	m_values[Kz] = kBasis3D.z;
	m_values[Tx] = translation3D.x;
	m_values[Ty] = translation3D.y;
	m_values[Tz] = translation3D.z;

}
Mat44::Mat44(Vec4 const& iBasis4D, Vec4 const& jBasis4D, Vec4 const& kBasis4D, Vec4 const& translation4D) {
	m_values[Ix] = iBasis4D.x;
	m_values[Iy] = iBasis4D.y;
	m_values[Iz] = iBasis4D.z;
	m_values[Iw] = iBasis4D.w;
	m_values[Jx] = jBasis4D.x;
	m_values[Jy] = jBasis4D.y;
	m_values[Jz] = jBasis4D.z;
	m_values[Jw] = jBasis4D.w;
	m_values[Kx] = kBasis4D.x;
	m_values[Ky] = kBasis4D.y;
	m_values[Kz] = kBasis4D.z;
	m_values[Kw] = kBasis4D.w;
	m_values[Tx] = translation4D.x;
	m_values[Ty] = translation4D.y;
	m_values[Tz] = translation4D.z;
	m_values[Tw] = translation4D.w;

}
Mat44::Mat44(float const* allBasisMajor) {
	for (int index = 0; index < numValues; index++) {
		m_values[index] = allBasisMajor[index];
	}
}

//None const functions
void Mat44::SetTranslation2D(Vec2 const& translationXY) {
	m_values[Tx] = translationXY.x;
	m_values[Ty] = translationXY.y;
	m_values[Tz] = 0.f;
	m_values[Tw] = 1.f;
}
void Mat44::SetTranslation3D(Vec3 const& translationXYZ) {
	m_values[Tx] = translationXYZ.x;
	m_values[Ty] = translationXYZ.y;
	m_values[Tz] = translationXYZ.z;
	m_values[Tw] = 1.f;
}
void Mat44::SetIJ2D(Vec2 const& iBasis2D, Vec2 const& jBasis2D) {
	//I---
	m_values[Ix] = iBasis2D.x;
	m_values[Iy] = iBasis2D.y;
	m_values[Iz] = 0.f;
	m_values[Iw] = 0.f;
	//J---
	m_values[Jx] = jBasis2D.x;
	m_values[Jy] = jBasis2D.y;
	m_values[Jz] = 0.f;
	m_values[Jw] = 0.f;

}
void Mat44::SetIJT2D(Vec2 const& iBasis2D, Vec2 const& jBasis2D, Vec2 const& translationXY) {
	SetIJ2D(iBasis2D, jBasis2D);
	m_values[Tx] = translationXY.x;
	m_values[Ty] = translationXY.y;
	m_values[Tz] = 0.f;
	m_values[Tw] = 1.f;
}
void Mat44::SetIJK3D(Vec3 const& iBasis3D, Vec3 const& jBasis3D, Vec3 const& kBasis3D) {
	//I---
	m_values[Ix] = iBasis3D.x;
	m_values[Iy] = iBasis3D.y;
	m_values[Iz] = iBasis3D.z;
	m_values[Iw] = 0.f;
	//J---
	m_values[Jx] = jBasis3D.x;
	m_values[Jy] = jBasis3D.y;
	m_values[Jz] = jBasis3D.z;
	m_values[Jw] = 0.f;
	//K---
	m_values[Kx] = kBasis3D.x;
	m_values[Ky] = kBasis3D.y;
	m_values[Kz] = kBasis3D.z;
	m_values[Kw] = 0.f;
}
void Mat44::SetIJKT3D(Vec3 const& iBasis3D, Vec3 const& jBasis3D, Vec3 const& kBasis3D, Vec3 const& translationXYZ) {
	SetIJK3D(iBasis3D, jBasis3D, kBasis3D);
	m_values[Tx] = translationXYZ.x;
	m_values[Ty] = translationXYZ.y;
	m_values[Tz] = translationXYZ.z;
	m_values[Tw] = 1.f;
}
void Mat44::SetIJKT4D(Vec4 const& iBasis4D, Vec4 const& jBasis4D, Vec4 const& kBasis4D, Vec4 const& translation4D) {
	//I---
	m_values[Ix] = iBasis4D.x;
	m_values[Iy] = iBasis4D.y;
	m_values[Iz] = iBasis4D.z;
	m_values[Iw] = iBasis4D.w;
	//J---
	m_values[Jx] = jBasis4D.x;
	m_values[Jy] = jBasis4D.y;
	m_values[Jz] = jBasis4D.z;
	m_values[Jw] = jBasis4D.w;
	//K---
	m_values[Kx] = kBasis4D.x;
	m_values[Ky] = kBasis4D.y;
	m_values[Kz] = kBasis4D.z;
	m_values[Kw] = kBasis4D.w;
	//T---
	m_values[Tx] = translation4D.x;
	m_values[Ty] = translation4D.y;
	m_values[Tz] = translation4D.z;
	m_values[Tw] = translation4D.w;

}
void Mat44::CopyFrom(Mat44 copyFrom) {
	SetIJKT4D(copyFrom.GetIBasis4D(), copyFrom.GetJBasis4D(), copyFrom.GetKBasis4D(), copyFrom.GetTranslation4D());
}
void Mat44::Transpose() {
	CopyFrom(GetTransposed());
}
void Mat44::Orthonormalize_XFwd_YLeft_ZUp() {
	Vec3 normalizedX = GetXBasis3D().GetNormalized();
	Vec3 normalizedY = (GetYBasis3D() - normalizedX * DotProduct3D(GetYBasis3D(), normalizedX)).GetNormalized();
	Vec3 normalizedZ = (GetZBasis3D() - normalizedX * DotProduct3D(GetZBasis3D(), normalizedX) - normalizedY * DotProduct3D(GetZBasis3D(), normalizedY)).GetNormalized();
	SetIJKT3D(normalizedX, normalizedY, normalizedZ, GetTranslation3D());
}


Mat44 const Mat44::CreateTranslation2D(Vec2 const& translationXY) {
	Mat44 resultMatt = Mat44();
	resultMatt.m_values[Tx] = translationXY.x;
	resultMatt.m_values[Ty] = translationXY.y;
	return resultMatt;
}
Mat44 const Mat44::CreateTranslation3D(Vec3 const& translationXYZ) {
	Mat44 resultMatt = Mat44();
	resultMatt.m_values[Tx] = translationXYZ.x;
	resultMatt.m_values[Ty] = translationXYZ.y;
	resultMatt.m_values[Tz] = translationXYZ.z;
	return resultMatt;
}
Mat44 const Mat44::CreateUniformScale2D(float uniformScaleXY) {
	Mat44 resultMatt = Mat44();
	resultMatt.m_values[Ix] = uniformScaleXY;
	resultMatt.m_values[Jy] = uniformScaleXY;
	return resultMatt;
}
Mat44 const Mat44::CreateUniformScale3D(float uniformScaleXYZ) {
	Mat44 resultMatt = Mat44();
	resultMatt.m_values[Ix] = uniformScaleXYZ;
	resultMatt.m_values[Jy] = uniformScaleXYZ;
	resultMatt.m_values[Kz] = uniformScaleXYZ;
	return resultMatt;
}
Mat44 const Mat44::CreateNonUniformScale2D(Vec2 const& nonUniformScaleXY) {
	Mat44 resultMatt = Mat44();
	resultMatt.m_values[Ix] = nonUniformScaleXY.x;
	resultMatt.m_values[Jy] = nonUniformScaleXY.y;
	return resultMatt;
}
Mat44 const Mat44::CreateNonUniformScale3D(Vec3 const& nonUniformScaleXYZ) {
	Mat44 resultMatt = Mat44();
	resultMatt.m_values[Ix] = nonUniformScaleXYZ.x;
	resultMatt.m_values[Jy] = nonUniformScaleXYZ.y;
	resultMatt.m_values[Kz] = nonUniformScaleXYZ.z;
	return resultMatt;
}
Mat44 const Mat44::CreateZRotationDegrees(float rotationDegreesAboutZ) {
	Mat44 resultMatt = Mat44();
	float cosValue = CosDegrees(rotationDegreesAboutZ);
	float sinValue = SinDegrees(rotationDegreesAboutZ);
	resultMatt.SetValue(Ix, cosValue);
	resultMatt.SetValue(Jy, cosValue);
	resultMatt.SetValue(Iy, sinValue);
	resultMatt.SetValue(Jx, -1.f * sinValue);
	return resultMatt;
}
Mat44 const Mat44::CreateYRotationDegrees(float rotationDegreesAboutY) {
	Mat44 resultMatt = Mat44();
	float cosValue = CosDegrees(rotationDegreesAboutY);
	float sinValue = SinDegrees(rotationDegreesAboutY);
	resultMatt.SetValue(Ix, cosValue);
	resultMatt.SetValue(Kz, cosValue);
	resultMatt.SetValue(Iz, -1.f * sinValue);
	resultMatt.SetValue(Kx, sinValue);
	return resultMatt;
}
Mat44 const Mat44::CreateXRotationDegrees(float rotationDegreesAboutX) {
	Mat44 resultMatt = Mat44();
	float cosValue = CosDegrees(rotationDegreesAboutX);
	float sinValue = SinDegrees(rotationDegreesAboutX);
	resultMatt.SetValue(Jy, cosValue);
	resultMatt.SetValue(Kz, cosValue);
	resultMatt.SetValue(Jz, sinValue);
	resultMatt.SetValue(Ky, -1.f * sinValue);
	return resultMatt;
}

//Project from some AABB2 to AABB2 (-1, -1, 1, 1).
Mat44 const Mat44::CreateOrthoProjection(float left, float right, float bottom, float top, float zNear, float zFar) {
	Mat44 resultMatt = Mat44();
	resultMatt.SetValue(Ix, 2.f / (right - left));
	resultMatt.SetValue(Jy, 2.f / (top - bottom));
	resultMatt.SetValue(Kz, 1.f / (zFar - zNear));
	resultMatt.SetValue(Tx, -1.f * (right + left) / (right - left));
	resultMatt.SetValue(Ty, -1.f * (top + bottom) / (top - bottom));
	resultMatt.SetValue(Tz, -1.f * zNear / (zFar - zNear));
	return resultMatt;
}
Mat44 const Mat44::CreatePerspectiveProjection(float fovYDegrees, float aspect, float zNear, float zFar) {
	Mat44 resultMatt = Mat44();
	resultMatt.SetValue(Tw, 0.f);
	resultMatt.SetValue(Kw, 1.f);
	resultMatt.SetValue(Tz, -1.f * (zNear * zFar) / (zFar - zNear));
	resultMatt.m_values[Jy] = CosDegrees(fovYDegrees * 0.5f) / SinDegrees(fovYDegrees * 0.5f);
	resultMatt.m_values[Ix] = resultMatt.m_values[Jy] / aspect;
	resultMatt.SetValue(Kz, zFar / (zFar - zNear));
	return resultMatt;
}






void Mat44::Append(Mat44 const& appendThis) {
	float newValues[numValues] = {};
	//I---
	newValues[Ix] = DotProduct4D(appendThis.GetIBasis4D(), GetXBasis4D());
	newValues[Iy] = DotProduct4D(appendThis.GetIBasis4D(), GetYBasis4D());
	newValues[Iz] = DotProduct4D(appendThis.GetIBasis4D(), GetZBasis4D());
	newValues[Iw] = DotProduct4D(appendThis.GetIBasis4D(), GetWBasis4D());
	//J---
	newValues[Jx] = DotProduct4D(appendThis.GetJBasis4D(), GetXBasis4D());
	newValues[Jy] = DotProduct4D(appendThis.GetJBasis4D(), GetYBasis4D());
	newValues[Jz] = DotProduct4D(appendThis.GetJBasis4D(), GetZBasis4D());
	newValues[Jw] = DotProduct4D(appendThis.GetJBasis4D(), GetWBasis4D());
	//K---
	newValues[Kx] = DotProduct4D(appendThis.GetKBasis4D(), GetXBasis4D());
	newValues[Ky] = DotProduct4D(appendThis.GetKBasis4D(), GetYBasis4D());
	newValues[Kz] = DotProduct4D(appendThis.GetKBasis4D(), GetZBasis4D());
	newValues[Kw] = DotProduct4D(appendThis.GetKBasis4D(), GetWBasis4D());
	//T---
	newValues[Tx] = DotProduct4D(appendThis.GetTranslation4D(), GetXBasis4D());
	newValues[Ty] = DotProduct4D(appendThis.GetTranslation4D(), GetYBasis4D());
	newValues[Tz] = DotProduct4D(appendThis.GetTranslation4D(), GetZBasis4D());
	newValues[Tw] = DotProduct4D(appendThis.GetTranslation4D(), GetWBasis4D());
	//End---
	for (int index = 0; index < numValues; index++) {
		m_values[index] = newValues[index];
	}
}
void Mat44::AppendZRotation(float degreesRotationAboutZ) {
	Append(CreateZRotationDegrees(degreesRotationAboutZ));
}
void Mat44::AppendYRotation(float degreesRotationAboutY) {
	Append(CreateYRotationDegrees(degreesRotationAboutY));
}
void Mat44::AppendXRotation(float degreesRotationAboutX) {
	Append(CreateXRotationDegrees(degreesRotationAboutX));
}
void Mat44::AppendTranslation2D(Vec2 const& translationXY) {
	Append(CreateTranslation2D(translationXY));
}
void Mat44::AppendTranslation3D(Vec3 const& translationXYZ) {
	Append(CreateTranslation3D(translationXYZ));
}
void Mat44::AppendScaleUniform2D(float uniformScaleXY) {
	Append(CreateUniformScale2D(uniformScaleXY));
}
void Mat44::AppendScaleUniform3D(float uniformScaleXYZ) {
	Append(CreateUniformScale3D(uniformScaleXYZ));
}
void Mat44::AppendScaleNonUniform2D(Vec2 const& nonUniformScaleXY) {
	Append(CreateNonUniformScale2D(nonUniformScaleXY));
}
void Mat44::AppendScaleNonUniform3D(Vec3 const& nonUniformScaleXYZ) {
	Append(CreateNonUniformScale3D(nonUniformScaleXYZ));
}


//Getters
float* Mat44::GetAsFloatArray() {
	return m_values;
}
float const* Mat44::GetAsFloatArray() const {
	return m_values;
}
Vec2 const Mat44::GetIBasis2D() const {
	return Vec2(m_values[Ix], m_values[Iy]);
}
Vec2 const Mat44::GetJBasis2D() const {
	return Vec2(m_values[Jx], m_values[Jy]);
}
Vec2 const Mat44::GetTranslation2D() const {
	return Vec2(m_values[Tx], m_values[Ty]);
}
Vec3 const Mat44::GetIBasis3D() const {
	return Vec3(m_values[Ix], m_values[Iy], m_values[Iz]);
}
Vec3 const Mat44::GetJBasis3D() const {
	return Vec3(m_values[Jx], m_values[Jy], m_values[Jz]);
}
Vec3 const Mat44::GetKBasis3D() const {
	return Vec3(m_values[Kx], m_values[Ky], m_values[Kz]);
}
Vec3 const Mat44::GetTranslation3D() const {
	return Vec3(m_values[Tx], m_values[Ty], m_values[Tz]);
}
Vec4 const Mat44::GetIBasis4D() const {
	return Vec4(m_values[Ix], m_values[Iy], m_values[Iz], m_values[Iw]);
}
Vec4 const Mat44::GetJBasis4D() const {
	return Vec4(m_values[Jx], m_values[Jy], m_values[Jz], m_values[Jw]);
}
Vec4 const Mat44::GetKBasis4D() const {
	return Vec4(m_values[Kx], m_values[Ky], m_values[Kz], m_values[Kw]);
}
Vec4 const Mat44::GetTranslation4D() const {
	return Vec4(m_values[Tx], m_values[Ty], m_values[Tz], m_values[Tw]);
}

Mat44 const Mat44::GetOrthonormalInverse() const {
	Mat44 resultMatt = Mat44();
	resultMatt.SetIJKT3D(GetXBasis3D(), GetYBasis3D(), GetZBasis3D(), -1.f * Vec3(Multiply3D(GetIBasis3D(), GetTranslation3D()), Multiply3D(GetJBasis3D(), GetTranslation3D()), Multiply3D(GetKBasis3D(), GetTranslation3D())) );
	return resultMatt;

}
Mat44 const Mat44::GetTransposed() const {
	Mat44 resultMatt = Mat44();
	resultMatt.SetIJKT4D(GetXBasis4D(), GetYBasis4D(), GetZBasis4D(), GetWBasis4D());
	return resultMatt;

}






Vec2 const Mat44::GetXBasis2D() const {
	return Vec2(m_values[Ix], m_values[Jx]);
}
Vec2 const Mat44::GetYBasis2D() const {
	return Vec2(m_values[Iy], m_values[Jy]);
}
Vec3 const Mat44::GetXBasis3D() const {
	return Vec3(m_values[Ix], m_values[Jx], m_values[Kx]);
}
Vec3 const Mat44::GetYBasis3D() const {
	return Vec3(m_values[Iy], m_values[Jy], m_values[Ky]);
}
Vec3 const Mat44::GetZBasis3D() const {
	return Vec3(m_values[Iz], m_values[Jz], m_values[Kz]);
}
Vec4 const Mat44::GetXBasis4D() const {
	return Vec4(m_values[Ix], m_values[Jx], m_values[Kx], m_values[Tx]);
}
Vec4 const Mat44::GetYBasis4D() const {
	return Vec4(m_values[Iy], m_values[Jy], m_values[Ky], m_values[Ty]);
}
Vec4 const Mat44::GetZBasis4D() const {
	return Vec4(m_values[Iz], m_values[Jz], m_values[Kz], m_values[Tz]);
}
Vec4 const Mat44::GetWBasis4D() const {
	return Vec4(m_values[Iw], m_values[Jw], m_values[Kw], m_values[Tw]);
}

Mat44 Mat44::GetAppend(Mat44 const& appendThis) {
	Mat44 newMat = Mat44(GetAsFloatArray());
	newMat.Append(appendThis);
	return newMat;
}


//Const functions
Vec2 Mat44::TransformVectorQuantity2D(Vec2 localVec) const {
	return Vec2(DotProduct2D(GetXBasis2D(), localVec), DotProduct2D(GetYBasis2D(), localVec));
}
Vec2 Mat44::TransformPosition2D(Vec2 localVec) const {
	return TransformVectorQuantity2D(localVec) + GetTranslation2D();
}
Vec3 Mat44::TransformVectorQuantity3D(Vec3 localVec) const {
	return Vec3(DotProduct3D(GetXBasis3D(), localVec), DotProduct3D(GetYBasis3D(), localVec), DotProduct3D(GetZBasis3D(), localVec));
}
Vec3 Mat44::TransformPosition3D(Vec3 localVec) const {
	return TransformVectorQuantity3D(localVec) + GetTranslation3D();
}
Vec4 Mat44::TransformHomogeneous3D(Vec4 localVec) const {
	return Vec4(DotProduct4D(GetXBasis4D(), localVec), DotProduct4D(GetYBasis4D(), localVec), DotProduct4D(GetZBasis4D(), localVec), DotProduct4D(GetWBasis4D(), localVec));
}