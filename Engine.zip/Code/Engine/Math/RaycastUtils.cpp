#include "Engine\Math\RaycastUtils.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\OBB2.hpp"
#include "Engine\Math\FloatRange.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include <math.h>
//#include "Engine\Core\EngineCommon.hpp"

void AddVertsForArrow2D(std::vector<Vertex_PCU>& verts, Vec2 tailPos, Vec2 tipPos, float arrowSize, float lineThickness, Rgba8 const& drawColor) {
	float totalLength = (tipPos - tailPos).GetLength();
	arrowSize = fminf(arrowSize, totalLength * 0.8f);
	Vec2 forwardNormal = (tipPos - tailPos) / totalLength;
	Vec2 sidewardNormal = forwardNormal.GetRotated90Degrees();
	Vec2 lineEnd = tipPos - forwardNormal * arrowSize;
	AddVertsForLine2D(verts, tailPos, lineEnd, lineThickness, drawColor);
	verts.emplace_back(Vertex_PCU(lineEnd + sidewardNormal * arrowSize * 0.5f, drawColor));
	verts.emplace_back(Vertex_PCU(lineEnd - sidewardNormal * arrowSize * 0.5f, drawColor));
	verts.emplace_back(Vertex_PCU(tipPos, drawColor));
}

void AddVertsForArrow2D(std::vector<Vertex_PCU>& verts, Vec2 tailPos, Vec2 tipPos, float arrowSize, float lineThickness) {
	AddVertsForArrow2D(verts, tailPos, tipPos, arrowSize, lineThickness, Rgba8(255,255,255,255));
}


RaycastResult2D RaycastVsLine(Vec2 startPos, Vec2 fwdNormal, float maxDist, Vec2 targetLineA, Vec2 targetLineB) {
	struct RaycastResult2D myResult;
	Vec2 yNormal = fwdNormal.GetRotated90Degrees();
	float targetLineADist = DotProduct2D((targetLineA - startPos), yNormal);
	float targetLineBDist = DotProduct2D((targetLineB - startPos), yNormal);
	//If targetLineA and targetLineB is on the same side:
	if (targetLineADist * targetLineBDist >= 0.f) {
		return myResult;
	}
	float intercectRatio = abs(targetLineADist) / (abs(targetLineADist) + abs(targetLineBDist));
	myResult.m_impactPos = targetLineA + intercectRatio * (targetLineB - targetLineA);
	//Dot product the start-to-impact-point vector with its own direction to get its length
	myResult.m_impactDist = DotProduct2D(myResult.m_impactPos - startPos, fwdNormal);
	if (myResult.m_impactDist > 0.f && myResult.m_impactDist <= maxDist) {
		myResult.m_didImpact = true;
	} else {
		return myResult;
	}
	Vec2 targetLineDir = (targetLineB - targetLineA).GetNormalized();
	myResult.m_impactNormal = (targetLineB - targetLineA).GetNormalized().GetRotated90Degrees();
	if (DotProduct2D(myResult.m_impactNormal, fwdNormal) > 0.f) {
		myResult.m_impactNormal *= -1.f;
	}
	return myResult;
}

RaycastResult2D RaycastVsAABB2(Vec2 startPos, Vec2 fwdNormal, float maxDist, AABB2 targetBox) {
	struct RaycastResult2D myResult;
	myResult.m_impactDist = maxDist * 2.f;
	if (targetBox.IsPointInside(startPos)) {
		myResult.m_didImpact = true;
		myResult.m_impactDist = 0.f;
		myResult.m_impactNormal = fwdNormal * -1.f;
		myResult.m_impactPos = startPos;
		return myResult;
	}
	if (fwdNormal.x != 0.f) {
		float distanceBeforeReachingXmin = (targetBox.m_mins.x - startPos.x) / fwdNormal.x;
		float distanceBeforeReachingXmax = (targetBox.m_maxs.x - startPos.x) / fwdNormal.x;
		if (distanceBeforeReachingXmin >= 0.f && distanceBeforeReachingXmin <= maxDist) {
			Vec2 collisionPoint = (startPos + fwdNormal * distanceBeforeReachingXmin);
			if (collisionPoint.y > targetBox.m_mins.y && collisionPoint.y < targetBox.m_maxs.y && distanceBeforeReachingXmin < myResult.m_impactDist) {
				myResult.m_didImpact = true;
				myResult.m_impactDist = distanceBeforeReachingXmin;
				myResult.m_impactNormal = Vec2(-1.f, 0.f);
				myResult.m_impactPos = collisionPoint;
			}
		}
		if (distanceBeforeReachingXmax >= 0.f && distanceBeforeReachingXmax <= maxDist) {
			Vec2 collisionPoint = (startPos + fwdNormal * distanceBeforeReachingXmax);
			if (collisionPoint.y > targetBox.m_mins.y && collisionPoint.y < targetBox.m_maxs.y && distanceBeforeReachingXmax < myResult.m_impactDist) {
				myResult.m_didImpact = true;
				myResult.m_impactDist = distanceBeforeReachingXmax;
				myResult.m_impactNormal = Vec2(1.f, 0.f);
				myResult.m_impactPos = collisionPoint;
			}
		}
	}
	if (fwdNormal.y != 0.f) {
		float distanceBeforeReachingYmin = (targetBox.m_mins.y - startPos.y) / fwdNormal.y;
		float distanceBeforeReachingYmax = (targetBox.m_maxs.y - startPos.y) / fwdNormal.y;
		if (distanceBeforeReachingYmin >= 0.f && distanceBeforeReachingYmin <= maxDist) {
			Vec2 collisionPoint = (startPos + fwdNormal * distanceBeforeReachingYmin);
			if (collisionPoint.x > targetBox.m_mins.x && collisionPoint.x < targetBox.m_maxs.x && distanceBeforeReachingYmin < myResult.m_impactDist) {
				myResult.m_didImpact = true;
				myResult.m_impactDist = distanceBeforeReachingYmin;
				myResult.m_impactNormal = Vec2(0.f, -1.f);
				myResult.m_impactPos = collisionPoint;
			}
		}
		if (distanceBeforeReachingYmax >= 0.f && distanceBeforeReachingYmax <= maxDist) {
			Vec2 collisionPoint = (startPos + fwdNormal * distanceBeforeReachingYmax);
			if (collisionPoint.x > targetBox.m_mins.x && collisionPoint.x < targetBox.m_maxs.x && distanceBeforeReachingYmax < myResult.m_impactDist) {
				myResult.m_didImpact = true;
				myResult.m_impactDist = distanceBeforeReachingYmax;
				myResult.m_impactNormal = Vec2(0.f, 1.f);
				myResult.m_impactPos = collisionPoint;
			}
		}
	}
	return myResult;
}

RaycastResult3D RaycastVsDiscXY3D(Vec3 startPos, Vec3 fwdNormal, float maxDist, Vec3 discCenter, float discRadius, float rayWidth) {
	float practicalDiskRadius = discRadius + rayWidth * 0.5f;
	struct RaycastResult3D myResult;
	//If ray is vertical
	if (fwdNormal.z == 0.f) {
		return myResult;
	}
	float potentialHitDistance = (discCenter.z - startPos.z) / fwdNormal.z;
	//If the ray's vertical direction is not right or distance too far
	if (potentialHitDistance < 0.f || potentialHitDistance > maxDist) {
		return myResult;
	}
	Vec3 potentialHitPosition = startPos + fwdNormal * potentialHitDistance;
	if (GetDistanceSquared3D(potentialHitPosition, discCenter) < practicalDiskRadius * practicalDiskRadius) {
		myResult.m_didImpact = true;
		myResult.m_impactDist = potentialHitDistance;
		myResult.m_impactPos = potentialHitPosition;
		if (startPos.z > discCenter.z) {
			myResult.m_impactNormal = Vec3(0.f, 0.f, 1.f);
		}
		else {
			myResult.m_impactNormal = Vec3(0.f, 0.f, -1.f);
		}
	}
	return myResult;
}

RaycastResult2D RaycastVsDisc2D(Vec2 startPos, Vec2 fwdNormal, float maxDist, Vec2 discCenter, float discRadius, float rayWidth) {
	float practicalDiskRadius = discRadius + rayWidth * 0.5f;
	struct RaycastResult2D myResult;
	Vec2 startToDiscCenterVector = discCenter - startPos;
	//Condition 1
	float startToDiscCenterLocalYCoordinate = DotProduct2D(startToDiscCenterVector, fwdNormal.GetRotated90Degrees());
	if (fabsf(startToDiscCenterLocalYCoordinate) > practicalDiskRadius) {
		return myResult;
	}
	//Condition 2
	float startToDiscCenterLocalXCoordinate = DotProduct2D(startToDiscCenterVector, fwdNormal);
	if (startToDiscCenterLocalXCoordinate < -1.f * practicalDiskRadius || startToDiscCenterLocalXCoordinate > maxDist + practicalDiskRadius) {
		return myResult;
	}
	//Condition final
	Vec2 nearestPointOnLineToDiscCenter = startPos + startToDiscCenterLocalXCoordinate * fwdNormal;
	float distanceToSupposedContactPoint1 = startToDiscCenterLocalXCoordinate - sqrtf(practicalDiskRadius * practicalDiskRadius - startToDiscCenterLocalYCoordinate * startToDiscCenterLocalYCoordinate);
	float distanceToSupposedContactPoint2 = startToDiscCenterLocalXCoordinate + sqrtf(practicalDiskRadius * practicalDiskRadius - startToDiscCenterLocalYCoordinate * startToDiscCenterLocalYCoordinate);
	if (!FloatRange{ distanceToSupposedContactPoint1, distanceToSupposedContactPoint2 }.IsOverlappingWithRange(FloatRange{ 0.0f, maxDist })) {
		return myResult;
	}
	//Fetch result case 1
	if (distanceToSupposedContactPoint1 * distanceToSupposedContactPoint2 < 0) {
		myResult.m_didImpact = true;
		myResult.m_impactPos = startPos;
		myResult.m_impactNormal = (startPos - discCenter).GetNormalized();
		myResult.m_impactDist = 0.f;
		return myResult;
	}
	//Fetch result case 2
	Vec2 contactPoint = startPos + distanceToSupposedContactPoint1 * fwdNormal;
	myResult.m_didImpact = true;
	myResult.m_impactDist = distanceToSupposedContactPoint1;
	myResult.m_impactPos = contactPoint;
	myResult.m_impactNormal = (contactPoint - discCenter).GetNormalized();
	return myResult;
	
}

RaycastResult3D RaycastVsCylinderZ(Vec3 startPos, Vec3 fwdNormal, float maxDist, Vec3 discCenter, float discRadius, float cylinderHeight, bool collideIfInside) {
	RaycastResult3D finalResult;
	if (!collideIfInside) {
		if (startPos.z < discCenter.z + cylinderHeight * 0.5f && startPos.z > discCenter.z - cylinderHeight * 0.5f && GetDistanceSquared2D(startPos, discCenter) < discRadius * discRadius) {
			return finalResult;
		}
	}	
	RaycastResult3D resultCylinderTop = RaycastVsDiscXY3D(startPos, fwdNormal, maxDist, discCenter + Vec3(0.f, 0.f, cylinderHeight * 0.5f), discRadius);
	RaycastResult3D resultCylinderBottom = RaycastVsDiscXY3D(startPos, fwdNormal, maxDist, discCenter - Vec3(0.f, 0.f, cylinderHeight * 0.5f), discRadius);
	RaycastResult3D resultCylinderSide;
	//If ray is not horizontal
	if (Vec2(fwdNormal).GetLengthSquared() != 0.f) {
		RaycastResult2D resultCylinder2DPlane = RaycastVsDisc2D(startPos, Vec2(fwdNormal).GetNormalized(), maxDist, discCenter, discRadius);
		//If can hit in xy plane
		if (resultCylinder2DPlane.m_didImpact) {
			float expected3DSideHitDistance = resultCylinder2DPlane.m_impactDist / Vec2(fwdNormal).GetLength();
			Vec3 expected3DSideHitPosition = startPos + expected3DSideHitDistance * fwdNormal;
			//if hit z is correct and distance isn't too far
			if (expected3DSideHitPosition.z < discCenter.z + cylinderHeight * 0.5f && expected3DSideHitPosition.z > discCenter.z - cylinderHeight * 0.5f && expected3DSideHitDistance <= maxDist) {
				resultCylinderSide.m_didImpact = true;
				resultCylinderSide.m_impactDist = expected3DSideHitDistance;
				resultCylinderSide.m_impactPos = expected3DSideHitPosition;
				resultCylinderSide.m_impactNormal = resultCylinder2DPlane.m_impactNormal;
			}
		}
	}
	finalResult = resultCylinderTop;
	if (RaycastResultIsCloser(resultCylinderBottom, finalResult)) {
		finalResult = resultCylinderBottom;
	}
	if (RaycastResultIsCloser(resultCylinderSide, finalResult)) {
		finalResult = resultCylinderSide;
	}
	return finalResult;
}



bool RaycastResultIsCloser(RaycastResult resultA, RaycastResult resultB) {
	if (resultA.m_didImpact && !resultB.m_didImpact) {
		return true;
	}
	if (resultA.m_didImpact && resultB.m_didImpact && resultA.m_impactDist < resultB.m_impactDist) {
		return true;
	}
	return false;
}

