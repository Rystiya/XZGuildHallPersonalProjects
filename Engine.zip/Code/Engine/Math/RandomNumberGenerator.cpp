#include "Engine\Math\RandomNumberGenerator.hpp"
#include "ThirdParty\Squirrel\RawNoise.hpp"
#include <stdlib.h>
#include <assert.h> 


//-----------------------------------------------------------------------------------------------
RandomNumberGenerator::RandomNumberGenerator(unsigned int seed) {
	m_seed = seed;
}

unsigned int RandomNumberGenerator::GetUnsignedIntNoise() {
	unsigned int result = Get1dNoiseUint(m_position, m_seed);
	m_position++;
	return result;
}

int RandomNumberGenerator::RollRandomIntLessThan(int maxNotInclusive) {
	return GetUnsignedIntNoise() % maxNotInclusive;
}

int RandomNumberGenerator::RollRandomIntInRange(int minInlcusive, int maxInclusive) {
	return minInlcusive + (GetUnsignedIntNoise() % (maxInclusive- minInlcusive+1));
}

float RandomNumberGenerator::RollRandomFloatZeroToOne() {
	return static_cast<float>(GetUnsignedIntNoise()) / static_cast<float>((UINT_MAX));
}

float RandomNumberGenerator::RollRandomFloatInRange(int minInlcusive, int maxInclusive) {
	return static_cast<float>(minInlcusive) + RollRandomFloatZeroToOne()*(maxInclusive- minInlcusive);
}
float RandomNumberGenerator::RollRandomFloatInRange(float minInlcusive, float maxInclusive) {
	return static_cast<float>(minInlcusive) + RollRandomFloatZeroToOne() * (maxInclusive - minInlcusive);
}

int RandomNumberGenerator::ChooseItemFromWeightedList(std::vector<float> const& weights) {
	float totalWeight = 0.f;
	for (int index = 0; index < weights.size(); index++) {
		totalWeight += weights[index];
	}
	float randomValue = RollRandomFloatInRange(0.f, totalWeight);
	float accumulatedWeight = 0.f;
	for (int index = 0; index < weights.size(); index++) {
		accumulatedWeight += weights[index];
		if (randomValue <= accumulatedWeight) {
			return index;
		}
	}
	assert(false);
	return 0;

}

int RandomNumberGenerator::RollRandomIntOneOrNegativeOne() {
	if (RollRandomFloatZeroToOne() > 0.5) {
		return 1;
	}
	return -1;
}
