#include "Engine\Math\Mat44.hpp"
#include "Engine\Math\EulerAngles.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>


EulerAngles::EulerAngles(Vec3 yawPitchRoll)
	: m_yawDegrees(yawPitchRoll.x)
	, m_pitchDegrees(yawPitchRoll.y)
	, m_rollDegrees(yawPitchRoll.z)
{
}

EulerAngles::EulerAngles(float yawDegrees, float pitchDegrees, float rollDegrees)
	: m_yawDegrees(yawDegrees)
	, m_pitchDegrees(pitchDegrees)
	, m_rollDegrees(rollDegrees)
{
}

Mat44 EulerAngles::GetAsMatrix_XFwd_YLeft_ZUp() const {
	Mat44 result = Mat44::CreateZRotationDegrees(m_yawDegrees);
	result.Append(Mat44::CreateYRotationDegrees(m_pitchDegrees));
	result.Append(Mat44::CreateXRotationDegrees(m_rollDegrees));
	return result;
}

void EulerAngles::GetAsVectors_XFwd_YLeft_ZUp(Vec3& out_forwardIBasis, Vec3& out_leftJBasis, Vec3& out_upKBasis) const {
	Mat44 resultMat = GetAsMatrix_XFwd_YLeft_ZUp();
	out_forwardIBasis = resultMat.GetIBasis3D();
	out_leftJBasis = resultMat.GetJBasis3D();
	out_upKBasis = resultMat.GetKBasis3D();
}


const EulerAngles EulerAngles::operator+(const EulerAngles& angleToAdd) const {
	return EulerAngles(AddAngle(m_yawDegrees, angleToAdd.m_yawDegrees), AddAngle(m_pitchDegrees, angleToAdd.m_pitchDegrees), AddAngle(m_rollDegrees, angleToAdd.m_rollDegrees));
}
const EulerAngles EulerAngles::operator-(const EulerAngles& angleToSubtract) const {
	return EulerAngles(AddAngle(m_yawDegrees, angleToSubtract.m_yawDegrees), AddAngle(m_pitchDegrees, angleToSubtract.m_pitchDegrees), AddAngle(m_rollDegrees, angleToSubtract.m_rollDegrees));
}


const EulerAngles EulerAngles::operator*(float uniformScale) const {
	return EulerAngles(m_yawDegrees * uniformScale, m_pitchDegrees * uniformScale, m_rollDegrees * uniformScale);
}
const EulerAngles EulerAngles::operator/(float inverseScale) const {
	float uniformScale = 1 / inverseScale;
	return EulerAngles(m_yawDegrees * uniformScale, m_pitchDegrees * uniformScale, m_rollDegrees * uniformScale);
}

void EulerAngles::Clamp(float maxValue) {
	m_yawDegrees = GetClamped(m_yawDegrees, -1.f * maxValue, maxValue);
	m_pitchDegrees = GetClamped(m_pitchDegrees, -1.f * maxValue, maxValue);
	m_rollDegrees = GetClamped(m_rollDegrees, -1.f * maxValue, maxValue);
}