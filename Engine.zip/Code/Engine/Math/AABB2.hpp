#pragma once
#include "Engine\Math\Vec2.hpp"

struct AABB3;

struct AABB2
{
	Vec2 m_mins = Vec2(0, 0);
	Vec2 m_maxs = Vec2(0, 0);

	~AABB2() {}
	AABB2() {}
	AABB2(AABB2 const& copyFrom);
	AABB2(AABB3 const& copyFrom);
	explicit AABB2(float minX, float minY, float maxX, float maxY);
	explicit AABB2(Vec2 const& mins, Vec2 const& maxs);
	AABB2(char const* text);

	//Accessors
	bool IsPointInside(Vec2 const& point) const;
	Vec2 const GetCenter() const;
	Vec2 const GetDimensions() const;
	float const GetAspect() const;
	Vec2 const GetNearestPoint(Vec2 const& referencePosition) const;
	Vec2 const GetPointAtUV(Vec2 const& uv) const;   //(0,0) represent mins, (1,1) represent maxs
	Vec2 const GetUVForPoint(Vec2 const& point) const; //Same as above, but the opposite
	bool IsPointOutOfAABB2Fast(Vec2 position, float leaveMargin) const;
	bool IsValid() const { return m_maxs.x > m_mins.x && m_maxs.y > m_mins.y; }

	//Mutators
	void Translate(Vec2 const& translationToApply);
	void SetCenter(Vec2 const& newCenter);
	void SetDimensions(Vec2 const& newDimensions);
	void StretchToIncludePoint(Vec2 const& point);
	AABB2 GetScaledBy(float scale) const;
	void SetFromText(char const* text);


};