
#include "Engine\Math\IntRange.hpp"
#include "Engine\Core\StringUtils.hpp"

const IntRange IntRange::ZERO = IntRange(0, 0);
const IntRange IntRange::ONE = IntRange(1, 1);
const IntRange IntRange::ZERO_TO_ONE = IntRange(0, 1);


IntRange::IntRange(IntRange const& copyFrom)
	: m_min(copyFrom.m_min)
	, m_max(copyFrom.m_max)
{
}
IntRange::IntRange(int min, int max)
	: m_min(min)
	, m_max(max)
{
}
IntRange::IntRange(char const* text) {
	SetFromText(text);
}



//Operators
void IntRange::operator=(const IntRange& setTo) {
	m_min = setTo.m_min;
	m_max = setTo.m_max;
}
bool IntRange::operator==(const IntRange& comparedAgainst) {
	return m_min == comparedAgainst.m_min && m_max == comparedAgainst.m_max;
}
bool IntRange::operator!=(const IntRange& comparedAgainst) {
	return m_min != comparedAgainst.m_min || m_max != comparedAgainst.m_max;
}
bool IntRange::IsOnRange(float value) {
	return m_min <= value && m_max >= value;
}
bool IntRange::IsOverlappingWithRange(IntRange anotherRange) {
	return m_min <= anotherRange.m_max && m_max >= anotherRange.m_min;
}


void IntRange::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	m_min = atoi(seperateedStrings[0].c_str());
	m_max = atoi(seperateedStrings[1].c_str());
}