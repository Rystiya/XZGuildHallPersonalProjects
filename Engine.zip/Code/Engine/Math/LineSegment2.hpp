#pragma once
#include "Engine\Math\Vec2.hpp"


//-----------------------------------------------------------------------------------------------
struct LineSegment2
{
public:
	Vec2 m_start = Vec2(0.f, 0.f);
	Vec2 m_end = Vec2(1.f, 1.f);
	bool m_isInfniteEnd = false;
	bool m_isInfniteStart = false;

public:
	// Construction/Destruction
	~LineSegment2() {}												// destructor (do nothing)
	explicit LineSegment2(Vec2 startVec = Vec2(), Vec2 endVec = Vec2(), bool isInfniteFront = false, bool isInfniteBack = false);


	float GetLength() const;
	Vec2 GetDirection() const;
	Vec2 GetCenter() const;
	float GetDistance(Vec2 referencePosition) const;
	Vec2 const GetNearestPoint(Vec2 const& referencePosition) const;
	void Translate(Vec2 translation);
	void SetCenter(Vec2 newCenter);
	void RotateAboutCenter(float rotationDeltaDegrees);

};


