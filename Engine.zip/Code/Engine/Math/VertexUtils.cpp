
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\AABB2.hpp"
#include "Engine\Math\OBB2.hpp"
#include <math.h>


void AddVertsForRing(std::vector<Vertex_PCU>& vertexes, Vec2 const& center, float radius, int edgeCount, float width, Rgba8 const& color) {
	float degreeEachPie = 360.f / edgeCount;
	for (int pieIndex = 0; pieIndex < edgeCount; pieIndex++) {
		Vec2 corner1 = center + Vec2::MakeFromPolarDegrees(degreeEachPie * float(pieIndex), radius);
		Vec2 corner2 = center + Vec2::MakeFromPolarDegrees(degreeEachPie * float(pieIndex + 1), radius);
		AddVertsForLine(vertexes, corner1, corner2, width, color);
	}
}


void AddVertsForAABB2(std::vector<Vertex_PCU>& vertexes, AABB2 const& bounds, Rgba8 const& color) {
	vertexes.push_back(Vertex_PCU(Vec2(bounds.m_mins.x, bounds.m_mins.y), color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(Vec2(bounds.m_maxs.x, bounds.m_mins.y), color, Vec2(1.f, 0.f)));
	vertexes.push_back(Vertex_PCU(Vec2(bounds.m_mins.x, bounds.m_maxs.y), color, Vec2(0.f, 1.f)));
	vertexes.push_back(Vertex_PCU(Vec2(bounds.m_maxs.x, bounds.m_mins.y), color, Vec2(1.f, 0.f)));
	vertexes.push_back(Vertex_PCU(Vec2(bounds.m_maxs.x, bounds.m_maxs.y), color, Vec2(1.f, 1.f)));
	vertexes.push_back(Vertex_PCU(Vec2(bounds.m_mins.x, bounds.m_maxs.y), color, Vec2(0.f, 1.f)));
}

void AddVertsForOBB2(std::vector<Vertex_PCU>& vertexes, Vec2 centerPosition, Vec2 forwardNormal, float halfLength, float halfWidth, Rgba8 const& color) {
	Vec2 verticalNormal = forwardNormal.GetRotated90Degrees();
	vertexes.push_back(Vertex_PCU(centerPosition - halfLength * forwardNormal - halfWidth * verticalNormal, color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(centerPosition + halfLength * forwardNormal - halfWidth * verticalNormal, color, Vec2(1.f, 0.f)));
	vertexes.push_back(Vertex_PCU(centerPosition - halfLength * forwardNormal + halfWidth * verticalNormal, color, Vec2(0.f, 1.f)));
	vertexes.push_back(Vertex_PCU(centerPosition + halfLength * forwardNormal - halfWidth * verticalNormal, color, Vec2(1.f, 0.f)));
	vertexes.push_back(Vertex_PCU(centerPosition + halfLength * forwardNormal + halfWidth * verticalNormal, color, Vec2(1.f, 1.f)));
	vertexes.push_back(Vertex_PCU(centerPosition - halfLength * forwardNormal + halfWidth * verticalNormal, color, Vec2(0.f, 1.f)));
}

void AddVertsForLine(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, Vec2 const& endLocation, float width, Rgba8 const& color) {
	Vec2 rectangleForwardEdgeVec = endLocation - startLocation;
	Vec2 rectangleDiagonalEdgeVec = rectangleForwardEdgeVec.GetNormalized().GetRotated90Degrees() * width;
	Vec2 rectangleCorner1 = startLocation - rectangleDiagonalEdgeVec * 0.5f;
	Vec2 rectangleCorner2 = startLocation + rectangleDiagonalEdgeVec * 0.5f;
	Vec2 rectangleCorner3 = rectangleCorner1 + rectangleForwardEdgeVec;
	Vec2 rectangleCorner4 = rectangleCorner2 + rectangleForwardEdgeVec;
	vertexes.push_back(Vertex_PCU(rectangleCorner1, color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(rectangleCorner2, color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(rectangleCorner3, color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(rectangleCorner4, color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(rectangleCorner3, color, Vec2(0.f, 0.f)));
	vertexes.push_back(Vertex_PCU(rectangleCorner2, color, Vec2(0.f, 0.f)));
}

void DrawDisk(Vec2 const& startLocation, float radius, int edgeCount, Rgba8 const& color, Rgba8 const& edgeColor) {
	std::vector<Vertex_PCU> vertexes;
	AddVertsForDisk(vertexes, startLocation, radius, edgeCount, color, edgeColor);
	DrawVertexVector(vertexes);
}

void AddVertsForDisk(std::vector<Vertex_PCU>& vertexes, Vec2 const& startLocation, float radius, int edgeCount, Rgba8 const& color, Rgba8 const& edgeColor) {
	for (int index = 0; index < edgeCount; index++) {
		float angle1 = float(index) * 360.f / float(edgeCount);
		float angle2 = float(index + 1) * 360.f / float(edgeCount);
		vertexes.push_back(Vertex_PCU(Vec3(startLocation) + Vec3(CosDegrees(angle1), SinDegrees(angle1), 0.f) * radius, edgeColor));
		vertexes.push_back(Vertex_PCU(Vec3(startLocation) + Vec3(CosDegrees(angle2), SinDegrees(angle2), 0.f) * radius, edgeColor));
		vertexes.push_back(Vertex_PCU(Vec3(startLocation), color));
	}
}