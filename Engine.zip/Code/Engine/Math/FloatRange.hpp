#pragma once



struct FloatRange
{
public:
	float m_min = 0;
	float m_max = 0;

	~FloatRange() {}
	FloatRange() {}
	FloatRange(float min, float max);
	FloatRange(FloatRange const& copyFrom);
	FloatRange(char const* text);

	//Operators
	void operator=(const FloatRange& setTo);
	bool operator==(const FloatRange& comparedAgainst);
	bool operator!=(const FloatRange& comparedAgainst);
	bool IsOnRange(float value);
	bool IsOverlappingWithRange(FloatRange anotherRange);

	static const FloatRange ZERO;
	static const FloatRange ONE;
	static const FloatRange ZERO_TO_ONE;

	void SetFromText(char const* text);
};