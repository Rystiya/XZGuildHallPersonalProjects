#include "Engine\Math\Vec2.hpp"
#include "Engine\Math\Vec3.hpp"
#include "Engine\Math\IntVec2.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\StringUtils.hpp"
#include <math.h>


//Basic stuff---------------------------------------------------------
Vec2::Vec2( const Vec2& copy )
	: x(copy.x)
	, y(copy.y)
{
}

Vec2::Vec2(const Vec3& copy)
	: x(copy.x)
	, y(copy.y)
{
}
Vec2::Vec2(const IntVec2& copy)
	: x((float)copy.x)
	, y((float)copy.y)
{
}
Vec2::Vec2()
	: x(0)
	, y(0)
{
}
Vec2::Vec2( float initialX, float initialY )
	: x(initialX)
	, y(initialY)
{
}
Vec2::Vec2(char const* text) {
	SetFromText(text);
}

const Vec2 Vec2::operator + ( const Vec2& vecToAdd ) const
{
	return Vec2(x + vecToAdd.x, y + vecToAdd.y);
}
const Vec2 Vec2::operator-( const Vec2& vecToSubtract ) const
{
	return Vec2(x - vecToSubtract.x, y - vecToSubtract.y);
}
const Vec2 Vec2::operator-() const
{
	return Vec2( -x, -y );
}
const Vec2 Vec2::operator*( float uniformScale ) const
{
	return Vec2( x* uniformScale, y* uniformScale);
}
const Vec2 Vec2::operator*( const Vec2& vecToMultiply ) const
{
	return Vec2(x * vecToMultiply.x, y * vecToMultiply.y);
}
const Vec2 Vec2::operator/( float inverseScale ) const
{	
	float uniformScale = 1 / inverseScale;
	return Vec2( x * uniformScale, y * uniformScale);
}
void Vec2::operator+=( const Vec2& vecToAdd )
{
	x += vecToAdd.x;
	y += vecToAdd.y;
}
void Vec2::operator-=( const Vec2& vecToSubtract )
{
	x -= vecToSubtract.x;
	y -= vecToSubtract.y;
}
void Vec2::operator*=( const float uniformScale )
{
	x *= uniformScale;
	y *= uniformScale;
}
void Vec2::operator/=( const float uniformDivisor )
{
	float uniformScale = 1 / uniformDivisor;
	x *= uniformScale;
	y *= uniformScale;
}
void Vec2::operator=( const Vec2& copyFrom )
{
	x = copyFrom.x;
	y = copyFrom.y;
}
const Vec2 operator*( float uniformScale, const Vec2& vecToScale )
{
	return Vec2(vecToScale.x * uniformScale, vecToScale.y * uniformScale);
}
bool Vec2::operator==( const Vec2& compare ) const
{
	return (x == compare.x && y == compare.y);
}
bool Vec2::operator!=( const Vec2& compare ) const
{
	return (x != compare.x || y != compare.y);
}


//Advanced stuff---------------------------------------------------

//Const at front doesn't mean anything....
Vec2 const Vec2::MakeFromPolarRadians(float orientationRadians, float length) {
	Vec2 outputVec2 = Vec2(length, 0);
	outputVec2.SetOrientationRadians(orientationRadians);
	return outputVec2;
}
Vec2 const Vec2::MakeFromPolarDegrees(float orientationDegrees, float length) {
	Vec2 outputVec2 = Vec2(length, 0);
	outputVec2.SetOrientationDegrees(orientationDegrees);
	return outputVec2;
}


//Accessors
//Const at the end means these functions don't change any member variables
float Vec2::GetLength() const {
	return sqrtf(x*x + y*y);
}
float Vec2::GetLengthSquared() const {
	return GetDistanceSquared2D(Vec2(0, 0), *this);
}
float Vec2::GetOrientationRadians() const {
	return Atan2Radians(y, x);
}
float Vec2::GetOrientationDegrees() const {
	return Atan2Degrees(y, x);
}
Vec2 const Vec2::GetRotated90Degrees() const {
	Vec2 outputVec2 = *this;
	outputVec2.Rotate90Degrees();
	return outputVec2;
}
Vec2 const Vec2::GetRotatedMinus90Degrees() const {
	Vec2 outputVec2 = *this;
	outputVec2.RotateMinus90Degrees();
	return outputVec2;
}
Vec2 const Vec2::GetRotatedRadians(float deltaRadians) const {
	Vec2 outputVec2 = *this;
	outputVec2.RotateRadians(deltaRadians);
	return outputVec2;
}
Vec2 const Vec2::GetRotatedDegrees(float deltaDegrees) const {
	Vec2 outputVec2 = *this;
	outputVec2.RotateDegrees(deltaDegrees);
	return outputVec2;
}
Vec2 const Vec2::GetClamped(float maxLength) const {
	Vec2 outputVec2 = *this;
	outputVec2.ClampLength(maxLength);
	return outputVec2;
}
Vec2 const Vec2::GetNormalized() const {
	Vec2 outputVec2 = *this;
	outputVec2.Normalize();
	return outputVec2;
}
Vec2 const Vec2::GetReflected(Vec2 const& hitSurfaceDirection) const {
	Vec2 hitVelocity = hitSurfaceDirection * DotProduct2D(Vec2(x, y), hitSurfaceDirection);
	return(Vec2(x, y) - 2 * hitVelocity);
}

//Mutators
void Vec2::SetOrientationRadians(float newOrientationRadians) {
	SetPolarRadians(newOrientationRadians, GetLength());
}
void Vec2::SetOrientationDegrees(float newOrientationDegrees) {
	SetPolarDegrees(newOrientationDegrees, GetLength());
}
void Vec2::SetPolarRadians(float newOrientationRadians, float newLength) {
	x = newLength * CosRadians(newOrientationRadians);
	y = newLength * SinRadians(newOrientationRadians);
}
void Vec2::SetPolarDegrees(float newOrientationDegrees, float newLength) {
	x = newLength * CosDegrees(newOrientationDegrees);
	y = newLength * SinDegrees(newOrientationDegrees);
}
void Vec2::Rotate90Degrees() {
	float temp = x;
	x = -y;
	y = temp;
}
void Vec2::RotateMinus90Degrees() {
	float temp = x;
	x = y;
	y = -1*temp;
}
void Vec2::RotateRadians(float deltaRadians) {
	RotateDegrees(ConvertRadiansToDegrees(deltaRadians));
}
void Vec2::RotateDegrees(float deltaDegrees) {
	TransformPosition2D(*this, 1, deltaDegrees, Vec2(0,0));
}
void Vec2::SetLength(float newLength) {
	if (newLength == 0) {
		x = 0;
		y = 0;
	}
	else {
		float myLength = GetLength();
		x = x * newLength / myLength;
		y = y * newLength / myLength;
	}
}
void Vec2::ClampLength(float maxLength) {
	float myLength = GetLength();
	if (myLength > maxLength) {
		SetLength(maxLength);
	}
}
void Vec2::Normalize() {
	NormalizeAndGetPreviousLength();
}
float Vec2::NormalizeAndGetPreviousLength() {
	float length = GetLength();
	if (length != 0.f) {
		x = x / length;
		y = y / length;
	}
	return length;
}
void Vec2::Reflect(Vec2 const& hitSurfaceDirection) {
	Vec2 result = GetReflected(hitSurfaceDirection);
	x = result.x;
	y = result.y;
}

void Vec2::SetFromText(char const* text) {
	Strings seperateedStrings = SplitStringOnDelimiter(text, ',', true);
	x = (float)atof(seperateedStrings[0].c_str());
	y = (float)atof(seperateedStrings[1].c_str());
}

