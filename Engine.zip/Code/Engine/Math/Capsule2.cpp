#include "Engine\Math\Capsule2.hpp"
#include "Engine\Math\MathUtils.hpp"
#include <math.h>


//Basic stuff---------------------------------------------------------
Capsule2::Capsule2(float radius, Vec2 startVec, Vec2 endVec, bool isInfniteFront, bool isInfniteBack)
	: m_radius(radius)
{
	m_myBone = LineSegment2(startVec, endVec, isInfniteFront, isInfniteBack);
}


bool Capsule2::IsPointInside(Vec2 referencePosition) const {
	Vec2 nearestPointOnBone = m_myBone.GetNearestPoint(referencePosition);
	return GetDistance2D(referencePosition, nearestPointOnBone) <= m_radius;
}


Vec2 const Capsule2::GetNearestPoint(Vec2 const& referencePosition) const {
	Vec2 nearestPointOnBone = m_myBone.GetNearestPoint(referencePosition);
	Vec2 nearestPointOnBoneToReference = referencePosition - nearestPointOnBone;
	return nearestPointOnBone + nearestPointOnBoneToReference.GetClamped(m_radius);

}


void Capsule2::Translate(Vec2 translation) {
	m_myBone.Translate(translation);
}
void Capsule2::SetCenter(Vec2 newCenter) {
	m_myBone.SetCenter(newCenter);
}
void Capsule2::RotateAboutCenter(float rotationDeltaDegrees) {
	m_myBone.RotateAboutCenter(rotationDeltaDegrees);
}