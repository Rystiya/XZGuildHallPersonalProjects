#pragma once
#include "Engine\Math\Vec3.hpp"

struct AABB2;

struct AABB3
{
	Vec3 m_mins = Vec3(0, 0, 0);
	Vec3 m_maxs = Vec3(0, 0, 0);

	~AABB3() {}
	AABB3() {}
	AABB3(AABB3 const& copyFrom);
	AABB3(AABB2 const& copyFrom);
	explicit AABB3(float minX, float minY, float minZ, float maxX, float maxY, float maxZ);
	explicit AABB3(Vec3 const& mins, Vec3 const& maxs);



};