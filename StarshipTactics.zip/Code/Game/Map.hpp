#pragma once
#include "Game\GameCommon.hpp"
#include "Game\Entity.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Math\RaycastUtils.hpp"
#include <vector>

class Game;

struct RaycastResultWithEntity
{
	RaycastResult2D	m_contactInfo;
	Entity* m_entityHit = nullptr;
};

struct EntitySearchFilter
{
	bool positiveCostOnly = false;
	bool canCollideOnly = false;
	bool noneInvincibleOnly = false;
	bool noneBulletOnly = false;
	bool seletableOnly = false;
	bool builderOnly = false;
	bool asteroidOnly = false;
	std::vector<Faction> excludeFactions = {};
	std::vector<Faction> onlyIncludeFactions = {};
	bool returnOnlyOneResult = false;
};

std::vector<Faction> EnemiesOf(Faction myFaction);
std::vector<Faction> ValidTargetsOf(Faction myFaction);
std::vector<Faction> FriendliesOf(Faction myFaction);
int GetFactionID(Faction ofFaction);
Faction GetFactionEnum(int ID);
Rgba8 GetFactionStandardColor(Faction ofFaction);

//-----------------------------------------------------------------------------------------------
class Map
{
	friend class Game;

public: // position, color, etc
	// Construction/Destruction
	Map(Game* parentGame, MapMode gameMode = MapMode::arena, int settingID = 0);
	~Map();
	Game* m_game;
	Shader* m_mapShader = nullptr;
	//Important stuff
	void UpdateStart(float deltaSeconds);
	void Update(float deltaSeconds);
	void UpdateEnd(float deltaSeconds);
	void Render() const;

	void TryCollideTwoEntitiesWithEachOther(Entity* thisThing, Entity* otherThing);
	void TryCollideWithAllEntities(Entity* thing);

	 //Deal with entity vectors
	 //Render
	void TryRenderAllEntities(WorldRenderingPass renderingPass) const;
	 void TryRenderEntityVector(std::vector<Entity*> const& entitiesToRender, WorldRenderingPass renderingPass) const;
	 void TryLetAllGameplayEntitiesAddUIVerts(std::vector<Vertex_PCU>& verts, UIRenderingPass renderingPass) const;
	 //Update
	 void TryUpdateEntityVector(std::vector<Entity*> const& entitiesToRender, float deltaSeconds, bool physicsUpdate = false);
	 void GenerateResources(std::vector<Entity*> const& entitiesToRender);
	 //Delete
	 void TryDeleteEntityVector(std::vector<Entity*>& entities, bool onlyGarbage = false);
	 //Gameplay stuff
	 int CountGameplayEntities() const;
	 int CountCosmeticEntities() const;
	 std::vector<Entity*> const& GetAllEntities() const { return m_gameplayEntities; }
	 std::vector<Entity*> FindEntities(Vec2 searchCenter = Vec2(), float withinRange = 50.f, EntitySearchFilter const& filter = EntitySearchFilter()) const;
	 RaycastResultWithEntity RaycastVSEntities(Vec2 rayStart, Vec2 rayNorm, float maxDistance = 50.f, float rayWidth = 0.1f, EntitySearchFilter const& filter = EntitySearchFilter()) const;
	 bool DoAreaDamage(Vec2 center, float areaRadius, float damageAmount, std::vector<Faction> excludeFactions = {}, std::vector<Faction> onlyIncludeFactions = {}, bool noImpulse = false);
	 void SelectAllEntitiesOfType(std::string entityType, bool onlyOnScreen = false, std::vector<Faction> onlyIncludeFactions = {}, std::vector<Faction> excludeFactions = {});
	 void ShareWaypointWithNearbyAllies(Entity* sharer, float radius = 100.f, bool overide = false);
	 Entity* SpawnEntity(std::string entityType, Faction faction = Faction::neutral, Vec2 position = Vec2(), float orientationDegrees = 0.f, Vec2 startingVelocity = Vec2());
	 Entity* SpawnEntity(EntityDefinition const* def, Faction faction = Faction::neutral, Vec2 position = Vec2(), float orientationDegrees = 0.f, Vec2 startingVelocity = Vec2());
	 std::vector<std::string> const& GetSelectedEntitiesCanBuildList() { return m_selectedEntitiesCanBuild; }
	 float GetAiResourceModifier() const { return m_aiResourceModifier; }
	 //system and helper functions
	 uint64_t EntityReportBirth(Entity* bornEntity, bool isCosmeticEntity = false);
	 void SelectedEntityReportCanBuild(std::string anotherBuildOption);
	 Entity* GetEntityByUID(uint64_t UID);
	 int InsertEntityIntoVector(std::vector<Entity*>& entities, Entity* thing);
	 Vec2 ClampPositionIntoMap(Vec2 anyosition) const;
	 Vec2 GetMousePositionWorld() const;
	 Vec2 GetSelectionBoxStartScreen() const { return m_mouseDragStartScreen; }
	 Vec2 GetSelectionBoxEndScreen() const { return m_mouseDragEndScreen; }
	 Vec2 GetSelectionBoxStartWorld() const { return m_mouseDragStartWorld; }
	 Vec2 GetSelectionBoxEndWorld() const { return m_mouseDragEndWorld; }
	 bool IsSelectionAreaActive() const;
	 bool IsPositionInSelectionArea(Vec2 position, float entitySize) const;
	 float GetZoomLevel() const { return m_currentZoomLevel; }
	 AABB2 const& GetMapArea() const { return m_mapArea; }
	 AABB2 GetWorldCameraArea() const { return m_world_camera->GetOrthoBound(); }
	 AABB2 GetMinimapArea() const { return m_minimapArea; }
	 Vec2 RangeMapPositionToMinimap(Vec2 worldPosition, AABB2 minimapArea) const;
	 Vec2 RangeMapPositionFromMinimap(Vec2 minimapPosition, AABB2 minimapArea) const;
	 int GetCredits(Faction ofFaction) const;
	 void SetCredits(Faction ofFaction, int amount);
	 void AddCredits(Faction ofFaction, int amount);
	 int GetRecoredPlayerIncome() const { return m_recoredPlayerIncome; }
	//Audio
	 bool PlaySoundAt(SoundID soundID, float volume, Vec2 position) const;

private:
	//Win lose condition
	const MapMode m_mode;
	float m_timeSinceWinOrLose = 0.f;
	float m_timeOfLastWinOrLoseCheck = 0.f;
	MapState m_state = MapState::normal;
	void TryDealWithWinOrLoseState(float deltaSeconds);
	bool m_shouldTerminate = false;
	//Minimap
	AABB2 m_minimapArea = AABB2();
	//Entities
	int m_credits[NUMBER_OF_FACTIONS];
	std::vector<Entity*> m_gameplayEntities;
	std::vector<Entity*> m_cosmeticEntities;
	Camera* m_world_camera = nullptr;
	//Starfield and other cosmetic stuff
	Camera* m_starfield1_camera = nullptr;
	Camera* m_starfield2_camera = nullptr;
	Camera* m_starfield3_camera = nullptr;
	std::vector<Vertex_PCU> m_starfield1;
	std::vector<Vertex_PCU> m_starfield2;
	std::vector<Vertex_PCU> m_starfield3;
	void AddVertsForStarField(std::vector<Vertex_PCU>& vertexes, float starfieldCameraExtraSize) const;
	AABB2 CaluclateStarfieldArea(float starfieldCameraExtraSize) const;
	void AddVertsForMinimapBottom(std::vector<Vertex_PCU>& vertexes) const;
	void AddVertsForMinimapTop(std::vector<Vertex_PCU>& vertexes) const;
	//System stuff
	uint64_t m_totalEntityCreated = 0;
	float m_timeInGame = 0.f;
	float m_remainingPhysicsUpdateTimeToDo = 0.f;
	void DealWithPlayerControl(float deltaSeconds);
	int m_recoredPlayerIncome = 0;
	//Player control and camera stuff
	Vec2 GetCenterOfSelectedUnits() const;
	void ApplyZoomLevel(float zoomLevel);
	void ConstraintCameraPosition();
	Vec2 m_mouseDragStartScreen = Vec2();
	Vec2 m_mouseDragEndScreen = Vec2();
	Vec2 m_mouseDragStartWorld = Vec2();
	Vec2 m_mouseDragEndWorld = Vec2();
	bool m_mouseDragStartedInMinimapArea = false;
	bool m_mouseDragStartedInButtonArea = false;
	float m_currentZoomLevel = 1.f;
	bool m_showInGameUI = true;
	AABB2 m_mapArea = AABB2(0.f, 0.f, 1000.f, 1000.f);
	//Build option stuff
	std::vector<std::string> m_selectedEntitiesCanBuild;
	//Deal with entities
	void TryUpdateEntity(Entity* thing, float deltaSeconds, bool physicsUpdate = false);
	void InitializeAsArena(int sceneID);
	void InitializeAsSkirmish(int sceneID);
	//AI related stuff
	float m_aiResourceModifier = 1.f;

};	