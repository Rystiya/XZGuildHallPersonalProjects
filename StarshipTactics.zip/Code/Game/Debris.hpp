#pragma once
#include "Game\Entity.hpp"


//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class Debris : public Entity
{
public:
	// Construction/Destruction
	~Debris() {}
	Debris(Map* parentMap, float persistTime, float size, float parentSize, Vec2 parentPosition = Vec2(), Vec2 parentVelocity = Vec2(), Rgba8 color = Rgba8(255, 200, 150, 255));

	void UpdateCustomBehavior(float deltaSeconds) override;


protected:
	Rgba8 m_startingColor;
	Rgba8 m_endingColor;
	float m_rotationSpeed;
};