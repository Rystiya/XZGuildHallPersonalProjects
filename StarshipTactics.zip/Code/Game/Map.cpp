
#include "Game\Map.hpp"
#include "Game\Game.hpp"
#include "Game\Entity.hpp"
#include "Game\Asteroid.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Core\ErrorWarningAssert.hpp"
#include "Engine\Core\Image.hpp"
#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include <math.h> 
#include <cassert> 


//Classless functions-----------------------------------------------------------------------------------------------

std::vector<Faction>  EnemiesOf(Faction myFaction) {
	switch (myFaction) {
	case Faction::player: {
		return { Faction::enemy };
	}
	case Faction::enemy: {
		return { Faction::player };
	}
	case Faction::neutral: {
		return {};
	}
	}
	return {};
}
std::vector<Faction>  ValidTargetsOf(Faction myFaction) {
	switch (myFaction) {
	case Faction::player: {
		return { Faction::enemy, Faction::neutral };
	}
	case Faction::enemy: {
		return { Faction::player, Faction::neutral };
	}
	case Faction::neutral: {
		return { Faction::enemy, Faction::player };
	}
	}
	return {};
}
std::vector<Faction>  FriendliesOf(Faction myFaction) {
	switch (myFaction) {
	case Faction::player: {
		return { Faction::player };
	}
	case Faction::enemy: {
		return { Faction::enemy };
	}
	case Faction::neutral: {
		return { Faction::neutral };
	}
	}
	return {};
}

int GetFactionID(Faction ofFaction) {
	switch (ofFaction) {
	case Faction::player: {
		return 1;
	}
	case Faction::enemy: {
		return 2;
	}
	case Faction::neutral: {
		return 0;
	}
	default: {
		assert(false);
		return -1;
	}
	}
}


Faction GetFactionEnum(int ID) {
	switch (ID) {
	case 1: {
		return Faction::player;
	}
	case 2: {
		return Faction::enemy;
	}
	case 0: {
		return Faction::neutral;
	}
	default: {
		assert(false);
		return Faction::neutral;
	}
	}
}

Rgba8 GetFactionStandardColor(Faction ofFaction) {
	switch (ofFaction) {
	case Faction::player: {
		return Rgba8(90, 170, 255);
	}
	case Faction::enemy: {
		return Rgba8(255, 110, 110);
	}
	case Faction::neutral: {
		return Rgba8(150, 150, 150);
	}
	default: {
		assert(false);
		return Rgba8(150, 150, 150);
	}
	}
}

//The map class-----------------------------------------------------------------------------------------------

Map::Map(Game* parentGame, MapMode gameMode, int settingID)
	: m_mode(gameMode) {
	m_game = parentGame;
	m_world_camera = new Camera(GetMapArea().GetCenter(), GetMapArea().GetCenter());
	m_starfield1_camera = new Camera(GetMapArea().GetCenter(), GetMapArea().GetCenter());
	m_starfield2_camera = new Camera(GetMapArea().GetCenter(), GetMapArea().GetCenter());
	m_starfield3_camera = new Camera(GetMapArea().GetCenter(), GetMapArea().GetCenter());
	AddVertsForStarField(m_starfield1, STARFIELD1_CAMERA_EXTRA_SIZE_X);
	AddVertsForStarField(m_starfield2, STARFIELD2_CAMERA_EXTRA_SIZE_X);
	AddVertsForStarField(m_starfield3, STARFIELD3_CAMERA_EXTRA_SIZE_X);
	ApplyZoomLevel(m_currentZoomLevel);
	if (gameMode == MapMode::arena) {
		InitializeAsArena(settingID);
	}
	else {
		InitializeAsSkirmish(settingID);
	}
	//initialize minimap
	AABB2 screenArea = m_game->m_screen_camera->GetOrthoBound();
	float minimapWidth = MINIMAP_DEFAULT_SIZE_X;
	float minimapHeight = minimapWidth / m_mapArea.GetAspect();
	float minimapRescale = MINIMAP_DEFAULT_SIZE_X * 2.f / (minimapWidth + minimapHeight);
	minimapWidth *= minimapRescale;
	minimapHeight *= minimapRescale;
	m_minimapArea.m_maxs.x = screenArea.m_maxs.x;
	m_minimapArea.m_mins.x = m_minimapArea.m_maxs.x - minimapWidth;
	m_minimapArea.m_maxs.y = screenArea.m_maxs.y;
	m_minimapArea.m_mins.y = m_minimapArea.m_maxs.y - minimapHeight;
}


Map::~Map() {
	TryDeleteEntityVector(m_gameplayEntities, false); //Only erase garbage
	TryDeleteEntityVector(m_cosmeticEntities, false); //Only erase garbage
	delete m_world_camera;
}

void Map::UpdateStart(float deltaSeconds) {
	(void)deltaSeconds;
}


void Map::Update(float deltaSeconds) {
	m_timeInGame += deltaSeconds;
	DealWithPlayerControl(deltaSeconds);
	m_selectedEntitiesCanBuild.clear();
	TryUpdateEntityVector(m_gameplayEntities, deltaSeconds);
	TryUpdateEntityVector(m_cosmeticEntities, deltaSeconds);
	m_remainingPhysicsUpdateTimeToDo += deltaSeconds;
	while (m_remainingPhysicsUpdateTimeToDo >= PHYSICS_TIME_STEP) {
		TryUpdateEntityVector(m_gameplayEntities, PHYSICS_TIME_STEP, true);
		m_remainingPhysicsUpdateTimeToDo -= PHYSICS_TIME_STEP;
	}
	TryUpdateEntityVector(m_cosmeticEntities, deltaSeconds, true);
	TryDealWithWinOrLoseState(deltaSeconds);
	//Generate resources once a second. All resources generators add credits at the same time
	if (int(m_timeInGame) != int(m_timeInGame - deltaSeconds)) {
		int playerCreditsPrevious = GetCredits(Faction::player);
		GenerateResources(m_gameplayEntities);
		m_recoredPlayerIncome = GetCredits(Faction::player) - playerCreditsPrevious;
	}
}

void Map::TryDealWithWinOrLoseState(float deltaSeconds) {
	if (m_timeInGame - m_timeOfLastWinOrLoseCheck > WIN_OR_LOSE_CHECK_RATE) {
		m_timeOfLastWinOrLoseCheck = m_timeInGame;
		if (m_state == MapState::normal) {
			EntitySearchFilter playerVictoryCriticalUnitFilter;
			playerVictoryCriticalUnitFilter.seletableOnly = true;
			playerVictoryCriticalUnitFilter.builderOnly = (m_mode == MapMode::skirmish);
			playerVictoryCriticalUnitFilter.returnOnlyOneResult = true;
			playerVictoryCriticalUnitFilter.onlyIncludeFactions = { Faction::player };
			EntitySearchFilter hostileVictoryCriticalUnitFilter = playerVictoryCriticalUnitFilter;
			hostileVictoryCriticalUnitFilter.onlyIncludeFactions = EnemiesOf(Faction::player);
			if (FindEntities(Vec2(), -100.f, hostileVictoryCriticalUnitFilter).size() < 1) {
				m_state = MapState::won;
			}
			else if (FindEntities(Vec2(), -100.f, playerVictoryCriticalUnitFilter).size() < 1) {
				m_state = MapState::lost;
			}
		}
	}
	if (m_state == MapState::lost) {
		m_timeSinceWinOrLose += deltaSeconds;
	}
	if (m_state == MapState::won) {
		m_timeSinceWinOrLose += deltaSeconds;
	}
	if (m_timeSinceWinOrLose > TIME_TO_STAY_IN_MAP_AFTER_WIN_OR_LOSE) {
		m_shouldTerminate = true;
	}
}

void Map::UpdateEnd(float deltaSeconds) {
	(void)deltaSeconds;
	TryDeleteEntityVector(m_gameplayEntities, true); //Only erase garbage
	TryDeleteEntityVector(m_cosmeticEntities, true); //Only erase garbage
}



void Map::Render() const {
	//Initialize1
	g_theRenderer->UseDefaultShader();
	g_theRenderer->BindTexture(nullptr);
	g_theRenderer->m_desiredBlendMode = BlendMode::BLENDMODE_ALPHA;
	//Draw starfield
	g_theRenderer->BeginCamera(*m_starfield1_camera);
	g_theRenderer->DrawVertexVector(m_starfield1);
	g_theRenderer->EndCamera(*m_starfield1_camera);
	g_theRenderer->BeginCamera(*m_starfield2_camera);
	g_theRenderer->DrawVertexVector(m_starfield2);
	g_theRenderer->EndCamera(*m_starfield2_camera);
	g_theRenderer->BeginCamera(*m_starfield3_camera);
	g_theRenderer->DrawVertexVector(m_starfield3);
	g_theRenderer->EndCamera(*m_starfield3_camera);
	//Initialize2
	g_theRenderer->BeginCamera(*m_world_camera);
	//Draw the asteriods
	TryRenderAllEntities(WorldRenderingPass::background);
	//Draw selection circles
	std::vector<Vertex_PCU> UIVerts;
	TryLetAllGameplayEntitiesAddUIVerts(UIVerts, UIRenderingPass::selectionCircle);
	g_theRenderer->DrawVertexVector(UIVerts);
	//Draw entities
	TryRenderAllEntities(WorldRenderingPass::effectsBottom);
	TryRenderAllEntities(WorldRenderingPass::units);
	TryRenderAllEntities(WorldRenderingPass::projectiles);
	TryRenderAllEntities(WorldRenderingPass::effectsTop);
	g_theRenderer->SetModelConstants();
	//Draw waypoint lines
	UIVerts.clear();
	TryLetAllGameplayEntitiesAddUIVerts(UIVerts, UIRenderingPass::waypointLine);
	g_theRenderer->DrawVertexVector(UIVerts);
	if (m_showInGameUI) {
		//Draw info bars
		UIVerts.clear();
		TryLetAllGameplayEntitiesAddUIVerts(UIVerts, UIRenderingPass::infoBar);
		g_theRenderer->DrawVertexVector(UIVerts);
	}
	//Debug render
	DebugRenderWorld(*m_world_camera);
	//The debug system might set this to cull back.
	g_theRenderer->m_desiredRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_NONE;
	g_theRenderer->EndCamera(*m_world_camera);
	//Draw minimap
	g_theRenderer->BeginCamera(*m_game->m_screen_camera);
	if (m_showInGameUI) {
		UIVerts.clear();
		AddVertsForMinimapBottom(UIVerts);
		TryLetAllGameplayEntitiesAddUIVerts(UIVerts, UIRenderingPass::screenWidgetsBottom);
		TryLetAllGameplayEntitiesAddUIVerts(UIVerts, UIRenderingPass::screenWidgets);
		AddVertsForMinimapTop(UIVerts);
		g_theRenderer->BindTexture(nullptr);
		g_theRenderer->DrawVertexVector(UIVerts);
	}
	if (m_state == MapState::lost) {
		m_game->PutTextOnScreen(40.f, "You have been defeated!", Rgba8(), 0.8f, Vec2(0.5f, 0.5f));
	}
	if (m_state == MapState::won) {
		m_game->PutTextOnScreen(40.f, "You are victorious!", Rgba8(), 0.8f, Vec2(0.5f, 0.5f));
	}
	g_theRenderer->EndCamera(*m_game->m_screen_camera);
}



//Helper functions--------------------------------------------------------------------------------
void Map::TryCollideTwoEntitiesWithEachOther(Entity* thisThing, Entity* otherThing) {
	//negative physicsRadius means no collision
	if (otherThing == thisThing || otherThing == nullptr || otherThing->m_isDead || otherThing->GetDefinition()->physicsRadius <= 0.f) {
		return;
	}
	if (!thisThing->GetDefinition()->collideWithAllies || !otherThing->GetDefinition()->collideWithAllies) {
		if (thisThing->m_faction == otherThing->m_faction) {
			return;
		}
	}
	float maxCollisionDistance = thisThing->GetDefinition()->physicsRadius + otherThing->GetDefinition()->physicsRadius;
	if (maxCollisionDistance * maxCollisionDistance < GetDistanceSquared2D(thisThing->m_position, otherThing->m_position)) {
		return;
	}
	if ((thisThing->m_parentUID == otherThing->m_UID || thisThing->m_UID == otherThing->m_parentUID) && (thisThing->GetDefinition()->isProjectile || otherThing->GetDefinition()->isProjectile)) {
		return;
	}
	//set friction to zero to avoid getting stuck
	TryCollideBallsIntoEachOther2D(thisThing->m_position, otherThing->m_position, thisThing->m_velocity, otherThing->m_velocity, thisThing->GetDefinition()->physicsRadius, otherThing->GetDefinition()->physicsRadius, 0.6f, 0.6f, 0.f, 0.f, thisThing->GetDefinition()->mass, otherThing->GetDefinition()->mass);
	thisThing->HandleCollisionAgainst(otherThing);
	otherThing->HandleCollisionAgainst(thisThing);
}

void Map::TryCollideWithAllEntities(Entity* thing) {
	if (thing == nullptr || thing->m_isDead || thing->GetDefinition()->physicsRadius <= 0.f) {
		//Don't do collision if the entity is not alive or have no collision
		return;
	}
	if (thing->GetDefinition()->passiveCollisionCheck) {
		//other entities check collision against this entity, but this entity doesn't check collision against other entities
		return;
	}
	for (int entityIndex = 0; entityIndex < m_gameplayEntities.size(); entityIndex++) {
		TryCollideTwoEntitiesWithEachOther(thing, m_gameplayEntities[entityIndex]);
	}
}



uint64_t Map::EntityReportBirth(Entity* bornEntity, bool isCosmeticEntity) {
	uint64_t itemUID = UID_INVALID;
	m_totalEntityCreated += 1;
	if (isCosmeticEntity) {
		uint64_t index = InsertEntityIntoVector(m_cosmeticEntities, bornEntity);
		itemUID = -1 * (m_totalEntityCreated * UID_ID_OFFSET + index);
	}
	else {
		uint64_t index = InsertEntityIntoVector(m_gameplayEntities, bornEntity);
		itemUID = m_totalEntityCreated * UID_ID_OFFSET + index;
	}
	//Prevent overflow
	if (m_totalEntityCreated >= 0.99f * std::numeric_limits<uint64_t>::max() / UID_ID_OFFSET) {
		m_totalEntityCreated = 0;
	}
	return itemUID;
}

Entity* Map::GetEntityByUID(uint64_t UID) {
	if (UID != UID_INVALID) {
		if (UID > 0) {
			uint64_t indexExtracted = UID % UID_ID_OFFSET;
			if (indexExtracted < m_gameplayEntities.size() && m_gameplayEntities[indexExtracted] !=nullptr && m_gameplayEntities[indexExtracted]->GetUID() == UID) {
				return m_gameplayEntities[indexExtracted];
			}
		}
		if (UID < 0) {
			UID *= -1;
			uint64_t indexExtracted = UID % UID_ID_OFFSET;
			if (indexExtracted < m_cosmeticEntities.size() && m_cosmeticEntities[indexExtracted] != nullptr && m_cosmeticEntities[indexExtracted]->GetUID() == UID) {
				return m_cosmeticEntities[indexExtracted];
			}
		}
	}
	return nullptr;
}


Vec2 Map::RangeMapPositionToMinimap(Vec2 worldPosition, AABB2 minimapArea) const {
	float resultX = RangeMap(worldPosition.x, m_mapArea.m_mins.x, m_mapArea.m_maxs.x, minimapArea.m_mins.x, minimapArea.m_maxs.x);
	float resultY = RangeMap(worldPosition.y, m_mapArea.m_mins.y, m_mapArea.m_maxs.y, minimapArea.m_mins.y, minimapArea.m_maxs.y);
	return Vec2(resultX, resultY);
}

Vec2 Map::RangeMapPositionFromMinimap(Vec2 minimapPosition, AABB2 minimapArea) const {
	float resultX = RangeMap(minimapPosition.x, minimapArea.m_mins.x, minimapArea.m_maxs.x, m_mapArea.m_mins.x, m_mapArea.m_maxs.x);
	float resultY = RangeMap(minimapPosition.y, minimapArea.m_mins.y, minimapArea.m_maxs.y, m_mapArea.m_mins.y, m_mapArea.m_maxs.y);
	return Vec2(resultX, resultY);
}

int Map::GetCredits(Faction ofFaction) const {
	int factionID = GetFactionID(ofFaction);
	return m_credits[factionID];
}
void Map::SetCredits(Faction ofFaction, int amount) {
	int factionID = GetFactionID(ofFaction);
	m_credits[factionID] = amount;
}
void Map::AddCredits(Faction ofFaction, int amount) {
	int factionID = GetFactionID(ofFaction);
	m_credits[factionID] += amount;
}

Vec2 Map::ClampPositionIntoMap(Vec2 anyosition) const {
	return m_mapArea.GetNearestPoint(anyosition);
}


Vec2 Map::GetMousePositionWorld() const {
	return m_world_camera->GetOrthoBound().GetPointAtUV(g_theWindow->GetNormalizedCursorPos());
}

bool Map::IsSelectionAreaActive() const {
	return (g_theInputSystem->IsKeyDown(KEYCODE_LEFTMOUSE) || g_theInputSystem->WasKeyJustDoubleReleased(KEYCODE_LEFTMOUSE)) && !m_mouseDragStartedInMinimapArea && !m_mouseDragStartedInButtonArea && !g_theApp->GetIsPuased();
}
bool Map::IsPositionInSelectionArea(Vec2 position, float entitySize) const {
	if (!IsSelectionAreaActive()) {
		return false;
	}
	Vec2 boxStart = GetSelectionBoxStartWorld();
	Vec2 boxEnd = GetSelectionBoxEndWorld();
	float directSelectRadius = entitySize * 0.67f + 1.2f;
	if (GetDistanceSquared2D(boxStart, position) < directSelectRadius * directSelectRadius) {
		return true;
	}
	else if ((boxStart.x - position.x) * (boxEnd.x - position.x) < 0 && (boxStart.y - position.y) * (boxEnd.y - position.y) < 0) {
		//If I'm in the selection box
		return true;
	}
	return false;
}

bool Map::PlaySoundAt(SoundID soundID, float volume, Vec2 position) const {
	Camera const* theCamera = m_world_camera;
	float volumnModifierZoom = WORLD_CAMERA_SIZE_X / theCamera->GetSize().x;
	float volumnModifierDistance = GetDistanceSquared2D(theCamera->GetSize(), Vec2()) / (GetDistanceSquared2D(position, theCamera->GetOrthoCenter()) + 1.f);
	volumnModifierDistance = fminf(1.f, volumnModifierDistance);
	float volumnModifierCombined = volumnModifierZoom * volumnModifierDistance * volume;
	if (volumnModifierCombined < 0.01f) {
		return false;
	}
	float xPositionRatio = m_world_camera->GetNormalizedXPositionRelativeToCamera(position.x);
	g_theAudioSystem->StartSound(soundID, false, volumnModifierCombined, xPositionRatio);
	return true;
}

Vec2 Map::GetCenterOfSelectedUnits() const {
	Vec2 weightedTotalCenter = Vec2();
	float totalWeight = 0.f;
	for (int index = 0; index < m_gameplayEntities.size(); index++) {
		if (m_gameplayEntities[index] != nullptr && m_gameplayEntities[index]->m_isSelected) {
			float entityRadius = m_gameplayEntities[index]->GetDefinition()->cosmeticRadius;
			totalWeight += entityRadius;
			weightedTotalCenter += entityRadius * m_gameplayEntities[index]->m_position;
		}
	}
	if (totalWeight == 0.f) {
		return Vec2();
	}
	return weightedTotalCenter / totalWeight;
}


void  Map::ApplyZoomLevel(float zoomLevel) {
	if (zoomLevel * WORLD_CAMERA_SIZE_X / g_theWindow->GetClientAspect() > m_mapArea.GetDimensions().y) {
		zoomLevel = m_mapArea.GetDimensions().y / (WORLD_CAMERA_SIZE_X / g_theWindow->GetClientAspect());
	}
	m_world_camera->SetOrthoSize(Vec2(zoomLevel * WORLD_CAMERA_SIZE_X, zoomLevel * WORLD_CAMERA_SIZE_X / g_theWindow->GetClientAspect()));
	m_starfield1_camera->SetOrthoSize(Vec2(STARFIELD1_CAMERA_EXTRA_SIZE_X + zoomLevel * WORLD_CAMERA_SIZE_X, (STARFIELD1_CAMERA_EXTRA_SIZE_X + zoomLevel * WORLD_CAMERA_SIZE_X) / g_theWindow->GetClientAspect()));
	m_starfield2_camera->SetOrthoSize(Vec2(STARFIELD2_CAMERA_EXTRA_SIZE_X + zoomLevel * WORLD_CAMERA_SIZE_X, (STARFIELD2_CAMERA_EXTRA_SIZE_X + zoomLevel * WORLD_CAMERA_SIZE_X) / g_theWindow->GetClientAspect()));
	m_starfield3_camera->SetOrthoSize(Vec2(STARFIELD3_CAMERA_EXTRA_SIZE_X + zoomLevel * WORLD_CAMERA_SIZE_X, (STARFIELD3_CAMERA_EXTRA_SIZE_X + zoomLevel * WORLD_CAMERA_SIZE_X) / g_theWindow->GetClientAspect()));
}


void Map::ConstraintCameraPosition() {
	Vec2 cameraAreaSize = m_world_camera->GetOrthoSize();
	AABB2 worldCameraMoveLimit = AABB2(m_mapArea.m_mins + cameraAreaSize * 0.5f, m_mapArea.m_maxs - cameraAreaSize * 0.5f);
	m_world_camera->SetOrthoCenter(worldCameraMoveLimit.GetNearestPoint(m_world_camera->GetOrthoCenter())); //Limit camera to world
	m_starfield1_camera->SetOrthoCenter(m_world_camera->GetOrthoCenter());
	m_starfield2_camera->SetOrthoCenter(m_world_camera->GetOrthoCenter());
	m_starfield3_camera->SetOrthoCenter(m_world_camera->GetOrthoCenter());
}

//std::vector<std::string> m_selectedEntitiesCanBuild;
void Map::SelectedEntityReportCanBuild(std::string anotherBuildOption) {
	if (std::find(m_selectedEntitiesCanBuild.begin(), m_selectedEntitiesCanBuild.end(), anotherBuildOption) == m_selectedEntitiesCanBuild.end()) {
		m_selectedEntitiesCanBuild.emplace_back(anotherBuildOption);
	}
}

void  Map::TryUpdateEntity(Entity* thing, float deltaSeconds, bool physicsUpdate) {
	if (thing == nullptr || thing->m_isGarbage) {
		return;
	}
	if (!physicsUpdate) {
		thing->Update(deltaSeconds);
	} else {
		thing->PhysicsUpdate(deltaSeconds);
	}
}

void Map::InitializeAsArena(int sceneID) {
	m_mapArea = AABB2(0.f, 0.f, WORLD_SIZE_ARENA_X, WORLD_SIZE_ARENA_Y);
	Vec2 mapCenter = m_mapArea.GetCenter();
	m_world_camera->SetOrthoCenter(mapCenter + Vec2(-250.f, 0.f));
	if (sceneID == 0) {
		for (int column = 1; column <= 5; column++) {
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
		}
		for (int column = 1; column <= 8; column++) {
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 5.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 5.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 15.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 15.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 25.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 25.f), 180.f);
		}
	}
	if (sceneID == 1) {
		SpawnEntity("SiegeShip", Faction::player, Vec2(mapCenter.x - 260.f, mapCenter.y + 20.f), 0.f);
		SpawnEntity("SiegeShip", Faction::player, Vec2(mapCenter.x - 260.f, mapCenter.y), 0.f);
		SpawnEntity("SiegeShip", Faction::player, Vec2(mapCenter.x - 260.f, mapCenter.y - 20.f), 0.f);
		for (int column = 18; column <= 24; column++) {
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
		}
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 270.f, mapCenter.y + 10.f), 180.f);
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 270.f, mapCenter.y - 10.f), 180.f);
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 270.f, mapCenter.y + 30.f), 180.f);
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 270.f, mapCenter.y - 30.f), 180.f);
	}
	if (sceneID == 2) {
		for (int column = 25; column <= 27; column++) {
			SpawnEntity("LaserFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y), 0.f);
			SpawnEntity("LaserFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 15.f), 0.f);
			SpawnEntity("LaserFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 15.f), 0.f);
			SpawnEntity("LaserFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("LaserFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
		}
		for (int column = 29; column <= 30; column++) {
			SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
		}
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 200.f, mapCenter.y + 20.f), 180.f);
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 200.f, mapCenter.y - 20.f), 180.f);
		//SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 200.f, mapCenter.y), 180.f);
		SpawnEntity("Battleship", Faction::enemy, Vec2(mapCenter.x + 160.f, mapCenter.y), 180.f);
	}
	if (sceneID == 3) {
		for (int column = 26; column <= 28; column++) {
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
		}
		for (int column = 21; column <= 27; column++) {
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 10.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 10.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 20.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 20.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 30.f), 180.f);
			SpawnEntity("Bomber", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 30.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 40.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 40.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 50.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 50.f), 180.f);
		}
	}
	if (sceneID == 4) {
		SpawnEntity("Battleship", Faction::player, Vec2(mapCenter.x - 250.f, mapCenter.y - 45.f), 0.f);
		SpawnEntity("Battleship", Faction::player, Vec2(mapCenter.x - 250.f, mapCenter.y + 45.f), 0.f);
		SpawnEntity("Battleship", Faction::player, Vec2(mapCenter.x - 250.f, mapCenter.y - 15.f), 0.f);
		SpawnEntity("Battleship", Faction::player, Vec2(mapCenter.x - 250.f, mapCenter.y + 15.f), 0.f);
		for (int column = 20; column <= 25; column++) {
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 10.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 10.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 20.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 20.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 30.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 30.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 40.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 40.f), 180.f);
		}
	}
	if (sceneID == 5) {
		SpawnEntity("Battleship", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y), 0.f);
		for (int column = 26; column <= 29; column++) {
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y), 0.f);
		}
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y + 20.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y - 20.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y), 180.f);
		for (int column = 20; column <= 21; column++) {
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 10.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 10.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 20.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 20.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 30.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 30.f), 180.f);
			SpawnEntity("LaserFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y), 180.f);
		}
	}
	if (sceneID == 6) {
		SpawnEntity("MissileCruiser", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y + 30.f), 0.f);
		SpawnEntity("MissileCruiser", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y - 30.f), 0.f);
		SpawnEntity("MissileCruiser", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y + 10.f), 0.f);
		SpawnEntity("MissileCruiser", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y - 10.f), 0.f);
		for (int column = 26; column <= 30; column++) {
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("FlakFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("FlakFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
			//SpawnEntity("FlakFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 40.f), 0.f);
			//SpawnEntity("FlakFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 40.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y), 0.f);
		}
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y + 10.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y - 10.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y + 30.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y - 30.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y + 50.f), 180.f);
		SpawnEntity("Cruiser", Faction::enemy, Vec2(mapCenter.x + 250.f, mapCenter.y - 50.f), 180.f);
	}
	if (sceneID == 7) {
		SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y + 50.f), 0.f);
		SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y - 50.f), 0.f);
		SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y + 20.f), 0.f);
		SpawnEntity("AntiMatterMissile", Faction::player, Vec2(mapCenter.x - 340.f, mapCenter.y - 20.f), 0.f);
		for (int column = 5; column <= 7; column++) {
			SpawnEntity("AntiMatterMissile", Faction::enemy, Vec2(mapCenter.x + 35.f * column, mapCenter.y + 20.f), 180.f);
			SpawnEntity("AntiMatterMissile", Faction::enemy, Vec2(mapCenter.x + 35.f * column, mapCenter.y - 20.f), 180.f);
			SpawnEntity("AntiMatterMissile", Faction::enemy, Vec2(mapCenter.x + 35.f * column, mapCenter.y + 60.f), 180.f);
			SpawnEntity("AntiMatterMissile", Faction::enemy, Vec2(mapCenter.x + 35.f * column, mapCenter.y - 60.f), 180.f);
			SpawnEntity("AntiMatterMissile", Faction::enemy, Vec2(mapCenter.x + 35.f * column, mapCenter.y), 180.f);
		}
	}
	if (sceneID == 8) {
		for (int column = 23; column <= 30; column++) {
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("MissileFrigate", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("Fighter", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
		}
		for (int column = 24; column <= 30; column++) {
			SpawnEntity("MissileFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 5.f), 180.f);
			SpawnEntity("MissileFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 5.f), 180.f);
			SpawnEntity("MissileFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 15.f), 180.f);
			SpawnEntity("MissileFrigate", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 15.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 25.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 25.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 35.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 35.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y + 45.f), 180.f);
			SpawnEntity("Fighter", Faction::enemy, Vec2(mapCenter.x + 10.f * column, mapCenter.y - 45.f), 180.f);
		}
	}
	if (sceneID == 9) {
		for (int column = 23; column <= 24; column++) {
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 10.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 10.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 20.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 20.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 30.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 30.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y + 40.f), 0.f);
			SpawnEntity("Bomber", Faction::player, Vec2(mapCenter.x - 10.f * column, mapCenter.y - 40.f), 0.f);
		}
		SpawnEntity("SiegeShip", Faction::enemy, Vec2(mapCenter.x + 270.f, mapCenter.y), 180.f);
	}
}

void Map::InitializeAsSkirmish(int sceneID) {
	//Set ai difficulty
	m_aiResourceModifier = (3.f + sceneID * sceneID) / 12.f;
	Entity* playerBase = nullptr;
	for (int index = 0; index < NUMBER_OF_FACTIONS; index++) {
		m_credits[index] = SKIRMISH_STARTING_CREDITS;
		if (GetFactionEnum(index) != Faction::player) {
			m_credits[index] = static_cast<int>(m_aiResourceModifier * m_credits[index]);
		}
	}
	//Choose a random map
	int mapCount = 3;
	int mapChosen = g_theApp->m_rnd->RollRandomIntInRange(1, mapCount);
	int asteroidToSpawn = 10;
	if (mapChosen == 1) {
		m_mapArea = AABB2(0.f, 0.f, 1800.f, 900.f);
		SpawnEntity("Shipyard", Faction::enemy, Vec2(m_mapArea.GetCenter().x * 0.2f + m_mapArea.m_mins.x * 0.8f, m_mapArea.GetCenter().y), 0.f);
		playerBase = SpawnEntity("Shipyard", Faction::player, Vec2(m_mapArea.GetCenter().x * 0.2f + m_mapArea.m_maxs.x * 0.8f, m_mapArea.GetCenter().y), 180.f);
		asteroidToSpawn = g_theApp->m_rnd->RollRandomIntInRange(6,8);
	}
	if (mapChosen == 2) {
		m_mapArea = AABB2(0.f, 0.f, 1600.f, 1400.f);
		playerBase = SpawnEntity("Shipyard", Faction::player, m_mapArea.GetCenter() * 0.2f + m_mapArea.m_mins * 0.8f, 45.f);
		SpawnEntity("Shipyard", Faction::enemy, m_mapArea.GetCenter() * 0.2f + m_mapArea.m_maxs * 0.8f, -135.f);
		asteroidToSpawn = g_theApp->m_rnd->RollRandomIntInRange(8,10);
	}
	if (mapChosen == 3) {
		m_mapArea = AABB2(0.f, 0.f, 1400.f, 2100.f);
		playerBase = SpawnEntity("Shipyard", Faction::player, Vec2(m_mapArea.GetCenter().x, m_mapArea.GetCenter().y * 0.2f + m_mapArea.m_mins.y * 0.8f), 90.f);
		SpawnEntity("Shipyard", Faction::enemy, Vec2(m_mapArea.GetCenter().x, m_mapArea.GetCenter().y * 0.2f + m_mapArea.m_maxs.y * 0.8f), -90.f);
		asteroidToSpawn = g_theApp->m_rnd->RollRandomIntInRange(10, 12);
	}
	for (int asteroidIndex = 0; asteroidIndex < asteroidToSpawn; asteroidIndex++) {
		AABB2 AsteroidSpawnArea = m_mapArea;
		AsteroidSpawnArea.SetDimensions(AsteroidSpawnArea.GetDimensions() * 0.8f);
		Vec2 spawnPosition = Vec2(g_theApp->m_rnd->RollRandomFloatInRange(AsteroidSpawnArea.m_mins.x, AsteroidSpawnArea.m_maxs.x), g_theApp->m_rnd->RollRandomFloatInRange(AsteroidSpawnArea.m_mins.y, AsteroidSpawnArea.m_maxs.y));
		new Asteroid(this, spawnPosition);
	}
	m_world_camera->SetOrthoCenter(playerBase->m_position);
}

void Map::TryDeleteEntityVector(std::vector<Entity*>& entities, bool onlyGarbage) {
	for (int index = 0; index < entities.size(); index++) {
		if (entities[index] != nullptr) {
			if (!onlyGarbage || entities[index]->m_isGarbage) {
				delete entities[index];
				entities[index] = nullptr;
			}
		}
	}
}

void Map::TryRenderAllEntities(WorldRenderingPass renderingPass) const {
	TryRenderEntityVector(m_gameplayEntities, renderingPass);
	TryRenderEntityVector(m_cosmeticEntities, renderingPass);
}
void Map::TryRenderEntityVector(std::vector<Entity*> const& entitiesToRender, WorldRenderingPass renderingPass) const {
	for (int index = 0; index < entitiesToRender.size(); index++) {
		if (entitiesToRender[index] == nullptr || entitiesToRender[index]->m_isGarbage) {
			continue;
		}
		entitiesToRender[index]->Render(renderingPass);
	}
}

void Map::TryLetAllGameplayEntitiesAddUIVerts(std::vector<Vertex_PCU>& verts, UIRenderingPass renderingPass) const {
	for (int index = 0; index < m_gameplayEntities.size(); index++) {
		if (m_gameplayEntities[index] == nullptr || m_gameplayEntities[index]->m_isGarbage) {
			continue;
		}
		m_gameplayEntities[index]->AddVertsForUI(verts, renderingPass);
	}
	g_theRenderer->SetModelConstants( );
	g_theRenderer->BindTexture(nullptr);
}

void Map::TryUpdateEntityVector(std::vector<Entity*> const& entitiesToRender, float deltaSeconds, bool physicsUpdate) {
	for (int index = 0; index < entitiesToRender.size(); index++) {
		TryUpdateEntity(entitiesToRender[index], deltaSeconds, physicsUpdate);
	}
}

void Map::GenerateResources(std::vector<Entity*> const& entitiesToRender) {
	for (int index = 0; index < entitiesToRender.size(); index++) {
		if (entitiesToRender[index] != nullptr && !entitiesToRender[index]->m_isGarbage) {
			entitiesToRender[index]->GenerateResources();
		}
	}
}

void Map::AddVertsForStarField(std::vector<Vertex_PCU>& vertexes, float starfieldCameraExtraSize) const {
	AABB2 starfieldArea = CaluclateStarfieldArea(starfieldCameraExtraSize);
	int starCount = static_cast<int>(0.01f * starfieldArea.GetDimensions().x * starfieldArea.GetDimensions().y * STARFIELD_DENSITY_FACTOR);
	for (int starIndex = 0; starIndex < starCount; starIndex++) {
		RandomNumberGenerator* gameRnd = g_theApp->m_rnd;
		Vec2 starPosition = Vec2(gameRnd->RollRandomFloatInRange(starfieldArea.m_mins.x, starfieldArea.m_maxs.x), gameRnd->RollRandomFloatInRange(starfieldArea.m_mins.y, starfieldArea.m_maxs.y));
		float starSize = STARFIELD_STAR_SIZE_FACTOR * gameRnd->RollRandomFloatInRange(0.6f, 1.7f);
		Rgba8 starColor = Rgba8(static_cast<unsigned char>(gameRnd->RollRandomIntInRange(175, 255)), static_cast<unsigned char>(gameRnd->RollRandomIntInRange(175, 240)), unsigned char(gameRnd->RollRandomIntInRange(175, 255)), static_cast<unsigned char>(gameRnd->RollRandomIntInRange(165, 235)));
		Rgba8 starColorEdge = starColor;
		starColorEdge.a = static_cast<uint8_t>(starColorEdge.a * 0.1f);
		for (int indexTriangle = 0; indexTriangle < 4; indexTriangle++) {
			//Each entity have g_VertexCount/3 triangles, with 2 external corners (their angles are calculated below) and one corner at the center.
			float angle1 = float(indexTriangle) * 90.f;
			Vec2 tipingPoint = Vec2(CosDegrees(angle1), SinDegrees(angle1));
			vertexes.emplace_back(Vertex_PCU(Vec3(starPosition) + Vec3(tipingPoint) * starSize * 1.25f, starColorEdge));
			vertexes.emplace_back(Vertex_PCU(Vec3(starPosition) + Vec3(tipingPoint.GetRotated90Degrees()) * starSize * 0.2f, starColor));
			vertexes.emplace_back(Vertex_PCU(Vec3(starPosition) - Vec3(tipingPoint.GetRotated90Degrees()) * starSize * 0.2f, starColor));
		}
	}
}

void Map::AddVertsForMinimapBottom(std::vector<Vertex_PCU>& vertexes) const {
	AABB2 minimapArea = GetMinimapArea();
	AddVertsForAABB2(vertexes, minimapArea, Rgba8(0, 0, 0, 105));
	float scanSize = 0.4f * fminf(minimapArea.GetDimensions().x, minimapArea.GetDimensions().y);
	Rgba8 scanColor = Rgba8(255,255,255,115);
	AddVertsForRing(vertexes, minimapArea.GetCenter(), UI_LINE_WIDTH * 1.5f, 30, UI_LINE_WIDTH * 1.5f, scanColor);
	AddVertsForRing(vertexes, minimapArea.GetCenter(), scanSize * 0.25f, 60, UI_LINE_WIDTH, scanColor);
	AddVertsForRing(vertexes, minimapArea.GetCenter(), scanSize * 0.5f, 90, UI_LINE_WIDTH, scanColor);
	AddVertsForRing(vertexes, minimapArea.GetCenter(), scanSize * 0.75f, 120, UI_LINE_WIDTH, scanColor);
	AddVertsForRing(vertexes, minimapArea.GetCenter(), scanSize * 1.f, 160, UI_LINE_WIDTH * 1.5f, scanColor);
	Vec2 scanVector = Vec2(0, scanSize);
	scanVector.RotateDegrees(fmodf(10.f * m_timeInGame, 360.f));
	AddVertsForLine2D(vertexes, minimapArea.GetCenter(), minimapArea.GetCenter() + scanVector, UI_LINE_WIDTH, scanColor);
	AddVertsForAABB2(vertexes, minimapArea, Rgba8(0, 0, 0, 145));
}
void Map::AddVertsForMinimapTop(std::vector<Vertex_PCU>& vertexes) const {
	AABB2 minimapArea = GetMinimapArea();
	Rgba8 minimapEdgeColor = Rgba8(60, 60, 60, 255) * 0.5f + g_UITextColor * 0.5f;
	AddVertsForAABB2Wireframe(vertexes, minimapArea, UI_LINE_WIDTH * 2.f, minimapEdgeColor);
	AABB2 cameraArea = m_world_camera->GetOrthoBound();
	AABB2 cameraAreaOnMimimap;
	cameraAreaOnMimimap.m_mins = RangeMapPositionToMinimap(cameraArea.m_mins, minimapArea);
	cameraAreaOnMimimap.m_maxs = RangeMapPositionToMinimap(cameraArea.m_maxs, minimapArea);
	Rgba8 minimapCameraAreaEdgeColor = minimapEdgeColor;
	minimapCameraAreaEdgeColor.r = minimapCameraAreaEdgeColor.b;
	minimapCameraAreaEdgeColor.g = minimapCameraAreaEdgeColor.b;
	minimapCameraAreaEdgeColor.b = uint8_t(minimapCameraAreaEdgeColor.b / 2);
	AddVertsForAABB2Wireframe(vertexes, cameraAreaOnMimimap, UI_LINE_WIDTH, minimapCameraAreaEdgeColor);
}


AABB2 Map::CaluclateStarfieldArea(float starfieldCameraExtraSize) const {
	Vec2 mapExtraSize = Vec2(starfieldCameraExtraSize * 2.f, starfieldCameraExtraSize / g_theWindow->GetClientAspect());
	//Might be broken if the window shape changes?
	mapExtraSize += m_mapArea.GetDimensions();
	Vec2 starFieldSize = m_mapArea.GetDimensions() + mapExtraSize;
	AABB2 result = m_mapArea;
	result.SetDimensions(starFieldSize);
	return result;
}

void Map::DealWithPlayerControl(float deltaSeconds) {
	if (g_theApp->GetIsPuased()) {
		return;
	}
	AABB2 minimapArea = GetMinimapArea();
	bool mouseInMinimap = true;
	if (!minimapArea.IsPointInside(m_mouseDragStartScreen) || !m_showInGameUI) {
		mouseInMinimap = false;
	}
	//Pan the camera
	Vec2 mousePositionInMap = g_theWindow->GetNormalizedCursorPos();
	Vec2 mousePositionMoveIntent = Vec2();
	if (g_theInputSystem->IsKeyDown(KEYCODE_MIDMOUSE) || g_theInputSystem->IsKeyDown('X')) {
		mousePositionMoveIntent = 2.5f * (mousePositionInMap - Vec2(0.5f, 0.5f));
	}
	else if(!m_game->HasButtonHovered()) {
		if (mousePositionInMap.x < SIDE_SCROLL_MARGIN) {
			mousePositionMoveIntent.x += (mousePositionInMap.x - SIDE_SCROLL_MARGIN) * SIDE_SCROLL_SPEED;
		}
		if (mousePositionInMap.x > 1.f - SIDE_SCROLL_MARGIN) {
			mousePositionMoveIntent.x += (mousePositionInMap.x - (1.f - SIDE_SCROLL_MARGIN)) * SIDE_SCROLL_SPEED;
		}
		if (mousePositionInMap.y < SIDE_SCROLL_MARGIN) {
			mousePositionMoveIntent.y += (mousePositionInMap.y - SIDE_SCROLL_MARGIN) * SIDE_SCROLL_SPEED;
		}
		if (mousePositionInMap.y > 1.f - SIDE_SCROLL_MARGIN) {
			mousePositionMoveIntent.y += (mousePositionInMap.y - (1.f - SIDE_SCROLL_MARGIN)) * SIDE_SCROLL_SPEED;
		}
	}
	if (g_theInputSystem->IsKeyDown(KEYCODE_LEFTARROW)) {
		mousePositionMoveIntent.x -= 0.45f;
	}
	if (g_theInputSystem->IsKeyDown(KEYCODE_RIGHTARROW)) {
		mousePositionMoveIntent.x += 0.45f;
	}
	if (g_theInputSystem->IsKeyDown(KEYCODE_UPARROW)) {
		mousePositionMoveIntent.y += 0.45f;
	}
	if (g_theInputSystem->IsKeyDown(KEYCODE_DOWNARROW)) {
		mousePositionMoveIntent.y -= 0.45f;
	}
	m_world_camera->SetOrthoCenter(m_world_camera->GetOrthoCenter() + mousePositionMoveIntent * m_world_camera->GetSize().x * deltaSeconds);

	for (uint8_t currentControlGroup = 1; currentControlGroup <= CONTROL_GROUP_COUNT; currentControlGroup++) {
		unsigned char currentControlGroupKeyCode = '1' - 1 + currentControlGroup;
		if (g_theInputSystem->IsKeyDown('F') || (g_theInputSystem->WasKeyJustDoubleReleased(currentControlGroupKeyCode) && !g_theInputSystem->IsKeyDown(KEYCODE_CTRL))) {
			Vec2 controlGroupCenter = GetCenterOfSelectedUnits();
			if (controlGroupCenter != Vec2()) {
				m_world_camera->SetOrthoCenter(controlGroupCenter);
			}
		}
	}
	//Record and save the selection box
	if (g_theInputSystem->WasKeyJustPressed(KEYCODE_LEFTMOUSE)) {
		m_mouseDragStartScreen = m_game->GetMouseOnScreenPosition();
		m_mouseDragStartWorld = GetMousePositionWorld();
		m_mouseDragEndScreen = m_mouseDragStartScreen;
		m_mouseDragEndWorld = m_mouseDragStartWorld;
		m_mouseDragStartedInButtonArea = m_game->HasButtonHovered();
		m_mouseDragStartedInMinimapArea = minimapArea.IsPointInside(m_mouseDragStartScreen);
	}
	if (g_theInputSystem->IsKeyDown(KEYCODE_LEFTMOUSE)) {
		m_mouseDragEndScreen = m_game->GetMouseOnScreenPosition();
		m_mouseDragEndWorld = GetMousePositionWorld();
	} 
	//Toogle in-game UI
	if (g_theInputSystem->WasKeyJustPressed(KEYCODE_TAB)) {
		m_showInGameUI = !m_showInGameUI;
	}
	//Zoom in/out the camera
	float zoomLevelDelta = 0.f;
	int mouseWheelDelta = g_theInputSystem->GetCursorClientMidDelta();
	zoomLevelDelta -= 0.0005f * mouseWheelDelta;
	if (g_theInputSystem->IsKeyDown('Z')) {
		zoomLevelDelta -= 0.5f * deltaSeconds;
	}
	if (g_theInputSystem->IsKeyDown('C')) {
		zoomLevelDelta += 0.5f * deltaSeconds;
	}
	m_currentZoomLevel *= (1 + zoomLevelDelta);
	m_currentZoomLevel = GetClamped(m_currentZoomLevel, ZOOM_LEVEL_MIN, ZOOM_LEVEL_MAX);
	float cameraSizePrevious = m_world_camera->GetOrthoBound().GetDimensions().x;
	ApplyZoomLevel(m_currentZoomLevel);
	//Move camera as we zoom in/out, so it feels like we are zooming in towards or zooming out from the mouse position
	float cameraSizeChange = m_world_camera->GetOrthoBound().GetDimensions().x - cameraSizePrevious;
	Vec2 cameraAreaChange = Vec2(cameraSizeChange, cameraSizeChange * g_theWindow->GetClientAspect());
	Vec2 zoomPivot = g_theWindow->GetNormalizedCursorPos() - Vec2(0.5f, 0.5f);
	if (cameraSizeChange > 0.f) {
		m_world_camera->SetOrthoCenter(m_world_camera->GetOrthoCenter() - 0.5f * zoomPivot * cameraAreaChange);
	}
	else {
		m_world_camera->SetOrthoCenter(m_world_camera->GetOrthoCenter() - zoomPivot * cameraAreaChange);
	}
	//Move camera if minimap is clicked
	if (g_theInputSystem->IsKeyDown(KEYCODE_LEFTMOUSE) && m_showInGameUI) {
		//If mouse start dragging in mimimap area, then move camera
		if (minimapArea.IsPointInside(m_mouseDragEndScreen) && m_mouseDragStartedInMinimapArea) {
			Vec2 correspondingWorldPosition = RangeMapPositionFromMinimap(m_mouseDragEndScreen, minimapArea);
			m_world_camera->SetOrthoCenter(correspondingWorldPosition);
		}
	}
	//Sanitize camera position, don't get out of map, etc
	ConstraintCameraPosition();
}

int Map::CountGameplayEntities() const {
	int count = 0;
	for (int index = 0; index < m_gameplayEntities.size(); index++) {
		if (m_gameplayEntities[index] != nullptr && !m_gameplayEntities[index]->m_isDead) {
			count++;
		}
	}
	return count;
}

int Map::CountCosmeticEntities() const {
	int count = 0;
	for (int index = 0; index < m_cosmeticEntities.size(); index++) {
		if (m_cosmeticEntities[index] != nullptr && !m_cosmeticEntities[index]->m_isDead) {
			count++;
		}
	}
	return count;
}

std::vector<Entity*> Map::FindEntities(Vec2 searchCenter, float withinRange, EntitySearchFilter const& filter) const {
	std::vector<Entity*> result;
	for (int index = 0; index < m_gameplayEntities.size(); index++) {
		//Check other conditions
		if (m_gameplayEntities[index] == nullptr || m_gameplayEntities[index]->m_isDead) {
			continue;
		}
		EntityDefinition const* targetDef = m_gameplayEntities[index]->GetDefinition();
		if (filter.positiveCostOnly && targetDef->price <= 0) {
			continue;
		}
		if (filter.canCollideOnly && targetDef->physicsRadius <= TINY_POSITIVE_NUMBER) {
			continue;
		}
		if (filter.noneInvincibleOnly && targetDef->maxHealth <= TINY_POSITIVE_NUMBER) {
			continue;
		}
		if (filter.noneBulletOnly && targetDef->maxHealth <= TINY_POSITIVE_NUMBER && targetDef->isProjectile) {
			continue;
		}
		if (filter.seletableOnly && !targetDef->isSelectable) {
			continue;
		}
		if (filter.builderOnly && !targetDef->isBuilder) {
			continue;
		}
		if (filter.asteroidOnly && !targetDef->isAsteriod) {
			continue;
		}
		//Check distance
		if (withinRange > -1.f * TINY_POSITIVE_NUMBER) {
			if (!m_gameplayEntities[index]->IsCloserThan(searchCenter, withinRange, true)) {
				continue;
			}
		} 
		//Check other conditions
		if (filter.excludeFactions.size() > 0 && std::find(filter.excludeFactions.begin(), filter.excludeFactions.end(), m_gameplayEntities[index]->m_faction) != filter.excludeFactions.end()) {
			continue;
		}
		if (filter.onlyIncludeFactions.size() > 0 && std::find(filter.onlyIncludeFactions.begin(), filter.onlyIncludeFactions.end(), m_gameplayEntities[index]->m_faction) == filter.onlyIncludeFactions.end()) {
			continue;
		}
		//Save result
		result.emplace_back(m_gameplayEntities[index]);
		if (filter.returnOnlyOneResult) {
			return result;
		}
	}
	#ifdef NDEBUG
	m_game->m_debug_numberOfUnitSearchesThisFrame += 1;
	#endif
	return result;
}

RaycastResultWithEntity Map::RaycastVSEntities(Vec2 rayStart, Vec2 rayNorm, float maxDistance, float rayWidth, EntitySearchFilter const& filter) const {
	RaycastResultWithEntity result;
	assert(filter.returnOnlyOneResult == false);
	std::vector<Entity*> victims = FindEntities(rayStart, -1.f, filter);
	for (int index = 0; index < victims.size(); index++) {
		//Check other conditions
		//Do raycast
		RaycastResult2D contactInfo = RaycastVsDisc2D(rayStart, rayNorm, maxDistance, victims[index]->m_position, victims[index]->GetDefinition()->physicsRadius, rayWidth);
		if (RaycastResultIsCloser(contactInfo, result.m_contactInfo)) {
			result.m_contactInfo = contactInfo;
			result.m_entityHit = victims[index];
		}
	}
	return result;
}

bool Map::DoAreaDamage(Vec2 center, float areaRadius, float damageAmount, std::vector<Faction> excludeFactions, std::vector<Faction> onlyIncludeFactions, bool noImpulse) {
	if (damageAmount <= 0.f) {
		return false;
	}
	EntitySearchFilter searchFilter;
	searchFilter.noneInvincibleOnly = true;
	searchFilter.excludeFactions = excludeFactions;
	searchFilter.onlyIncludeFactions = onlyIncludeFactions;
	std::vector<Entity*> victims = FindEntities(center, areaRadius, searchFilter);
	bool hitSomeThing = false;
	for (int index = 0; index < victims.size(); index++) {
		float actualDistance = GetDistance2D(center, victims[index]->m_position) - victims[index]->GetDefinition()->physicsRadius;
		actualDistance = fmaxf(actualDistance, 0.f);
		float actualDamage = damageAmount * (areaRadius - actualDistance) / areaRadius;
		if (victims[index]->TakeDamage(actualDamage)) {
			hitSomeThing = true;
			if (!noImpulse) {
				Vec2 impulseNorm = (victims[index]->m_position - center).GetNormalized();
				victims[index]->TakeImpulse(impulseNorm, AOE_IMPULSE_FACTOR * damageAmount);
			}
		}
	}
	return hitSomeThing;
}
void Map::SelectAllEntitiesOfType(std::string entityType, bool onlyOnScreen, std::vector<Faction> onlyIncludeFactions, std::vector<Faction> excludeFactions) {

	for (int index = 0; index < m_gameplayEntities.size(); index++) {
		//Check other conditions
		if (m_gameplayEntities[index] == nullptr || m_gameplayEntities[index]->m_isDead || m_gameplayEntities[index]->GetDefinition()->uncontrollable) {
			continue;
		}
		if (m_gameplayEntities[index]->GetDefinition()->name != entityType) {
			continue;
		}
		if (onlyOnScreen && !GetWorldCameraArea().IsPointInside(m_gameplayEntities[index]->m_position)) {
			continue;
		}
		if (excludeFactions.size() > 0 && std::find(excludeFactions.begin(), excludeFactions.end(), m_gameplayEntities[index]->m_faction) != excludeFactions.end()) {
			continue;
		}
		if (onlyIncludeFactions.size() > 0 && std::find(onlyIncludeFactions.begin(), onlyIncludeFactions.end(), m_gameplayEntities[index]->m_faction) == onlyIncludeFactions.end()) {
			continue;
		}
		//Set as selected
		m_gameplayEntities[index]->SetAsSelected(true);
	}
}

void Map::ShareWaypointWithNearbyAllies(Entity* sharer, float radius, bool overide) {
	EntitySearchFilter searchFilter;
	searchFilter.seletableOnly = true;
	searchFilter.onlyIncludeFactions = { sharer->m_faction };
	std::vector<Entity*> nearbyEntities = FindEntities(sharer->m_position, radius, searchFilter);
	for (int index = 0; index < nearbyEntities.size(); index++) {
		if (nearbyEntities[index]->GetDefinition()->isSelectable != sharer->GetDefinition()->isSelectable) {
			continue;
		}
		if (!overide && nearbyEntities[index]->m_currentWaypointType != WaypointType::none) {
			continue;
		}
		nearbyEntities[index]->m_currentWaypointType = sharer->m_currentWaypointType;
		nearbyEntities[index]->m_waypointEntityTarget = sharer->m_waypointEntityTarget;
		nearbyEntities[index]->m_waypointPositionTarget = sharer->m_waypointPositionTarget;
	}
}

Entity* Map::SpawnEntity(std::string entityType, Faction faction, Vec2 position, float orientationDegrees, Vec2 startingVelocity) {
	EntityDefinition const* fetchedDef = g_theApp->GetEntityTypeByName(entityType);
	return SpawnEntity(fetchedDef, faction, position, orientationDegrees, startingVelocity);
}

Entity* Map::SpawnEntity(EntityDefinition const* def, Faction faction, Vec2 position, float orientationDegrees, Vec2 startingVelocity) {
	if (def == nullptr) {
		return nullptr;
	}
	return new Entity(this, *def, faction, position, orientationDegrees, startingVelocity);
}

int Map::InsertEntityIntoVector(std::vector<Entity*>& entities, Entity* thing) {
	for (int index = 0; index < entities.size(); index++) {
		if (entities[index] == nullptr) {
			entities[index] = thing;
			return index;
		}
	}
	entities.emplace_back(thing);
	return static_cast<int>(entities.size() - 1);
}


