
#include "Game\Game.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"

Button::Button(AABB2 area, std::string text, float fontSize) :
	m_area(area),
	m_fontSize(fontSize),
	m_text(text)
{
}

void Button::Update() {
	m_isHovered = m_area.IsPointInside(m_game->GetMouseOnScreenPositionNorm());
	m_isClicked = m_isHovered && g_theApp->WasKeyJustUp(KEYCODE_LEFTMOUSE);
	m_game->m_hasButtonHovered |= m_isHovered;
	m_game->m_hasButtonClicked |= m_isClicked;
}

void Button::Render() const {
	if (m_isHovered) {
		m_game->PutTextOnScreen(m_fontSize, m_text, g_UITextHighLightColor, 0.75f, m_area);
	}
	else {
		m_game->PutTextOnScreen(m_fontSize, m_text, g_UITextColor, 0.75f, m_area);
	}
}



//Game class
Game::Game() {
	m_screen_camera = new Camera();
}

Game::~Game() {
	delete m_screen_camera;
}

//Basic and critical stuff used by the system-------------------------------------------------------
void Game::Startup() {
	g_theApp->RandomlyResetBackgroundMusic();
	m_screen_camera->SetOrthoView(Vec2(0.f, 0.f), Vec2(SCREEN_CAMERA_SIZE_X, SCREEN_CAMERA_SIZE_X / g_theWindow->GetClientAspect()));
	std::vector<std::string> m_menuText;
	for (int index = 1; index <= NUMBER_OF_SKIRMISHES; index++) {
		m_menuText.push_back(Stringf("Skirmish Difficulty %d", index));
	}
	for (int index = 1; index <= NUMBER_OF_CHALLENGES; index++) {
		m_menuText.push_back(Stringf("Challenge Level %d", index));
	}
	m_menuText.push_back("Quit To Desktop");
	for (int menuButtonIndex = 0; menuButtonIndex < m_menuText.size(); menuButtonIndex++) {
		AABB2 area;
		area.m_mins.x = 0.38f;
		area.m_maxs.x = 0.62f;
		area.m_mins.y = 1.f - (0.3f + 0.05f * menuButtonIndex);
		area.m_maxs.y = 1.f - (0.25f + 0.05f * menuButtonIndex);
		m_mainMenuButtons.emplace_back(Button(area, m_menuText[menuButtonIndex]));
	}
	m_pauseButton = Button(AABB2(Vec2(0.025f, 0.025f), Vec2(0.1f, 0.085f)), "Pause");
	m_resumeButton = Button(AABB2(Vec2(0.025f, 0.025f), Vec2(0.1f, 0.085f)), "Resume");
	m_backToMenuButton = Button(AABB2(Vec2(0.1f, 0.025f), Vec2(0.175f, 0.085f)), "Exit");
}

void Game::EnterGame() {
	m_map = new Map(this, m_desiredMapMode, m_desiredMapSettingID);
	g_theApp->RandomlyResetBackgroundMusic();
	g_theApp->m_isPaused = false;
}

//
void Game::ExitGame() {
	delete m_map;
	m_map = nullptr;
	g_theApp->RandomlyResetBackgroundMusic();
	g_theApp->m_isPaused = false;
}

void Game::PutTextOnScreen(float cellHeight, std::string const& text, Rgba8 const& tint, float cellAspect, Vec2 const& alignment) const {
	std::vector<Vertex_PCU> TextVerts;
	g_theApp->GetBitmapFont().AddVertsForTextInBox2D(TextVerts, m_screen_camera->GetOrthoBound(), cellHeight, text, tint, cellAspect, alignment, TextDrawMode::SHRINK_TO_FIT, INT_MAX);
	g_theRenderer->BindTexture(&(g_theApp->GetBitmapFont().GetTexture()));
	g_theRenderer->DrawVertexVector(TextVerts);
	g_theRenderer->BindTexture(nullptr);
}

void Game::PutTextOnScreen(float cellHeight, std::string const& text, Rgba8 const& tint, float cellAspect, AABB2 const& relativeArea) const {
	std::vector<Vertex_PCU> TextVerts;
	AABB2 entireArea = m_screen_camera->GetOrthoBound();
	AABB2 drawArea;
	drawArea.m_mins.x = Interpolate(entireArea.m_mins.x, entireArea.m_maxs.x, relativeArea.m_mins.x);
	drawArea.m_maxs.x = Interpolate(entireArea.m_mins.x, entireArea.m_maxs.x, relativeArea.m_maxs.x);
	drawArea.m_mins.y = Interpolate(entireArea.m_mins.y, entireArea.m_maxs.y, relativeArea.m_mins.y);
	drawArea.m_maxs.y = Interpolate(entireArea.m_mins.y, entireArea.m_maxs.y, relativeArea.m_maxs.y);
	g_theApp->GetBitmapFont().AddVertsForTextInBox2D(TextVerts, drawArea, cellHeight, text, tint, cellAspect, Vec2(0.5f, 0.5f), TextDrawMode::SHRINK_TO_FIT, INT_MAX);
	g_theRenderer->BindTexture(&(g_theApp->GetBitmapFont().GetTexture()));
	g_theRenderer->DrawVertexVector(TextVerts);
	g_theRenderer->BindTexture(nullptr);
}

void Game::UnitTryAddDescription(std::string description) {
	if (!HasButtonHovered() && !g_theApp->GetIsPuased() && m_unitDescriptionToDisplay == "") {
		m_unitDescriptionToDisplay = description;
	}
}


void Game::UpdateStart(float deltaSeconds) {
	(void)deltaSeconds;  //Do nothing, repress warning
	if (g_theApp->m_currentGameState == GameState::inFight) {
		if (m_map) {
			m_map->UpdateStart(deltaSeconds);
		}
		else {
			EnterGame();
		}
	}
	if (g_theApp->m_currentGameState == GameState::inMenu) {
		if (m_map) {
			ExitGame();
		}
	}
	UpdateUI();
}


void Game::Update(float deltaSeconds) {
	m_debug_numberOfUnitSearchesEachFrameSmooth = 0.9f * m_debug_numberOfUnitSearchesEachFrameSmooth + 0.1f * m_debug_numberOfUnitSearchesThisFrame;
	m_debug_numberOfUnitSearchesThisFrame = 0;
	UpdateStart(deltaSeconds);
	if (g_theApp->m_currentGameState == GameState::inFight && m_map) {
		//Update entities here
		m_map->Update(deltaSeconds);
		if (m_map->m_shouldTerminate) {
			g_theApp->m_currentGameState = GameState::inMenu;
			//It feels better if we don't play quit sound when match end normally
			//g_theApp->PlayExitSound();
		}
	}
	UpdateEnd(deltaSeconds);
}

void Game::UpdateEnd(float deltaSeconds) {
	if (g_theApp->m_currentGameState == GameState::inFight && m_map) {
		m_map->UpdateEnd(deltaSeconds);
	}
}


void Game::Render() const {
	//Draw actual stuff first
	if (g_theApp->m_currentGameState == GameState::inFight && m_map) {
		m_map->Render();
	}
	//Draw UI last, otherwise stuff will cover UI....
	g_theRenderer->BeginCamera(*m_screen_camera);
	DebugRenderScreen(*m_screen_camera);
	//The debug system might set this to cull back.
	g_theRenderer->m_desiredRasterizerMode = RasterizerMode::RASTERIZERMODE_SOLID_CULL_NONE;
	g_theRenderer->EndCamera(*m_screen_camera); 
	RenderUI();
	//Render FPS and game speed
	std::vector<Vertex_PCU> FPStextVerts;
	std::string FPSText = Stringf("%d FPS \n", (int)g_theApp->GetFrameRate());
	if (g_theApp->GetCurrentTimeScalePow() > 0) {
		FPSText.append(Stringf("Game speed: +%d \n", g_theApp->GetCurrentTimeScalePow()));
	}
	if (g_theApp->GetCurrentTimeScalePow() < 0) {
		FPSText.append(Stringf("Game speed: %d \n", g_theApp->GetCurrentTimeScalePow()));
	}
#ifdef NDEBUG
#else
	if (g_theApp->m_currentGameState == GameState::inFight && m_map) {
		FPSText.append(Stringf("Number of unit searches each frame: %d \n", static_cast<int>(m_debug_numberOfUnitSearchesEachFrameSmooth)));
		FPSText.append(Stringf("Number of gameplay entities: %d \n", m_map->CountGameplayEntities()));
		FPSText.append(Stringf("Number of cosmetic entities: %d \n", m_map->CountCosmeticEntities()));
	}
#endif
	PutTextOnScreen(12.f, FPSText, Rgba8(), 0.75f, Vec2(0.005f, 0.005f));
}

void Game::RenderUI() const {
	g_theRenderer->BeginCamera(*m_screen_camera);
	//Render title in attract mode, or credits in combat mode
	if (g_theApp->m_currentGameState == GameState::inMenu) {
		PutTextOnScreen(55.f, g_theApp->m_Title, g_UITextColor, 0.75f, Vec2(0.5f, 0.12f));
		for (int menuIndex = 0; menuIndex < m_mainMenuButtons.size(); menuIndex++) {
			m_mainMenuButtons[menuIndex].Render();
		}
	}
	if (g_theApp->m_currentGameState == GameState::inFight && m_map != nullptr && m_map->m_showInGameUI) {
		std::string creditString = Stringf("Credits:$%d(+%d)", m_map->GetCredits(Faction::player), m_map->GetRecoredPlayerIncome());
		float minimapXMinPos = GetFractionWithinRange(m_map->GetMinimapArea().m_mins.x, m_screen_camera->GetOrthoBound().m_mins.x, m_screen_camera->GetOrthoBound().m_maxs.x);
		PutTextOnScreen(15.f, creditString, g_UITextHighLightColor, 0.75f, AABB2(Vec2(minimapXMinPos - 0.16f, 0.96f), Vec2(minimapXMinPos, 1.f)));
		if (m_unitDescriptionToDisplay != "") {
			PutTextOnScreen(15.f, m_unitDescriptionToDisplay, g_UITextHighLightColor, 0.75f, AABB2(Vec2(0.25f, 0.01f), Vec2(0.75f, 0.15f)));
		}
	}
	//Render pause screen stuff
	std::vector<Vertex_PCU> UIVerts;
	if (g_theApp->m_isPaused) {
		//Add grey background
		AddVertsForAABB2(UIVerts, m_screen_camera->GetOrthoBound(), Rgba8(40, 40, 40, 200));
		g_theRenderer->DrawVertexVector(UIVerts);
		UIVerts.clear();
		//Add hint text
		std::string hintText = "";
		hintText.append("[System]\n");
		hintText.append("esc key: pause/resume game\n");
		hintText.append("+/- key: modify game speed \n");
		hintText.append("P key: step one frame then pause \n\n");
		hintText.append("[Controls]\n");
		hintText.append("Left click: select units, drag to group select \n");
		hintText.append("Left click + shift/control: add/remove units from selection, drag to group select\n");
		hintText.append("Right click: assign move or attack order, double click to attack move\n");
		hintText.append("Arrow keys or move mouse to screen edge: move camera\n");
		hintText.append("Hold X key or middle mouse button while moving mouse: move camera\n");
		hintText.append("Z/C keys or mid mouse wheel: zoom in/out camera\n");
		hintText.append("S key: cancel current waypoint\n");
		hintText.append("Number key + control: assign control group\n");
		hintText.append("Number key: select control group, double press to focus\n");
		hintText.append("F key: focus on selected units\n");
		hintText.append("Click on minimap: move camera to that area of the map\n");
		hintText.append("Tab key: toggle health bar and minimap\n\n");
		hintText.append("[Skirmish mode]\n");
		hintText.append("Selete your shipyard or carrier to display build menu, hold shift to enable batch build\n");
		hintText.append("Destroy enemy shipyard and carriers to win\n");
		hintText.append("Increase your income by capturing and holding more asteriods\n");
		hintText.append("Difficulty level affect your ai oppoent's income\n");
		hintText.append("Hover mouse above units or build options to see detailed description\n");
		PutTextOnScreen(16.f, hintText, g_UITextColor, 0.75f, Vec2(0.02f, 0.8f));
		//Add story text
		std::string storyText = "";
		storyText.append("Incoming message from the Church. \n");
		storyText.append("In the name of Prince Rystiya:\n");
		storyText.append("We finally managed to reestablish contact with galaxy HX79dV3 as the energy storm calms down, and things aren't looking good.\n");
		storyText.append("The lizardfolk tribes have captured one of the warehouses that stores retired void-war-era imperial ships.\n");
		storyText.append("They have thus managed to conquer many more civilized factions, forcing them to conduct mass human sacrifices for their dark gods.\n");
		storyText.append("Entire sectors are being genocided just because they refuse to cut the throat of their children as you read this message.\n");
		storyText.append("If the empire does not take action, it's only a matter of time before they summon a dark god or something similar.\n");
		storyText.append("Normally we should tell the legions to deal with such situations, but they don't have available strike fleets in our galaxy cluster.\n");
		storyText.append("They are either occupied clearing up void infestations, recovering from losses, or simply too far away.\n");
		storyText.append("That's why we contact mercenaries like you.\n");
		storyText.append("Your job is to clean up all lizardfolk forces and reestablish order. Save the people so they are ready to be converted to our faith.\n");
		storyText.append("The church will pay you handsomely when this is done.\n");
		storyText.append("May prince Rystiya's courage be with you.\n");
		PutTextOnScreen(15.f, storyText, g_UITextColor, 0.75f, Vec2(0.02f, 0.05f));
	}
	//Render the buttons
	if (g_theApp->m_currentGameState == GameState::inFight && m_map != nullptr && m_map->m_showInGameUI) {
		if (!g_theApp->m_isPaused) {
			m_pauseButton.Render();
			for (int menuIndex = 0; menuIndex < m_buildOptionButtons.size(); menuIndex++) {
				m_buildOptionButtons[menuIndex].Render();
			}

		}
		else {
			m_resumeButton.Render();
			m_backToMenuButton.Render();
		}
	}
	//Render mouse and selection area
	Vec2 mousePositionInMap = GetMouseOnScreenPosition();
	std::vector<Vertex_PCU> vertexes;
	if (g_theInputSystem->IsKeyDown(KEYCODE_MIDMOUSE) || g_theInputSystem->IsKeyDown('X')) {
		AddVertsForMouseArrowOfDirection(vertexes, Vec2(), Vec2(100.f, 0.f), mousePositionInMap, 0.65f);
		AddVertsForMouseArrowOfDirection(vertexes, Vec2(), Vec2(-100.f, 0.f), mousePositionInMap, 0.65f);
		AddVertsForMouseArrowOfDirection(vertexes, Vec2(), Vec2(0.f, 100.f), mousePositionInMap, 0.65f);
		AddVertsForMouseArrowOfDirection(vertexes, Vec2(), Vec2(0.f, -100.f), mousePositionInMap, 0.65f);
	}
	else {
		AddVertsForMouseArrowOfDirection(vertexes, Vec2(75.f, -100.f), Vec2(), mousePositionInMap);
	}

	if (m_map != nullptr && m_map->IsSelectionAreaActive()) {
		Vec2 boxStart = m_map->GetSelectionBoxStartScreen();
		Vec2 boxEnd = m_map->GetSelectionBoxEndScreen();
		AddVertsForAABB2Wireframe(vertexes, AABB2(boxStart, boxEnd), UI_LINE_WIDTH * 0.75f);
	}
	g_theRenderer->DrawVertexVector(vertexes);
	g_theRenderer->EndCamera(*m_screen_camera);
}

void Game::UpdateUI() {
	//The buttons will write on these two values when updated
	m_hasButtonClicked = false;
	m_hasButtonHovered = false;
	m_buildOptionButtons.clear();
	m_unitDescriptionToDisplay = "";
	//If in attract mode, show the menu
	if (g_theApp->m_currentGameState == GameState::inMenu) {
		for (int menuIndex = 0; menuIndex < m_mainMenuButtons.size(); menuIndex++) {
			m_mainMenuButtons[menuIndex].Update();
			if (m_mainMenuButtons[menuIndex].m_isClicked) {
				if (menuIndex == m_mainMenuButtons.size() - 1) {
					g_theApp->m_isQuitting = true;
				}
				else {
					g_theApp->m_currentGameState = GameState::inFight;
					g_theApp->PlayStartSound();
					if (menuIndex < NUMBER_OF_SKIRMISHES) {
						m_desiredMapMode = MapMode::skirmish;
						m_desiredMapSettingID = menuIndex + 1;
					}
					else {
						m_desiredMapMode = MapMode::arena;
						m_desiredMapSettingID = menuIndex + 1 - NUMBER_OF_SKIRMISHES;
					}
				}
			}
		}
	}
	//If it's in game, then it depends on whether it's paused...
	if (g_theApp->m_currentGameState == GameState::inFight && m_map != nullptr && m_map->m_showInGameUI) {
		//First, set build options based on what selected entities can build
		std::vector<std::string> buildOptions = m_map->GetSelectedEntitiesCanBuildList();
		for (int buildMenuIndex = 0; buildMenuIndex < buildOptions.size(); buildMenuIndex++) {
			AABB2 area;
			area.m_mins.x = 0.8f;
			area.m_maxs.x = 1.f;
			area.m_mins.y = 0.03f * (buildMenuIndex);
			area.m_maxs.y = 0.03f * (1 + buildMenuIndex);
			EntityDefinition* entityCanBuild = g_theApp->GetEntityTypeByName(buildOptions[buildMenuIndex]);
			std::string nextButtonText = Stringf("%s: $%d", buildOptions[buildMenuIndex].c_str(), entityCanBuild->price);
			if (g_theApp->IsKeyDown(KEYCODE_SHIFT)) {
				nextButtonText = Stringf("%s*%d: $%d", buildOptions[buildMenuIndex].c_str(), BATCH_BUILD_BATCH_SIZE, entityCanBuild->price * BATCH_BUILD_BATCH_SIZE);
			}
			Button buttonToPush = Button(area, nextButtonText, 15.f);
			m_buildOptionButtons.emplace_back(buttonToPush);
		}
		//Then update the buttons
		if (!g_theApp->m_isPaused) {
			m_pauseButton.Update();
			if (m_pauseButton.m_isClicked) {
				g_theApp->m_isPaused = true;
			}
			m_playerIntendBuildUnit = "";
			for (int menuIndex = 0; menuIndex < m_buildOptionButtons.size(); menuIndex++) {
				m_buildOptionButtons[menuIndex].Update();
				EntityDefinition* entityCanBuild = g_theApp->GetEntityTypeByName(buildOptions[menuIndex]);
				if (m_buildOptionButtons[menuIndex].m_isHovered) {
					m_unitDescriptionToDisplay = entityCanBuild->description;
				}
				if (m_buildOptionButtons[menuIndex].m_isClicked) {
					int creditsNeeded = entityCanBuild->price;
					if (g_theApp->IsKeyDown(KEYCODE_SHIFT)) {
						creditsNeeded *= BATCH_BUILD_BATCH_SIZE;
					}
					bool insufficientCredits = m_map->GetCredits(Faction::player) < creditsNeeded;
					if (insufficientCredits) {
						g_theApp->PlayErrorSound();
					}
					else {
						m_playerIntendBuildUnit = buildOptions[menuIndex];
					}
				}
			}
		}
		else {
			m_resumeButton.Update();
			if (m_resumeButton.m_isClicked) {
				g_theApp->m_isPaused = false;
			}
			m_backToMenuButton.Update();
			if (m_backToMenuButton.m_isClicked) {
				g_theApp->m_currentGameState = GameState::inMenu;
				g_theApp->PlayExitSound();
			}
		}
	}
	//Play sound at last.
	if (m_hasButtonClicked) {
		g_theApp->PlayIntefaceSound();
	}
}

void Game::AddVertsForMouseArrowOfDirection(std::vector<Vertex_PCU>& verts, Vec2 start, Vec2 end, Vec2 position, float arrowSizeScale) const {
	Vec2 outerShapeShift = (start - end) * (MOUSE_SCALE_INNER - MOUSE_SCALE_OUTER) * 0.5f;
	AddVertsForArrow2D(verts, outerShapeShift + position + start * MOUSE_SCALE_OUTER, outerShapeShift + position + end * MOUSE_SCALE_OUTER, arrowSizeScale * MOUSE_SIZE_TIP * MOUSE_SCALE_OUTER, arrowSizeScale * MOUSE_SIZE_WIDTH * MOUSE_SCALE_OUTER, Rgba8());
	AddVertsForArrow2D(verts, position + start * MOUSE_SCALE_INNER, position + end * MOUSE_SCALE_INNER, arrowSizeScale * MOUSE_SIZE_TIP * MOUSE_SCALE_INNER, arrowSizeScale * MOUSE_SIZE_WIDTH * MOUSE_SCALE_INNER, g_UITextColor);
}



