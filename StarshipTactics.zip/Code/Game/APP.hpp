#pragma once

#include "Engine\Core\EventSystem.hpp"
#include "Engine\Audio\AudioSystem.hpp"
#include "Engine\Core\Rgba8.hpp"
#include "Engine\Core\Vertex_PCU.hpp"

class Game;
class Camera;
class Clock;
class BitmapFont;
struct WeaponDefinition;
struct TurretDefinition;
struct EntityDefinition;

enum class GameState { inMenu, inFight };







struct SoundEntry {
public:
	std::string name = "";
	float volume = 0.5f;
	SoundID soundResourceHandle = (SoundID)0;
	SoundEntry() {}
	SoundEntry(const XmlElement& xmlElement);
};

struct BuildEntry {
public:
	std::string name = "";
	Vec2 launchPosition = Vec2();
	float launchDirection = 0.f;
	float launchSpeed = 0.f;
	float buildTimeCostModifier = 1.f;
	BuildEntry() {}
	BuildEntry(const XmlElement& xmlElement, float parentSizeScale = 1.f);
	EntityDefinition* builtEntity = nullptr;
};

struct MoveEffectEntry {
public:
	Vec2 spawnPosition = Vec2();
	float moveEffectSize = 0.5f;
	float moveEffectTime = 0.6f;
	Vec2 moveEffectEjectVelocity = Vec2(10.f, 0.f);
	float moveEffectRandomSpeed = 0.f;
	MoveEffectEntry() {}
	MoveEffectEntry(const XmlElement& xmlElement, float parentSizeScale = 1.f);
};

struct WeaponDefinition {
public:
	//Core stuff
	std::string name = "";
	float turnRate = 360.f;
	float refireTime = 1.f;
	int projectileCount = 0;
	std::string projectileFired = "";
	EntityDefinition* projectileFiredEntity = nullptr;
	float projectileCone = 0.f;
	float projectileSpeed = 3.f;
	int rayCount = 0;
	float rayDamage = 1.f;
	float rayDuration = 0.25f;
	float rayDistance = 5.f;
	float rayCone = 0.f;
	Rgba8 rayColor = Rgba8();
	float rayWidth = 0.2f;
	float energyMax = 1.f;
	float energyRegen = 0.1f;
	float energyUse = 0.f;
	bool lockedWhenEnergyRechargeFromEmpty = false;
	//AI stuff
	bool onlyTargetPositiveCostTargets = false;
	bool isHealWeapon = false;
	float fireDistance = -1.f;
	float fireAngleTolerance = -1.f;
	//visual
	float brightness = 0.5f;
	float muzzleExplosionSize = -1.f;
	float muzzleExplosionTime = 0.f;
	float rayExplosionSize = -1.f;
	float rayExplosionTime = 0.f;
	int rayParticles = 0;
	float rayParticleSize = -1.f;
	float rayParticleLifeTime = 0.f;

	std::vector<Vec2> muzzles;
	std::vector<Vertex_PCU> vertexes;
	std::vector<SoundEntry> sounds;

	WeaponDefinition() {}
	WeaponDefinition(const XmlElement& xmlElement);
};

struct TurretDefinition {
public:
	float direction = 0.f;
	float limitingAngle = 181.f;
	bool useParentAttackTarget = true;
	bool canSearchTarget = false;
	bool installedAtBottom = false;
	Vec2 mountPosition = Vec2();
	WeaponDefinition weaponMounted;

	TurretDefinition() {}
	TurretDefinition(const XmlElement& xmlElement, float parentSizeScale = 1.f);
};

struct EntityDefinition {
public:
	//Core stuff
	std::string name = "";
	std::string description = "";
	float maxHealth = 1.f;
	float armor = 0.f;
	float mass = 1.f;
	float healthRegen = 0.f;
	float lifespan = -1.f;
	float impactDamage = 0.f;
	float buildPower = 1.f;
	float deathExplosionAreaDamage = 0.f;
	float deathExplosionAreaRadius = -1.f;
	bool isProjectile = false;
	bool isBuilder = false;
	bool isBaseDefense = false;
	int price = 0;
	int creditGeneration = 0;
	//Asteriod have quite some special behaviors
	bool isAsteriod = false;
	//physics
	bool reemergeAtEdge = false;
	bool dieAtEdge = false;
	bool collideWithAllies = true;
	//other entities check collision against this entity, but this entity doesn't check collision against other entities
	//True for basic bullets.
	bool passiveCollisionCheck = false; 
	float physicsRadius = 1.f;
	float forwardAcceleration = 10.f;
	float backwardAccelerationRatio = 0.5f;
	float turnSpeed = 100.f;
	float speedDecayRate = 0.5f;
	//AI
	bool uncontrollable = false;
	bool isSelectable = true;
	bool turnToFire = true;
	bool proximityFuse = false;
	bool onlyTargetPositiveCostTargets = false;
	float engageMaxDistance = 100.f;
	float engageMinDistance = 20.f;
	float followMaxDistance = 10.f;
	float attckMoveSearchExtraRadius = 50.f;
	//visuals
	float cosmeticRadius = 0.2f;
	float brightness = 1.f;
	int numDebrisOnDeath = 0;
	float debrisSizeModifier = 2.f;
	float debrisLifeTime = 2.f;
	float explosionSize = 3.f;
	float explosionTime = 0.f;
	float explosionFadeInTimeRatio = 0.18f;
	float moveEffectRate = 0.2f;
	float fadeInTimeRatio = 0.f;
	float fadeOutTimeRatio = 0.f;
	std::vector<Vertex_PCU> vertexes;
	std::vector<MoveEffectEntry> moveEffects;
	//sounds
	std::vector<SoundEntry> sounds = {};
	std::vector<BuildEntry> buildOptions = {};
	std::vector<TurretDefinition> turrets = {};

	EntityDefinition() {}
	EntityDefinition(const XmlElement& xmlElement);
	static void ReadVertexFromXmlElement(std::vector<Vertex_PCU> & verts, const XmlElement& xmlElement, float sizeScale = 1.f);
	static void ReadVertexQuadFromXmlElement(std::vector<Vertex_PCU>& verts, const XmlElement& xmlElement, float sizeScale = 1.f);
	static void ReadVertexLightFromXmlElement(std::vector<Vertex_PCU>& verts, const XmlElement& xmlElement, float sizeScale = 1.f);
};


extern const Rgba8 g_UITextColor;
extern const Rgba8 g_UITextActiveColor;
extern const Rgba8 g_UITextHighLightColor;


class App
{
public:
	friend class Game;

	Game* m_game = nullptr;
	void Run();

	App();								// default constructor
	~App();
	const std::string m_Title = "Prince Rystiya's Starfleet";
	void Startup();
	void RunFrame();
	void Shutdown();

	//System stuff
	bool IsKeyDown(unsigned char charInInt) const;
	bool IsKeyUp(unsigned char charInInt) const;
	bool WasKeyJustPressed(unsigned char charInInt) const;
	bool WasKeyJustUp(unsigned char charInInt) const;

	SoundID GetSoundResourceByName(std::string soundFilePath);
	void PlayIntefaceSound() const;
	void PlayErrorSound() const;
	void PlayStartSound() const;
	void PlayExitSound() const;
	void PlayUnitReadySound() const;
	float GetFrameRate() const { return 1.f / m_averageSecondPerFrame; }
	float GetCurrentTimeScale() const { return m_currentTimeScale; }
	int GetCurrentTimeScalePow() const { return m_currentTimeScalePow; }

	//Getters
	std::vector<EntityDefinition> const& GetEntityTypes() const { return m_entityTypes; }
	std::vector<WeaponDefinition> const& GetWeaponTypes() const { return m_weaponTypes; }
	std::vector<SoundID> const& GetBackgroundMusics() const { return m_backgroundMusics; }
	bool GetIsPuased() const { return m_isPaused; }
	EntityDefinition* GetEntityTypeByName(std::string entityType);
	WeaponDefinition* GetWeaponTypeByName(std::string weaponType);
	BitmapFont const& GetBitmapFont() const { return *m_myTexturedFont; }
	GameState GetCurrentGameState() const { return m_currentGameState; }

	RandomNumberGenerator* m_rnd = nullptr;
	void RandomlyResetBackgroundMusic();

private:
	//App state
	bool m_isQuitting = false;
	bool m_isPaused = false;
	GameState m_currentGameState = GameState::inMenu;

	Clock* m_gamePlayBaseClock = nullptr;
	float m_currentTimeScale = 1.f;
	int m_currentTimeScalePow = 0;

	std::vector<EntityDefinition> m_entityTypes;
	std::vector<WeaponDefinition> m_weaponTypes;
	std::vector<SoundID> m_backgroundMusics;

	void LoadAssets();
	float GetUpdateAmount();
	void BeginFrame();
	void Update();
	void Render() const;
	void EndFrame();
	void AdjustGameStateWithInput();
	static bool HandleExitEvent(EventArgs& eventData);
	bool m_pauseNextFrame = false;
	float m_averageSecondPerFrame = 1.f;
	BitmapFont* m_myTexturedFont = nullptr;
	//Sound stuff
	SoundID m_intefaceSound = (SoundID)0;
	SoundID m_errorSound = (SoundID)0;
	SoundID m_enterGameSound = (SoundID)0;
	SoundID m_exitGameSound = (SoundID)0;
	SoundID m_unitReadySound = (SoundID)0;
	SoundPlaybackID m_currentBackgroundMusic = (SoundID)0;
};


