#pragma once
#include "Game\App.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Input\InputSystem.hpp"
#include "Engine\Audio\AudioSystem.hpp"
#include "Engine\Window\Window.hpp"

enum class Faction { player, enemy, neutral };
constexpr int NUMBER_OF_FACTIONS = 3;
constexpr int NUMBER_OF_SKIRMISHES = 5;
constexpr int NUMBER_OF_CHALLENGES = 9;
enum class WaypointType { move, attack, attackMove, follow, none};
enum class UIRenderingPass { selectionCircle, infoBar, waypointLine, screenWidgetsBottom, screenWidgets};
enum class WorldRenderingPass {background, effectsBottom,  units, projectiles, effectsTop};
enum class MapMode { arena, skirmish };
enum class MapState { notStarted, normal, won, lost };

extern InputSystem* g_theInputSystem;
extern AudioSystem* g_theAudioSystem;
extern Renderer *g_theRenderer;
extern App* g_theApp;
extern Window* g_theWindow;

constexpr float GLOBAL_GAME_SPEED_MODIFIER = 0.65f;

constexpr float MOUSE_SIZE_TIP = 80.f;
constexpr float MOUSE_SIZE_WIDTH = 30.f;
constexpr float MOUSE_SCALE_OUTER = 0.2f;
constexpr float MOUSE_SCALE_INNER = 0.15f;
//Not work if 1 or less, for some reason...
constexpr float UI_LINE_WIDTH = 1.5f;
constexpr float UI_LINE_WIDTH_WORLD = 0.2f;

//Time stuff
//Will only slow down the game when frame rate is less than 1 / MAX_FRAME_TIME_STEP.
//If bullet speed reach 100 or higher, it will move 100 * MAX_FRAME_TIME_STEP distance each frame... 
//If MAX_FRAME_TIME_STEP is big, bullet might bypass targets, especially missiles!!! 
constexpr float MAX_FRAME_TIME_STEP = 0.1f;
constexpr float PHYSICS_TIME_STEP = 0.003f;
constexpr int MIN_TIME_SCALE_POW = -5;
constexpr int MAX_TIME_SCALE_POW = 5;
constexpr float TIME_SCALE_POW_BASE = 1.5f;


constexpr float WORLD_SIZE_ARENA_X = 1000.f;
constexpr float WORLD_SIZE_ARENA_Y = 1000.f;

constexpr float WORLD_CAMERA_SIZE_X = 200.f;
constexpr float STARFIELD1_CAMERA_EXTRA_SIZE_X = 9000.f;
constexpr float STARFIELD2_CAMERA_EXTRA_SIZE_X = 13500.f;
constexpr float STARFIELD3_CAMERA_EXTRA_SIZE_X = 20000.f;
constexpr float STARFIELD_DENSITY_FACTOR = 0.0005f;
constexpr float STARFIELD_STAR_SIZE_FACTOR = 30.f;
constexpr float ZOOM_LEVEL_MIN = 0.25f;
constexpr float ZOOM_LEVEL_MAX = 2.f;
constexpr float SCREEN_CAMERA_SIZE_X = 1600.f;
constexpr float MINIMAP_DEFAULT_SIZE_X = 400.f;
constexpr float MINIMAP_DOT_SIZE_SCALE = 0.67f;
constexpr float SIDE_SCROLL_MARGIN = 0.03f;
constexpr float SIDE_SCROLL_SPEED = 10.f;

constexpr int BATCH_BUILD_BATCH_SIZE = 10;
constexpr int SKIRMISH_STARTING_CREDITS = 2000;
constexpr float ASTEROID_SIZE_FACTOR = 1.5f;
constexpr float ASTEROID_MAX_AFFINITY = 7.5f;
constexpr float ASTEROID_RESOURCE_RATE = 0.03f;
constexpr float AOE_IMPULSE_FACTOR = 2.f;

constexpr uint64_t UID_ID_OFFSET = 1000000;
constexpr uint64_t UID_INVALID = 0l;
constexpr uint64_t  CONTROL_GROUP_COUNT = 10;
constexpr float MOVE_WAYPOINT_DISTANCE_TOLERANCE = 6.f;
constexpr float MOVE_WAYPOINT_SPEED_TOLERANCE_SQUARED = 100.f;
constexpr float AI_UNIT_SEARCH_RANGE = 350.f;
constexpr float AI_MISSILE_SEARCH_RANGE = 135.f;
constexpr float AI_SEARCH_RATE = 0.1f;
constexpr float DEBRIS_SCATTER_VELOCITY_FACTOR = 6.f;
constexpr float DEBRIS_SPIN_SPEED_FACTOR = 10.f;

constexpr float TIME_TO_STAY_IN_MAP_AFTER_WIN_OR_LOSE = 10.f;
constexpr float WIN_OR_LOSE_CHECK_RATE = 1.f;