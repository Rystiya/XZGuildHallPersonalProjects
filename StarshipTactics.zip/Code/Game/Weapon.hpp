#pragma once
#include "Game\Entity.hpp"

class Entity;

//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class Weapon
{
	friend class Entity;
public:
	// Construction/Destruction
	virtual ~Weapon();
	Weapon(Entity* owner, WeaponDefinition const& theDefinition, Vec2 mountPosition = Vec2(), float mountOrientation = 0.f, float limitingAngle = 181.f, bool useParentAttackTarget = false, bool canSearchTarget = false);

	void Update(float deltaSeconds);
	void Render() const;
	Rgba8 GetFactionColor() const;
	bool TargetWithinArcOfFire(Vec2 targetPosition) const;
	bool TargetWithinSectorOfFire(Vec2 targetPosition, float targetSize) const;
	bool WeaponCanReach(Entity* target) const;
	bool IsWeaponReady() const;
	WeaponDefinition const* GetDefinition() const { return &m_def; }

protected:
	Entity* m_owner = nullptr;
	WeaponDefinition m_def;
	//const mounting info
	const Vec2 m_MountPosition = Vec2();
	const float m_MountOrientation = 0.f;
	const float m_LimitingAngle = 181.f;
	const bool m_UseParentAttackTarget = false;
	const bool m_CanSearchTarget = false;
	//Local stuff
	float m_localOrientation = 0.f;
	//Global stuff
	float m_globalOrientation = 0.f;
	Vec2 m_forwardNormal = Vec2();
	Vec2 m_globalPosition = Vec2();
	Vec2 m_globalMuzzlePosition = Vec2();
	Mat44 m_transformMatrix;
	//Targetting stuff
	uint64_t m_currentAttackIntentTarget = UID_INVALID;
	float m_timeAlive = 0.f;

	float m_refireTimeRemaining = 0.f;
	float m_currentEnergy = 0.f;
	float m_weaponLockedUntilEnergyFull = false;

	bool m_isOddShot = false;
	uint8_t m_currentMuzzleIndex = 0;
	void UpdatePositionalData();
	float GetLeadFiringOrientation();
	bool TurnAndFire(float deltaSeconds);
	void TryPlaySound(std::string soundName);
	void UseNextMuzzle();
	Vec2 GetGlobalPositionOfCurrentMuzzle();
	
};