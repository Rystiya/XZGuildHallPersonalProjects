#pragma once
#include "Game\Entity.hpp"


//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class LightEffect : public Entity
{
public:
	// Construction/Destruction
	~LightEffect() {}
	LightEffect(Map* parentMap, float persistTime, float size, Vec2 startingPosition, Vec2 startingVelocity, Rgba8 color = Rgba8(255, 200, 150, 255), float centerWhiteRatio = 0.4f, float fadeInTimeRatio = 0.15f, float fadeOutTimeRatio = -1.f, bool spawnAtBottom = false);



protected:
	Rgba8 m_startingColor;
	Rgba8 m_endingColor;
};