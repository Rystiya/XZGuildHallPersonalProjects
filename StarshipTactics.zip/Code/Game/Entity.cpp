
#include "Game\Entity.hpp"
#include "Game\Weapon.hpp"
#include "Game\Map.hpp"
#include "Game\Game.hpp"
#include "Game\LightEffect.hpp"
#include "Game\Debris.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include <math.h> 
#include <vector>
#include <assert.h>


Entity::~Entity() {
	for (int turretIndex = 0; turretIndex < m_turretsBottom.size(); turretIndex++) {
		delete m_turretsBottom[turretIndex];
	}
	for (int turretIndex = 0; turretIndex < m_turretsTop.size(); turretIndex++) {
		delete m_turretsTop[turretIndex];
	}
}

Entity::Entity(Map* parentMap, EntityDefinition const& theDefinition, Faction theFaction, Vec2 startingPosition, float orientation, Vec2 startingVelocity, bool isCosmeticOnly, uint64_t parentUID) {
	m_map = parentMap;
	m_faction = theFaction;
	m_position = startingPosition;
	m_orientationDegrees = orientation;
	m_UID = m_map->EntityReportBirth(this, isCosmeticOnly);
	m_parentUID = parentUID;
	m_def = theDefinition;
	m_health = m_def.maxHealth;	
	m_velocity = startingVelocity;
	//To prevent all enemies searching for targets at the same time
	m_lastAIUpdateTime = g_theApp->m_rnd->RollRandomFloatInRange(0.f, AI_SEARCH_RATE);
	for (int turretIndex = 0; turretIndex < m_def.turrets.size(); turretIndex++) {
		TurretDefinition const& currentTurret = m_def.turrets[turretIndex];
		Weapon* newWeapon = new Weapon(this, currentTurret.weaponMounted, currentTurret.mountPosition, currentTurret.direction, currentTurret.limitingAngle, currentTurret.useParentAttackTarget, currentTurret.canSearchTarget);
		if (currentTurret.installedAtBottom) {
			m_turretsBottom.push_back(newWeapon);
		}
		else {
			m_turretsTop.push_back(newWeapon);
		}
	}
	for (int buildOptionIndex = 0; buildOptionIndex < m_def.buildOptions.size(); buildOptionIndex++) {
		m_def.buildOptions[buildOptionIndex].builtEntity = g_theApp->GetEntityTypeByName(m_def.buildOptions[buildOptionIndex].name);
	}
	if (m_def.isProjectile) {
		m_myRenderingPass = WorldRenderingPass::projectiles;
	}
}


void Entity::Update(float deltaSeconds) {
	UpdatePositionalData();
	TrySpawnMoveEffects();
	m_timeAlive += deltaSeconds;
	m_health += m_def.healthRegen * deltaSeconds;
	m_health = fminf(m_health, m_def.maxHealth);
	m_currentAcceleration = 0.f;
	//m_velocity.ClampLength(ENTITY_SPEED_HARD_LIMIT);
	if (m_def.maxHealth > 0.f && m_health < 0.f) {
		Die();
	}
	if (m_def.lifespan > 0.f && m_timeAlive > m_def.lifespan) {
		Die();
	}
	if (m_timeAlive - m_lastAIUpdateTime > AI_SEARCH_RATE) {
		m_lastAIUpdateTime = m_timeAlive;
		m_doAIUpdateThisFrame = true;
	}
	else {
		m_doAIUpdateThisFrame = false;
	}
	if (!m_def.uncontrollable) {
		WaypointReceivalUpdate();
		PrioritizeProjectileParent();
		WaypointExecutionUpdate(deltaSeconds);
	}
	if (m_def.proximityFuse) {
		ProximityFuseUpdate();
	}
	for (int index = 0; index < m_turretsBottom.size(); index++) {
		m_turretsBottom[index]->Update(deltaSeconds);
	}
	for (int index = 0; index < m_turretsTop.size(); index++) {
		m_turretsTop[index]->Update(deltaSeconds);
	}
	if (m_isSelected) {
		for (int buildOptionIndex = 0; buildOptionIndex < m_def.buildOptions.size(); buildOptionIndex++) {
			m_map->SelectedEntityReportCanBuild(m_def.buildOptions[buildOptionIndex].name);
		}
	}
	if (m_def.description != "" && IsCloserThan(m_map->GetMousePositionWorld(), 0.f, true)) {
		m_map->m_game->UnitTryAddDescription(m_def.description);
	}
	UpdateActionQueue(deltaSeconds);
	UpdateAsBuilder();
	UpdateCustomBehavior(deltaSeconds);
}


void Entity::WaypointExecutionUpdate(float deltaSeconds) {
	//make sure waypoint info is valid
	if (m_currentWaypointType == WaypointType::attack || m_currentWaypointType == WaypointType::follow) {
		if (m_map->GetEntityByUID(m_waypointEntityTarget) == nullptr) {
			m_waypointEntityTarget = UID_INVALID;
			m_currentWaypointType = WaypointType::none;
		}
	}
	else {
		m_waypointEntityTarget = UID_INVALID;
	}	
	if (m_map->GetEntityByUID(m_currentAttackIntentTarget) == nullptr) {
		m_currentAttackIntentTarget = UID_INVALID;
	}
	if (m_currentWaypointType == WaypointType::move || (m_currentWaypointType == WaypointType::attackMove && m_currentAttackIntentTarget == UID_INVALID)) {
		if (IsCloserThan(m_waypointPositionTarget, MOVE_WAYPOINT_DISTANCE_TOLERANCE, true) && m_velocity.GetLengthSquared() < MOVE_WAYPOINT_SPEED_TOLERANCE_SQUARED) {
			m_currentWaypointType = WaypointType::none;
		}
	}
	//Main behaviors
	if (m_currentWaypointType == WaypointType::attack) {
		Entity* currentTarget = m_map->GetEntityByUID(m_waypointEntityTarget);
		m_currentAttackIntentTarget = m_waypointEntityTarget;
		TryEngageWithTarget(currentTarget->m_position, deltaSeconds, currentTarget->GetDefinition()->physicsRadius);
		return;
	}
	if (m_currentWaypointType == WaypointType::follow) {
		Entity* currentTarget = m_map->GetEntityByUID(m_waypointEntityTarget);
		float enemySearchRange = m_def.engageMaxDistance + m_def.attckMoveSearchExtraRadius;
		float enemyChaseRange = enemySearchRange * 1.1f;
		bool timeConsumed = TryFindAndEngageEnemiesWithinRange(currentTarget->m_position, enemySearchRange, enemyChaseRange, deltaSeconds);
		if (!timeConsumed) {
			TryFollowTarget(currentTarget->m_position, deltaSeconds, currentTarget->GetDefinition()->physicsRadius);
		}
		return;
	}
	if (m_currentWaypointType == WaypointType::move) {
		TryReachTargetLocation(m_waypointPositionTarget, deltaSeconds);
		return;
	}
	if (m_currentWaypointType == WaypointType::attackMove) {
		float enemySearchRange = m_def.engageMaxDistance + m_def.attckMoveSearchExtraRadius;
		float enemyChaseRange = enemySearchRange * 1.25f;
		bool timeConsumed = TryFindAndEngageEnemiesWithinRange(m_position, enemySearchRange, enemyChaseRange, deltaSeconds);
		if(!timeConsumed) {
			TryReachTargetLocation(m_waypointPositionTarget, deltaSeconds);
		}
		return;
	}
	if (m_currentWaypointType == WaypointType::none) {
		TryFindAndEngageEnemiesWithinRange(m_position, m_def.engageMaxDistance, m_def.engageMaxDistance * 1.1f, deltaSeconds, true);
		return;
	}
}


void Entity::PrioritizeProjectileParent() {
	if (m_currentAttackIntentTarget != m_waypointEntityTarget) {
		Entity* currentTarget = m_map->GetEntityByUID(m_currentAttackIntentTarget);
		if (currentTarget != nullptr && currentTarget->GetDefinition()->isProjectile) {
			Entity* currentTargetParent = m_map->GetEntityByUID(currentTarget->GetParentUID());
			if (currentTargetParent != nullptr && !currentTargetParent->m_isDead && currentTargetParent->IsCloserThan(m_position, m_def.engageMaxDistance)) {
				m_currentAttackIntentTarget = currentTargetParent->GetUID();
			}
		}
	}
}


void Entity::WaypointReceivalUpdate() {
	//Maunal input
	if (m_faction == Faction::player && m_def.isSelectable && !g_theApp->GetIsPuased()) {
		//Player selection
		if (g_theInputSystem->WasKeyJustDoubleReleased(KEYCODE_LEFTMOUSE)) {
			if (m_map->IsPositionInSelectionArea(m_position, m_def.cosmeticRadius)) {
				m_map->SelectAllEntitiesOfType(m_def.name, true, { m_faction });
			}
		}
		else if (g_theApp->WasKeyJustUp(KEYCODE_SPACE)) {
			SetAsSelected(false);
		}
		else if (m_map->IsSelectionAreaActive()) {
			if (g_theInputSystem->WasKeyJustPressed(KEYCODE_LEFTMOUSE)) {
				m_wasSelectedWhenLMBJustPressed = m_isSelected;
			}
			if (g_theInputSystem->IsKeyDown(KEYCODE_SHIFT) == g_theInputSystem->IsKeyDown(KEYCODE_CTRL)) {
				if (m_map->IsPositionInSelectionArea(m_position, m_def.cosmeticRadius)) {
					SetAsSelected(true);
				}
				else {
					SetAsSelected(false);
				}
			}
			else if (g_theInputSystem->IsKeyDown(KEYCODE_SHIFT)) {
				if (m_map->IsPositionInSelectionArea(m_position, m_def.cosmeticRadius)) {
					SetAsSelected(true);
				}
				else {
					SetAsSelected(m_wasSelectedWhenLMBJustPressed);
				}
			}
			else if (g_theInputSystem->IsKeyDown(KEYCODE_CTRL)) {
				if (m_map->IsPositionInSelectionArea(m_position, m_def.cosmeticRadius)) {
					SetAsSelected(false);
				}
				else {
					SetAsSelected(m_wasSelectedWhenLMBJustPressed);
				}
			}
		}
		else {  //Manage control groups
			for (uint8_t currentControlGroup = 1; currentControlGroup <= CONTROL_GROUP_COUNT; currentControlGroup++) {
				unsigned char currentControlGroupKeyCode = '1' - 1 + currentControlGroup;
				if (g_theApp->WasKeyJustUp(currentControlGroupKeyCode)) {
					if (!g_theInputSystem->IsKeyDown(KEYCODE_CTRL) && m_controlGroup == currentControlGroup) {
						SetAsSelected(true);
					}
					if (!g_theInputSystem->IsKeyDown(KEYCODE_CTRL) && m_controlGroup != currentControlGroup && !g_theInputSystem->IsKeyDown(KEYCODE_SHIFT)) {
						SetAsSelected(false);
					}
					if (g_theInputSystem->IsKeyDown(KEYCODE_CTRL) && !m_isSelected && m_controlGroup == currentControlGroup && !g_theInputSystem->IsKeyDown(KEYCODE_SHIFT)) {
						m_controlGroup = CONTROL_GROUP_COUNT + 1;
					}
					if (g_theInputSystem->IsKeyDown(KEYCODE_CTRL) && m_isSelected) {
						m_controlGroup = currentControlGroup;
					}
				}
			}
		}
		//player give orders
		if (m_isSelected) {
			if (g_theInputSystem->WasKeyJustDoubleReleased(KEYCODE_RIGHTMOUSE)) {
				AddWaypoint(WaypointType::attackMove, UID_INVALID, m_map->GetMousePositionWorld());
			}
			if (g_theInputSystem->WasKeyJustSingleReleased(KEYCODE_RIGHTMOUSE)) {
				EntitySearchFilter attackSearchFilter;
				attackSearchFilter.positiveCostOnly = m_def.onlyTargetPositiveCostTargets;
				attackSearchFilter.onlyIncludeFactions = ValidTargetsOf(m_faction);
				attackSearchFilter.seletableOnly = true;
				attackSearchFilter.returnOnlyOneResult = true;
				Vec2 mouseInWorldPos = m_map->GetMousePositionWorld();
				std::vector<Entity*> enemiesClickedOn = m_map->FindEntities(mouseInWorldPos, 0.f, attackSearchFilter);
				if (enemiesClickedOn.size() > 0) {
					AddWaypoint(WaypointType::attack, enemiesClickedOn[0]->GetUID(), Vec2());
				}
				else {
					EntitySearchFilter followSearchFilter = attackSearchFilter;
					followSearchFilter.onlyIncludeFactions = { m_faction };
					std::vector<Entity*> alliesClickedOn = m_map->FindEntities(mouseInWorldPos, 0.f, followSearchFilter);
					if (alliesClickedOn.size() > 0) {
						AddWaypoint(WaypointType::follow, alliesClickedOn[0]->GetUID(), Vec2());
					}
					else {
						AddWaypoint(WaypointType::move, UID_INVALID, m_map->GetMousePositionWorld());
					}
				}
			}
		}
		if (g_theApp->WasKeyJustUp('S')) {
			AddWaypoint(WaypointType::none, UID_INVALID, Vec2());
		}
	} 
	//Ai input
	if (m_doAIUpdateThisFrame) {
		//This is for missiles of any side
		if (!m_def.isSelectable) {
			if (m_currentWaypointType == WaypointType::none) {
				Entity* parentRemembered = m_map->GetEntityByUID(m_parentUID);
				if (parentRemembered != nullptr) {
					Entity* parentTarget = m_map->GetEntityByUID(parentRemembered->GetCurrentAttackIntentTargetUID());
					if (parentTarget != nullptr) {
						AddWaypoint(WaypointType::attack, parentTarget->GetUID(), parentTarget->m_position);
						m_map->ShareWaypointWithNearbyAllies(this, 100.f, false);
					}
				}
			}
			if (m_currentWaypointType == WaypointType::none) {
				//Try search for enemy if still no target
				EntitySearchFilter searchFilter;
				searchFilter.positiveCostOnly = m_def.onlyTargetPositiveCostTargets;
				searchFilter.onlyIncludeFactions = EnemiesOf(m_faction);
				searchFilter.noneBulletOnly = true;
				searchFilter.canCollideOnly = true;
				std::vector<Entity*> potentialTargets = m_map->FindEntities(m_position, AI_MISSILE_SEARCH_RANGE, searchFilter);
				if (potentialTargets.size() > 0) {
					int randomIndex = g_theApp->m_rnd->RollRandomIntInRange(0, static_cast<int>(potentialTargets.size() - 1));
					AddWaypoint(WaypointType::attack, potentialTargets[randomIndex]->GetUID(), potentialTargets[randomIndex]->m_position);
					m_map->ShareWaypointWithNearbyAllies(this, 100.f, false);
				}
			}
			if (m_currentWaypointType == WaypointType::none) {
				//If a missile cannot find its target, when destroy it
				Die();
			}
			
		}
		//This is for ai controled units
		if (m_def.isSelectable && m_faction != Faction::player && m_faction != Faction::neutral && !m_noMoreWaypoints) {
			if (m_currentWaypointType == WaypointType::none) {
				EntitySearchFilter searchFilter;
				searchFilter.positiveCostOnly = m_def.onlyTargetPositiveCostTargets;
				searchFilter.onlyIncludeFactions = EnemiesOf(m_faction);
				searchFilter.noneBulletOnly = true;
				searchFilter.canCollideOnly = true; 
				std::vector<Entity*> potentialTargets = m_map->FindEntities(m_position, AI_UNIT_SEARCH_RANGE, searchFilter);
				if (potentialTargets.size() > 0) {
					int randomIndex = g_theApp->m_rnd->RollRandomIntInRange(0, static_cast<int>(potentialTargets.size() - 1));
					AddWaypoint(WaypointType::attackMove, potentialTargets[randomIndex]->GetUID(), potentialTargets[randomIndex]->m_position);
					m_map->ShareWaypointWithNearbyAllies(this, 100.f, false);
				}
			}
			if (m_currentWaypointType == WaypointType::none) {
				WaypointType desiredWaypointType = WaypointType::attackMove;
				EntitySearchFilter searchFilter2;
				//Move to random asteriods or enemy builders
				float siegeChance = static_cast<float>(m_def.price) / 5000.f;
				if (m_def.isBuilder) {
					siegeChance = 0.f;
					desiredWaypointType = WaypointType::move;
				}
				if (g_theApp->m_rnd->RollRandomFloatZeroToOne() > siegeChance) {
					searchFilter2.asteroidOnly = true;
				}
				else {
					searchFilter2.builderOnly = true;
					searchFilter2.onlyIncludeFactions = EnemiesOf(m_faction);
				}
				std::vector<Entity*> regroupTargets = m_map->FindEntities(m_position, -100.f, searchFilter2);
				if (regroupTargets.size() > 0) {
					Entity* regroupTarget = regroupTargets[g_theApp->m_rnd->RollRandomIntInRange(0, static_cast<int>(regroupTargets.size() - 1))];
					AddWaypoint(desiredWaypointType, regroupTarget->GetUID(), regroupTarget->m_position);
					if (m_def.isBaseDefense) {
						//Base defense will not try to go anywhere else after reaching its destination
						m_noMoreWaypoints = true;
						m_waypointPositionTarget += Vec2(g_theApp->m_rnd->RollRandomFloatInRange(-40.f, 40.f), g_theApp->m_rnd->RollRandomFloatInRange(-40.f, 40.f));
					}
					m_map->ShareWaypointWithNearbyAllies(this, 175.f, false);
				}
			}
		}
	}

}


void Entity::UpdateActionQueue(float deltaSeconds) {
	float progressCanMake = deltaSeconds * m_def.buildPower;
	while (m_actionQueue.size() > 0 && progressCanMake > TINY_POSITIVE_NUMBER) {
		if (m_actionQueue.front().m_remainingTime > progressCanMake) {
			m_actionQueue.front().m_remainingTime -= progressCanMake;
			progressCanMake = 0.f;
		}
		else {
			ExecuteQueuedAction(m_actionQueue.front());
			progressCanMake -= m_actionQueue.front().m_remainingTime;
			m_actionQueue.pop();
		}
	}
}

void Entity::GenerateResources() {
	int creditsToGenerate = m_def.creditGeneration;
	if (m_faction != Faction::player) {
		creditsToGenerate = static_cast<int>(creditsToGenerate * m_map->GetAiResourceModifier());
	}
	m_map->AddCredits(m_faction, creditsToGenerate);
}

void Entity::UpdateAsBuilder() {
	if (m_def.buildOptions.size() < 1) {
		return;
	}
	if (m_faction == Faction::player) {
		QueueBuildActionAsPlayerCommands();
	}
	else if (m_faction != Faction::neutral) {
		QueueBuildActionAsAICommands();
	}
}

void Entity::ProximityFuseUpdate() {
	Entity* storedTemporaryTarget = m_map->GetEntityByUID(m_proximityFuseTarget);
	if (storedTemporaryTarget == nullptr) {
		m_proximityFuseTarget = UID_INVALID;
	}
	if (m_proximityFuseTarget == UID_INVALID) {
		m_proximityFuseTargetSquaredDistance = -1.f;
		float proximityFuseTriggerDistance = m_def.deathExplosionAreaRadius * 0.5f;
		EntitySearchFilter searchFilter;
		searchFilter.positiveCostOnly = m_def.onlyTargetPositiveCostTargets;
		searchFilter.onlyIncludeFactions = ValidTargetsOf(m_faction);
		searchFilter.noneBulletOnly = true;
		searchFilter.canCollideOnly = true;
		searchFilter.returnOnlyOneResult = true;
		std::vector<Entity*> potentialTargets = m_map->FindEntities(m_position, proximityFuseTriggerDistance, searchFilter);
		if (potentialTargets.size() > 0) {
			m_proximityFuseTarget = potentialTargets[0]->GetUID();
		}
	}
	if (m_proximityFuseTarget != UID_INVALID) {
		float currentProximityFuseSquaredDistance = GetDistanceSquared2D(m_position, m_map->GetEntityByUID(m_proximityFuseTarget)->m_position);
		if (currentProximityFuseSquaredDistance > m_proximityFuseTargetSquaredDistance && m_proximityFuseTargetSquaredDistance > 0.f) {
			Die();
		}
		m_proximityFuseTargetSquaredDistance = currentProximityFuseSquaredDistance;
	}
}

void Entity::PhysicsUpdate(float deltaSeconds) {
	m_velocity += GetForwardNormal() * m_currentAcceleration * deltaSeconds;
	m_position += deltaSeconds * m_velocity;
	//m_orientationDegrees = AddAngle(m_orientationDegrees, deltaSeconds * m_def.turnSpeed);
	m_velocity *= 1.f - m_def.speedDecayRate * deltaSeconds;
	m_map->TryCollideWithAllEntities(this);
	if (m_def.dieAtEdge) {
		DieIfAtEdge();
	}
	if (m_def.reemergeAtEdge) {
		ReemergeIfOutOfWorld();
	}
	else {
		BounceIfAtEdge();
	}
}

void Entity::Render(WorldRenderingPass renderingPass) const {
	if (renderingPass != m_myRenderingPass) {
		return;
	}
	for (int index = 0; index < m_turretsBottom.size(); index++) {
		m_turretsBottom[index]->Render();
	}
	//Tried to use alternative blend mode on explosions, but it didn't work
	//g_theRenderer->m_desiredBlendMode = m_blendMode;
	Rgba8 tintColor = GetMyFactionColor() * m_def.brightness;
	if (m_def.lifespan > TINY_POSITIVE_NUMBER) {
		float currentLifeSpanRatio = m_timeAlive / m_def.lifespan;
		if (currentLifeSpanRatio < m_def.fadeInTimeRatio) {
			tintColor.a = uint8_t(255 * currentLifeSpanRatio / m_def.fadeInTimeRatio);
		}
		else if(1.f - currentLifeSpanRatio < m_def.fadeOutTimeRatio) {
			tintColor.a = uint8_t(255 * (1.f - currentLifeSpanRatio) / m_def.fadeOutTimeRatio);
		}
	} else {
		tintColor.a = 255;
	}
	g_theRenderer->SetModelConstants(GetModelMatrix(), tintColor);
	g_theRenderer->DrawVertexVector(m_def.vertexes);
	for (int index = 0; index < m_turretsTop.size(); index++) {
		m_turretsTop[index]->Render();
	}
}

void Entity::AddVertsForUI(std::vector<Vertex_PCU>& verts, UIRenderingPass randeringPass) const {
	if (randeringPass == UIRenderingPass::infoBar) {
		Vec2 barPosition = m_position - Vec2(0.f, 0.25f * m_def.cosmeticRadius);
		float barWidth = (0.65f + 0.025f * m_def.cosmeticRadius) * m_map->GetZoomLevel();
		if (m_def.maxHealth >= 0.f) {
			g_theRenderer->AddVertsForHealthBar(verts, barPosition, m_def.cosmeticRadius, m_health, m_def.maxHealth, barWidth);
		}
		if (m_actionQueue.size() > 0) {
			g_theRenderer->AddVertsForEnergyBar(verts, barPosition, m_def.cosmeticRadius, m_actionQueue.front().m_totalTime - m_actionQueue.front().m_remainingTime, m_actionQueue.front().m_totalTime, barWidth);
		}
		return;
	}
	if (randeringPass == UIRenderingPass::selectionCircle && m_isSelected) {
		Rgba8 ringColor = GetMyFactionColor() * 0.5f + Rgba8() * 0.5f;
		AddVertsForRing(verts, m_position, m_def.cosmeticRadius * 0.85f, 10 + static_cast<int>(2 * m_def.cosmeticRadius), m_map->GetZoomLevel() * UI_LINE_WIDTH_WORLD, ringColor);
		return;
	}
	bool showAllWaypoints = true;
	#ifdef NDEBUG
		showAllWaypoints = false;
	#endif
	if (randeringPass == UIRenderingPass::waypointLine && (m_isSelected || showAllWaypoints)) {
		if (m_currentWaypointType == WaypointType::attack) {
			Entity* attackWaypointTarget = m_map->GetEntityByUID(m_waypointEntityTarget);
			if (attackWaypointTarget != nullptr) {
				AddVertsForLine2D(verts, m_position, attackWaypointTarget->m_position, m_map->GetZoomLevel() * UI_LINE_WIDTH_WORLD, Rgba8(255, 75, 75, 255));
			}
		}
		if (m_currentWaypointType == WaypointType::follow) {
			Entity* followWaypointTarget = m_map->GetEntityByUID(m_waypointEntityTarget);
			if (followWaypointTarget != nullptr) {
				AddVertsForLine2D(verts, m_position, followWaypointTarget->m_position, m_map->GetZoomLevel() * UI_LINE_WIDTH_WORLD, Rgba8(0, 255, 255, 255));
			}
		}
		if (m_currentWaypointType == WaypointType::move) {
			AddVertsForLine2D(verts, m_position, m_waypointPositionTarget, m_map->GetZoomLevel() * UI_LINE_WIDTH_WORLD, Rgba8(75, 255, 75, 255));
		}
		if (m_currentWaypointType == WaypointType::attackMove) {
			AddVertsForLine2D(verts, m_position, m_waypointPositionTarget, m_map->GetZoomLevel() * UI_LINE_WIDTH_WORLD, Rgba8(255, 255, 0, 255));
		}
		if (m_currentAttackIntentTarget != m_waypointEntityTarget) {
			Entity* attackTarget = m_map->GetEntityByUID(m_currentAttackIntentTarget);
			if (attackTarget != nullptr) {
				AddVertsForLine2D(verts, m_position, attackTarget->m_position, m_map->GetZoomLevel() * UI_LINE_WIDTH_WORLD, Rgba8(125, 125, 125, 125));
			}
		}
		return;
	}
	if (randeringPass == UIRenderingPass::screenWidgets && !(m_def.isProjectile && m_def.maxHealth <= 0.f)) {
		AABB2 minimapArea = m_map->GetMinimapArea();
		Vec2 positionOnMinimap = m_map->RangeMapPositionToMinimap(m_position, minimapArea);
		float sizeOnMinimap = MINIMAP_DOT_SIZE_SCALE * (minimapArea.GetDimensions().x + minimapArea.GetDimensions().y) * 0.0008f * (4.f + m_def.cosmeticRadius);
		AABB2 minimapDot;
		minimapDot.SetCenter(positionOnMinimap);
		minimapDot.SetDimensions(Vec2(sizeOnMinimap, sizeOnMinimap));
		AddVertsForAABB2(verts, minimapDot, GetMyFactionColor());
	}
}

bool Entity::TakeDamage(float damage, bool ignoreArmor) {
	if (damage <= 0.f) {
		m_health = fminf(m_health - damage, m_def.maxHealth);
		return true;
	}
	if (m_def.maxHealth <= 0.f) {
		return false;
	}
	if (!ignoreArmor) {
		float effectiveArmor = m_def.armor;
		float effectiveArmorCap = damage * 3.f;
		if (effectiveArmor > effectiveArmorCap) {
			effectiveArmor = sqrtf(m_def.armor * effectiveArmorCap);
		}
		float ratioOfDamageThroughArmor = damage / (damage + effectiveArmor);
		m_health -= damage * ratioOfDamageThroughArmor;
	}
	else {
		m_health -= damage;
	}
	if (m_health < 0.f) {
		Die();
	}
	return true;
}

void Entity::TakeImpulse(Vec2 ImpulseNorm, float intensity) {
	float velocityChange = intensity / m_def.mass;
	float velocityChangeMax = 30.f;
	if (velocityChange > velocityChangeMax) {
		velocityChange = sqrtf(velocityChange * velocityChangeMax);
	}
	m_velocity += velocityChange * ImpulseNorm;
}

void Entity::HandleCollisionAgainst(Entity* other) {
	if ((m_def.isProjectile || other->GetDefinition()->isProjectile) && (m_faction != other->m_faction || m_def.impactDamage < -1.f * TINY_POSITIVE_NUMBER || other->GetDefinition()->impactDamage < -1.f * TINY_POSITIVE_NUMBER)) {
		if (m_def.isProjectile && other->GetDefinition()->isProjectile) {
			//If both are projectiles
			if (m_def.maxHealth < -1.f * TINY_POSITIVE_NUMBER) {
				Die();
			}
			else {
				float damageToTake = 0.f;
				damageToTake = fmaxf(other->GetDefinition()->impactDamage, damageToTake);
				damageToTake = fmaxf((1.f + TINY_POSITIVE_NUMBER) * other->GetDefinition()->maxHealth, damageToTake);
				TakeDamage(damageToTake, true);
			}
		}
		else if (m_def.isProjectile)  {
			//If only me is projectile
			Die();
		}
		else {
			//If only the other is projectile
			TakeDamage(other->GetDefinition()->impactDamage);
		}
	}
	else {
		TakeDamage(other->GetDefinition()->impactDamage);
	}
	TryPlaySound("Hit");
}

void Entity::Die() {
	if (m_isDead || m_isGarbage) {
		return;
	}
	m_isDead = true;
	m_isGarbage = true;
	m_timeAlive = -99999999.f;
	std::vector<Faction> affectFactions;
	if (fabsf(m_def.deathExplosionAreaDamage > TINY_POSITIVE_NUMBER)) {
		if (m_def.deathExplosionAreaDamage >= 0.f) {
			affectFactions = ValidTargetsOf(m_faction);
		}
		else {
			affectFactions = FriendliesOf(m_faction);
		}
		m_map->DoAreaDamage(m_position, m_def.deathExplosionAreaRadius, m_def.deathExplosionAreaDamage, {}, affectFactions);
	}
	for (int debrisIndex = 0; debrisIndex < m_def.numDebrisOnDeath; debrisIndex++) {
		continue;
	}
	TryPlaySound("Death");
	//Spawn debris first and light second, so light is drawn on top
	if (m_def.debrisLifeTime > 0.f) {
		for (int debrisSpawned = 0; debrisSpawned < m_def.numDebrisOnDeath; debrisSpawned++) {
			new Debris(m_map, m_def.debrisLifeTime, m_def.debrisSizeModifier, m_def.cosmeticRadius, m_position, m_velocity, GetMyFactionColor());
		}
	}
	if (m_def.explosionTime > 0.f && m_def.explosionSize > 0.f) {
		Vec2 explosionEffectVelocity = m_velocity;
		if (m_def.isProjectile) {
			explosionEffectVelocity *= 0.25f;
		}
		new LightEffect(m_map, m_def.explosionTime, m_def.explosionSize, m_position, explosionEffectVelocity, GetMyFactionColor(), 0.6f, m_def.explosionFadeInTimeRatio);
	}
}


bool Entity::IsOutOfWorld(float maxMargin) const {
	return m_map->GetMapArea().IsPointOutOfAABB2Fast(m_position, maxMargin);
}

bool Entity::NeedsHealing() const {
	return m_def.maxHealth > TINY_POSITIVE_NUMBER && m_def.maxHealth - m_health > TINY_POSITIVE_NUMBER;
}

void Entity::BounceIfAtEdge() {
	AABB2 mapBounds = m_map->GetMapArea();
	if (m_position.x - m_def.physicsRadius < mapBounds.m_mins.x && m_velocity.x < 0) {
		//Could get infinitely fast if this doesn't reduce speed and the speed cap is removed...
		m_velocity.x *= -0.75f;
		m_velocity.y *= 1.f;
	}
	if (m_position.x + m_def.physicsRadius > mapBounds.m_maxs.x && m_velocity.x > 0) {
		m_velocity.x *= -0.75f;
		m_velocity.y *= 1.f;
	}
	if (m_position.y - m_def.physicsRadius < mapBounds.m_mins.y && m_velocity.y < 0) {
		m_velocity.x *= 1.f;
		m_velocity.y *= -0.75f;
	}
	if (m_position.y + m_def.physicsRadius > mapBounds.m_maxs.y && m_velocity.y > 0) {
		m_velocity.x *= 1.f;
		m_velocity.y *= -0.75f;
	}
}


void Entity::ReemergeIfOutOfWorld() {
	AABB2 mapBounds = m_map->GetMapArea();
	if (IsOutOfWorld(m_def.cosmeticRadius)) {
		if (m_position.x < mapBounds.m_mins.x || m_position.x > mapBounds.m_maxs.x) {
			float xVectorTowardsCenter = mapBounds.GetCenter().x * 0.5f - m_position.x;
			if (m_velocity.x * xVectorTowardsCenter < 0) {
				m_position.x += 2 * xVectorTowardsCenter;
			}
		}
		else {
			float yVectorTowardsCenter = mapBounds.GetCenter().y * 0.5f - m_position.y;
			if (m_velocity.y * yVectorTowardsCenter < 0) {
				m_position.y += 2 * yVectorTowardsCenter;
			}
		}
	}
}

void Entity::DieIfAtEdge() {
	if (IsOutOfWorld(m_def.cosmeticRadius)) {
		Die();
	}
}



//Graphics stuff---------------------------------------------------------------------------------------------------------


void Entity::UpdatePositionalData() {
	m_transformMatrix = Mat44();
	m_transformMatrix.SetTranslation3D(m_position);
	m_transformMatrix.Append(Mat44::CreateZRotationDegrees(m_orientationDegrees));
	m_forwardNormal = Vec2::MakeFromPolarDegrees(m_orientationDegrees);
}


Rgba8 Entity::GetMyFactionColor() const {
	return GetFactionStandardColor(m_faction);
}


void Entity::AddWaypoint(WaypointType type, uint64_t waypointEntityTarget, Vec2 waypointPositionTarget) {
	if (m_noMoreWaypoints) {
		return;
	}
	m_currentWaypointType = type;
	if (type == WaypointType::attack || type == WaypointType::follow) {
		assert(m_map->GetEntityByUID(waypointEntityTarget) != nullptr);
		m_waypointEntityTarget = waypointEntityTarget;
	}
	if (type == WaypointType::attackMove || type == WaypointType::move) {
		m_waypointPositionTarget = m_map->ClampPositionIntoMap(waypointPositionTarget);
	}
}


uint64_t Entity::GetCurrentFollowingTargetUID() const {
	if (m_currentWaypointType != WaypointType::follow) {
		return UID_INVALID;
	}
	return m_waypointEntityTarget;
}

void Entity::TryPlaySound(std::string soundName) {
	for (int index = 0; index < m_def.sounds.size(); index++) {
		if (m_def.sounds[index].name == soundName) {
			m_map->PlaySoundAt(m_def.sounds[index].soundResourceHandle, m_def.sounds[index].volume, m_position);
			return;
		}
	}
}

Vec2 Entity::GetGlobalPositionFromLocalPosition(Vec2 localPosition) const {
	Vec2 sidewardNormal = m_forwardNormal.GetRotated90Degrees();
	return m_position + m_forwardNormal * localPosition.x + sidewardNormal * localPosition.y;
}

Vec2 Entity::GetGlobalVelocityFromLocalVelocity(Vec2 localVelocity) const {
	Vec2 sidewardNormal = m_forwardNormal.GetRotated90Degrees();
	Vec2 relativeVelocity = m_forwardNormal * localVelocity.x + sidewardNormal * localVelocity.y;
	return m_velocity + relativeVelocity;
}


void Entity::SetAsSelected(bool isSelected) {
	m_isSelected = isSelected;
}

void Entity::QueueBuildActionAsPlayerCommands() {
	std::string intendBuild = m_map->m_game->GetPlayerIntendBuildUnit();
	int intendBuildNumber = 1;
	if (g_theApp->IsKeyDown(KEYCODE_SHIFT)) {
		intendBuildNumber = BATCH_BUILD_BATCH_SIZE;
	}
	if(intendBuild == "") {
		return;
	}
	for (int buildOptionIndex = 0; buildOptionIndex < m_def.buildOptions.size(); buildOptionIndex++) {
		if (m_def.buildOptions[buildOptionIndex].name == intendBuild) {
			int creditsNeeded = m_def.buildOptions[buildOptionIndex].builtEntity->price * intendBuildNumber;
			if (m_map->GetCredits(m_faction) > creditsNeeded) {
				QueueBuildAction(buildOptionIndex, intendBuildNumber);
				m_map->AddCredits(m_faction,  -1 * creditsNeeded);
			}
		}
	}
}


void Entity::QueueBuildActionAsAICommands() {
	if (m_aiBuildOptionIntent < 0) {
		EntitySearchFilter searchFilter; 
		searchFilter.positiveCostOnly = true;
		searchFilter.seletableOnly = true;
		searchFilter.onlyIncludeFactions = { m_faction };
		std::vector<Entity*> unitsInTeam = m_map->FindEntities(m_position, -100.f, searchFilter);
		int numberOfUnitInTeam = static_cast<int>(unitsInTeam.size());
		int creditsOwned = m_map->GetCredits(m_faction);
		float myPowerFactor = static_cast<float>(creditsOwned) + numberOfUnitInTeam * 250.f;
		float biasTowardsCapitalShips = myPowerFactor;
		float biasTowardsFighters = 10000.f;
		float biasTowardsFrigates = sqrtf(myPowerFactor * biasTowardsFighters);
		if (numberOfUnitInTeam > 200) {
			biasTowardsFighters = 0.f;
		}
		std::vector<float> buildWeights;
		for (int buildOptionIndex = 0; buildOptionIndex < m_def.buildOptions.size(); buildOptionIndex++) {
			if (creditsOwned > 15000 && m_def.buildOptions[buildOptionIndex].builtEntity->isBaseDefense) {
				//Base defense takes too long to build
				buildWeights.emplace_back(0.f);
			}
			else {
				float optionPrice = static_cast<float>(m_def.buildOptions[buildOptionIndex].builtEntity->price) + TINY_POSITIVE_NUMBER;
				if (optionPrice > 1200) {
					buildWeights.emplace_back(biasTowardsCapitalShips / optionPrice);
				}
				else if (optionPrice < 200) {
					buildWeights.emplace_back(biasTowardsFighters / optionPrice);
				}
				else {
					buildWeights.emplace_back(biasTowardsFrigates / optionPrice);
				}
			}
		}
		assert(buildWeights.size() == m_def.buildOptions.size());
		m_aiBuildOptionIntent = g_theApp->m_rnd->ChooseItemFromWeightedList(buildWeights);
	}
	if (m_aiBuildOptionIntent >= 0) {
		int creditsOwned = m_map->GetCredits(m_faction);
		int optionPrice = m_def.buildOptions[m_aiBuildOptionIntent].builtEntity->price;
		if (creditsOwned > optionPrice) {
			m_map->AddCredits(m_faction, -1 * optionPrice);
			QueueBuildAction(m_aiBuildOptionIntent, 1);
			m_aiBuildOptionIntent = -1;
		}
	}
}

void Entity::QueueBuildAction(int buildOptionIndex, int number) {
	assert(buildOptionIndex < m_def.buildOptions.size() && buildOptionIndex >= 0);
	BuildEntry buildOption = m_def.buildOptions[buildOptionIndex];
	EntityDefinition* entityToBuild = buildOption.builtEntity;
	QueuableAction buildActionToAdd = QueuableAction(entityToBuild->price * buildOption.buildTimeCostModifier * 0.01f);
	buildActionToAdd.m_finishBuildOptionID = buildOptionIndex;
	buildActionToAdd.m_refundPrice = entityToBuild->price;
	for (int index = 0; index < number; index++) {
		m_actionQueue.push(buildActionToAdd);
	}
}

void Entity::ExecuteQueuedAction(QueuableAction const& itemToExecute) {
	if (itemToExecute.m_finishBuildOptionID >= 0) {
		FinishBuildOption(itemToExecute.m_finishBuildOptionID);
	}
}

void Entity::FinishBuildOption(int buildOptionIndex) {
	if (m_faction == Faction::player) {
		g_theApp->PlayUnitReadySound();
	}
	assert(buildOptionIndex < m_def.buildOptions.size() && buildOptionIndex >= 0);
	Vec2 spawnPosition = GetGlobalPositionFromLocalPosition(m_def.buildOptions[buildOptionIndex].launchPosition);
	float launchDirection = AddAngle(m_orientationDegrees, m_def.buildOptions[buildOptionIndex].launchDirection);
	Vec2 spawnVelocity = Vec2::MakeFromPolarDegrees(launchDirection) * m_def.buildOptions[buildOptionIndex].launchSpeed;
	m_map->SpawnEntity(m_def.buildOptions[buildOptionIndex].builtEntity, m_faction, spawnPosition, launchDirection, spawnVelocity);
}

bool Entity::IsCloserThan(Vec2 target, float distanceLimit, bool includeRadius) {
	float actualDistanceLimit = distanceLimit;
	if (includeRadius) {
		actualDistanceLimit += m_def.physicsRadius;
	}
	return GetDistanceSquared2D(target, m_position) < actualDistanceLimit * actualDistanceLimit;
}

//AI and control stuff-------------------------------------------------------------------------------------

void Entity::TryReachTargetLocation(Vec2 const& targetLocation, float deltaSeconds, bool flee, bool tryReverseMove) {
	//Turn towards target
	TryTurnToTargetLocation(targetLocation, deltaSeconds, flee, tryReverseMove);
	//Are we moving too fast?
	if (!m_def.isProjectile) {
		Vec2 targetDirection = (targetLocation - m_position).GetNormalized();
		float targetDistanceSquared = (targetLocation - m_position).GetLengthSquared();
		float velocityOnTargetDirection = DotProduct2D(targetDirection, m_velocity);
		float roughBrakeDistance = 1.f * velocityOnTargetDirection / (m_def.backwardAccelerationRatio + m_def.speedDecayRate + 0.01f);
		if (velocityOnTargetDirection > 0.f && (roughBrakeDistance * roughBrakeDistance) > targetDistanceSquared) {
			flee = true;
			tryReverseMove = true;
		}
	}
	float angleToTarget = (targetLocation - m_position).GetOrientationDegrees();
	//If we are facing enemy and we are not fleeing... or if we are not facing enemy but we are fleeing
	bool isFacingTarget = GetShortestAngularDispDegreesAbs(m_orientationDegrees, angleToTarget) < 90;
	if (isFacingTarget != flee) {
		m_currentAcceleration = m_def.forwardAcceleration;
	}
	else {
		m_currentAcceleration = -1.f * m_def.forwardAcceleration * m_def.backwardAccelerationRatio;
	}
}
void Entity::TryTurnToTargetLocation(Vec2 const& targetLocation, float deltaSeconds, bool flee, bool tryReverseMove) {
	float angleToTarget = (targetLocation - m_position).GetOrientationDegrees();
	if (tryReverseMove || !flee) {
		m_orientationDegrees = GetTurnedTowardDegrees(m_orientationDegrees, angleToTarget, m_def.turnSpeed * deltaSeconds);
	}
	else {
		m_orientationDegrees = GetTurnedTowardDegrees(m_orientationDegrees, angleToTarget, -1.f * m_def.turnSpeed * deltaSeconds);
	}
}
bool Entity::TryEngageWithTarget(Vec2 const& targetLocation, float deltaSeconds, float targetSize, bool forceStationary) {
	bool timeConsumed = false;
	float distanceToTargetSquared = (targetLocation - m_position).GetLengthSquared();
	float actualMaxEngageDistance = m_def.engageMaxDistance + targetSize;
	float actualMinEngageDistance = m_def.engageMinDistance + targetSize;
	if (distanceToTargetSquared > actualMaxEngageDistance * actualMaxEngageDistance && !forceStationary) {
		TryReachTargetLocation(targetLocation, deltaSeconds, false);
		timeConsumed = true;
	}
	else if (distanceToTargetSquared < actualMinEngageDistance * actualMinEngageDistance && !forceStationary) {
		TryReachTargetLocation(targetLocation, deltaSeconds, true, m_def.turnToFire);
		timeConsumed = true;
	}
	else if (m_def.turnToFire) {
		TryTurnToTargetLocation(targetLocation, deltaSeconds, false, true);
		timeConsumed = true;
	}
	return timeConsumed;
}

bool Entity::TryFollowTarget(Vec2 const& targetLocation, float deltaSeconds, float targetSize) {
	bool timeConsumed = false;
	float distanceToTargetSquared = (targetLocation - m_position).GetLengthSquared();
	float actualMaxFollowDistance = m_def.followMaxDistance + targetSize;
	if (distanceToTargetSquared > actualMaxFollowDistance * actualMaxFollowDistance) {
		TryReachTargetLocation(targetLocation, deltaSeconds, false);
		timeConsumed = true;
	}
	return timeConsumed;
}

bool Entity::TryFindAndEngageEnemiesWithinRange(Vec2 centerPosition, float engageDistance, float disengageDistance, float deltaSeconds, bool forceStationary) {
	bool timeConsumed = false;
	Entity* storedTemporaryTarget = m_map->GetEntityByUID(m_currentAttackIntentTarget);
	if (storedTemporaryTarget == nullptr || !storedTemporaryTarget->IsCloserThan(centerPosition, disengageDistance, true)) {
		m_currentAttackIntentTarget = UID_INVALID;
	}
	if (m_currentAttackIntentTarget == UID_INVALID && m_doAIUpdateThisFrame) {
		TryFindAndSetMainAttackTarget(centerPosition, engageDistance);
	}
	if (m_currentAttackIntentTarget != UID_INVALID) {
		Entity* currentTarget = m_map->GetEntityByUID(m_currentAttackIntentTarget);
		TryEngageWithTarget(currentTarget->m_position, deltaSeconds, currentTarget->GetDefinition()->physicsRadius, forceStationary);
		timeConsumed = true;
	}
	return timeConsumed;
}


bool Entity::IsAimmingAtTarget(Vec2 const& targetLocation, float maxAttackRange, float angleLimit) const {
	return IsPointInsideOrientedSector2D(targetLocation, m_position, m_orientationDegrees, angleLimit, maxAttackRange);
}
bool Entity::TryFindAndSetMainAttackTarget(Vec2 centerPosition, float maxDistance) {
	EntitySearchFilter searchFilter;
	searchFilter.positiveCostOnly = m_def.onlyTargetPositiveCostTargets;
	searchFilter.onlyIncludeFactions = EnemiesOf(m_faction);
	searchFilter.noneBulletOnly = true;
	searchFilter.canCollideOnly = true;
	std::vector<Entity*> potentialTargets = m_map->FindEntities(centerPosition, maxDistance, searchFilter);
	if (potentialTargets.size() > 0) {
		m_currentAttackIntentTarget = potentialTargets[g_theApp->m_rnd->RollRandomIntInRange(0, static_cast<int>(potentialTargets.size() - 1))]->GetUID();
		return true;
	}
	return false;
}

void Entity::TrySpawnMoveEffects() { 
	if (!m_def.uncontrollable && m_currentAcceleration <= m_def.forwardAcceleration * 0.3f) {
		return;
	}
	if (m_def.moveEffects.size() < 1) {
		return;
	}
	if (m_timeAlive - m_timeOfLastMoveEffectSpawn < m_def.moveEffectRate) {
		return;
	}
	AABB2 worldCameraArea = m_map->GetWorldCameraArea();
	worldCameraArea.SetDimensions(worldCameraArea.GetDimensions() * 1.2f + Vec2(m_def.cosmeticRadius, m_def.cosmeticRadius));
	if (!worldCameraArea.IsPointInside(m_position)) {
		return;
	}
	m_timeOfLastMoveEffectSpawn = m_timeAlive;
	for (int effectIndex = 0; effectIndex < m_def.moveEffects.size(); effectIndex++) {
		MoveEffectEntry currentEffect = m_def.moveEffects[effectIndex];
		Vec2 spawnPosition = GetGlobalPositionFromLocalPosition(currentEffect.spawnPosition + Vec2(-0.33f * currentEffect.moveEffectSize, 0.f));
		Vec2 spawnVelocity = GetGlobalVelocityFromLocalVelocity(currentEffect.moveEffectEjectVelocity);
		Vec2 spawnRandomVelocity = Vec2(g_theApp->m_rnd->RollRandomFloatInRange(-1.f * currentEffect.moveEffectRandomSpeed, currentEffect.moveEffectRandomSpeed), g_theApp->m_rnd->RollRandomFloatInRange(-1.f * currentEffect.moveEffectRandomSpeed, currentEffect.moveEffectRandomSpeed));
		spawnVelocity += spawnRandomVelocity;
		new LightEffect(m_map, currentEffect.moveEffectTime, currentEffect.moveEffectSize, spawnPosition, spawnVelocity, GetMyFactionColor(), 0.f, 0.f, 1.f, true);
	}

}