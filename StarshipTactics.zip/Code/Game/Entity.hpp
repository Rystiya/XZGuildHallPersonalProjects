#pragma once

#include "Engine\Core\Vertex_PCU.hpp"
#include "Engine\Math\Mat44.hpp"
#include "Game\GameCommon.hpp"
#include <queue>

class QueuableAction {
public:
	QueuableAction(float totalTime) { m_totalTime = totalTime; m_remainingTime = totalTime;}
	float m_totalTime = 10.f;
	float m_remainingTime = 10.f;
	int m_refundPrice = 0;
	int m_finishBuildOptionID = -1;
};

class Map;
class Weapon;

//-----------------------------------------------------------------------------------------------
class Entity
{
public: // position, color, etc
	// Construction/Destruction
	friend class Map;
	friend class Weapon;
	virtual ~Entity();												// destructor (do nothing)
	Entity(Map* parentMap, EntityDefinition const& theDefinition, Faction theFaction = Faction::neutral, Vec2 startingPosition = Vec2(), float orientation = 0.f, Vec2 startingVelocity = Vec2(), bool isCosmeticOnly = false, uint64_t parentUID = UID_INVALID);

	Map* m_map = nullptr;
	Vec2 m_velocity = Vec2();
	Vec2 m_position = Vec2();
	float m_orientationDegrees = 0.f;
	void Update(float deltaSeconds);
	void WaypointExecutionUpdate(float deltaSeconds);
	void WaypointReceivalUpdate();
	void UpdateActionQueue(float deltaSeconds);
	virtual void UpdateCustomBehavior(float deltaSeconds) { (void)deltaSeconds; }
	virtual void GenerateResources();
	void UpdateAsBuilder();
	void PrioritizeProjectileParent();
	void ProximityFuseUpdate();
	void PhysicsUpdate(float deltaSeconds);
	void Render(WorldRenderingPass renderingPass) const;
	virtual void AddVertsForUI(std::vector<Vertex_PCU>& verts, UIRenderingPass randeringPass) const;

	//Gameplay stuff
	void Die();
	bool IsOutOfWorld(float maxMargin = 0.f) const;
	bool TakeDamage(float damage, bool ignoreArmor = false);
	void TakeImpulse(Vec2 ImpulseNorm, float intensity);
	bool NeedsHealing() const;
	void HandleCollisionAgainst(Entity* other);
	Mat44 GetModelMatrix() const { return m_transformMatrix; }
	Vec2 GetForwardNormal() const { return m_forwardNormal; }
	Rgba8 GetMyFactionColor() const;
	Faction GetMyFaction() const { return m_faction; }
	void AddWaypoint(WaypointType type, uint64_t waypointEntityTarget, Vec2 waypointPositionTarget);
	uint64_t GetCurrentAttackIntentTargetUID() const { return m_currentAttackIntentTarget; }
	uint64_t GetCurrentFollowingTargetUID() const;
	Vec2 GetGlobalPositionFromLocalPosition(Vec2 localPosition) const;
	Vec2 GetGlobalVelocityFromLocalVelocity(Vec2 localVelocity) const;
	void SetAsSelected(bool isSelected);
	void QueueBuildActionAsPlayerCommands();
	void QueueBuildActionAsAICommands();
	void QueueBuildAction(int buildOptionIndex, int number = 1);
	void ExecuteQueuedAction(QueuableAction const& itemToExecute);
	void FinishBuildOption(int buildOptionIndex);
	bool IsCloserThan(Vec2 target, float distanceLimit, bool includeRadius = true);

	//System stuff
	uint64_t GetUID() const { return m_UID; }
	uint64_t GetParentUID() const { return m_parentUID; }
	EntityDefinition const* GetDefinition() const { return &m_def; }
	bool GetDoAIUpdateThisFrame() const { return m_doAIUpdateThisFrame; }

protected:
	std::vector<Weapon*> m_turretsTop;
	std::vector<Weapon*> m_turretsBottom;
	std::queue<QueuableAction> m_actionQueue;
	Faction m_faction = Faction::neutral;
	void BounceIfAtEdge();
	void DieIfAtEdge();
	void ReemergeIfOutOfWorld();
	float m_timeAlive = 0.f;
	float m_timeOfLastMoveEffectSpawn = 0.f;
	float m_currentAcceleration = 0.f;
	float m_health;
	Vec2 m_forwardNormal = Vec2();

	//System stuff
	uint64_t m_UID = UID_INVALID;
	uint64_t m_parentUID = UID_INVALID;
	EntityDefinition m_def;
	WorldRenderingPass m_myRenderingPass = WorldRenderingPass::units;
	bool m_isDead = false;

	//System stuff
	bool m_isGarbage = false;
	float m_lastAIUpdateTime = 0.f;
	bool m_doAIUpdateThisFrame = false;
	bool m_noMoreWaypoints = false;  //Currently used by base defenses under AI control
	Mat44 m_transformMatrix;

	//AI and control
	bool m_isSelected = false;
	bool m_wasSelectedWhenLMBJustPressed = false;
	uint8_t m_controlGroup = CONTROL_GROUP_COUNT + 1;
	uint64_t m_waypointEntityTarget = UID_INVALID;		//Set as if out of range, otherwise set as m_currentMainAttackTarget. Also display red line.
	uint64_t m_currentAttackIntentTarget = UID_INVALID;		//Set as if out of range, otherwise set as m_currentMainAttackTarget. Also display red line.
	Vec2 m_waypointPositionTarget = Vec2();	//Move towards this, stop if very close
	WaypointType m_currentWaypointType = WaypointType::none;
	float m_proximityFuseTargetSquaredDistance = -1.f;
	uint64_t m_proximityFuseTarget = UID_INVALID;		//Set as if out of range, otherwise set as m_currentMainAttackTarget. Also display red line.
	int m_aiBuildOptionIntent = -1;

	void TryReachTargetLocation(Vec2 const& targetLocation, float deltaSeconds, bool flee = false, bool tryReverseMove = false);
	void TryTurnToTargetLocation(Vec2 const& targetLocation, float deltaSeconds, bool flee = false, bool tryReverseMove = false);
	bool TryEngageWithTarget(Vec2 const& targetLocation, float deltaSeconds, float targetSize = 0.f, bool forceStationary = false);
	bool TryFollowTarget(Vec2 const& targetLocation, float deltaSeconds, float targetSize = 0.f);
	bool TryFindAndEngageEnemiesWithinRange(Vec2 centerPosition, float engageDistance, float disengageDistance, float deltaSeconds, bool forceStationary = false);
	bool IsAimmingAtTarget(Vec2 const& targetLocation, float maxAttackRange, float angleLimit = 10.f) const;
	bool TryFindAndSetMainAttackTarget(Vec2 centerPosition, float maxDistance);

	//Graphic and audio stuff
	void UpdatePositionalData();
	void TryPlaySound(std::string soundName);
	void TrySpawnMoveEffects();

};	