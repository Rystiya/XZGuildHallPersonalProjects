
#include "Game\Asteroid.hpp"
#include "Game\Map.hpp"
#include "Game\Game.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"

Asteroid::Asteroid(Map* parentMap, Vec2 startingPosition) : Entity(parentMap, EntityDefinition(), Faction::neutral, startingPosition, 0.f, Vec2()) {
	//Initializing....
	m_def.name = "Asteroid";
	float scaleFactor = g_theApp->m_rnd->RollRandomFloatInRange(0.67f, 1.5f);
	m_def.cosmeticRadius = ASTEROID_SIZE_FACTOR * scaleFactor * 10.f;
	m_rotationSpeed = g_theApp->m_rnd->RollRandomFloatZeroToOne();
	m_rotationSpeed = m_rotationSpeed * 2.f - 1.f;
	m_rotationSpeed = m_rotationSpeed * fabsf(m_rotationSpeed);
	m_rotationSpeed *= 30.f;
	//Remove if too close to another asteriod.
	//Do the search before it's set to an asteroid itself.
	EntitySearchFilter searchFilter;
	searchFilter.asteroidOnly = true;
	searchFilter.returnOnlyOneResult = true;
	std::vector<Entity*> otherAsteriods = parentMap->FindEntities(startingPosition, m_def.cosmeticRadius * 2.f, searchFilter);
	if (otherAsteriods.size() > 0) {
		//Don't do self delete, it will leave pointers behind...
		m_isGarbage = true;
	}
	//No collision
	m_def.physicsRadius = -1.f;
	m_def.forwardAcceleration = 0.f;
	m_def.turnSpeed = 0.f;
	m_def.maxHealth = -1.f;
	m_def.uncontrollable = true;
	m_def.isAsteriod = true;
	m_def.isSelectable = false;

	RandomNumberGenerator* gameRnd = g_theApp->m_rnd;
	int cornorCount = gameRnd->RollRandomIntInRange(25, 50);
	std::vector<float> randomizedRadiuses = {};
	for (int indexCorner = 0; indexCorner < cornorCount + 2; indexCorner++) {
		randomizedRadiuses.emplace_back(gameRnd->RollRandomFloatInRange(m_def.cosmeticRadius * 0.9f, m_def.cosmeticRadius));
	}

	Rgba8 m_edgeColor = Rgba8(75, 75, 75, 255);
	Rgba8 m_centerColor = Rgba8(100, 100, 100, 255);
	for (int indexTriangle = 0; indexTriangle < cornorCount; indexTriangle++) {
		float angle1 = static_cast<float>(indexTriangle) * 360.f / static_cast<float>(cornorCount);
		float angle2 = static_cast<float>(indexTriangle + 1) * 360.f / static_cast<float>(cornorCount);
		m_def.vertexes.emplace_back(Vertex_PCU(Vec3(CosDegrees(angle1) * randomizedRadiuses[indexTriangle], SinDegrees(angle1) * randomizedRadiuses[indexTriangle], 0.f), m_edgeColor));
		m_def.vertexes.emplace_back(Vertex_PCU(Vec3(CosDegrees(angle2) * randomizedRadiuses[indexTriangle + 1], SinDegrees(angle2) * randomizedRadiuses[indexTriangle + 1], 0.f), m_edgeColor));
		m_def.vertexes.emplace_back(Vertex_PCU(Vec3(), m_centerColor));
	}
	for (int index = 0; index < NUMBER_OF_FACTIONS; index++) {
		m_affinities[index] = 0.f;
	}
	m_resourceGenerationRate = 2 + static_cast<int>(ASTEROID_RESOURCE_RATE * m_def.cosmeticRadius * m_def.cosmeticRadius);
	m_maxAffinity = ASTEROID_MAX_AFFINITY * scaleFactor;
	//Drawn below everything else
	m_myRenderingPass = WorldRenderingPass::background;
}


void Asteroid::UpdateCustomBehavior(float deltaSeconds) {
	float totalAffinity = 0.f;
	for (int index = 0; index < NUMBER_OF_FACTIONS; index++) {
		totalAffinity += m_affinities[index];
	}
	//Capture control
	for (int index = 0; index < NUMBER_OF_FACTIONS; index++) {
		Faction currentFaction = GetFactionEnum(index);
		if (currentFaction == Faction::neutral) {
			m_affinities[index] = 0.f;
			continue;
		}
		EntitySearchFilter searchFilter;
		searchFilter.onlyIncludeFactions = { currentFaction };
		searchFilter.returnOnlyOneResult = true;
		searchFilter.positiveCostOnly = true;
		std::vector<Entity*> unitsOfThisFaction = m_map->FindEntities(m_position, m_def.cosmeticRadius, searchFilter);
		searchFilter.onlyIncludeFactions = EnemiesOf(currentFaction);
		std::vector<Entity*> unitsOfEnemiesOfThisFaction = m_map->FindEntities(m_position, m_def.cosmeticRadius, searchFilter);
		//If no enemies and no other affinity, then consider adding affinity
		if (unitsOfEnemiesOfThisFaction.size() < 1 && totalAffinity - m_affinities[index] < TINY_POSITIVE_NUMBER) {
			if (unitsOfThisFaction.size() > 0) {
				m_affinities[index] += deltaSeconds;
			} else if (index == m_factionWithMaxAffinity) {
				m_affinities[index] += 0.15f * deltaSeconds;
			}
			m_affinities[index] = fminf(m_maxAffinity, m_affinities[index]);
		}
		//If no friendlies, then consider reducing affinity
		if (unitsOfThisFaction.size() < 1) { 
			if (unitsOfEnemiesOfThisFaction.size() > 0) {
				m_affinities[index] -= deltaSeconds;
			}
			else if (index != m_factionWithMaxAffinity) {
				m_affinities[index] -= 0.1f * deltaSeconds;
			}
			m_affinities[index] = fmaxf(0.f, m_affinities[index]);
		}
	}
	//Set the faction with max affinity
	if (m_affinities[m_factionWithMaxAffinity] < m_maxAffinity - TINY_POSITIVE_NUMBER) {
		float maxAffinityFound = 0.f;
		for (int index = 0; index < NUMBER_OF_FACTIONS; index++) {
			if (m_affinities[index] > maxAffinityFound + TINY_POSITIVE_NUMBER) {
				m_factionWithMaxAffinity = index;
				maxAffinityFound = m_affinities[index];
			}
		}
	}
	//Rotate
	m_orientationDegrees += deltaSeconds * m_rotationSpeed;
}

void Asteroid::GenerateResources() {
	if (m_affinities[m_factionWithMaxAffinity] >= m_maxAffinity) {
		m_map->AddCredits(GetFactionEnum(m_factionWithMaxAffinity), m_resourceGenerationRate);
	}
}
void Asteroid::AddVertsForUI(std::vector<Vertex_PCU>& verts, UIRenderingPass randeringPass) const {
	//UIRenderingPass::selectionCircle: this should be drawn below other stuff
	if (randeringPass == UIRenderingPass::selectionCircle) {
		//Draw a pie chart
		if (m_affinities[m_factionWithMaxAffinity] > TINY_POSITIVE_NUMBER) {
			Rgba8 colorAtEdge = GetFactionStandardColor(GetFactionEnum(m_factionWithMaxAffinity));
			colorAtEdge.a = 125;
			if (m_affinities[m_factionWithMaxAffinity] >= m_maxAffinity) {
				colorAtEdge * 1.2f;
				colorAtEdge.a = 215;
			}
			Rgba8 colorAtCenter = colorAtEdge;
			colorAtCenter.a = 0;
			float diskRatio = m_affinities[m_factionWithMaxAffinity] / m_maxAffinity;
			AddVertsForSector2(verts, m_position, m_def.cosmeticRadius * 0.2f, 12 + static_cast<int>(m_def.cosmeticRadius), -180.f * diskRatio, 180.f * diskRatio, colorAtCenter, colorAtEdge);
		}
	}
	if (randeringPass == UIRenderingPass::screenWidgetsBottom && !(m_def.isProjectile && m_def.maxHealth <= 0.f)) {
		AABB2 minimapArea = m_map->GetMinimapArea();
		Vec2 positionOnMinimap = m_map->RangeMapPositionToMinimap(m_position, minimapArea);
		float sizeOnMinimap = MINIMAP_DOT_SIZE_SCALE * (minimapArea.GetDimensions().x + minimapArea.GetDimensions().y) * 0.0005f * (4.f + m_def.cosmeticRadius);
		AddVertsForDisk(verts, positionOnMinimap, sizeOnMinimap, 10, Rgba8(100,100,100), Rgba8(100, 100, 100));
		if (m_affinities[m_factionWithMaxAffinity] >= m_maxAffinity) {
			Rgba8 minimapInnerColor = GetFactionStandardColor(GetFactionEnum(m_factionWithMaxAffinity));
			AddVertsForDisk(verts, positionOnMinimap, 0.75f * sizeOnMinimap, 6, minimapInnerColor, minimapInnerColor);
		}
	}
}