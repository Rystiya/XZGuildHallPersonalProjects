
#include "Game\Weapon.hpp"
#include "Game\Map.hpp"
#include "Game\Game.hpp"
#include "Game\Entity.hpp"
#include "Game\LightEffect.hpp"
#include "Game\BeamEffect.hpp"
#include "Game\GameCommon.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\Camera.hpp"
#include "Engine\Renderer\Texture.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"
#include <assert.h>


Weapon::Weapon(Entity* owner, WeaponDefinition const& theDefinition, Vec2 mountPosition, float mountOrientation, float limitingAngle, bool useParentAttackTarget, bool canSearchTarget)
	: m_MountOrientation(mountOrientation)
	, m_LimitingAngle(limitingAngle)
	, m_MountPosition(mountPosition)
	, m_UseParentAttackTarget(useParentAttackTarget)
	, m_CanSearchTarget(canSearchTarget)
{
	m_def = theDefinition;
	m_owner = owner;
	m_localOrientation = 0.f;
	if (m_def.projectileCount > 0) {
		m_def.projectileFiredEntity = g_theApp->GetEntityTypeByName(m_def.projectileFired);
		if (m_def.fireDistance <= 0.f) {  //If the value is uninitialized or invalid
			m_def.fireDistance = 0.9f * m_def.projectileSpeed * m_def.projectileFiredEntity->lifespan;
		}
		if (m_def.fireAngleTolerance <= 0.f) { //If the value is uninitialized or invalid
			m_def.fireAngleTolerance = GetClamped(0.8f * m_def.projectileCone, 1.f, 10.f);
		}
		m_def.isHealWeapon = (m_def.projectileFiredEntity->impactDamage + m_def.projectileFiredEntity->deathExplosionAreaDamage) < -1.f * TINY_POSITIVE_NUMBER;
	}
	if (m_def.rayCount > 0) {
		if (m_def.fireDistance <= 0.f) { //If the value is uninitialized or invalid
			m_def.fireDistance = fmaxf(m_def.fireDistance, 0.95f * m_def.rayDistance);
		}
		if (m_def.fireAngleTolerance <= 0.f) { //If the value is uninitialized or invalid
			m_def.fireAngleTolerance = GetClamped(0.9f * m_def.rayCone, 3.f, 15.f);
		}
		m_def.isHealWeapon = m_def.rayDamage < -1.f * TINY_POSITIVE_NUMBER;
	}
	m_currentEnergy = m_def.energyMax;
}

Weapon::~Weapon() {
}

void Weapon::Update(float deltaSeconds) {
	m_timeAlive += deltaSeconds;
	UpdatePositionalData();
	Entity* myTarget = m_owner->m_map->GetEntityByUID(m_currentAttackIntentTarget);
	if (myTarget == nullptr || !WeaponCanReach(myTarget)) {
		m_currentAttackIntentTarget = UID_INVALID;
	}
	m_refireTimeRemaining -= deltaSeconds;
	m_currentEnergy += m_def.energyRegen * deltaSeconds;
	if (m_currentEnergy >= m_def.energyMax) {
		m_currentEnergy = m_def.energyMax;
		m_weaponLockedUntilEnergyFull = false;
	}
	if (m_UseParentAttackTarget) {
		Entity* parentTarget = nullptr;
		if (!m_def.isHealWeapon) {
			parentTarget = m_owner->m_map->GetEntityByUID(m_owner->GetCurrentAttackIntentTargetUID());
		}
		else {
			parentTarget = m_owner->m_map->GetEntityByUID(m_owner->GetCurrentFollowingTargetUID());
		}
		if (parentTarget != nullptr && WeaponCanReach(parentTarget)) {
			m_currentAttackIntentTarget = parentTarget->GetUID();
		}
	}
	if (m_CanSearchTarget && m_currentAttackIntentTarget == UID_INVALID && m_owner->GetDoAIUpdateThisFrame()) {
		EntitySearchFilter searchFilter;
		searchFilter.positiveCostOnly = m_def.onlyTargetPositiveCostTargets;
		searchFilter.noneBulletOnly = true;
		searchFilter.canCollideOnly = true;
		if (!m_def.isHealWeapon) {
			searchFilter.onlyIncludeFactions = EnemiesOf(m_owner->GetMyFaction());
		}
		else {
			searchFilter.onlyIncludeFactions = FriendliesOf(m_owner->GetMyFaction());
		}
		std::vector<Entity*> possibleTargets = m_owner->m_map->FindEntities(m_globalPosition, m_def.fireDistance, searchFilter);
		std::vector<Entity*> validTargets;
		for (int index = 0; index < possibleTargets.size(); index++) {
			if ((!m_def.isHealWeapon || possibleTargets[index]->NeedsHealing()) && WeaponCanReach(possibleTargets[index])) {
				validTargets.emplace_back(possibleTargets[index]);
			}
		}
		if (validTargets.size() > 0) {
			m_currentAttackIntentTarget = validTargets[g_theApp->m_rnd->RollRandomIntInRange(0, static_cast<int>(validTargets.size() - 1))]->GetUID();
		}
	}
	TurnAndFire(deltaSeconds);
}


void Weapon::Render() const {
	Rgba8 tintColor = GetFactionColor() * m_def.brightness;
	tintColor.a = 255;
	g_theRenderer->SetModelConstants(m_transformMatrix, tintColor);
	g_theRenderer->DrawVertexVector(m_def.vertexes);
}

Rgba8 Weapon::GetFactionColor() const {
	return m_owner->GetMyFactionColor();
}

bool Weapon::TargetWithinArcOfFire(Vec2 targetPosition) const {
	//Check limiting Angle
	float targetOrientation = (targetPosition - m_globalPosition).GetOrientationDegrees();
	float turretSlotOrientation = AddAngle(m_owner->m_orientationDegrees, m_MountOrientation);
	float m_degreesOff = AddAngle(turretSlotOrientation, -1.f * targetOrientation);
	if (fabsf(m_degreesOff) > m_LimitingAngle + m_def.fireAngleTolerance) {
		//if target not within arc of fire
		return false;
	}
	return true;
}

bool Weapon::TargetWithinSectorOfFire(Vec2 targetPosition, float targetSize) const {
	//Check distance
	float squaredDistance = GetDistanceSquared2D(m_globalPosition, targetPosition);
	if (squaredDistance > (m_def.fireDistance + targetSize) * (m_def.fireDistance + targetSize)) {
		return false;
	}
	//Check limiting Angle
	return (TargetWithinArcOfFire(targetPosition));
}

bool Weapon::WeaponCanReach(Entity* target) const {
	return (!m_def.isHealWeapon || (target->NeedsHealing() && target != m_owner)) && TargetWithinSectorOfFire(target->m_position, target->GetDefinition()->physicsRadius);
}

bool Weapon::IsWeaponReady() const {
	return m_refireTimeRemaining <= 0.f && m_currentEnergy >= m_def.energyUse && !m_weaponLockedUntilEnergyFull;
}

void Weapon::UpdatePositionalData() {
	m_globalOrientation = AddAngle(AddAngle(m_owner->m_orientationDegrees, m_MountOrientation), m_localOrientation);
	Vec2 parentForwardNormal = m_owner->GetForwardNormal();
	Vec2 parentSidewardNormal = parentForwardNormal.GetRotated90Degrees();
	m_globalPosition = m_owner->GetGlobalPositionFromLocalPosition(m_MountPosition);
	m_transformMatrix = Mat44();
	m_transformMatrix.SetTranslation3D(m_globalPosition);
	m_transformMatrix.Append(Mat44::CreateZRotationDegrees(m_globalOrientation));
	m_forwardNormal = Vec2::MakeFromPolarDegrees(m_globalOrientation);
}

//This function is pretty expensive. Only called when actually firing projectiles (rather than every frame) to make sure projectiles can hit moving targets.
//The turrets, on the other hand, aim at the target's current position.
float Weapon::GetLeadFiringOrientation() {
	Entity* attackTarget = m_owner->m_map->GetEntityByUID(m_currentAttackIntentTarget);
	//If target is invalid
	if (attackTarget == nullptr) {
		m_currentAttackIntentTarget = UID_INVALID;
		return 0.f;
	}
	Vec2 targetRelativePos = attackTarget->m_position - m_globalPosition;
	//If this weapon does not fire projectiles
	if (m_def.projectileCount < 1) {
		return targetRelativePos.GetOrientationDegrees();
	}
	//Test result suggest that leadTargettingRatio is necessary to avoid targetting too far forward.
	float leadTargettingRatio = 1.f;
	Vec2 targetRelativeVelocity = leadTargettingRatio * attackTarget->m_velocity - m_owner->m_velocity;
	//distance is added by a small value to avoid divide-by-zero error
	float distance = targetRelativePos.GetLength() + TINY_POSITIVE_NUMBER;
	//targetRelativePos / distance equals to targetRelativePos.GetNormalized. It just avoids calculating twice.
	float targetPerpendicularRelativeSpeed = DotProduct2D(targetRelativeVelocity, targetRelativePos / distance);
	float targetParallelRelativeSpeedSquared = targetRelativeVelocity.GetLengthSquared() - targetPerpendicularRelativeSpeed * targetPerpendicularRelativeSpeed;
	float bulletParallelRelativeSpeedSquared = targetParallelRelativeSpeedSquared;
	float bulletPerpendicularRelativeSpeedSquared = m_def.projectileSpeed * m_def.projectileSpeed - bulletParallelRelativeSpeedSquared;
	float bulletPerpendicularRelativeSpeed = sqrtf(bulletPerpendicularRelativeSpeedSquared);
	float perpendicularRelativeSpeed = bulletPerpendicularRelativeSpeed - targetPerpendicularRelativeSpeed;
	if (perpendicularRelativeSpeed <= 0.f) {
		//If the bullet is too slow to hit the target
		return targetRelativeVelocity.GetOrientationDegrees();
	}
	float leadTargettingSeconds = distance / perpendicularRelativeSpeed;
	//Calculate where the target will be leadTargettingSeconds later, in local space 
	Vec2 targetProjectedRelativePosition = targetRelativePos + targetRelativeVelocity * leadTargettingSeconds;
	//Calculate where the weapon should aim at. This is in global space (not relative to parent). 
	return targetProjectedRelativePosition.GetOrientationDegrees();
}

void Weapon::TryPlaySound(std::string soundName) {
	for (int index = 0; index < m_def.sounds.size(); index++) {
		if (m_def.sounds[index].name == soundName) {
			m_owner->m_map->PlaySoundAt(m_def.sounds[index].soundResourceHandle, m_def.sounds[index].volume, m_owner->m_position);
			return;
		}
	}
}

void Weapon::UseNextMuzzle() {
	if (m_currentMuzzleIndex < m_def.muzzles.size() - 1) {
		m_currentMuzzleIndex += 1;
	}
	else {
		m_currentMuzzleIndex = 0;
	}
}

Vec2 Weapon::GetGlobalPositionOfCurrentMuzzle() {
	Vec2 localPosition = m_def.muzzles[m_currentMuzzleIndex];
	return m_globalPosition + m_forwardNormal * localPosition.x + m_forwardNormal.GetRotated90Degrees() * localPosition.y;
}

bool Weapon::TurnAndFire(float deltaSeconds) {
	Entity* attackTarget = m_owner->m_map->GetEntityByUID(m_currentAttackIntentTarget);
	//if target is invalid or not in range
	if (attackTarget == nullptr) {
		m_currentAttackIntentTarget = UID_INVALID;
		m_localOrientation = GetTurnedTowardDegrees(m_localOrientation, 0.f, m_def.turnRate * deltaSeconds);
		return false;
	}
	float targetOrientation = 0.f;
	if (m_def.projectileCount <= 0 || m_def.projectileFiredEntity->uncontrollable) {
		//If this is an unguilded projectile, do the lead targetting
		targetOrientation = GetLeadFiringOrientation();
	}
	else {
		//Else, don't do the lead targetting
		targetOrientation = (attackTarget->m_position - m_globalPosition).GetOrientationDegrees();
	}
	m_globalOrientation = GetTurnedTowardDegrees(m_globalOrientation, targetOrientation, m_def.turnRate * deltaSeconds);
	m_localOrientation = AddAngle(m_globalOrientation, -1.f * (m_owner->m_orientationDegrees + m_MountOrientation));
	float m_degreesOff = AddAngle(m_globalOrientation, -1.f * targetOrientation);
	if (fabsf(m_degreesOff) > m_def.fireAngleTolerance) {
		//if target not within arc of fire
		return false;
	}
	//Try fire the weapon
	if (!IsWeaponReady()) {
		//if weapon not yet reloaded, or not enough energy
		return false;
	}
	m_refireTimeRemaining = m_def.refireTime;
	m_currentEnergy -= m_def.energyUse;
	if (m_def.lockedWhenEnergyRechargeFromEmpty) {
		if (m_currentEnergy < m_def.energyUse) {
			m_weaponLockedUntilEnergyFull = true;
		}
	}
	TryPlaySound("Fire"); 
	for (int projectileIndex = 0; projectileIndex < m_def.projectileCount; projectileIndex++) {
		Vec2 firePosition = GetGlobalPositionOfCurrentMuzzle();
		float randomAngle = g_theApp->m_rnd->RollRandomFloatInRange(-1.f * m_def.projectileCone, m_def.projectileCone);
		float projectileOrientation = AddAngle(randomAngle, m_globalOrientation);
		Vec2 projectieVelocity = m_owner->m_velocity + m_def.projectileSpeed * Vec2::MakeFromPolarDegrees(projectileOrientation);
		Entity* projectieFired = new Entity(m_owner->m_map, *m_def.projectileFiredEntity, m_owner->GetMyFaction(), firePosition, projectileOrientation, projectieVelocity, false, m_owner->GetUID());
		if (!projectieFired->GetDefinition()->uncontrollable) {
			projectieFired->m_currentWaypointType = WaypointType::attack;
			projectieFired->m_waypointEntityTarget = attackTarget->GetUID();
		}
		if (m_def.muzzleExplosionSize > 0.f && m_def.muzzleExplosionTime > 0.f) {
			Vec2 muzzleFlameVelocity = m_owner->m_velocity + 7.5f * Vec2::MakeFromPolarDegrees(projectileOrientation);
			new LightEffect(m_owner->m_map, m_def.muzzleExplosionTime, m_def.muzzleExplosionSize, firePosition, muzzleFlameVelocity, GetFactionColor(), 0.f);
		}
		UseNextMuzzle();
	}
	for (int rayIndex = 0; rayIndex < m_def.rayCount; rayIndex++) {
		Vec2 firePosition = GetGlobalPositionOfCurrentMuzzle();
		if (m_def.muzzleExplosionSize > 0.f && m_def.muzzleExplosionTime > 0.f) {
			//Note none of the laser effects will inherit parent velocity
			new LightEffect(m_owner->m_map, m_def.muzzleExplosionTime, m_def.muzzleExplosionSize, firePosition, Vec2(), GetFactionColor(), 0.6f, 0.f);
		}
		float randomAngle = g_theApp->m_rnd->RollRandomFloatInRange(-1.f * m_def.rayCone, m_def.rayCone);
		float beamOrientation = AddAngle(randomAngle, m_globalOrientation);
		Vec2 rayForward = Vec2::MakeFromPolarDegrees(beamOrientation);
		EntitySearchFilter searchFilter;
		if (m_def.rayDamage >= 0.f) {
			searchFilter.onlyIncludeFactions = ValidTargetsOf(m_owner->GetMyFaction());
		}
		else {
			searchFilter.onlyIncludeFactions = FriendliesOf(m_owner->GetMyFaction());
		}
		searchFilter.canCollideOnly = true;
		searchFilter.noneBulletOnly = true;
		RaycastResultWithEntity raycastResult = m_owner->m_map->RaycastVSEntities(firePosition, rayForward, m_def.rayDistance, m_def.rayWidth, searchFilter);
		if (raycastResult.m_contactInfo.m_didImpact) {
			raycastResult.m_entityHit->TakeDamage(m_def.rayDamage);
			new BeamEffect(m_owner->m_map, m_def.rayDuration, m_def.rayWidth, firePosition, raycastResult.m_contactInfo.m_impactPos, GetFactionColor(), false);
			//Make laser hit effect
			AABB2 worldCameraArea = m_owner->m_map->GetWorldCameraArea();
			worldCameraArea.SetDimensions(worldCameraArea.GetDimensions() * 1.4f);
			if (worldCameraArea.IsPointInside(raycastResult.m_contactInfo.m_impactPos)) {
				if (m_def.rayParticleLifeTime > 0.f && m_def.rayParticleSize > 0.f) {
					for (int rayParticleIndex = 0; rayParticleIndex < m_def.rayParticles; rayParticleIndex++) {
						float particleBaseOrientation = AddAngle(beamOrientation, 180.f);
						float particleRandomAngle = g_theApp->m_rnd->RollRandomFloatInRange(-80.f, 80.f);
						float particleOrientation = AddAngle(particleRandomAngle, particleBaseOrientation);
						Vec2 particleVelocity = raycastResult.m_entityHit->m_velocity + Vec2::MakeFromPolarDegrees(particleOrientation) * g_theApp->m_rnd->RollRandomFloatInRange(40.f, 120.f);
						new LightEffect(m_owner->m_map, m_def.rayParticleLifeTime, m_def.rayParticleSize, raycastResult.m_contactInfo.m_impactPos, particleVelocity, GetFactionColor(), 0.6f, 0.f);
					}
					new LightEffect(m_owner->m_map, m_def.rayExplosionTime, m_def.rayExplosionSize, raycastResult.m_contactInfo.m_impactPos, Vec2(), GetFactionColor(), 0.6f, 0.f);
				}
			}			
		} else {
			new BeamEffect(m_owner->m_map, m_def.rayDuration, m_def.rayWidth, firePosition, firePosition + m_def.rayDistance * rayForward, GetFactionColor(), true);
		}
		UseNextMuzzle();
	}
	return true;
}