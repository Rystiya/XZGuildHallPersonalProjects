
#include "Game\BeamEffect.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"

BeamEffect::BeamEffect(Map* parentMap, float persistTime, float width, Vec2 startPosition, Vec2 endPosition, Rgba8 color, bool missed, float centerWhiteRatio) : Entity(parentMap, EntityDefinition(), Faction::neutral, startPosition, 0.f, Vec2(), true) {
	m_def.name = "BeamEffect";
	m_def.physicsRadius = -1.f;
	m_def.forwardAcceleration = 0.f;
	m_def.turnSpeed = 0.f;
	m_def.maxHealth = -1.f;
	//brightness of 2 turn neutral faction color to white color.
	m_def.brightness = 2.f;
	m_def.speedDecayRate = 1.f;
	m_def.fadeOutTimeRatio = 1.f;
	m_def.dieAtEdge = true;
	m_def.uncontrollable = true;
	m_def.lifespan = persistTime;
	m_myRenderingPass = WorldRenderingPass::effectsTop;
	Rgba8 colorTransparent = color;
	colorTransparent.a = 0;
	color = color * (1.f - centerWhiteRatio) + Rgba8() * centerWhiteRatio;
	m_def.cosmeticRadius = (endPosition - startPosition).GetLength() * 1.01f;
	//Add verts for the beam
	if (width > 0.f) {
		AddVertsForLine2DMultiColor(m_def.vertexes, Vec2(), endPosition - startPosition, width, color, color, colorTransparent);
	}
	//Start and end effects are drawn after the beam itself
	if (missed) {
		Vec2 extraBeamEndOnMiss = endPosition + (endPosition - startPosition).GetNormalized() * width * 6.f;
		AddVertsForLine2DMultiColor(m_def.vertexes, endPosition - startPosition, extraBeamEndOnMiss - startPosition, width, color, colorTransparent, colorTransparent);
	}
}

