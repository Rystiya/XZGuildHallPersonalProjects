#pragma once
#include "Game\Entity.hpp"


//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class Asteroid : public Entity
{
public:
	// Construction/Destruction
	~Asteroid() {}
	Asteroid(Map* parentMap, Vec2 startingPosition = Vec2());

	void GenerateResources() override;
	void UpdateCustomBehavior(float deltaSeconds) override;
	void AddVertsForUI(std::vector<Vertex_PCU>& verts, UIRenderingPass randeringPass) const override;


protected:
	float m_rotationSpeed = 5.f;
	float m_affinities[NUMBER_OF_FACTIONS];
	int m_factionWithMaxAffinity = 0;
	int m_resourceGenerationRate = 0;
	float m_maxAffinity = 5.f;

};