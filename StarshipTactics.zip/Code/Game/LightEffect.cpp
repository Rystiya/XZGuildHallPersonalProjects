
#include "Game\LightEffect.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"

LightEffect::LightEffect(Map* parentMap, float persistTime, float size, Vec2 startingPosition, Vec2 startingVelocity, Rgba8 color, float centerWhiteRatio, float fadeInTimeRatio, float fadeOutTimeRatio, bool spawnAtBottom) : Entity(parentMap, EntityDefinition(), Faction::neutral, startingPosition, 0.f, startingVelocity, true) {
	m_def.name = "LightEffect";
	m_def.cosmeticRadius = size;
	m_def.physicsRadius = -1.f;
	m_def.forwardAcceleration = 0.f;
	m_def.turnSpeed = 0.f;
	m_def.maxHealth = -1.f;
	//brightness of 2 turn neutral faction color to white color.
	m_def.brightness = 2.f;
	m_def.speedDecayRate = 1.f;
	m_def.fadeInTimeRatio = fadeInTimeRatio;
	if (fadeOutTimeRatio < -1.f * TINY_POSITIVE_NUMBER || fadeOutTimeRatio + fadeInTimeRatio > 1.f) {
		m_def.fadeOutTimeRatio = 1.f - m_def.fadeInTimeRatio;
	}
	else {
		m_def.fadeOutTimeRatio = fadeOutTimeRatio;
	}
	m_def.dieAtEdge = true;
	m_def.uncontrollable = true;
	m_def.lifespan = persistTime;
	Rgba8 colorTransparent = color;
	colorTransparent.a = 0;
	color = color * (1.f - centerWhiteRatio) + Rgba8() * centerWhiteRatio;
	AddVertsForDisk(m_def.vertexes, Vec2(), size, 12 + static_cast<int>(3*size), color, colorTransparent);
	if (spawnAtBottom) {
		m_myRenderingPass = WorldRenderingPass::effectsBottom;
	} else {
		m_myRenderingPass = WorldRenderingPass::effectsTop;
	}
}

