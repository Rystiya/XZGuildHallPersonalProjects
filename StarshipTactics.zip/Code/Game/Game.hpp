#pragma once

#include "Game\Map.hpp"
#include "Game\GameCommon.hpp"
#include <vector>

class LightEffect;
class RandomNumberGenerator;
class Entity;
class Game;


class Button
{
public:
	Button() {}
	Button(AABB2 area, std::string text, float fontSize = 25.f);
	AABB2 m_area = AABB2(0.f, 0.f, 1.f, 1.f);
	std::string m_text = "button";
	Game* m_game = g_theApp->m_game;
	float m_fontSize = 25.f;

	void Update();
	void Render() const;
	bool m_isClicked = false;
	bool m_isHovered = false;
};

class Game
{
	friend class App;
	friend class Map;
	friend class Button;

public: // position, color, etc
	// Construction/Destruction
	Game();
	~Game();											// destructor (do nothing)

	//Primary functions----------------------------------------------------------------------------------------------
	void Startup();
	void UpdateStart(float deltaSeconds);
	void Update(float deltaSeconds);
	void UpdateEnd(float deltaSeconds);
	void Render() const;
	void RenderUI() const;
	void UpdateUI();
	//Other stuff
	void AddVertsForMouseArrowOfDirection(std::vector<Vertex_PCU>& verts, Vec2 start, Vec2 end, Vec2 position, float arrowSizeScale = 1.f) const;
	Vec2 GetMouseOnScreenPosition() const {return m_screen_camera->GetOrthoBound().GetPointAtUV(g_theWindow->GetNormalizedCursorPos()); }
	Vec2 GetMouseOnScreenPositionNorm() const { return g_theWindow->GetNormalizedCursorPos(); }
	//Start up/exit
	void EnterGame();
	void ExitGame();
	//System assist
	void PutTextOnScreen(float cellHeight, std::string const& text, Rgba8 const& tint = Rgba8(), float cellAspect = 1.f, Vec2 const& alignment = Vec2(.5f, .5f)) const;
	void PutTextOnScreen(float cellHeight, std::string const& text, Rgba8 const& tint = Rgba8(), float cellAspect = 1.f, AABB2 const& relativeArea = AABB2(0.f, 0.f, 1.f, 1.f)) const;
	bool HasButtonPressed() const { return m_hasButtonClicked; }
	bool HasButtonHovered() const { return m_hasButtonHovered; }
	std::string GetPlayerIntendBuildUnit() const { return m_playerIntendBuildUnit; }
	void UnitTryAddDescription(std::string description);

protected:
	Camera* m_screen_camera = nullptr; 
	Map* m_map = nullptr;
	MapMode m_desiredMapMode = MapMode::arena;
	int m_desiredMapSettingID = 0;
	bool m_hasButtonClicked = false;
	bool m_hasButtonHovered = false;
	std::string m_unitDescriptionToDisplay = "";
	std::string m_playerIntendBuildUnit = "";

	//Menu stuff
	std::vector<Button> m_mainMenuButtons;
	Button m_pauseButton;
	Button m_resumeButton;
	Button m_backToMenuButton;
	std::vector<Button> m_buildOptionButtons;

	//debug
	int m_debug_numberOfUnitSearchesThisFrame = 0;
	float m_debug_numberOfUnitSearchesEachFrameSmooth = 0.f;

};