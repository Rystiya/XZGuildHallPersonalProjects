#pragma once
#include "Game\Entity.hpp"


//Inherit from class Entity
//-----------------------------------------------------------------------------------------------
class BeamEffect : public Entity
{
public:
	// Construction/Destruction
	~BeamEffect() {}
	BeamEffect(Map* parentMap, float persistTime, float width, Vec2 startPosition, Vec2 endPosition, Rgba8 color = Rgba8(255, 200, 150, 255), bool missed = false, float centerWhiteRatio = 0.5f);



protected:
	Rgba8 m_startingColor;
	Rgba8 m_endingColor;
};