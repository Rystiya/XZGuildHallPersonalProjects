
#include "Game\App.hpp"
#include "Game\GameCommon.hpp"
#include "Game\Game.hpp"
#include "Engine\Core\Clock.hpp"
#include "Engine\Renderer\Renderer.hpp"
#include "Engine\Renderer\BitmapFont.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Core\DevConsole.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\Audio\AudioSystem.hpp"
#include "Engine\Core\StringUtils.hpp"
#include "Engine\Core\DebugRenderSystem.hpp"
#include "Engine\ErrorsAndStrings\ErrorWarningAssert.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"

extern const Rgba8 g_UITextColor = Rgba8(50, 120, 255, 255);
extern const Rgba8 g_UITextActiveColor = Rgba8(255, 165, 0, 255);
extern const Rgba8 g_UITextHighLightColor = Rgba8(100, 255, 255, 255);

//Required by specification, but putting g_theApp here doesn't make sense... 
Renderer* g_theRenderer = nullptr;
InputSystem* g_theInputSystem = nullptr;
AudioSystem* g_theAudioSystem = nullptr;
Window* g_theWindow = nullptr;




SoundEntry::SoundEntry(const XmlElement& xmlElement) {
	name = ParseXmlAttribute(xmlElement, "name", name);
	volume = ParseXmlAttribute(xmlElement, "volume", volume);
	std::string soundFilePath = ParseXmlAttribute(xmlElement, "path", "");
	soundResourceHandle = g_theApp->GetSoundResourceByName(soundFilePath);
}

BuildEntry::BuildEntry(const XmlElement& xmlElement, float parentSizeScale) {
	name = ParseXmlAttribute(xmlElement, "name", name);
	launchPosition = parentSizeScale * ParseXmlAttribute(xmlElement, "launchPosition", launchPosition);
	launchDirection = ParseXmlAttribute(xmlElement, "launchDirection", launchDirection);
	launchSpeed = ParseXmlAttribute(xmlElement, "launchSpeed", launchSpeed);
	buildTimeCostModifier = ParseXmlAttribute(xmlElement, "buildTimeCostModifier", buildTimeCostModifier);
}

MoveEffectEntry::MoveEffectEntry(const XmlElement& xmlElement, float parentSizeScale) {
	spawnPosition = parentSizeScale * ParseXmlAttribute(xmlElement, "spawnPosition", spawnPosition);
	moveEffectSize = parentSizeScale * ParseXmlAttribute(xmlElement, "moveEffectSize", moveEffectSize);
	moveEffectTime = ParseXmlAttribute(xmlElement, "moveEffectTime", moveEffectTime);
	moveEffectEjectVelocity = ParseXmlAttribute(xmlElement, "moveEffectEjectVelocity", moveEffectEjectVelocity);
	moveEffectRandomSpeed = ParseXmlAttribute(xmlElement, "moveEffectRandomSpeed", moveEffectRandomSpeed);
}


WeaponDefinition::WeaponDefinition(const XmlElement& xmlElement) {
	const XmlElement* visualInfoElement = nullptr;
	const XmlElement* soundInfoElement = nullptr;
	const XmlElement* aiInfoElement = nullptr;
	const XmlElement* currentXmlElement = xmlElement.FirstChildElement();
	while (currentXmlElement != nullptr) {
		if (std::string(currentXmlElement->Name()) == "Visuals") {
			visualInfoElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "Sounds") {
			soundInfoElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "AI") {
			aiInfoElement = currentXmlElement;
		}
		currentXmlElement = currentXmlElement->NextSiblingElement();
	}

	float sizeScale = ParseXmlAttribute(xmlElement, "sizeScale", 1.f);
	name = ParseXmlAttribute(xmlElement, "name", name);
	turnRate = ParseXmlAttribute(xmlElement, "turnRate", turnRate);
	refireTime = ParseXmlAttribute(xmlElement, "refireTime", refireTime);
	projectileCount = ParseXmlAttribute(xmlElement, "projectileCount", projectileCount);
	projectileFired = ParseXmlAttribute(xmlElement, "projectileFired", projectileFired);
	projectileCone = ParseXmlAttribute(xmlElement, "projectileCone", projectileCone);
	projectileSpeed = ParseXmlAttribute(xmlElement, "projectileSpeed", projectileSpeed);
	rayCount = ParseXmlAttribute(xmlElement, "rayCount", rayCount);
	rayDamage = ParseXmlAttribute(xmlElement, "rayDamage", rayDamage);
	rayDistance = ParseXmlAttribute(xmlElement, "rayDistance", rayDistance);
	rayColor = ParseXmlAttribute(xmlElement, "rayColor", rayColor);
	rayCone = ParseXmlAttribute(xmlElement, "rayCone", rayCone);
	rayWidth = ParseXmlAttribute(xmlElement, "rayWidth", rayWidth);
	energyMax = ParseXmlAttribute(xmlElement, "energyMax", energyMax);
	energyRegen = ParseXmlAttribute(xmlElement, "energyRegen", energyRegen);
	energyUse = ParseXmlAttribute(xmlElement, "energyUse", energyUse);
	lockedWhenEnergyRechargeFromEmpty = ParseXmlAttribute(xmlElement, "lockedWhenEnergyRechargeFromEmpty", lockedWhenEnergyRechargeFromEmpty);

	if (soundInfoElement != nullptr) {
		const XmlElement* currentSoundEntryElement = soundInfoElement->FirstChildElement();
		while (currentSoundEntryElement != nullptr) {
			SoundEntry* currentSoundEntry = new SoundEntry(*currentSoundEntryElement);
			sounds.push_back(*currentSoundEntry);
			currentSoundEntryElement = currentSoundEntryElement->NextSiblingElement();
		}
	}
	if (aiInfoElement != nullptr) {
		fireDistance = ParseXmlAttribute(*aiInfoElement, "fireDistance", fireDistance);
		fireAngleTolerance = ParseXmlAttribute(*aiInfoElement, "fireAngleTolerance", fireAngleTolerance);
		onlyTargetPositiveCostTargets = ParseXmlAttribute(*aiInfoElement, "onlyTargetPositiveCostTargets", onlyTargetPositiveCostTargets);
	}
	if (visualInfoElement != nullptr) {
		muzzleExplosionSize = ParseXmlAttribute(*visualInfoElement, "muzzleExplosionSize", muzzleExplosionSize);
		muzzleExplosionTime = ParseXmlAttribute(*visualInfoElement, "muzzleExplosionTime", muzzleExplosionTime);
		rayExplosionSize = ParseXmlAttribute(*visualInfoElement, "rayExplosionSize", rayExplosionSize);
		rayExplosionTime = ParseXmlAttribute(*visualInfoElement, "rayExplosionTime", rayExplosionTime);
		brightness = ParseXmlAttribute(*visualInfoElement, "brightness", brightness);
		rayDuration = ParseXmlAttribute(*visualInfoElement, "rayDuration", rayDuration);
		rayParticles = ParseXmlAttribute(*visualInfoElement, "rayParticles", rayParticles);
		rayParticleSize = ParseXmlAttribute(*visualInfoElement, "rayParticleSize", rayParticleSize);
		rayParticleLifeTime = ParseXmlAttribute(*visualInfoElement, "rayParticleLifeTime", rayParticleLifeTime);
		Vec2 muzzlePosition1 = ParseXmlAttribute(*visualInfoElement, "muzzlePosition1", Vec2());
		muzzles.emplace_back(sizeScale * muzzlePosition1);
		for (int muzzleIndex = 2; muzzleIndex <= 10; muzzleIndex++) {
			std::string currentMuzzleName = Stringf("muzzlePosition%d", muzzleIndex);
			Vec2 newMuzzlePosition = ParseXmlAttribute(*visualInfoElement, currentMuzzleName.c_str(), Vec2());
			if (newMuzzlePosition != Vec2()) {
				muzzles.emplace_back(sizeScale * newMuzzlePosition);
			}
		}
		const XmlElement* currentVisualElement = visualInfoElement->FirstChildElement();
		while (currentVisualElement != nullptr) {
			if (std::string(currentVisualElement->Name()) == "Vertex") {
				EntityDefinition::ReadVertexFromXmlElement(vertexes, *currentVisualElement, sizeScale);
			}
			if (std::string(currentVisualElement->Name()) == "Quad") {
				EntityDefinition::ReadVertexQuadFromXmlElement(vertexes, *currentVisualElement, sizeScale);
			}
			currentVisualElement = currentVisualElement->NextSiblingElement();
		}
	}

}

TurretDefinition::TurretDefinition(const XmlElement& xmlElement, float parentSizeScale) {
	direction = ParseXmlAttribute(xmlElement, "direction", direction);
	limitingAngle = ParseXmlAttribute(xmlElement, "limitingAngle", limitingAngle);
	mountPosition = parentSizeScale * ParseXmlAttribute(xmlElement, "mountPosition", mountPosition);
	useParentAttackTarget = ParseXmlAttribute(xmlElement, "useParentAttackTarget", useParentAttackTarget);
	canSearchTarget = ParseXmlAttribute(xmlElement, "canSearchTarget", canSearchTarget);
	installedAtBottom = ParseXmlAttribute(xmlElement, "installedAtBottom", installedAtBottom);

	std::string weaponName = ParseXmlAttribute(xmlElement, "weaponMounted", weaponName);

	std::vector<WeaponDefinition> const& weaponDefs = g_theApp->GetWeaponTypes();
	bool weaponFound = false;
	for (int index = 0; index < weaponDefs.size(); index++) {
		if (weaponDefs[index].name == weaponName) {
			weaponMounted = weaponDefs[index];
			weaponFound = true;
		}
	}
	if (!weaponFound) {
		ERROR_AND_DIE("Failed to find weapon specified by turret definition!");
	}
}

EntityDefinition::EntityDefinition(const XmlElement& xmlElement) {
	const XmlElement* physicsInfoElement = nullptr;
	const XmlElement* visualInfoElement = nullptr;
	const XmlElement* aiInfoElement = nullptr;
	const XmlElement* soundInfoElement = nullptr;
	const XmlElement* inventoryElement = nullptr;
	const XmlElement* hangerElement = nullptr;
	const XmlElement* currentXmlElement = xmlElement.FirstChildElement();
	while (currentXmlElement != nullptr) {
		if (std::string(currentXmlElement->Name()) == "Physics") {
			physicsInfoElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "Visuals") {
			visualInfoElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "AI") {
			aiInfoElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "Sounds") {
			soundInfoElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "Inventory") {
			inventoryElement = currentXmlElement;
		}
		if (std::string(currentXmlElement->Name()) == "Hanger") {
			hangerElement = currentXmlElement;
		}
		currentXmlElement = currentXmlElement->NextSiblingElement();
	}

	float sizeScale = ParseXmlAttribute(xmlElement, "sizeScale", 1.f);
	name = ParseXmlAttribute(xmlElement, "name", name);
	description = ParseXmlAttribute(xmlElement, "description", description);
	//Note that description.size() - 1 will underflow
	for (int index = 0; index + 1 < description.size(); index++) {
		//The liberary file automatically replace \n with \\n.... We need to undo that
		if (description[index] == '\\' && description[index + 1] == 'n') {
			description[index] = ' ';
			description[index+1] = '\n';
		}
	}
	description = "[" + name + "]\n" + description;
	armor = ParseXmlAttribute(xmlElement, "armor", armor);
	maxHealth = ParseXmlAttribute(xmlElement, "maxHealth", maxHealth);
	isProjectile = ParseXmlAttribute(xmlElement, "isProjectile", isProjectile);
	isBaseDefense = ParseXmlAttribute(xmlElement, "isBaseDefense", isBaseDefense);
	impactDamage = ParseXmlAttribute(xmlElement, "impactDamage", impactDamage);
	buildPower = ParseXmlAttribute(xmlElement, "buildPower", buildPower);
	deathExplosionAreaDamage = ParseXmlAttribute(xmlElement, "deathExplosionAreaDamage", deathExplosionAreaDamage);
	deathExplosionAreaRadius = ParseXmlAttribute(xmlElement, "deathExplosionAreaRadius", deathExplosionAreaRadius);
	price = ParseXmlAttribute(xmlElement, "price", price);
	creditGeneration = ParseXmlAttribute(xmlElement, "creditGeneration", creditGeneration);
	if (isProjectile) {
		mass = fmaxf(fabsf(impactDamage + deathExplosionAreaDamage) - 6.f, 1.f) * 0.05f;
	} else {
		mass = fmaxf(fabsf(maxHealth * (150.f + armor) / 300.f), TINY_POSITIVE_NUMBER);
	}
	if (isBaseDefense) {
		mass *= 4.f;
	}
	healthRegen = ParseXmlAttribute(xmlElement, "healthRegen", healthRegen);
	lifespan = ParseXmlAttribute(xmlElement, "lifespan", lifespan);

	if (physicsInfoElement != nullptr) {
		reemergeAtEdge = sizeScale * ParseXmlAttribute(*physicsInfoElement, "reemergeAtEdge", reemergeAtEdge);
		dieAtEdge = sizeScale * ParseXmlAttribute(*physicsInfoElement, "dieAtEdge", dieAtEdge);
		passiveCollisionCheck = ParseXmlAttribute(*physicsInfoElement, "passiveCollisionCheck", (isProjectile && maxHealth < 0.f));
		physicsRadius = sizeScale * ParseXmlAttribute(*physicsInfoElement, "physicsRadius", physicsRadius);
		forwardAcceleration = ParseXmlAttribute(*physicsInfoElement, "forwardAcceleration", forwardAcceleration);
		backwardAccelerationRatio = ParseXmlAttribute(*physicsInfoElement, "backwardAccelerationRatio", backwardAccelerationRatio);
		turnSpeed = ParseXmlAttribute(*physicsInfoElement, "turnSpeed", turnSpeed);
		speedDecayRate = ParseXmlAttribute(*physicsInfoElement, "speedDecayRate", speedDecayRate);
		followMaxDistance = ParseXmlAttribute(*physicsInfoElement, "followMaxDistance", physicsRadius * 1.1f + 25.f);
	}
	if (aiInfoElement != nullptr) {
		uncontrollable = ParseXmlAttribute(*aiInfoElement, "uncontrollable", uncontrollable);
		proximityFuse = ParseXmlAttribute(*aiInfoElement, "proximityFuse", proximityFuse);
		turnToFire = ParseXmlAttribute(*aiInfoElement, "turnToFire", turnToFire);
		onlyTargetPositiveCostTargets = ParseXmlAttribute(*aiInfoElement, "onlyTargetPositiveCostTargets", onlyTargetPositiveCostTargets);
		engageMaxDistance = ParseXmlAttribute(*aiInfoElement, "engageMaxDistance", engageMaxDistance);
		engageMinDistance = ParseXmlAttribute(*aiInfoElement, "engageMinDistance", engageMinDistance);
		attckMoveSearchExtraRadius = ParseXmlAttribute(*aiInfoElement, "attckMoveSearchExtraRadius", attckMoveSearchExtraRadius);
		isSelectable = ParseXmlAttribute(*aiInfoElement, "isSelectable", !isProjectile && !uncontrollable);
	}
	if (soundInfoElement != nullptr) {
		const XmlElement* currentSoundEntryElement = soundInfoElement->FirstChildElement();
		while (currentSoundEntryElement != nullptr) {
			SoundEntry* currentSoundEntry = new SoundEntry(*currentSoundEntryElement);
			sounds.push_back(*currentSoundEntry);
			currentSoundEntryElement = currentSoundEntryElement->NextSiblingElement();
		}
	}
	if (hangerElement != nullptr) {
		const XmlElement* currentBuildOptionElement = hangerElement->FirstChildElement();
		while (currentBuildOptionElement != nullptr) {
			BuildEntry* currentBuildEntry = new BuildEntry(*currentBuildOptionElement, sizeScale);
			buildOptions.push_back(*currentBuildEntry);
			currentBuildOptionElement = currentBuildOptionElement->NextSiblingElement();
		}
	}
	if (visualInfoElement != nullptr) {
		cosmeticRadius = sizeScale * ParseXmlAttribute(*visualInfoElement, "cosmeticRadius", cosmeticRadius);
		brightness = ParseXmlAttribute(*visualInfoElement, "brightness", brightness);
		numDebrisOnDeath = ParseXmlAttribute(*visualInfoElement, "numDebrisOnDeath", numDebrisOnDeath);
		debrisSizeModifier = sizeScale * ParseXmlAttribute(*visualInfoElement, "debrisSizeModifier", debrisSizeModifier);
		debrisLifeTime = sizeScale * ParseXmlAttribute(*visualInfoElement, "debrisLifeTime", debrisLifeTime);
		explosionSize = ParseXmlAttribute(*visualInfoElement, "explosionSize", explosionSize);
		explosionTime = ParseXmlAttribute(*visualInfoElement, "explosionTime", explosionTime);
		fadeInTimeRatio = ParseXmlAttribute(*visualInfoElement, "fadeInTimeRatio", fadeInTimeRatio);
		fadeOutTimeRatio = ParseXmlAttribute(*visualInfoElement, "fadeOutTimeRatio", fadeOutTimeRatio);
		if (isProjectile) {
			explosionFadeInTimeRatio = 0.f;
		}
		explosionFadeInTimeRatio = ParseXmlAttribute(*visualInfoElement, "explosionFadeInTimeRatio", explosionFadeInTimeRatio);
		moveEffectRate = ParseXmlAttribute(*visualInfoElement, "moveEffectRate", moveEffectRate);
		const XmlElement* currentVisualElement = visualInfoElement->FirstChildElement();
		while (currentVisualElement != nullptr) {
			if (std::string(currentVisualElement->Name()) == "Vertex") {
				ReadVertexFromXmlElement(vertexes, *currentVisualElement, sizeScale);
			}
			if (std::string(currentVisualElement->Name()) == "Quad") {
				ReadVertexQuadFromXmlElement(vertexes, *currentVisualElement, sizeScale);
			}
			if (std::string(currentVisualElement->Name()) == "Light") {
				ReadVertexLightFromXmlElement(vertexes, *currentVisualElement, sizeScale);
			}
			if (std::string(currentVisualElement->Name()) == "MoveEffect") {
				MoveEffectEntry* currentMoveEffectDefinition = new MoveEffectEntry(*currentVisualElement, sizeScale);
				moveEffects.push_back(*currentMoveEffectDefinition);
			}
			currentVisualElement = currentVisualElement->NextSiblingElement();
		}
	}
	if (inventoryElement != nullptr) {
		const XmlElement* currentTurretElement = inventoryElement->FirstChildElement();
		while (currentTurretElement != nullptr) {
			TurretDefinition* currentTurretDefinition = new TurretDefinition(*currentTurretElement, sizeScale);
			turrets.push_back(*currentTurretDefinition);
			currentTurretElement = currentTurretElement->NextSiblingElement();
		}
	}
	collideWithAllies = !isProjectile || isSelectable || impactDamage + deathExplosionAreaDamage < -1.f * TINY_POSITIVE_NUMBER;
	isBuilder = (buildOptions.size() > 0);

}

void EntityDefinition::ReadVertexFromXmlElement(std::vector<Vertex_PCU>& verts, const XmlElement& xmlElement, float sizeScale) {
	float brightnessMultiplier = ParseXmlAttribute(xmlElement, "brightnessMultiplier", 1.f);
	float alphaMultiplier = ParseXmlAttribute(xmlElement, "alphaMultiplier", 1.f);
	Rgba8 vertexColor = Rgba8(155, 155, 155, 255);
	vertexColor = vertexColor * brightnessMultiplier;
	vertexColor.a = uint8_t(GetClamped(alphaMultiplier * 255, 0.f, 255.f));
	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(ParseXmlAttribute(xmlElement, "position", Vec2())), vertexColor));
}


void EntityDefinition::ReadVertexQuadFromXmlElement(std::vector<Vertex_PCU>& verts, const XmlElement& xmlElement, float sizeScale) {
	float brightnessMultiplier = ParseXmlAttribute(xmlElement, "brightnessMultiplier", 1.f);
	float alphaMultiplier = ParseXmlAttribute(xmlElement, "alphaMultiplier", 1.f);
	Rgba8 vertexColor = Rgba8(155, 155, 155, 255);
	vertexColor = vertexColor * brightnessMultiplier;
	vertexColor.a = static_cast<uint8_t>(GetClamped(alphaMultiplier * 255, 0.f, 255.f));
	Vec2 position1 = ParseXmlAttribute(xmlElement, "position1", Vec2());
	Vec2 position2 = ParseXmlAttribute(xmlElement, "position2", Vec2());
	Vec2 position3 = ParseXmlAttribute(xmlElement, "position3", Vec2(position1.x, position2.y));
	Vec2 position4 = ParseXmlAttribute(xmlElement, "position4", Vec2(position2.x, position1.y));

	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(position1), vertexColor));
	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(position2), vertexColor));
	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(position3), vertexColor));
	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(position1), vertexColor));
	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(position2), vertexColor));
	verts.emplace_back(Vertex_PCU(sizeScale * Vec3(position4), vertexColor));
}

void EntityDefinition::ReadVertexLightFromXmlElement(std::vector<Vertex_PCU>& verts, const XmlElement& xmlElement, float sizeScale) {
	float radius = ParseXmlAttribute(xmlElement, "radius", 3.f) * sizeScale;
	float alpha = ParseXmlAttribute(xmlElement, "alpha", 0.6f);
	Vec2 position = ParseXmlAttribute(xmlElement, "position", Vec2()) * sizeScale;
	Rgba8 vertexColor = Rgba8(255,255,255, static_cast<uint8_t>(255.f * alpha));
	Rgba8 colorTransparent = vertexColor;
	colorTransparent.a = 0;
	AddVertsForDisk(verts, position, radius, 12 + static_cast<int>(3 * radius), vertexColor, colorTransparent);
}

App::App() {
}

App::~App() {
	delete m_game;
	delete g_theRenderer;
	delete g_theInputSystem;
	delete g_theAudioSystem;
	delete g_theWindow;
	delete g_theEventSystem;
	delete g_theDevConsole;
	delete m_rnd;
}


////////////////////////////////////////The App will doing this
// One "frame" of the game.  Generally: Input, Update, Render.  We call this 60+ times per second.
void App::Run() {
	// Program main loop; keep running frames until it's time to quit
	while (!m_isQuitting)
	{
		RunFrame();
	}
}


void App::RunFrame() {
	BeginFrame();
	Update();
	Render();
	EndFrame();
}


//Primary functions-----------------------------------------------------------------------------------------------

void App::Startup() {
	m_game = new Game();
	m_rnd = new RandomNumberGenerator();

	InputSystemConfig inputConfig;
	g_theInputSystem = new InputSystem(inputConfig);

	WindowConfig windowConfig;
	windowConfig.m_windowTitle = m_Title;
	windowConfig.m_inputSystem = g_theInputSystem;
	#ifdef NDEBUG
		windowConfig.m_isFullScreen = true;
	#endif
	g_theWindow = new Window(windowConfig);

	RendererConfig renderConfig;
	renderConfig.m_window = g_theWindow;
	g_theRenderer = new Renderer(renderConfig);
	
	AudioSystemConfig audioConfig;
	g_theAudioSystem = new AudioSystem(audioConfig);

	g_theEventSystem = new EventSystem(EventSystemConfig());
	m_gamePlayBaseClock = new Clock(Clock::GetSystemClock());
	m_gamePlayBaseClock->SetMaxTimeStep(MAX_FRAME_TIME_STEP);

	DevConsoleConfig consoleConfig = DevConsoleConfig();
	consoleConfig.m_camera = m_game->m_screen_camera;
	consoleConfig.m_renderer = g_theRenderer;
	g_theDevConsole = new DevConsole(consoleConfig);

	//g_theRenderer start before g_theDevConsole, because the latter need the m_device for creating fonts
	g_theWindow->Startup();
	g_theRenderer->Startup();
	g_theDevConsole->Startup();
	g_theInputSystem->Startup();
	g_theAudioSystem->Startup();
	g_theEventSystem->Startup();
	LoadAssets();

	m_game->Startup();
	DebugRenderSystemStartup(DebugRenderConfig{ g_theRenderer, false });

	SubscribeEventCallbackFunction("exit", App::HandleExitEvent);
	m_myTexturedFont = g_theRenderer->CreateOrGetBitmapFont("Data/Images/SquirrelFixedFont");
	g_theInputSystem->SetCursorMode(true, false);
	m_currentTimeScale = GLOBAL_GAME_SPEED_MODIFIER;
}

void App::BeginFrame()
{
	if (m_pauseNextFrame) {
		m_pauseNextFrame = false;
		m_isPaused = true;
	}
	DebugRenderBeginFrame();
	g_theDevConsole->BeginFrame();
	g_theWindow->BeginFrame();
	AdjustGameStateWithInput();
	g_theRenderer->BeginFrame();
	g_theInputSystem->BeginFrame();
	g_theAudioSystem->BeginFrame();
}

void App::Update() {
	float updateAmount = GetUpdateAmount();
	Clock::TickSystemClock();
	m_game->Update(updateAmount);
	//Use raw time on input system, so that double click work properly when game slow down or accelerate
	g_theInputSystem->Update(m_gamePlayBaseClock->GetDeltaSeconds());
}

void App::EndFrame() {
	g_theDevConsole->EndFrame();
	g_theAudioSystem->EndFrame();
	g_theRenderer->EndFrame();
	g_theInputSystem->EndFrame();
	g_theWindow->EndFrame();
	DebugRenderEndFrame();
}

// Some simple OpenGL example drawing code.
void App::Render() const {
	g_theRenderer->ClearScreen();
	m_game->Render();
	g_theDevConsole->Render();
}

//Maybe write a save file or something?
void App::Shutdown() {
	g_theDevConsole->Shutdown();
	g_theInputSystem->Shutdown();
	g_theAudioSystem->Shutdown();
	g_theWindow->Shutdown();
	g_theRenderer->Shutdown();
	g_theEventSystem->Shutdown();

	UnSubscribeEventCallbackFunction("exit", App::HandleExitEvent);
}

float App::GetUpdateAmount() {
	//static variable timePrevious is kept each time this is run.
	float deltaTime = m_gamePlayBaseClock->GetDeltaSeconds();
	m_averageSecondPerFrame = m_averageSecondPerFrame * 0.9f + m_gamePlayBaseClock->GetBaseDeltaSeconds() * 0.1f;
	deltaTime *= m_currentTimeScale;
	deltaTime = fminf(deltaTime, MAX_FRAME_TIME_STEP);
	if (m_isPaused) {
		return 0.f;
	}
	return deltaTime;
}


//UI functions-----------------------------------------------------------------------------------------------
bool App::IsKeyDown(unsigned char charInInt) const {
	return g_theInputSystem->IsKeyDown(charInInt);
}
bool App::IsKeyUp(unsigned char charInInt) const {
	return !IsKeyDown(charInInt);
}
bool App::WasKeyJustPressed(unsigned char charInInt) const {
	return g_theInputSystem->WasKeyJustPressed(charInInt);
}
bool App::WasKeyJustUp(unsigned char charInInt) const {
	return g_theInputSystem->WasKeyJustReleased(charInInt);
}


void App::AdjustGameStateWithInput() {
	//Game control (keyboard)-------------------------------------------------------------------------------
	if (WasKeyJustPressed(KEYCODE_PLUS)) {
		m_currentTimeScalePow = GetClamped(m_currentTimeScalePow + 1, MIN_TIME_SCALE_POW, MAX_TIME_SCALE_POW);
	}
	if (WasKeyJustPressed(KEYCODE_MINUS)) {
		m_currentTimeScalePow = GetClamped(m_currentTimeScalePow - 1, MIN_TIME_SCALE_POW, MAX_TIME_SCALE_POW);
	}
	m_currentTimeScale = GLOBAL_GAME_SPEED_MODIFIER * PowerInt(TIME_SCALE_POW_BASE, m_currentTimeScalePow);
	if (WasKeyJustPressed(KEYCODE_ESC) && m_currentGameState != GameState::inMenu) {
		m_isPaused = !m_isPaused;
		g_theAudioSystem->StartSound(m_intefaceSound, false, 0.25f, 0.0f, 1.0f);

	}
	if (WasKeyJustUp('P') && m_currentGameState != GameState::inMenu) {
		m_isPaused = false;
		m_pauseNextFrame = true;
		g_theAudioSystem->StartSound(m_intefaceSound, false, 0.25f, 0.0f, 1.0f);

	}
}

//Helper functions-----------------------------------------------------------------------------------------------

bool App::HandleExitEvent(EventArgs& eventData) {
	(void)eventData;
	g_theApp->m_isQuitting = true;
	return true;
}


SoundID App::GetSoundResourceByName(std::string soundFilePath) {
	return g_theAudioSystem->CreateOrGetSound(soundFilePath);
}

void App::PlayIntefaceSound() const { 
	g_theAudioSystem->StartSound(m_intefaceSound, false, 0.25f, 0.0f, 1.0f); 
}
void App::PlayStartSound() const { 
	g_theAudioSystem->StartSound(m_enterGameSound, false, 0.2f, 0.0f, 1.0f); 
}
void App::PlayExitSound() const { 
	g_theAudioSystem->StartSound(m_exitGameSound, false, 0.2f, 0.0f, 1.0f); 
}

void App::PlayUnitReadySound() const {
	g_theAudioSystem->StartSound(m_unitReadySound, false, 0.1f, 0.0f, 1.0f);
}
void App::PlayErrorSound() const {
	g_theAudioSystem->StartSound(m_errorSound, false, 0.15f, 0.0f, 1.0f);
}

EntityDefinition* App::GetEntityTypeByName(std::string entityType) {
	for (int entityDefIndex = 0; entityDefIndex < m_entityTypes.size(); entityDefIndex++) {
		if (m_entityTypes[entityDefIndex].name == entityType) {
			return &m_entityTypes[entityDefIndex];
		}
	}
	return nullptr;
}

WeaponDefinition* App::GetWeaponTypeByName(std::string weaponType) {
	for (int weaponDefIndex = 0; weaponDefIndex < m_weaponTypes.size(); weaponDefIndex++) {
		if (m_weaponTypes[weaponDefIndex].name == weaponType) {
			return &m_weaponTypes[weaponDefIndex];
		}
	}
	return nullptr;
}

void App::LoadAssets() {
	//Load weapon definition
	XmlDocument weaponXmlDoc;
	weaponXmlDoc.LoadFile("Data/Definitions/WeaponDefinitions.xml");
	XmlElement* allWeaponsElement = weaponXmlDoc.RootElement();
	XmlElement* currentWeaponElement = allWeaponsElement->FirstChildElement();
	while (currentWeaponElement != nullptr) {
		WeaponDefinition* currentWeaponDef = new WeaponDefinition(*currentWeaponElement);
		m_weaponTypes.push_back(*currentWeaponDef);
		currentWeaponElement = currentWeaponElement->NextSiblingElement();
	}
	//Load entity definition
	XmlDocument entityXmlDoc;
	entityXmlDoc.LoadFile("Data/Definitions/EntityDefinitions.xml");
	XmlElement* allEntitiesElement = entityXmlDoc.RootElement();
	XmlElement* currentEntityElement = allEntitiesElement->FirstChildElement();
	while (currentEntityElement != nullptr) {
		EntityDefinition* currentEntityDef = new EntityDefinition(*currentEntityElement);
		m_entityTypes.push_back(*currentEntityDef);
		currentEntityElement = currentEntityElement->NextSiblingElement();
	}
	m_intefaceSound = g_theAudioSystem->CreateOrGetSound("Data/Audio/Sounds/notification.ogg");
	m_enterGameSound = g_theAudioSystem->CreateOrGetSound("Data/Audio/Sounds/matchBegin.ogg");
	m_exitGameSound = g_theAudioSystem->CreateOrGetSound("Data/Audio/Sounds/matchEnd.ogg");
	m_unitReadySound = g_theAudioSystem->CreateOrGetSound("Data/Audio/Sounds/unitReady.ogg");
	m_errorSound = g_theAudioSystem->CreateOrGetSound("Data/Audio/Sounds/error.ogg");
	m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/108 - Peace And Prosperity.ogg"));
	m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/114 - Birth of the Coalition.ogg"));
	m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/117 - The Emerging Empire.ogg"));
	m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/204 - Defending the Colony.ogg"));
	m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/205 - TEC Loyalists - Watching the Borders.ogg"));
	//m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/209 - TEC Rebels - To the Victor.ogg"));
	//m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/213 - Advent Loyalists - In the Name of the Unity.ogg"));
	//m_backgroundMusics.emplace_back(g_theAudioSystem->CreateOrGetSound("Data/Audio/Musics/222 - Vasari Rebels - History in the Making.ogg"));
 }


void App::RandomlyResetBackgroundMusic() {
	g_theAudioSystem->StopSound(m_currentBackgroundMusic);
	int nextSoundToPlay = m_rnd->RollRandomIntInRange(0, static_cast<int>(g_theApp->GetBackgroundMusics().size() - 1));
	m_currentBackgroundMusic = g_theAudioSystem->StartSound(GetBackgroundMusics()[nextSoundToPlay], true, 0.125f, 0.0f, 1.0f);
}