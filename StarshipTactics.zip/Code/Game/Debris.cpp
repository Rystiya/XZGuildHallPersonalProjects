
#include "Game\Debris.hpp"
#include "Game\Map.hpp"
#include "Game\Game.hpp"
#include "Engine\Math\MathUtils.hpp"
#include "Engine\Renderer\VertexUtils.hpp"
#include "Engine\Math\RandomNumberGenerator.hpp"

Debris::Debris(Map* parentMap, float persistTime, float size, float parentSize, Vec2 parentPosition, Vec2 parentVelocity, Rgba8 color) : Entity(parentMap, EntityDefinition(), Faction::neutral, parentPosition, 0.f, parentVelocity, true) {
	m_def.name = "debris";
	m_def.physicsRadius = -1.f;
	m_def.forwardAcceleration = 0.f;
	m_def.turnSpeed = 0.f;
	m_def.maxHealth = -1.f;
	//Use brightness to make debris darker or brighter than orginal
	m_def.brightness = 1.2f;
	//m_def.speedDecayRate = 0.5f;
	m_def.fadeOutTimeRatio = 0.9f;
	m_def.dieAtEdge = true;
	m_def.uncontrollable = true;
	color.a = (char)(color.a * 0.75f);

	RandomNumberGenerator* gameRnd = g_theApp->m_rnd;
	float randomSizeDeterminer = 0.2f + 0.8f * gameRnd->RollRandomFloatZeroToOne();
	randomSizeDeterminer = randomSizeDeterminer * randomSizeDeterminer;

	Vec2 debrisPositionSpread = Vec2(g_theApp->m_rnd->RollRandomFloatInRange(-0.75f * parentSize, 0.75f * parentSize), g_theApp->m_rnd->RollRandomFloatInRange(-0.75f * parentSize, 0.75f * parentSize));
	m_position += debrisPositionSpread;
	Vec2 spreadVelocityDirection = debrisPositionSpread.GetNormalized();
	spreadVelocityDirection.RotateDegrees(gameRnd->RollRandomFloatInRange(-90.f, 90.f));
	float randomSpeedDeterminer = gameRnd->RollRandomFloatInRange(0.f, 1.f);
	m_velocity += spreadVelocityDirection * randomSpeedDeterminer * DEBRIS_SCATTER_VELOCITY_FACTOR / (randomSizeDeterminer * sqrtf(randomSizeDeterminer));
	m_rotationSpeed = DEBRIS_SPIN_SPEED_FACTOR * gameRnd->RollRandomFloatInRange(0.f, 1.f) * randomSpeedDeterminer / PowerInt(randomSizeDeterminer, 4);

	m_def.cosmeticRadius = size * randomSizeDeterminer;
	m_def.lifespan = persistTime * (0.4f + 1.f * randomSizeDeterminer);
	float mimimumVerticalEdgeLength = m_def.cosmeticRadius / 5.f;

	int cornorCount = gameRnd->RollRandomIntInRange(5, 8);
	std::vector<float> randomizedRadiuses = {};
	for (int indexCorner = 0; indexCorner < cornorCount + 2; indexCorner++) {
		randomizedRadiuses.emplace_back(gameRnd->RollRandomFloatInRange(mimimumVerticalEdgeLength, m_def.cosmeticRadius));
	}
	for (int indexTriangle = 0; indexTriangle < cornorCount; indexTriangle++) {
		float angle1 = static_cast<float>(indexTriangle) * 360.f / static_cast<float>(cornorCount);
		float angle2 = static_cast<float>(indexTriangle + 1) * 360.f / static_cast<float>(cornorCount);
		m_def.vertexes.emplace_back(Vertex_PCU(Vec3(CosDegrees(angle1) * randomizedRadiuses[indexTriangle], SinDegrees(angle1) * randomizedRadiuses[indexTriangle], 0.f), color));
		m_def.vertexes.emplace_back(Vertex_PCU(Vec3(CosDegrees(angle2) * randomizedRadiuses[indexTriangle + 1], SinDegrees(angle2) * randomizedRadiuses[indexTriangle + 1], 0.f), color));
		m_def.vertexes.emplace_back(Vertex_PCU(Vec3(), color));
	}
	m_myRenderingPass = WorldRenderingPass::effectsTop;
}



void Debris::UpdateCustomBehavior(float deltaSeconds) {
	//Rotate
	m_orientationDegrees += deltaSeconds * m_rotationSpeed;
}